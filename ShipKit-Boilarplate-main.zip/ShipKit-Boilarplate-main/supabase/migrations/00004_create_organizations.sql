-- Organizations & Memberships
-- Enables multi-tenant workspaces where each user can belong to multiple orgs.

-- 1. Create organizations table
CREATE TABLE public.organizations (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name        text NOT NULL,
  slug        text UNIQUE NOT NULL,
  logo_url    text,
  owner_id    uuid REFERENCES public.users(id) ON DELETE SET NULL,
  plan        text DEFAULT 'free' CHECK (plan IN ('free', 'basic', 'pro')),
  created_at  timestamptz DEFAULT now() NOT NULL,
  updated_at  timestamptz DEFAULT now() NOT NULL
);

-- 2. Create memberships table (join table: user ↔ org)
CREATE TABLE public.memberships (
  id      uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  org_id  uuid REFERENCES public.organizations(id) ON DELETE CASCADE NOT NULL,
  role    text DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE (user_id, org_id)
);

-- 3. Enable RLS
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.memberships ENABLE ROW LEVEL SECURITY;

-- 4. RLS policies — Organizations
-- Users can read orgs they belong to
CREATE POLICY "org_members_can_read" ON public.organizations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.memberships
      WHERE memberships.org_id = organizations.id
        AND memberships.user_id = auth.uid()
    )
  );

-- Only owners/admins can update
CREATE POLICY "org_admins_can_update" ON public.organizations
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.memberships
      WHERE memberships.org_id = organizations.id
        AND memberships.user_id = auth.uid()
        AND memberships.role IN ('owner', 'admin')
    )
  );

-- Any authenticated user can create an org
CREATE POLICY "authenticated_can_create_org" ON public.organizations
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Only owner can delete
CREATE POLICY "org_owner_can_delete" ON public.organizations
  FOR DELETE USING (owner_id = auth.uid());

-- 5. RLS policies — Memberships
-- Users can see memberships of orgs they belong to
CREATE POLICY "members_can_read_memberships" ON public.memberships
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.memberships AS m
      WHERE m.org_id = memberships.org_id
        AND m.user_id = auth.uid()
    )
  );

-- Owners/admins can add members
CREATE POLICY "admins_can_add_members" ON public.memberships
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.memberships AS m
      WHERE m.org_id = memberships.org_id
        AND m.user_id = auth.uid()
        AND m.role IN ('owner', 'admin')
    )
    OR NOT EXISTS (
      SELECT 1 FROM public.memberships AS m
      WHERE m.org_id = memberships.org_id
    )
  );

-- Owners/admins can remove members, but the owner membership can never be deleted
CREATE POLICY "admins_can_remove_members" ON public.memberships
  FOR DELETE USING (
    memberships.role <> 'owner'
    AND (
      EXISTS (
        SELECT 1 FROM public.memberships AS m
        WHERE m.org_id = memberships.org_id
          AND m.user_id = auth.uid()
          AND m.role IN ('owner', 'admin')
      )
      OR memberships.user_id = auth.uid()
    )
  );

-- Owners can update roles
CREATE POLICY "owners_can_update_roles" ON public.memberships
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.memberships AS m
      WHERE m.org_id = memberships.org_id
        AND m.user_id = auth.uid()
        AND m.role = 'owner'
    )
  );

-- 6. Indexes
CREATE INDEX idx_memberships_user_id ON public.memberships(user_id);
CREATE INDEX idx_memberships_org_id ON public.memberships(org_id);
CREATE INDEX idx_organizations_slug ON public.organizations(slug);
CREATE INDEX idx_organizations_owner_id ON public.organizations(owner_id);

-- 7. Triggers
CREATE TRIGGER set_org_updated_at
  BEFORE UPDATE ON public.organizations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
