-- 1. Create webhook events table (idempotency)
CREATE TABLE public.webhook_events (
  id              uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id        text UNIQUE NOT NULL,
  event_name      text NOT NULL,
  processed_at    timestamptz DEFAULT now() NOT NULL
);

ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;
-- No user policy needed — only service role accesses this table
CREATE POLICY "service_role_only" ON public.webhook_events FOR ALL USING (false);
CREATE INDEX idx_webhook_events_event_id ON public.webhook_events(event_id);

-- 2. Create subscriptions table
CREATE TABLE public.subscriptions (
  id                    uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id               uuid REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  ls_subscription_id    text UNIQUE,
  ls_customer_id        text,
  plan                  text DEFAULT 'free' CHECK (plan IN ('free', 'basic', 'pro')),
  status                text DEFAULT 'inactive',
  current_period_start  timestamptz,
  current_period_end    timestamptz,
  created_at            timestamptz DEFAULT now() NOT NULL,
  updated_at            timestamptz DEFAULT now() NOT NULL
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users_own_subscription" ON public.subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE INDEX idx_subscriptions_user_id ON public.subscriptions(user_id);
CREATE INDEX idx_subscriptions_ls_id ON public.subscriptions(ls_subscription_id);

CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
