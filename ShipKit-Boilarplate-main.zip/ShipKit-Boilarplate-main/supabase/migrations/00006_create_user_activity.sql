-- User Activity Feed
-- Tracks user actions for the dashboard activity feed.
-- Auto-populated via database triggers — no extra API calls needed.

-- 1. Create user_activity table
CREATE TABLE public.user_activity (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     uuid REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  action      text NOT NULL,
  description text NOT NULL,
  metadata    jsonb DEFAULT '{}',
  created_at  timestamptz DEFAULT now() NOT NULL
);

-- 2. Enable RLS
ALTER TABLE public.user_activity ENABLE ROW LEVEL SECURITY;

-- 3. Policies
-- Users can only read their own activity
CREATE POLICY "users_read_own_activity" ON public.user_activity
  FOR SELECT USING (auth.uid() = user_id);

-- Users can insert their own activity (for manual logging from API)
CREATE POLICY "users_insert_own_activity" ON public.user_activity
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 4. Indexes
CREATE INDEX idx_user_activity_user_id ON public.user_activity(user_id);
CREATE INDEX idx_user_activity_created_at ON public.user_activity(created_at DESC);
CREATE INDEX idx_user_activity_user_created ON public.user_activity(user_id, created_at DESC);

-- ============================================================
-- 5. Auto-logging triggers (SECURITY DEFINER bypasses RLS)
-- ============================================================

-- 5a. Log account creation (welcome activity)
CREATE OR REPLACE FUNCTION log_account_created()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_activity (user_id, action, description)
  VALUES (NEW.id, 'account.created', 'Account created — welcome!');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_account_created
  AFTER INSERT ON public.users
  FOR EACH ROW EXECUTE FUNCTION log_account_created();

-- 5b. Log profile updates and plan changes
CREATE OR REPLACE FUNCTION log_profile_update()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.full_name IS DISTINCT FROM NEW.full_name
     OR OLD.avatar_url IS DISTINCT FROM NEW.avatar_url THEN
    INSERT INTO public.user_activity (user_id, action, description)
    VALUES (NEW.id, 'profile.updated', 'Updated profile information');
  END IF;

  IF OLD.plan IS DISTINCT FROM NEW.plan THEN
    INSERT INTO public.user_activity (user_id, action, description, metadata)
    VALUES (
      NEW.id,
      'plan.changed',
      'Plan changed from ' || COALESCE(OLD.plan, 'free') || ' to ' || NEW.plan,
      jsonb_build_object('old_plan', OLD.plan, 'new_plan', NEW.plan)
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_profile_update
  AFTER UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION log_profile_update();

-- 5c. Log organization creation
CREATE OR REPLACE FUNCTION log_org_created()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.owner_id IS NOT NULL THEN
    INSERT INTO public.user_activity (user_id, action, description, metadata)
    VALUES (
      NEW.owner_id,
      'org.created',
      'Created organization "' || NEW.name || '"',
      jsonb_build_object('org_id', NEW.id, 'org_name', NEW.name)
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_org_created
  AFTER INSERT ON public.organizations
  FOR EACH ROW EXECUTE FUNCTION log_org_created();

-- 5d. Log membership creation (user joined an org)
CREATE OR REPLACE FUNCTION log_membership_created()
RETURNS TRIGGER AS $$
DECLARE
  org_name text;
BEGIN
  SELECT name INTO org_name FROM public.organizations WHERE id = NEW.org_id;

  INSERT INTO public.user_activity (user_id, action, description, metadata)
  VALUES (
    NEW.user_id,
    'org.joined',
    'Joined organization "' || COALESCE(org_name, 'Unknown') || '" as ' || NEW.role,
    jsonb_build_object('org_id', NEW.org_id, 'role', NEW.role)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_membership_created
  AFTER INSERT ON public.memberships
  FOR EACH ROW EXECUTE FUNCTION log_membership_created();
