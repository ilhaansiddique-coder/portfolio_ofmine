-- Add support for Stripe payment processor alongside LemonSqueezy

-- 1. Add payment_processor column to users table
ALTER TABLE public.users
ADD COLUMN IF NOT EXISTS payment_processor text DEFAULT 'lemonsqueezy' CHECK (payment_processor IN ('lemonsqueezy', 'stripe'));

-- 2. Add Stripe-specific columns to subscriptions table
ALTER TABLE public.subscriptions
ADD COLUMN IF NOT EXISTS stripe_subscription_id text UNIQUE,
ADD COLUMN IF NOT EXISTS stripe_customer_id text;

-- 3. Add missing ls_customer_id if it doesn't exist
ALTER TABLE public.subscriptions
ADD COLUMN IF NOT EXISTS ls_customer_id text;

-- 4. Create indexes for Stripe lookups
CREATE INDEX IF NOT EXISTS idx_subscriptions_stripe_id ON public.subscriptions(stripe_subscription_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_stripe_customer_id ON public.subscriptions(stripe_customer_id);

-- 5. Add payment_processor column to subscriptions table for audit trail
ALTER TABLE public.subscriptions
ADD COLUMN IF NOT EXISTS payment_processor text DEFAULT 'lemonsqueezy' CHECK (payment_processor IN ('lemonsqueezy', 'stripe'));

-- 6. Update webpack_events table with processor field for better tracking
ALTER TABLE public.webhook_events
ADD COLUMN IF NOT EXISTS processor text DEFAULT 'lemonsqueezy' CHECK (processor IN ('lemonsqueezy', 'stripe')),
ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES public.users(id) ON DELETE SET NULL;

-- 7. Create indexes for faster webhook lookups
CREATE INDEX IF NOT EXISTS idx_webhook_events_processor ON public.webhook_events(processor);
CREATE INDEX IF NOT EXISTS idx_webhook_events_user_id ON public.webhook_events(user_id);

