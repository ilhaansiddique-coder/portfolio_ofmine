-- 1. Create updated_at trigger function (reusable)
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

-- 2. Create users table
CREATE TABLE public.users (
  id                   uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email                text UNIQUE NOT NULL,
  full_name            text,
  avatar_url           text,
  plan                 text DEFAULT 'free' CHECK (plan IN ('free', 'basic', 'pro')),
  is_paid              boolean DEFAULT false,
  ls_customer_id       text,
  subscription_status  text DEFAULT 'inactive',
  created_at           timestamptz DEFAULT now() NOT NULL,
  updated_at           timestamptz DEFAULT now() NOT NULL
);

-- 3. Enable RLS (MANDATORY)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- 4. Add policies
CREATE POLICY "users_own_profile" ON public.users
  FOR ALL USING (auth.uid() = id);

-- 5. Add indexes
CREATE INDEX idx_users_email ON public.users(email);

-- 6. Add updated_at trigger
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- 7. Auto-create profile on auth signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, full_name, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
