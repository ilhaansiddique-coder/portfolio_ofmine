-- Make DB webhook triggers safe when custom Postgres settings are not configured.
-- Without this, signup can fail with "Database error saving new user" because
-- current_setting('app.settings.*') throws when the setting does not exist.

CREATE OR REPLACE FUNCTION notify_new_user()
RETURNS TRIGGER AS $$
DECLARE
  app_url text := current_setting('app.settings.app_url', true);
  webhook_secret text := current_setting('app.settings.webhook_secret', true);
BEGIN
  IF app_url IS NULL OR webhook_secret IS NULL OR app_url = '' OR webhook_secret = '' THEN
    RETURN NEW;
  END IF;

  PERFORM net.http_post(
    url := app_url || '/api/automations/user-created',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-webhook-secret', webhook_secret
    ),
    body := jsonb_build_object(
      'record', row_to_json(NEW),
      'type', 'INSERT',
      'table', 'users'
    )
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION notify_subscription_change()
RETURNS TRIGGER AS $$
DECLARE
  app_url text := current_setting('app.settings.app_url', true);
  webhook_secret text := current_setting('app.settings.webhook_secret', true);
BEGIN
  IF NEW.subscription_status IS DISTINCT FROM OLD.subscription_status THEN
    IF app_url IS NULL OR webhook_secret IS NULL OR app_url = '' OR webhook_secret = '' THEN
      RETURN NEW;
    END IF;

    PERFORM net.http_post(
      url := app_url || '/api/automations/subscription-changed',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'x-webhook-secret', webhook_secret
      ),
      body := jsonb_build_object(
        'record', row_to_json(NEW),
        'old_record', row_to_json(OLD),
        'type', 'UPDATE',
        'table', 'users'
      )
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
