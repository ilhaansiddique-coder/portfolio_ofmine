-- Enable pg_net extension (required for HTTP calls from Postgres)
CREATE EXTENSION IF NOT EXISTS pg_net;

-- ─────────────────────────────────────
-- Trigger: Notify on new user creation
-- ─────────────────────────────────────
CREATE OR REPLACE FUNCTION notify_new_user()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM net.http_post(
    url := current_setting('app.settings.app_url') || '/api/automations/user-created',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-webhook-secret', current_setting('app.settings.webhook_secret')
    ),
    body := jsonb_build_object(
      'record', row_to_json(NEW),
      'type', 'INSERT',
      'table', 'users'
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_user_created
  AFTER INSERT ON public.users
  FOR EACH ROW EXECUTE FUNCTION notify_new_user();

-- ─────────────────────────────────────
-- Trigger: Notify on subscription status change
-- ─────────────────────────────────────
CREATE OR REPLACE FUNCTION notify_subscription_change()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.subscription_status IS DISTINCT FROM OLD.subscription_status THEN
    PERFORM net.http_post(
      url := current_setting('app.settings.app_url') || '/api/automations/subscription-changed',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'x-webhook-secret', current_setting('app.settings.webhook_secret')
      ),
      body := jsonb_build_object(
        'record', row_to_json(NEW),
        'old_record', row_to_json(OLD),
        'type', 'UPDATE',
        'table', 'users'
      )
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_subscription_changed
  AFTER UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION notify_subscription_change();
