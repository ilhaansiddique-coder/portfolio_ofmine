-- Invoices table
-- Tracks all invoices generated from orders and subscriptions for audit and accounting purposes.

-- 1. Create invoices table
CREATE TABLE public.invoices (
  id                  uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id             uuid REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  subscription_id     uuid REFERENCES public.subscriptions(id) ON DELETE CASCADE,
  ls_invoice_id       text UNIQUE,
  description         text NOT NULL,
  amount              numeric(10, 2) NOT NULL,
  currency            text DEFAULT 'USD',
  status              text DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'viewed', 'paid', 'cancelled')),
  due_date            timestamptz,
  issued_at           timestamptz DEFAULT now() NOT NULL,
  paid_at             timestamptz,
  created_at          timestamptz DEFAULT now() NOT NULL,
  updated_at          timestamptz DEFAULT now() NOT NULL
);

-- 2. Enable RLS
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

-- 3. Policies
-- Users can read their own invoices
CREATE POLICY "users_read_own_invoices" ON public.invoices
  FOR SELECT USING (auth.uid() = user_id);

-- 4. Indexes
CREATE INDEX idx_invoices_user_id ON public.invoices(user_id);
CREATE INDEX idx_invoices_subscription_id ON public.invoices(subscription_id);
CREATE INDEX idx_invoices_status ON public.invoices(status);
CREATE INDEX idx_invoices_issued_at ON public.invoices(issued_at DESC);

-- 5. Add updated_at trigger
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.invoices
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
