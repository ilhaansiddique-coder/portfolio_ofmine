-- Dev/staging seed data — runs on `supabase db reset`
-- NEVER use in production

INSERT INTO public.users (id, email, full_name, plan, is_paid, subscription_status)
VALUES
  ('00000000-0000-0000-0000-000000000001', 'pro@example.com', 'Pro User', 'pro', true, 'active'),
  ('00000000-0000-0000-0000-000000000002', 'free@example.com', 'Free User', 'free', false, 'inactive');
