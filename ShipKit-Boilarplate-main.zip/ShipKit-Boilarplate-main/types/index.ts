export type PlanName = 'free' | 'basic' | 'pro'

export type SubscriptionStatus =
  | 'inactive'
  | 'active'
  | 'cancelled'
  | 'expired'
  | 'past_due'
  | 'paused'

export interface User {
  id: string
  email: string
  full_name: string | null
  avatar_url: string | null
  plan: PlanName
  is_paid: boolean
  ls_customer_id: string | null
  subscription_status: SubscriptionStatus
  created_at: string
  updated_at: string
}

export type OrgRole = 'owner' | 'admin' | 'member'

export interface Organization {
  id: string
  name: string
  slug: string
  logo_url: string | null
  owner_id: string | null
  plan: PlanName
  created_at: string
  updated_at: string
}

export interface Membership {
  id: string
  user_id: string
  org_id: string
  role: OrgRole
  created_at: string
}

export interface MembershipWithUser extends Membership {
  user: Pick<User, 'id' | 'email' | 'full_name' | 'avatar_url'>
}

export type ApiSuccess<T> = { data: T; error: null }
export type ApiError = { data: null; error: string; code?: string }
export type ApiResponse<T> = ApiSuccess<T> | ApiError
