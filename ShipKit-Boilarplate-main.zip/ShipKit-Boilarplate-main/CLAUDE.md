# SaaS Boilerplate — Development Guidelines

## Tech Stack

- **Framework**: Next.js 15+ (App Router), React 19, TypeScript (strict)
- **Database**: Supabase (Postgres + RLS)
- **Styling**: Scoped `<style>` components + Tailwind (layout utilities only)
- **State**: React Query (server), Zustand (client)
- **Forms**: React Hook Form + Zod
- **Payments**: LemonSqueezy (webhook-based)
- **Background Jobs**: BullMQ + Redis
- **Logging**: Pino v9 (structured JSON)
- **Error Tracking**: GlitchTip (Sentry-compatible)
- **Testing**: Vitest (unit/integration), Playwright (E2E)
- **Fonts**: Bricolage_Grotesque (headings), Source_Sans_3 (body)

## Color Palette

| Token | Value | Usage |
|-------|-------|-------|
| brand | `#7c3aed` | Buttons, links, accents |
| brand-dark | `#6d28d9` | Gradient end |
| text-primary | `#1a1625` | Headings |
| text-secondary | `#6b5f80` | Muted labels |
| text-tertiary | `#8b7fa8` | Subtitles |
| text-body | `#4b4466` | Body text |
| bg-page | `#f8f4eb` | Page background |
| bg-card | `#fff` | Cards |

## Key Patterns

### Scoped CSS
- Every page uses a `{Prefix}Styles` component with `<style>{``}</style>`
- 2-letter class prefix per page (e.g., `db-` for dashboard, `st-` for settings)
- Tailwind only for layout utilities (`flex`, `absolute`, `pointer-events-none`)

### Page Header
```
eyebrow (pulsing dot + uppercase label) → title (2rem/900) → subtitle (0.8rem/muted)
```

### Cards
- White bg, `1.5px solid rgba(124,58,237,0.07)`, radius `1.125rem`
- Hover: `translateY(-2px)`, increased shadow, border `rgba(124,58,237,0.15)`
- Fade-up entrance animation with staggered delays

### API Routes
- `validateBody()` for input validation
- `withErrorHandler()` wrapper for error handling
- `ok()`/`err()` response helpers
- All env access via `env.X` from `lib/env.ts`

### Webhooks
- `timingSafeEqual` for HMAC verification
- Idempotent via `webhook_events` table

### Database
- Every migration: create table → enable RLS → policies → indexes → triggers
- Use admin client only in webhooks/server-only routes

## File Structure

```
app/
  (auth)/          — login, signup, reset-password
  (dashboard)/     — dashboard layout with sidebar
    dashboard/     — main dashboard page
    settings/      — user settings
  api/             — API routes
    health/        — health check
    webhooks/      — webhook handlers
  auth/callback/   — OAuth callback
components/
  shared/          — Navbar, Sidebar, Toast, ErrorBoundary, PricingCard
  ui/              — shadcn base components
  providers/       — React Query provider
  auth/            — AuthForm
lib/
  supabase/        — client, server, admin Supabase clients
  queries/         — React Query hooks and types
  env.ts           — Zod env validation
  logger.ts        — Pino structured logging
  plans.ts         — Plan definitions and limits
stores/            — Zustand stores
types/             — TypeScript types
workers/           — BullMQ worker files
supabase/
  migrations/      — SQL migrations
tests/             — Vitest + Playwright tests
```

## Rules for AI Models

1. Always use scoped `<style>` components, never global CSS or inline styles for patterns
2. Prefix all CSS classes with 2-letter page prefix
3. Follow exact color values from the palette above
4. Match the page header pattern: eyebrow → title → subtitle
5. Cards must have subtle border, shadow, hover lift, and fade-up animation
6. Use `env.X` from `lib/env.ts`, never `process.env.X!`
7. API routes must use `withErrorHandler()` + `validateBody()` + `ok()`/`err()`
8. Webhooks use `timingSafeEqual`, never `===`
9. Every migration must enable RLS with policies
10. Toast notifications fixed bottom-right with backdrop blur
