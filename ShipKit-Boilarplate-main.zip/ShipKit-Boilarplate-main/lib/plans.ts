export type PlanName = 'free' | 'basic' | 'pro'

export interface PlanLimits {
  maxProjects: number | 'unlimited'
  maxStorageMb: number
  features: string[]
}

export const PLAN_LIMITS: Record<PlanName, PlanLimits> = {
  free: {
    maxProjects: 1,
    maxStorageMb: 100,
    features: ['Basic features', 'Community support'],
  },
  basic: {
    maxProjects: 5,
    maxStorageMb: 1024,
    features: [
      'Everything in Free',
      'Priority support',
      'Custom branding',
      'API access',
    ],
  },
  pro: {
    maxProjects: 'unlimited',
    maxStorageMb: 10240,
    features: [
      'Everything in Basic',
      'Unlimited projects',
      'Advanced analytics',
      'Dedicated support',
      'Custom integrations',
    ],
  },
}

export function normalizePlan(plan: string | null | undefined): PlanName {
  if (plan === 'basic' || plan === 'pro') return plan
  return 'free'
}

export const PLAN_DISPLAY: Record<PlanName, { name: string; price: string }> = {
  free: { name: 'Free', price: '$0' },
  basic: { name: 'Basic', price: '$19/mo' },
  pro: { name: 'Pro', price: '$49/mo' },
}
