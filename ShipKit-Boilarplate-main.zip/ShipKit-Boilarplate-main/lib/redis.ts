import { Redis } from 'ioredis'
import { env } from './env'
import { logger } from './logger'

const redis = new Redis(env.REDIS_URL, {
  maxRetriesPerRequest: 3,
  retryStrategy(times) {
    if (times > 3) return null
    return Math.min(times * 200, 1000)
  },
  lazyConnect: true,
})

redis.on('error', (err) => {
  logger.error({ err }, 'Redis connection error')
})

export default redis

export async function getCached<T>(
  key: string,
  fetcher: () => Promise<T>,
  ttlSeconds = 300
): Promise<T> {
  try {
    const cached = await redis.get(key)
    if (cached) return JSON.parse(cached) as T
  } catch {}

  const data = await fetcher()

  try {
    await redis.setex(key, ttlSeconds, JSON.stringify(data))
  } catch {}

  return data
}

export async function invalidateCache(pattern: string) {
  const keys = await redis.keys(pattern)
  if (keys.length > 0) await redis.del(...keys)
}

export async function setTemp(
  key: string,
  value: unknown,
  ttlSeconds: number
) {
  await redis.setex(`temp:${key}`, ttlSeconds, JSON.stringify(value))
}

export async function getTemp<T>(key: string): Promise<T | null> {
  const val = await redis.get(`temp:${key}`)
  return val ? JSON.parse(val) : null
}

export async function deleteTemp(key: string) {
  await redis.del(`temp:${key}`)
}
