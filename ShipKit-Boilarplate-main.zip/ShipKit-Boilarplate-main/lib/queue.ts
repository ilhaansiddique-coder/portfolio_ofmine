import { Queue } from 'bullmq'
import { getBullMQConnection } from '@/lib/redis-connection'

const connection = getBullMQConnection()

// ─────────────────────────────────────
// QUEUES
// ─────────────────────────────────────
export const emailQueue = new Queue('email', {
  connection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 1000 },
    removeOnComplete: { age: 86400 },
    removeOnFail: { age: 7 * 86400 },
  },
})

export const notificationQueue = new Queue('notification', {
  connection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 1000 },
  },
})

export const automationQueue = new Queue('automation', {
  connection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
    removeOnComplete: { age: 86400 },
    removeOnFail: { age: 7 * 86400 },
  },
})

export const webhookQueue = new Queue('webhook-processing', {
  connection,
  defaultJobOptions: {
    attempts: 5,
    backoff: { type: 'exponential', delay: 2000 },
  },
})

// ─────────────────────────────────────
// HELPERS
// ─────────────────────────────────────
export async function enqueueEmail(
  to: string,
  subject: string,
  html: string,
  text?: string
) {
  return emailQueue.add('send', { to, subject, html, text })
}

export async function enqueueNotification(
  channel: 'slack' | 'email',
  payload: Record<string, unknown>
) {
  return notificationQueue.add(channel, payload)
}

export async function enqueueDelayedJob(
  name: string,
  data: Record<string, unknown>,
  delayMs: number
) {
  return automationQueue.add(name, data, { delay: delayMs })
}

export async function enqueueWebhookProcessing(
  eventName: string,
  payload: Record<string, unknown>
) {
  return webhookQueue.add(eventName, payload)
}

// ─────────────────────────────────────
// REPEATABLE JOBS (replaces cron/n8n schedules)
// ─────────────────────────────────────
export async function registerRepeatableJobs() {
  // Daily digest — every day at 9am
  await automationQueue.add(
    'daily-digest',
    {},
    { repeat: { pattern: '0 9 * * *' } }
  )

  // Weekly cleanup — every Sunday at 2am
  await automationQueue.add(
    'weekly-cleanup',
    {},
    { repeat: { pattern: '0 2 * * 0' } }
  )
}
