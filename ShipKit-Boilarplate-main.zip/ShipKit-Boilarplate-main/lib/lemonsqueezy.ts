import { env } from '@/lib/env'
import { logger } from '@/lib/logger'

export const PLANS = {
  basic: env.LEMONSQUEEZY_VARIANT_BASIC,
  pro: env.LEMONSQUEEZY_VARIANT_PRO,
  monthly: env.LEMONSQUEEZY_VARIANT_MONTHLY,
  yearly: env.LEMONSQUEEZY_VARIANT_YEARLY,
}

/**
 * Creates a checkout session via the LemonSqueezy API and returns the checkout URL.
 * Uses the API rather than URL interpolation because LEMONSQUEEZY_STORE_ID is a
 * numeric ID, not a hostname slug.
 */
export async function getCheckoutUrl(
  variantId: string,
  userId: string,
  email: string,
  name?: string
): Promise<string> {
  const response = await fetch('https://api.lemonsqueezy.com/v1/checkouts', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.LEMONSQUEEZY_API_KEY}`,
      Accept: 'application/vnd.api+json',
      'Content-Type': 'application/vnd.api+json',
    },
    body: JSON.stringify({
      data: {
        type: 'checkouts',
        attributes: {
          checkout_data: {
            email,
            name: name ?? '',
            custom: { user_id: userId },
          },
        },
        relationships: {
          store: { data: { type: 'stores', id: env.LEMONSQUEEZY_STORE_ID } },
          variant: { data: { type: 'variants', id: variantId } },
        },
      },
    }),
  })

  if (!response.ok) {
    logger.error({ variantId, status: response.status }, 'Failed to create checkout')
    throw new Error(`LemonSqueezy checkout error: ${response.status}`)
  }

  const result = await response.json()
  return result.data.attributes.url as string
}

export function getCustomerPortalUrl(): string {
  return 'https://app.lemonsqueezy.com/my-orders'
}

export async function getSubscription(subscriptionId: string) {
  const response = await fetch(
    `https://api.lemonsqueezy.com/v1/subscriptions/${subscriptionId}`,
    {
      headers: {
        Authorization: `Bearer ${env.LEMONSQUEEZY_API_KEY}`,
        Accept: 'application/vnd.api+json',
      },
    }
  )
  if (!response.ok) {
    logger.error({ subscriptionId, status: response.status }, 'LemonSqueezy API error')
    throw new Error(`LS API error: ${response.status}`)
  }
  return response.json()
}
