'use client'

let csrfToken: string | null = null

/** Lazily fetch and cache a CSRF token for mutation requests. */
export async function getCsrfToken(): Promise<string> {
  if (csrfToken) return csrfToken
  const res = await fetch('/api/csrf', { credentials: 'include' })
  if (!res.ok) throw new Error('Failed to fetch CSRF token')
  const payload = await res.json()
  csrfToken = payload.data.token
  return csrfToken!
}

/** Clear the cached token (call after logout or on 403). */
export function clearCsrfToken(): void {
  csrfToken = null
}
