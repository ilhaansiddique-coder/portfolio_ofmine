import { createBrowserClient } from '@supabase/ssr'
import type { Database } from '@/types/supabase'
import { clientEnv } from '@/lib/env-client'

let client: ReturnType<typeof createBrowserClient<Database>> | null = null

export function createClient() {
  if (client) return client

  client = createBrowserClient<Database>(
    clientEnv.NEXT_PUBLIC_SUPABASE_URL,
    clientEnv.NEXT_PUBLIC_SUPABASE_ANON_KEY
  )

  return client
}
