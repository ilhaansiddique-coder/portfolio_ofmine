import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/types/supabase'
import { env } from '@/lib/env'

export function createAdminClient() {
  return createClient<Database>(
    env.NEXT_PUBLIC_SUPABASE_URL,
    env.SUPABASE_SERVICE_ROLE_KEY, // Bypasses RLS — server only!
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  )
}
