import { logger } from './logger'

/**
 * Error tracking is a bootstrap module — it must work BEFORE env validation runs,
 * so it intentionally reads process.env directly instead of importing env.ts.
 */
let Sentry: typeof import('@sentry/nextjs') | null = null

export async function initErrorTracking() {
  if (process.env.GLITCHTIP_DSN) {
    Sentry = await import('@sentry/nextjs')
    Sentry.init({
      dsn: process.env.GLITCHTIP_DSN,
      environment: process.env.NODE_ENV,
      tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
      sendDefaultPii: false,
      beforeSend(event) {
        if (
          event.extra?.statusCode &&
          (event.extra.statusCode as number) < 500
        ) {
          return null
        }
        return event
      },
    })
  }
}

export function captureError(
  error: Error,
  context?: Record<string, unknown>
) {
  if (Sentry) {
    Sentry.captureException(error, { extra: context })
  }
  logger.error({ err: error, ...context }, error.message)
}
