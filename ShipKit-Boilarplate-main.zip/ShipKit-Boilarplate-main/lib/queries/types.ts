import type { PlanName, SubscriptionStatus } from '@/types'

export interface CurrentUser {
  id: string
  email: string
  full_name: string | null
  avatar_url: string | null
  plan: PlanName
  is_paid: boolean
  ls_customer_id: string | null
  stripe_customer_id: string | null
  payment_processor: 'lemonsqueezy' | 'stripe'
  subscription_status: SubscriptionStatus
}

export interface DashboardStats {
  organizations: number
  teamMembers: number
  plan: string
  memberSinceDays: number
}

export interface UserActivity {
  id: string
  action: string
  description: string
  metadata: Record<string, unknown>
  created_at: string
}

export interface UserSubscription {
  id: string
  user_id: string
  ls_subscription_id: string | null
  ls_customer_id: string | null
  plan: PlanName
  status: SubscriptionStatus
  current_period_start: string | null
  current_period_end: string | null
  created_at: string
  updated_at: string
}
