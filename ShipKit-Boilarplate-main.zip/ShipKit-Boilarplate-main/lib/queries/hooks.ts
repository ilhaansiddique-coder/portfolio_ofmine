'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getCsrfToken } from '@/lib/csrf-client'
import type { CurrentUser, DashboardStats, UserActivity, UserSubscription } from './types'
import type { Organization, OrgRole, MembershipWithUser } from '@/types'

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url, { credentials: 'include' })
  const payload = await res.json()
  if (!res.ok) throw new Error(payload.error ?? 'Request failed')
  return payload.data
}

async function mutateJson<T>(url: string, method: string, body?: unknown): Promise<T> {
  const csrfToken = await getCsrfToken()
  const headers: Record<string, string> = { 'x-csrf-token': csrfToken }
  if (body) headers['Content-Type'] = 'application/json'

  const res = await fetch(url, {
    method,
    credentials: 'include',
    headers,
    body: body ? JSON.stringify(body) : undefined,
  })
  const payload = await res.json()
  if (!res.ok) throw new Error(payload.error ?? 'Request failed')
  return payload.data
}

export function useCurrentUser() {
  return useQuery<CurrentUser>({
    queryKey: ['current-user'],
    queryFn: () => fetchJson<CurrentUser>('/api/me'),
    staleTime: 1000 * 60 * 5,
  })
}

// ----- Organizations -----

export type OrgWithRole = Organization & { currentUserRole: OrgRole }

export function useOrganizations() {
  return useQuery<OrgWithRole[]>({
    queryKey: ['organizations'],
    queryFn: () => fetchJson<OrgWithRole[]>('/api/orgs'),
    staleTime: 1000 * 60 * 5,
  })
}

export function useOrganization(orgId: string) {
  return useQuery<OrgWithRole>({
    queryKey: ['organization', orgId],
    queryFn: () => fetchJson<OrgWithRole>(`/api/orgs/${orgId}`),
    enabled: !!orgId,
    staleTime: 1000 * 60 * 5,
  })
}

export function useOrgMembers(orgId: string) {
  return useQuery<MembershipWithUser[]>({
    queryKey: ['org-members', orgId],
    queryFn: () => fetchJson<MembershipWithUser[]>(`/api/orgs/${orgId}/members`),
    enabled: !!orgId,
    staleTime: 1000 * 60 * 2,
  })
}

export function useCreateOrg() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (data: { name: string; slug: string }) =>
      mutateJson<Organization>('/api/orgs', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] })
    },
  })
}

export function useInviteMember(orgId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (data: { email: string; role?: 'admin' | 'member' }) =>
      mutateJson<MembershipWithUser>(`/api/orgs/${orgId}/members`, 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['org-members', orgId] })
    },
  })
}

export function useRemoveMember(orgId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (userId: string) =>
      mutateJson<{ removed: boolean }>(`/api/orgs/${orgId}/members?userId=${userId}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['org-members', orgId] })
    },
  })
}

export function useUpdateMemberRole(orgId: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (data: { userId: string; role: 'admin' | 'member' }) =>
      mutateJson(`/api/orgs/${orgId}/members?userId=${data.userId}`, 'PATCH', { role: data.role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['org-members', orgId] })
    },
  })
}

// ----- Dashboard -----

export function useDashboardStats() {
  return useQuery<DashboardStats>({
    queryKey: ['dashboard-stats'],
    queryFn: () => fetchJson<DashboardStats>('/api/dashboard/stats'),
    staleTime: 1000 * 60 * 2,
  })
}

export function useRecentActivity() {
  return useQuery<UserActivity[]>({
    queryKey: ['recent-activity'],
    queryFn: () => fetchJson<UserActivity[]>('/api/dashboard/activity'),
    staleTime: 1000 * 60 * 2,
  })
}

// ----- Profile -----

export function useUpdateProfile() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (data: { full_name?: string; avatar_url?: string | null }) =>
      mutateJson<CurrentUser>('/api/me', 'PATCH', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['current-user'] })
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] })
      queryClient.invalidateQueries({ queryKey: ['recent-activity'] })
    },
  })
}

// ----- Billing -----

export function useUserSubscriptions() {
  return useQuery<UserSubscription>({
    queryKey: ['user-subscriptions'],
    queryFn: () => fetchJson<UserSubscription>('/api/billing/subscriptions'),
    staleTime: 1000 * 60 * 5,
  })
}

export function useCheckoutUrl() {
  return useMutation({
    mutationFn: (planId: string) =>
      mutateJson<{ checkoutUrl: string }>('/api/billing/checkout', 'POST', { planId }),
  })
}
