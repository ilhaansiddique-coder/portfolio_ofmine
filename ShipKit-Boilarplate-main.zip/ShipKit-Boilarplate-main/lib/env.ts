import { z } from 'zod'

const serverSchema = z
  .object({
    NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
    NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
    SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
    DATABASE_URL: z.string().startsWith('postgresql://'),
    LEMONSQUEEZY_API_KEY: z.string().min(1),
    LEMONSQUEEZY_WEBHOOK_SECRET: z.string().min(1),
    LEMONSQUEEZY_STORE_ID: z.string().min(1),
    LEMONSQUEEZY_VARIANT_BASIC: z.string().min(1),
    LEMONSQUEEZY_VARIANT_PRO: z.string().min(1),
    LEMONSQUEEZY_VARIANT_MONTHLY: z.string().min(1),
    LEMONSQUEEZY_VARIANT_YEARLY: z.string().min(1),
    STRIPE_API_KEY: z.string().min(1).optional(),
    STRIPE_WEBHOOK_SECRET: z.string().min(1).optional(),
    STRIPE_PRODUCT_BASIC: z.string().min(1).optional(),
    STRIPE_PRODUCT_PRO: z.string().min(1).optional(),
    STRIPE_PRICE_BASIC_MONTHLY: z.string().min(1).optional(),
    STRIPE_PRICE_BASIC_YEARLY: z.string().min(1).optional(),
    STRIPE_PRICE_PRO_MONTHLY: z.string().min(1).optional(),
    STRIPE_PRICE_PRO_YEARLY: z.string().min(1).optional(),
    EMAIL_PROVIDER: z.enum(['ses', 'resend', 'mailgun']).default('ses'),
    EMAIL_FROM: z.string().email().optional(),
    AWS_ACCESS_KEY_ID: z.string().min(1).optional(),
    AWS_SECRET_ACCESS_KEY: z.string().min(1).optional(),
    AWS_REGION: z.string().min(1).optional(),
    SES_FROM_EMAIL: z.string().email().optional(),
    RESEND_API_KEY: z.string().min(1).optional(),
    MAILGUN_API_KEY: z.string().min(1).optional(),
    MAILGUN_DOMAIN: z.string().min(1).optional(),
    MAILGUN_API_BASE_URL: z.string().url().default('https://api.mailgun.net'),
    REDIS_URL: z.string().min(1),
    ANTHROPIC_API_KEY: z.string().min(1),
    GROQ_API_KEY: z.string().min(1),
    INTERNAL_WEBHOOK_SECRET: z.string().min(1),
    NEXT_PUBLIC_APP_URL: z.string().url(),
    NEXT_PUBLIC_APP_NAME: z.string().default('MySaaS'),
    NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
    LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
    CORS_ALLOWED_ORIGINS: z.string().default('http://localhost:3000'),
    ADMIN_EMAILS: z.string().optional(),
    // Optional
    GLITCHTIP_DSN: z.string().optional(),
    ELEVENLABS_API_KEY: z.string().optional(),
    SLACK_WEBHOOK_URL: z.string().url().optional(),
    DIRECT_DATABASE_URL: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    if (!data.EMAIL_FROM && !data.SES_FROM_EMAIL) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['EMAIL_FROM'],
        message: 'EMAIL_FROM is required (or set SES_FROM_EMAIL for backward compatibility).',
      })
    }

    if (data.EMAIL_PROVIDER === 'ses') {
      if (!data.AWS_ACCESS_KEY_ID) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['AWS_ACCESS_KEY_ID'],
          message: 'AWS_ACCESS_KEY_ID is required when EMAIL_PROVIDER=ses.',
        })
      }
      if (!data.AWS_SECRET_ACCESS_KEY) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['AWS_SECRET_ACCESS_KEY'],
          message: 'AWS_SECRET_ACCESS_KEY is required when EMAIL_PROVIDER=ses.',
        })
      }
      if (!data.AWS_REGION) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['AWS_REGION'],
          message: 'AWS_REGION is required when EMAIL_PROVIDER=ses.',
        })
      }
    }

    if (data.EMAIL_PROVIDER === 'resend' && !data.RESEND_API_KEY) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['RESEND_API_KEY'],
        message: 'RESEND_API_KEY is required when EMAIL_PROVIDER=resend.',
      })
    }

    if (data.EMAIL_PROVIDER === 'mailgun') {
      if (!data.MAILGUN_API_KEY) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['MAILGUN_API_KEY'],
          message: 'MAILGUN_API_KEY is required when EMAIL_PROVIDER=mailgun.',
        })
      }
      if (!data.MAILGUN_DOMAIN) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['MAILGUN_DOMAIN'],
          message: 'MAILGUN_DOMAIN is required when EMAIL_PROVIDER=mailgun.',
        })
      }
    }
  })

const clientSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  NEXT_PUBLIC_APP_URL: z.string().url(),
  NEXT_PUBLIC_APP_NAME: z.string().default('MySaaS'),
})

export type ServerEnv = z.infer<typeof serverSchema>

// Validate at import time — app crashes immediately if env is wrong
export const env = serverSchema.parse(process.env)

export const clientEnv = clientSchema.parse({
  NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
  NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
})
