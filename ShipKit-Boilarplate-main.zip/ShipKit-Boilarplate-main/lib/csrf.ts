import { cookies } from 'next/headers'
import { randomBytes, timingSafeEqual } from 'crypto'

export async function generateCsrfToken(): Promise<string> {
  const token = randomBytes(32).toString('hex')
  const cookieStore = await cookies()
  cookieStore.set('csrf_token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/',
  })
  return token
}

export async function validateCsrfToken(token: string): Promise<boolean> {
  const cookieStore = await cookies()
  const stored = cookieStore.get('csrf_token')?.value
  if (!stored || !token) return false
  try {
    return timingSafeEqual(Buffer.from(stored), Buffer.from(token))
  } catch {
    return false
  }
}
