import Stripe from 'stripe'
import { env } from './env'
import { logger } from './logger'

let stripeClient: Stripe | null = null

function requireStripeEnv<K extends keyof typeof env>(
  key: K
): NonNullable<(typeof env)[K]> {
  const value = env[key]
  if (!value) {
    throw new Error(`Stripe is not configured. Missing ${String(key)}.`)
  }
  return value as NonNullable<(typeof env)[K]>
}

export function getStripeClient(): Stripe {
  if (!stripeClient) {
    stripeClient = new Stripe(requireStripeEnv('STRIPE_API_KEY'), {
      apiVersion: '2025-02-24.acacia',
    })
  }

  return stripeClient
}

export function getStripeWebhookSecret(): string {
  return requireStripeEnv('STRIPE_WEBHOOK_SECRET')
}

/* Plan mapping for Stripe prices */
function getStripePlans() {
  return {
    basic: {
      monthly: requireStripeEnv('STRIPE_PRICE_BASIC_MONTHLY'),
      yearly: requireStripeEnv('STRIPE_PRICE_BASIC_YEARLY'),
    },
    pro: {
      monthly: requireStripeEnv('STRIPE_PRICE_PRO_MONTHLY'),
      yearly: requireStripeEnv('STRIPE_PRICE_PRO_YEARLY'),
    },
  }
}

/**
 * Get Stripe price ID for a given plan and billing interval
 */
export function getStripePriceId(
  plan: 'basic' | 'pro',
  interval: 'monthly' | 'yearly' = 'monthly'
): string {
  const stripePlans = getStripePlans()

  if (!(plan in stripePlans)) {
    throw new Error(`Invalid plan: ${plan}`)
  }

  const priceId = stripePlans[plan][interval]
  if (!priceId) {
    throw new Error(`Invalid interval: ${interval}`)
  }

  return priceId
}

/**
 * Create or retrieve a Stripe customer and return the checkout URL
 */
export async function createCheckoutSession(
  priceId: string,
  userId: string,
  email: string,
  metadata?: Record<string, string>
): Promise<string> {
  try {
    const stripe = getStripeClient()
    const session = await stripe.checkout.sessions.create({
      customer_email: email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${env.NEXT_PUBLIC_APP_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${env.NEXT_PUBLIC_APP_URL}/billing`,
      billing_address_collection: 'auto',
      metadata: {
        userId,
        ...metadata,
      },
    })

    if (!session.url) {
      throw new Error('No checkout URL returned from Stripe')
    }

    logger.info(
      { userId, sessionId: session.id, email },
      'Stripe checkout session created'
    )

    return session.url
  } catch (error) {
    logger.error(
      { userId, email, error },
      'Failed to create Stripe checkout session'
    )
    throw error
  }
}

/**
 * Retrieve subscription details
 */
export async function getSubscription(subscriptionId: string) {
  try {
    const stripe = getStripeClient()
    const subscription = await stripe.subscriptions.retrieve(subscriptionId)
    return subscription
  } catch (error) {
    logger.error({ subscriptionId, error }, 'Failed to retrieve Stripe subscription')
    throw error
  }
}

/**
 * Cancel a subscription
 */
export async function cancelSubscription(
  subscriptionId: string,
  atPeriodEnd: boolean = true
) {
  try {
    const stripe = getStripeClient()
    const subscription = await stripe.subscriptions.update(subscriptionId, {
      cancel_at_period_end: atPeriodEnd,
    })

    logger.info(
      { subscriptionId, atPeriodEnd },
      'Stripe subscription cancelled'
    )

    return subscription
  } catch (error) {
    logger.error(
      { subscriptionId, atPeriodEnd, error },
      'Failed to cancel Stripe subscription'
    )
    throw error
  }
}

/**
 * Get the status of a subscription for display purposes
 */
export function getSubscriptionStatus(
  subscription: Stripe.Subscription
): 'active' | 'cancelled' | 'past_due' | 'paused' | 'trialing' {
  if (subscription.status === 'active' || subscription.status === 'trialing') {
    return 'active'
  }
  if (subscription.status === 'past_due') {
    return 'past_due'
  }
  if (subscription.status === 'paused') {
    return 'paused'
  }
  return 'cancelled'
}

/**
 * Extract plan name from Stripe price ID
 */
export function getPlanFromPriceId(priceId: string): 'basic' | 'pro' {
  const stripePlans = getStripePlans()

  for (const [plan, prices] of Object.entries(stripePlans)) {
    for (const price of Object.values(prices)) {
      if (price === priceId) {
        return plan as 'basic' | 'pro'
      }
    }
  }
  return 'basic' // default fallback
}
