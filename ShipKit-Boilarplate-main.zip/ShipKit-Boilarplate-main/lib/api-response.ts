import { NextResponse } from 'next/server'

type ApiSuccess<T> = { data: T; error: null }
type ApiError = { data: null; error: string; code?: string }

export function ok<T>(data: T, status = 200): NextResponse {
  return NextResponse.json({ data, error: null } satisfies ApiSuccess<T>, {
    status,
  })
}

export function err(
  message: string,
  status = 500,
  code?: string
): NextResponse {
  return NextResponse.json(
    { data: null, error: message, code } satisfies ApiError,
    { status }
  )
}
