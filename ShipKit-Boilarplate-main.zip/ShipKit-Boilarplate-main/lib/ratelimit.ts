import { NextRequest } from 'next/server'
import redis from './redis'

export function getClientIp(req: NextRequest): string {
  return (
    req.headers.get('cf-connecting-ip') ??
    req.headers.get('x-forwarded-for')?.split(',')[0].trim() ??
    req.headers.get('x-real-ip') ??
    'anonymous'
  )
}

export async function rateLimit(
  identifier: string,
  limit = 10,
  windowSeconds = 60
): Promise<{ success: boolean; remaining: number; reset: number }> {
  const key = `ratelimit:${identifier}`
  const now = Math.floor(Date.now() / 1000)

  const pipeline = redis.pipeline()
  pipeline.incr(key)
  pipeline.ttl(key)
  const results = await pipeline.exec()

  const count = results?.[0]?.[1] as number
  const ttl = results?.[1]?.[1] as number

  if (count === 1) {
    await redis.expire(key, windowSeconds)
  }

  return {
    success: count <= limit,
    remaining: Math.max(0, limit - count),
    reset: now + (ttl > 0 ? ttl : windowSeconds),
  }
}
