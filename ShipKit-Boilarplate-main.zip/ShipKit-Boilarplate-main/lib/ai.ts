import Anthropic from '@anthropic-ai/sdk'
import Groq from 'groq-sdk'
import { env } from '@/lib/env'
import { logger } from '@/lib/logger'

// ─────────────────────────────────────
// CLAUDE (primary — logic, reasoning, agents)
// ─────────────────────────────────────
const anthropic = new Anthropic({
  apiKey: env.ANTHROPIC_API_KEY,
})

export async function askClaude(
  prompt: string,
  systemPrompt?: string,
  maxTokens = 1024
): Promise<string> {
  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    system: systemPrompt,
    messages: [{ role: 'user', content: prompt }],
  })
  return (response.content[0] as { text: string }).text
}

export async function streamClaude(
  prompt: string,
  systemPrompt?: string,
  onChunk?: (text: string) => void
): Promise<string> {
  let fullText = ''
  const stream = anthropic.messages.stream({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 2048,
    system: systemPrompt,
    messages: [{ role: 'user', content: prompt }],
  })
  for await (const event of stream) {
    if (
      event.type === 'content_block_delta' &&
      event.delta.type === 'text_delta'
    ) {
      fullText += event.delta.text
      onChunk?.(event.delta.text)
    }
  }
  return fullText
}

// ─────────────────────────────────────
// GROQ (fast/cheap — high volume tasks)
// ─────────────────────────────────────
const groq = new Groq({ apiKey: env.GROQ_API_KEY })

export async function askGroq(
  prompt: string,
  systemPrompt?: string,
  maxTokens = 1024
): Promise<string> {
  const response = await groq.chat.completions.create({
    model: 'llama-3.3-70b-versatile',
    max_tokens: maxTokens,
    messages: [
      ...(systemPrompt ? [{ role: 'system' as const, content: systemPrompt }] : []),
      { role: 'user', content: prompt },
    ],
  })
  return response.choices[0].message.content ?? ''
}

// ─────────────────────────────────────
// ELEVENLABS (TTS)
// ─────────────────────────────────────
export async function textToSpeech(
  text: string,
  voiceId = 'EXAVITQu4vr4xnSDxMaL'
): Promise<Buffer> {
  const response = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
    {
      method: 'POST',
      headers: {
        'xi-api-key': env.ELEVENLABS_API_KEY ?? '',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.75 },
      }),
    }
  )
  if (!response.ok) {
    logger.error({ status: response.status }, 'ElevenLabs TTS failed')
    throw new Error(`TTS failed: ${response.status}`)
  }
  return Buffer.from(await response.arrayBuffer())
}
