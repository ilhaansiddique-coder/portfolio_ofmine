import { createClient } from '@/lib/supabase/server'
import { logger } from '@/lib/logger'

const ALLOWED_MIME_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'application/pdf',
] as const

const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB

/** Magic byte signatures for server-side MIME verification */
const MAGIC_BYTES: Record<string, { offset: number; bytes: number[] }[]> = {
  'image/jpeg': [{ offset: 0, bytes: [0xff, 0xd8, 0xff] }],
  'image/png': [{ offset: 0, bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a] }],
  'image/gif': [
    { offset: 0, bytes: [0x47, 0x49, 0x46, 0x38, 0x37, 0x61] }, // GIF87a
    { offset: 0, bytes: [0x47, 0x49, 0x46, 0x38, 0x39, 0x61] }, // GIF89a
  ],
  'image/webp': [
    { offset: 8, bytes: [0x57, 0x45, 0x42, 0x50] }, // "WEBP" at offset 8 (definitive identifier)
  ],
  'application/pdf': [{ offset: 0, bytes: [0x25, 0x50, 0x44, 0x46] }], // %PDF
}

function matchesMagicBytes(header: Uint8Array, signatures: { offset: number; bytes: number[] }[]): boolean {
  return signatures.some(sig =>
    sig.bytes.every((byte, i) => header[sig.offset + i] === byte)
  )
}

async function verifyMagicBytes(file: File): Promise<string | null> {
  const headerSlice = file.slice(0, 12)
  const header = new Uint8Array(await headerSlice.arrayBuffer())

  const signatures = MAGIC_BYTES[file.type]
  if (!signatures) {
    // No magic bytes to verify for this type — accept based on extension/type
    return null
  }

  if (!matchesMagicBytes(header, signatures)) {
    return `File content does not match declared type "${file.type}"`
  }
  return null
}

interface UploadResult {
  success: boolean
  path?: string
  publicUrl?: string
  error?: string
}

export function validateFile(
  file: File,
  allowedTypes: readonly string[] = ALLOWED_MIME_TYPES,
  maxSize: number = MAX_FILE_SIZE
): { valid: true } | { valid: false; error: string } {
  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: `File type "${file.type}" is not allowed` }
  }
  if (file.size > maxSize) {
    return {
      valid: false,
      error: `File exceeds maximum size of ${maxSize / 1024 / 1024}MB`,
    }
  }
  if (file.size === 0) {
    return { valid: false, error: 'File is empty' }
  }
  const nameParts = file.name.split('.')
  if (nameParts.length > 2) {
    return { valid: false, error: 'File name contains multiple extensions' }
  }
  return { valid: true }
}

export async function uploadToStorage(
  bucket: string,
  path: string,
  file: File,
  allowedTypes?: readonly string[],
  maxSize?: number
): Promise<UploadResult> {
  const validation = validateFile(file, allowedTypes, maxSize)
  if (!validation.valid) {
    return { success: false, error: validation.error }
  }

  // Server-side magic byte verification — don't trust client-reported MIME type
  const magicError = await verifyMagicBytes(file)
  if (magicError) {
    return { success: false, error: magicError }
  }

  const supabase = await createClient()

  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, {
      contentType: file.type,
      upsert: false,
    })

  if (error) {
    logger.error({ error, bucket, path }, 'File upload failed')
    return { success: false, error: 'Upload failed' }
  }

  const { data: urlData } = supabase.storage
    .from(bucket)
    .getPublicUrl(data.path)

  return {
    success: true,
    path: data.path,
    publicUrl: urlData.publicUrl,
  }
}
