import { ZodSchema } from 'zod'
import { NextResponse } from 'next/server'
import { logger } from '@/lib/logger'

export function validateBody<T>(
  schema: ZodSchema<T>,
  body: unknown
): { success: true; data: T } | { success: false; response: NextResponse } {
  const result = schema.safeParse(body)
  if (!result.success) {
    logger.warn({ details: result.error.flatten() }, 'Request body failed validation')
    return {
      success: false,
      response: NextResponse.json(
        { error: 'Invalid input' },
        { status: 400 }
      ),
    }
  }
  return { success: true, data: result.data }
}
