import pino from 'pino'

/**
 * Logger is a bootstrap module — it must work BEFORE env validation runs,
 * so it intentionally reads process.env directly instead of importing env.ts.
 */
export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  ...(process.env.NODE_ENV === 'development' && {
    transport: {
      target: 'pino-pretty',
      options: {
        colorize: true,
        translateTime: 'HH:MM:ss',
        ignore: 'pid,hostname',
      },
    },
  }),
  base: {
    service: process.env.NEXT_PUBLIC_APP_NAME ?? 'saas-app',
    env: process.env.NODE_ENV,
  },
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'password',
      'token',
      'apiKey',
      'secret',
      'creditCard',
      'email',
      '*.email',
      'user.email',
      'data.email',
      'profile.email',
    ],
    censor: '[REDACTED]',
  },
})

export const dbLogger = logger.child({ module: 'database' })
export const authLogger = logger.child({ module: 'auth' })
export const paymentLogger = logger.child({ module: 'payments' })
export const emailLogger = logger.child({ module: 'email' })
