/**
 * Shared Redis connection config for BullMQ queues and workers.
 * Parses REDIS_URL to avoid ioredis/BullMQ version conflicts.
 */
export function parseRedisUrl(url: string) {
  try {
    const parsed = new URL(url)
    return {
      host: parsed.hostname || 'localhost',
      port: Number(parsed.port) || 6379,
      password: parsed.password || undefined,
      username: parsed.username || undefined,
    }
  } catch {
    return { host: 'localhost', port: 6379 }
  }
}

export function getBullMQConnection() {
  return {
    ...parseRedisUrl(process.env.REDIS_URL ?? 'redis://localhost:6379'),
    maxRetriesPerRequest: null,
  }
}
