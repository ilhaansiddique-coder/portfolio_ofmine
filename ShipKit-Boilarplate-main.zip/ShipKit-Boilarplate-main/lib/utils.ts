import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { clientEnv } from '@/lib/env-client'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getBaseUrl(): string {
  return clientEnv.NEXT_PUBLIC_APP_URL
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((w) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

const avatarColorPairs: [string, string][] = [
  ['#7c3aed', '#a78bfa'],
  ['#2563eb', '#60a5fa'],
  ['#059669', '#34d399'],
  ['#dc2626', '#f87171'],
  ['#d97706', '#fbbf24'],
  ['#ec4899', '#f472b6'],
  ['#0ea5e9', '#38bdf8'],
  ['#8b5cf6', '#c4b5fd'],
]

export function colorForName(name: string): [string, string] {
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }
  return avatarColorPairs[Math.abs(hash) % avatarColorPairs.length]
}
