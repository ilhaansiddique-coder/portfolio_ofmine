import { NextRequest, NextResponse } from 'next/server'
import { err } from './api-response'
import { logger } from './logger'
import { captureError } from './error-tracking'
import { rateLimit, getClientIp } from './ratelimit'
import { validateCsrfToken } from './csrf'

type RouteHandler = (
  req: NextRequest,
  ctx: { params: Promise<Record<string, string>> }
) => Promise<NextResponse>

type HandlerOptions = {
  /** Rate-limit configuration. Omit to skip rate limiting. */
  rateLimit?: { limit?: number; windowSeconds?: number }
  /** When true, POST/PATCH/PUT/DELETE requests must include a valid x-csrf-token header. */
  csrf?: boolean
}

export function withErrorHandler(
  handler: RouteHandler,
  options?: HandlerOptions
): RouteHandler {
  return async (req, ctx) => {
    try {
      // ---- Rate limiting ----
      if (options?.rateLimit) {
        const isMutation = ['POST', 'PATCH', 'PUT', 'DELETE'].includes(
          req.method
        )
        try {
          const ip = getClientIp(req)
          const key = `${req.method}:${new URL(req.url).pathname}:${ip}`
          const { limit = 30, windowSeconds = 60 } = options.rateLimit
          const result = await rateLimit(key, limit, windowSeconds)

          if (!result.success) {
            const retryAfter = String(
              result.reset - Math.floor(Date.now() / 1000)
            )
            return NextResponse.json(
              { data: null, error: 'Too many requests' },
              {
                status: 429,
                headers: {
                  'Retry-After': retryAfter,
                  'X-RateLimit-Remaining': '0',
                },
              }
            )
          }
        } catch (e) {
          logger.warn({ err: e }, 'Rate limiting unavailable — Redis may be down')
          // Mutations fail closed — reject if we can't verify the rate limit
          if (isMutation) {
            return err('Service temporarily unavailable', 503)
          }
          // Reads fail open — don't block legitimate GET requests
        }
      }

      // ---- CSRF validation (mutations only) ----
      if (
        options?.csrf &&
        ['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method)
      ) {
        const token = req.headers.get('x-csrf-token') ?? ''
        const valid = await validateCsrfToken(token)
        if (!valid) {
          return err('Invalid CSRF token', 403)
        }
      }

      return await handler(req, ctx)
    } catch (error) {
      logger.error(
        { err: error, url: req.url, method: req.method },
        'Unhandled route error'
      )
      captureError(error as Error, { url: req.url, method: req.method })
      return err('Internal server error', 500)
    }
  }
}
