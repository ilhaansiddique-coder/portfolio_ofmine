import { SESv2Client, SendEmailCommand } from '@aws-sdk/client-sesv2'
import { env } from '@/lib/env'
import { logger } from '@/lib/logger'

type EmailProvider = 'ses' | 'resend' | 'mailgun'

interface EmailOptions {
  to: string | string[]
  subject: string
  html: string
  text?: string
  replyTo?: string
}

interface EmailProviderConfig {
  fromEmail: string
  provider: EmailProvider
}

let sesClient: SESv2Client | null = null

function getEmailConfig(): EmailProviderConfig {
  return {
    provider: env.EMAIL_PROVIDER,
    fromEmail: env.EMAIL_FROM ?? env.SES_FROM_EMAIL!,
  }
}

function getSesClient() {
  if (!sesClient) {
    sesClient = new SESv2Client({
      region: env.AWS_REGION!,
      credentials: {
        accessKeyId: env.AWS_ACCESS_KEY_ID!,
        secretAccessKey: env.AWS_SECRET_ACCESS_KEY!,
      },
    })
  }

  return sesClient
}

async function sendWithSes(
  { fromEmail }: EmailProviderConfig,
  { to, subject, html, text, replyTo }: EmailOptions
) {
  return getSesClient().send(
    new SendEmailCommand({
      FromEmailAddress: fromEmail,
      Destination: { ToAddresses: Array.isArray(to) ? to : [to] },
      ReplyToAddresses: replyTo ? [replyTo] : undefined,
      Content: {
        Simple: {
          Subject: { Data: subject, Charset: 'UTF-8' },
          Body: {
            Html: { Data: html, Charset: 'UTF-8' },
            ...(text && { Text: { Data: text, Charset: 'UTF-8' } }),
          },
        },
      },
    })
  )
}

async function sendWithResend(
  { fromEmail }: EmailProviderConfig,
  { to, subject, html, text, replyTo }: EmailOptions
) {
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.RESEND_API_KEY!}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: fromEmail,
      to: Array.isArray(to) ? to : [to],
      subject,
      html,
      text,
      reply_to: replyTo,
    }),
  })

  if (!response.ok) {
    const body = await response.text()
    throw new Error(`Resend API error: ${response.status} ${body}`)
  }

  return response.json()
}

async function sendWithMailgun(
  { fromEmail }: EmailProviderConfig,
  { to, subject, html, text, replyTo }: EmailOptions
) {
  const formData = new FormData()
  formData.set('from', fromEmail)
  formData.set('to', Array.isArray(to) ? to.join(',') : to)
  formData.set('subject', subject)
  formData.set('html', html)
  if (text) formData.set('text', text)
  if (replyTo) formData.set('h:Reply-To', replyTo)

  const credentials = Buffer.from(`api:${env.MAILGUN_API_KEY!}`).toString('base64')
  const baseUrl = env.MAILGUN_API_BASE_URL.replace(/\/$/, '')
  const response = await fetch(`${baseUrl}/v3/${env.MAILGUN_DOMAIN!}/messages`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${credentials}`,
    },
    body: formData,
  })

  if (!response.ok) {
    const body = await response.text()
    throw new Error(`Mailgun API error: ${response.status} ${body}`)
  }

  return response.json()
}

export async function sendEmail(options: EmailOptions) {
  const config = getEmailConfig()
  const recipients = Array.isArray(options.to) ? options.to : [options.to]

  try {
    let result: unknown

    switch (config.provider) {
      case 'resend':
        result = await sendWithResend(config, options)
        break
      case 'mailgun':
        result = await sendWithMailgun(config, options)
        break
      case 'ses':
      default:
        result = await sendWithSes(config, options)
        break
    }

    logger.info(
      { provider: config.provider, to: recipients, subject: options.subject },
      'Email sent'
    )

    return result
  } catch (error) {
    logger.error(
      { err: error, provider: config.provider, to: recipients, subject: options.subject },
      'Email send failed'
    )
    throw error
  }
}

// Email templates
export function welcomeEmail(name: string): string {
  return `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <h1>Welcome, ${name}!</h1>
      <p>Your account is ready. Get started by logging in.</p>
      <a href="${env.NEXT_PUBLIC_APP_URL}/dashboard"
         style="background: #7c3aed; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
        Go to Dashboard
      </a>
    </div>
  `
}

export function paymentSuccessEmail(name: string, plan: string): string {
  return `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <h1>Payment confirmed</h1>
      <p>Hi ${name}, your <strong>${plan}</strong> plan is now active.</p>
    </div>
  `
}

export function passwordResetEmail(name: string, resetLink: string): string {
  return `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <h1>Reset Your Password</h1>
      <p>Hi ${name},</p>
      <p>We received a request to reset your password. Click the link below to create a new password:</p>
      <p style="margin: 2rem 0;">
        <a href="${resetLink}"
           style="background: #7c3aed; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
          Reset Password
        </a>
      </p>
      <p style="color: #666; font-size: 0.9rem;">
        Or copy and paste this link in your browser:<br/>
        <code style="background: #f0f0f0; padding: 2px 4px; border-radius: 3px;">${resetLink}</code>
      </p>
      <p style="color: #666; font-size: 0.9rem;">
        This link will expire in 24 hours. If you didn't request a password reset, you can safely ignore this email.
      </p>
    </div>
  `
}

export function invitationEmail(inviterName: string, orgName: string, invitationLink: string): string {
  return `
    <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <h1>You're invited!</h1>
      <p>${inviterName} invited you to join <strong>${orgName}</strong> on MySaaS.</p>
      <p style="margin: 2rem 0;">
        <a href="${invitationLink}"
           style="background: #7c3aed; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
          Accept Invitation
        </a>
      </p>
      <p style="color: #666; font-size: 0.9rem;">
        This invitation will expire in 7 days.
      </p>
    </div>
  `
}
