import { Worker } from 'bullmq'
import { sendEmail } from '@/lib/email'
import { logger } from '@/lib/logger'
import { getBullMQConnection } from '@/lib/redis-connection'

const connection = getBullMQConnection()

const emailWorker = new Worker(
  'email',
  async (job) => {
    const { to, subject, html, text } = job.data
    logger.info({ to, subject, jobId: job.id }, 'Sending email')
    await sendEmail({ to, subject, html, text })
    logger.info({ to, jobId: job.id }, 'Email sent successfully')
  },
  {
    connection,
    concurrency: 5,
    limiter: {
      max: 14,
      duration: 1000,
    },
  }
)

emailWorker.on('failed', (job, err) => {
  logger.error({ jobId: job?.id, err }, 'Email job failed')
})

logger.info('Email worker started')
