import { Worker } from 'bullmq'
import { logger } from '@/lib/logger'
import { createAdminClient } from '@/lib/supabase/admin'
import { getBullMQConnection } from '@/lib/redis-connection'

const connection = getBullMQConnection()

const webhookWorker = new Worker(
  'webhook-processing',
  async (job) => {
    const supabase = createAdminClient()
    const { eventName, userId, customerId, status } = job.data

    switch (eventName) {
      case 'order_created':
        await supabase
          .from('users')
          .update({ is_paid: true, plan: 'basic', ls_customer_id: customerId })
          .eq('id', userId)
        logger.info({ userId, plan: 'basic' }, 'Deferred order processing complete')
        break

      case 'subscription_created':
      case 'subscription_updated':
      case 'subscription_resumed':
        await supabase
          .from('users')
          .update({
            plan: status === 'active' ? 'pro' : 'free',
            ls_customer_id: customerId,
            subscription_status: status,
            is_paid: status === 'active',
          })
          .eq('id', userId)
        logger.info({ userId, status, eventName }, 'Deferred subscription processing complete')
        break

      default:
        logger.warn({ eventName }, 'Unhandled deferred webhook event')
    }
  },
  { connection, concurrency: 3 }
)

webhookWorker.on('failed', (job, err) => {
  logger.error({ jobId: job?.id, err }, 'Webhook processing job failed')
})

logger.info('Webhook worker started')
