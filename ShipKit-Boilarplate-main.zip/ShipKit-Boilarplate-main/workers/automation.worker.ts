import { Worker } from 'bullmq'
import { logger } from '@/lib/logger'
import { createAdminClient } from '@/lib/supabase/admin'
import { sendEmail } from '@/lib/email'
import { getBullMQConnection } from '@/lib/redis-connection'
import { env } from '@/lib/env'

const connection = getBullMQConnection()

const automationWorker = new Worker(
  'automation',
  async (job) => {
    const supabase = createAdminClient()

    switch (job.name) {
      case 'daily-digest': {
        const yesterday = new Date(Date.now() - 86400000).toISOString()

        const { count: newUsers } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', yesterday)

        const { count: newPaid } = await supabase
          .from('users')
          .select('*', { count: 'exact', head: true })
          .eq('is_paid', true)
          .gte('updated_at', yesterday)

        const report = `Daily digest: ${newUsers ?? 0} new users, ${newPaid ?? 0} new paid`
        logger.info({ newUsers, newPaid }, 'Daily digest generated')

        await sendEmail({
          to: env.EMAIL_FROM ?? env.SES_FROM_EMAIL ?? 'noreply@example.com',
          subject: `Daily Digest - ${new Date().toLocaleDateString()}`,
          html: `<p>${report}</p>`,
          text: report,
        })
        break
      }

      case 'win-back-email': {
        const { email, name } = job.data
        await sendEmail({
          to: email,
          subject: 'We miss you!',
          html: `<p>Hi ${name}, we noticed you cancelled. Anything we can help with?</p>`,
        })
        logger.info({ email }, 'Win-back email sent')
        break
      }

      case 'weekly-cleanup': {
        // Clean up old webhook events
        const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString()
        await supabase.from('webhook_events').delete().lt('created_at', thirtyDaysAgo)
        logger.info('Weekly cleanup completed')
        break
      }

      default:
        logger.warn({ jobName: job.name }, 'Unknown automation job')
    }
  },
  {
    connection,
    concurrency: 3,
  }
)

automationWorker.on('failed', (job, err) => {
  logger.error({ jobId: job?.id, jobName: job?.name, err }, 'Automation job failed')
})

logger.info('Automation worker started')
