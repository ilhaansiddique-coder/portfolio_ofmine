import { Worker } from 'bullmq'
import { logger } from '@/lib/logger'
import { getBullMQConnection } from '@/lib/redis-connection'
import { env } from '@/lib/env'

const connection = getBullMQConnection()

const notificationWorker = new Worker(
  'notification',
  async (job) => {
    switch (job.name) {
      case 'slack': {
        const { channel, text } = job.data
        const webhookUrl = env.SLACK_WEBHOOK_URL
        if (!webhookUrl) {
          logger.warn('SLACK_WEBHOOK_URL not set, skipping Slack notification')
          return
        }
        await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ channel, text }),
        })
        logger.info({ channel }, 'Slack notification sent')
        break
      }

      default:
        logger.warn({ jobName: job.name }, 'Unknown notification type')
    }
  },
  { connection, concurrency: 5 }
)

notificationWorker.on('failed', (job, err) => {
  logger.error({ jobId: job?.id, err }, 'Notification job failed')
})

logger.info('Notification worker started')
