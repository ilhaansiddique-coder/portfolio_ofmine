import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

/**
 * Middleware runs in the Edge runtime which cannot import Node.js-only modules.
 * process.env is intentional here — env.ts relies on Node APIs unavailable at the edge.
 */

// ---- CSP builder ----

const isDev = process.env.NODE_ENV === 'development'

function buildCsp(nonce: string): string {
  const scriptSrc = isDev
    ? `script-src 'self' 'nonce-${nonce}' 'unsafe-eval'`
    : `script-src 'self' 'nonce-${nonce}'`

  const styleSrc = isDev
    ? `style-src 'self' 'unsafe-inline'`
    : `style-src 'self' 'nonce-${nonce}'`

  return [
    "default-src 'self'",
    scriptSrc,
    styleSrc,
    "img-src 'self' blob: https:",
    "font-src 'self'",
    "connect-src 'self' https://*.supabase.co wss://*.supabase.co https://api.lemonsqueezy.com",
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "object-src 'none'",
    "worker-src 'self'",
    ...(isDev ? [] : ["upgrade-insecure-requests"]),
  ].join('; ')
}

// ---- CORS helpers ----

function getCorsOrigins(): string[] {
  return (process.env.CORS_ALLOWED_ORIGINS ?? '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean)
}

function handleCors(request: NextRequest): NextResponse {
  const origin = request.headers.get('origin')
  const corsOrigins = getCorsOrigins()
  const isAllowed =
    origin && corsOrigins.length > 0 && corsOrigins.includes(origin)

  const corsHeaders: Record<string, string> = {}
  if (isAllowed && origin) {
    corsHeaders['Access-Control-Allow-Origin'] = origin
    corsHeaders['Access-Control-Allow-Methods'] =
      'GET, POST, PATCH, DELETE, OPTIONS'
    corsHeaders['Access-Control-Allow-Headers'] =
      'Content-Type, Authorization, x-csrf-token'
    corsHeaders['Access-Control-Allow-Credentials'] = 'true'
    corsHeaders['Access-Control-Max-Age'] = '86400'
  }

  // Preflight
  if (request.method === 'OPTIONS') {
    return new NextResponse(null, { status: 204, headers: corsHeaders })
  }

  // Pass through with CORS headers
  const response = NextResponse.next({ request })
  for (const [key, value] of Object.entries(corsHeaders)) {
    response.headers.set(key, value)
  }
  return response
}

// ---- Main middleware ----

export async function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname

  // ---- CORS for API routes (skip webhooks — they use HMAC auth) ----
  if (
    pathname.startsWith('/api/') &&
    !pathname.startsWith('/api/webhooks')
  ) {
    return handleCors(request)
  }

  // ---- CSP nonce for page routes (production only) ----
  // In development, Next.js font optimization and React HMR inject inline
  // styles/scripts that conflict with strict CSP. Skip CSP entirely in dev.
  const nonce = isDev ? '' : btoa(crypto.randomUUID())
  const requestHeaders = new Headers(request.headers)
  requestHeaders.set('x-nonce', nonce)

  const response = NextResponse.next({ request: { headers: requestHeaders } })
  if (!isDev) {
    response.headers.set('Content-Security-Policy', buildCsp(nonce))
  }

  // ---- Auth redirects (only for auth-relevant routes) ----
  const needsAuth =
    pathname.startsWith('/dashboard') ||
    pathname === '/login' ||
    pathname === '/signup'

  if (needsAuth) {
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll: () => request.cookies.getAll(),
          setAll: (cookiesToSet: Array<{ name: string; value: string; options?: Record<string, unknown> }>) => {
            cookiesToSet.forEach(({ name, value, options }) => {
              request.cookies.set(name, value)
              response.cookies.set(name, value, options as never)
            })
          },
        },
      }
    )

    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (pathname.startsWith('/dashboard') && !user) {
      return NextResponse.redirect(new URL('/login', request.url))
    }

    if ((pathname === '/login' || pathname === '/signup') && user) {
      return NextResponse.redirect(new URL('/dashboard', request.url))
    }
  }

  return response
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization)
     * - favicon.ico and static image assets
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
