# Dual Payment Processor Setup — LemonSqueezy & Stripe

This boilerplate supports **two payment processors** — users can choose between **LemonSqueezy** and **Stripe** during checkout. Both processors are fully integrated with the same billing system, webhooks, and subscription management.

## Overview

- **LemonSqueezy**: Default processor, easy setup, content creator friendly
- **Stripe**: Enterprise-grade, widely used, powerful customization

Both processors:
- Create secure checkout sessions
- Handle subscription lifecycle (active, paused, cancelled, expired)
- Process webhook events idempotently
- Track subscription status in the database
- Support monthly and yearly billing intervals
- Integrate with the same billing UI and subscription management

## Configuration

### Environment Variables

Add these to your `.env.local`:

```bash
# ============================================
# LEMONSQUEEZY
# ============================================
LEMONSQUEEZY_API_KEY=your_api_key
LEMONSQUEEZY_WEBHOOK_SECRET=your_webhook_secret
LEMONSQUEEZY_STORE_ID=your_store_id
LEMONSQUEEZY_VARIANT_BASIC=basic_monthly_variant_id
LEMONSQUEEZY_VARIANT_PRO=pro_monthly_variant_id
LEMONSQUEEZY_VARIANT_MONTHLY=monthly_variant_id
LEMONSQUEEZY_VARIANT_YEARLY=yearly_variant_id

# ============================================
# STRIPE
# ============================================
STRIPE_API_KEY=sk_test_... # or sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRODUCT_BASIC=prod_...
STRIPE_PRODUCT_PRO=prod_...
STRIPE_PRICE_BASIC_MONTHLY=price_...
STRIPE_PRICE_BASIC_YEARLY=price_...
STRIPE_PRICE_PRO_MONTHLY=price_...
STRIPE_PRICE_PRO_YEARLY=price_...
```

## Architecture

### Database Schema

Tables support both processors:

```sql
-- Users table
users.payment_processor  -- 'lemonsqueezy' | 'stripe'
users.ls_customer_id     -- LemonSqueezy customer ID
users.stripe_customer_id -- Stripe customer ID

-- Subscriptions table
subscriptions.payment_processor     -- 'lemonsqueezy' | 'stripe'
subscriptions.ls_subscription_id    -- LemonSqueezy subscription ID
subscriptions.ls_customer_id        -- LemonSqueezy customer ID
subscriptions.stripe_subscription_id -- Stripe subscription ID
subscriptions.stripe_customer_id    -- Stripe customer ID

-- Webhook events table (idempotency)
webhook_events.processor -- 'lemonsqueezy' | 'stripe'
webhook_events.user_id   -- Reference to user for easier tracking
```

### API Routes

#### POST `/api/billing/checkout`

Initiates a checkout session. Users select their processor during checkout.

**Request:**
```json
{
  "planId": "basic" | "pro",
  "processor": "lemonsqueezy" | "stripe",
  "billingInterval": "monthly" | "yearly"
}
```

**Response:**
```json
{
  "data": {
    "checkoutUrl": "https://lemonsqueezy.com/checkout/... or https://checkout.stripe.com/..."
  }
}
```

**Flow:**
1. User selects plan, payment processor, and billing interval
2. API generates checkout URL for the selected processor
3. Update `users.payment_processor` to the selected value
4. Redirect to checkout URL
5. After payment, webhook creates/updates subscription record with processor info

#### POST `/api/billing/cancel`

Cancels the user's subscription. Works with both processors.

**Flow:**
1. Fetch user's payment processor
2. If Stripe: Call `stripe.subscriptions.update()` with `cancel_at_period_end: true`
3. If LemonSqueezy: Log message for user to cancel in LemonSqueezy portal
4. Update `users.subscription_status` to 'cancelled'

#### GET `/api/billing/subscriptions`

Fetches subscription details (works with both processors).

### Webhook Handlers

#### LemonSqueezy: POST `/api/webhooks/lemonsqueezy`

Accepts LemonSqueezy webhook events:
- `order_created` → Upgrade to basic plan
- `subscription_created`, `subscription_updated`, `subscription_resumed` → Update subscription status
- `subscription_cancelled` → Mark as cancelled (remains active until period end)
- `subscription_expired` → Downgrade to free plan

HMAC verification using `X-Signature` header.

#### Stripe: POST `/api/webhooks/stripe`

Accepts Stripe webhook events:
- `customer.subscription.created` → Create subscription record
- `customer.subscription.updated` → Update subscription status and plan
- `customer.subscription.deleted` → Mark as cancelled
- `invoice.payment_failed` → Set status to 'past_due'
- `invoice.payment_succeeded` → Recover from past_due

Signature verification using Stripe's `stripe.webhooks.constructEvent()`.

### Idempotency & Safety

Both webhooks use the same idempotency pattern:

```sql
-- webhook_events table (unique constraint on event_id)
INSERT INTO webhook_events (event_id, event_name, processor, user_id)
VALUES (...)
ON CONFLICT (event_id) DO NOTHING
RETURNING id;
```

If the same event fires multiple times:
1. First webhook processes and inserts record
2. Duplicate webhooks conflict on `event_id` and are silently skipped
3. No double-charging or duplicate subscriptions

## Implementation Details

### LemonSqueezy (`lib/lemonsqueezy.ts`)

```typescript
const PLANS = {
  basic: env.LEMONSQUEEZY_VARIANT_BASIC,
  pro: env.LEMONSQUEEZY_VARIANT_PRO,
  // ... monthly/yearly variants
}

async function getCheckoutUrl(variantId, userId, email, name) {
  // POST to https://api.lemonsqueezy.com/v1/checkouts
  // Returns checkout URL
}
```

### Stripe (`lib/stripe.ts`)

```typescript
const STRIPE_PLANS = {
  basic: {
    monthly: env.STRIPE_PRICE_BASIC_MONTHLY,
    yearly: env.STRIPE_PRICE_BASIC_YEARLY,
  },
  pro: {
    monthly: env.STRIPE_PRICE_PRO_MONTHLY,
    yearly: env.STRIPE_PRICE_PRO_YEARLY,
  },
}

async function createCheckoutSession(priceId, userId, email) {
  // Creates Stripe checkout session
  // Returns session.url
}

async function cancelSubscription(subscriptionId, atPeriodEnd) {
  // Stripe subscription update
}
```

## UI/UX

### Billing Page

The billing page (`app/(dashboard)/billing/page.tsx`) includes:

1. **Payment Processor Selector**
   - Choose between LemonSqueezy and Stripe
   - Emoji badges for easy identification
   - Persistent selection across sessions

2. **Billing Interval Selector**
   - Monthly (full price)
   - Yearly (17% discount)

3. **Plan Cards**
   - Shows pricing for selected processor + interval
   - "Upgrade" button triggers checkout

4. **Payment Method Display**
   - Shows which processor is active
   - Displays card on file info
   - Links to processor portals for updates

5. **Subscription Status**
   - Active, paused, cancelled, past_due states
   - Renewal date display
   - Cancel subscription button (Stripe) or portal link (LemonSqueezy)

## Scenarios

### User Switches from LemonSqueezy to Stripe

1. User selects Stripe in checkout options
2. Clicks "Upgrade to Pro"
3. Redirected to Stripe checkout
4. Upon success, Stripe webhook fires `customer.subscription.created`
5. New subscription record created with `stripe_subscription_id`
6. `users.payment_processor` updated to 'stripe'
7. Old LemonSqueezy subscription remains (users should manually cancel)

### Invoice/Billing History

Both processors' invoices appear in the billing history table:
- Date, plan name, price, status
- Records pulled from subscription table (works for both)

### Admin Dashboard

Admin analytics work with both processors:
- Total active subscriptions (counts both Stripe and LemonSqueezy)
- MRR calculation includes both processors
- Conversion rate includes both

### GDPR Compliance

Data export (`GET /api/me/export-data`) includes:
- `payment_processor` for each subscription
- IDs from both processors (if user has used both)

## Testing

### LemonSqueezy Test Webhook

```bash
curl -X POST http://localhost:3000/api/webhooks/lemonsqueezy \
  -H "Content-Type: application/json" \
  -H "X-Signature: <hmac-sha256-signature>" \
  -d '{
    "meta": {
      "event_name": "subscription_created",
      "webhook_id": "test-123",
      "custom_data": { "user_id": "user-uuid" }
    },
    "data": {
      "attributes": {
        "customer_id": "cust-123",
        "status": "active"
      }
    }
  }'
```

### Stripe Test Webhook

Use Stripe CLI:

```bash
stripe listen --forward-to localhost:3000/api/webhooks/stripe
stripe trigger customer.subscription.created
stripe trigger customer.subscription.updated
stripe trigger customer.subscription.deleted
```

## Best Practices

1. **Never hardcode processor**: Always fetch from the database
2. **Idempotent webhooks**: Always use event ID deduplication
3. **Processor neutrality**: Don't assume LemonSqueezy in code; check `payment_processor`
4. **User choice**: Let users select their preferred processor; don't force one
5. **Fallback**: If a processor is down, users can still use the other
6. **Logging**: Always log which processor is being used for debugging
7. **Error handling**: Handle both processors' error formats gracefully

## Migration Path

If upgrading from single-processor setup:

1. Run migration `00008_add_stripe_support.sql`
2. Existing users default to `payment_processor = 'lemonsqueezy'`
3. New users can choose their processor
4. No disruption to existing subscriptions

## Troubleshooting

### Webhook not firing

**LemonSqueezy:**
- Check webhook URL in LemonSqueezy dashboard settings
- Verify `X-Signature` header is being verified correctly
- Enable webhook logging: `LEMONSQUEEZY_LOG_WEBHOOKS=true`

**Stripe:**
- Use `stripe listen` to test locally
- Verify webhook endpoint is registered in Stripe dashboard
- Check `stripe logs` for errors

### Customer ID mismatch

- Ensure webhook includes correct metadata (userId)
- Verify correct columns are being updated (ls_customer_id vs stripe_customer_id)
- Check subscription table for orphaned records

### Subscription status stuck

- Manually trigger webhook in processor's dashboard
- Check webhook_events table for duplicate prevention
- Verify RLS policies allow updates

## Future Enhancements

- [ ] Support PayPal, Square, Gumroad
- [ ] Plan switching (basic → pro without cancellation)
- [ ] Promo codes / discounts
- [ ] Usage-based billing
- [ ] Multi-currency support
- [ ] Dunning & retry logic UI
