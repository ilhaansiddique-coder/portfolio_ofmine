const config = {
  colorize: true,
  translateTime: 'HH:MM:ss',
  ignore: 'pid,hostname',
  singleLine: false,
}

export default config
