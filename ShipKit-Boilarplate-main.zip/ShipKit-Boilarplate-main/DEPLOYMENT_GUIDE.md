# Deployment Guide

Complete guide to deploying your SaaS boilerplate to production.

## Prerequisites

- Node.js 20+
- npm or yarn
- Git
- Supabase account
- LemonSqueezy account (or alternative payment processor)
- AWS account (for SES email)
- Redis instance (Upstash or self-hosted)

## Environment Variables

1. Copy `.env.example` to `.env.local`
2. Fill in all required values:

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-key
SUPABASE_SERVICE_ROLE_KEY=your-key
DATABASE_URL=your-db-url

# LemonSqueezy
LEMONSQUEEZY_API_KEY=your-key
LEMONSQUEEZY_WEBHOOK_SECRET=your-secret
LEMONSQUEEZY_STORE_ID=your-id
LEMONSQUEEZY_VARIANT_BASIC=variant-id
LEMONSQUEEZY_VARIANT_PRO=variant-id

# AWS SES
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_REGION=us-east-1
SES_FROM_EMAIL=noreply@yourdomain.com

# Redis
REDIS_URL=redis://your-redis

# App
NEXT_PUBLIC_APP_URL=https://yourdomain.com
NEXT_PUBLIC_APP_NAME=Your SaaS Name

# Webhooks
INTERNAL_WEBHOOK_SECRET=generate-random-secret
```

## Database Setup

### 1. Create Supabase Project

1. Go to supabase.com and create a new project
2. Wait for the project to be provisioned
3. Copy the database URL and anon key

### 2. Run Migrations

```bash
# Install CLI if not already done
npm install @supabase/cli --save-dev

# Push migrations to production database
npx supabase db push --db-url="your-production-db-url"

# Generate types
npm run db:types
```

### 3. Configure Webhook Settings

In Supabase, set the `app.settings` for database notifications:

```sql
SELECT set_config('app.settings.app_url', 'https://yourdomain.com', false);
SELECT set_config('app.settings.webhook_secret', 'your-internal-webhook-secret', false);
```

## Payment Processing Setup

### LemonSqueezy

1. Create a LemonSqueezy account
2. Create a product with variants:
   - **Basic Plan** ($19/mo)
   - **Pro Plan** ($49/mo)
3. Note the variant IDs and paste into env
4. Create an API key
5. Create webhook endpoint pointing to: `https://yourdomain.com/api/webhooks/lemonsqueezy`
6. Save the webhook signing secret

### Alternative: Stripe

If using Stripe instead of LemonSqueezy:

1. Update `/app/api/webhooks/lemonsqueezy/route.ts` to use Stripe SDK
2. Update environment variables
3. Update LemonSqueezy checkout logic in `/lib/lemonsqueezy.ts`

## Email Configuration (AWS SES)

### 1. Set Up AWS Account

```bash
# Install AWS CLI
npm install -g aws-cli

# Configure credentials
aws configure

# Use your access key and secret key
```

### 2. Create SES Identity

```bash
# Verify domain
aws ses verify-domain-identity --domain yourdomain.com

# Add DKIM records to your DNS registrar (AWS will provide)
# Add SPF and DMARC records
```

### 3. Request Production Access

By default, SES is in sandbox mode (emails only to verified addresses).

1. Go to AWS SES console
2. Go to "Account Dashboard" → "Send Limits"
3. Click "Edit your Amazon SES sending limits" request
4. Request production access

### 4. Create SMTP Credentials

```bash
# In AWS SES console:
# 1. Click "SMTP Settings"
# 2. Click "Create My SMTP Credentials"
# 3. Download credentials
```

## Redis Setup

### Option 1: Upstash (Recommended for simplicity)

1. Go to upstash.com
2. Create a new Redis database
3. Copy the URL and add to `REDIS_URL` env variable
4. Enable EVICTION POLICY: "No eviction"

### Option 2: Self-Hosted Redis

```bash
# Docker
docker run -d -p 6379:6379 redis:7-alpine

# Or install locally
brew install redis
redis-server
```

## Deployment to Vercel

### 1. Upload to GitHub

```bash
git add .
git commit -m "Production ready"
git push origin main
```

### 2. Import to Vercel

1. Go to vercel.com
2. Click "Add New..." → "Project"
3. Import GitHub repository
4. Configure environment variables from `.env.local`
5. Click "Deploy"

### 3. Set Custom Domain

1. In Vercel project settings
2. Go to "Domains"
3. Add your custom domain
4. Vercel will provide DNS records
5. Update DNS at your registrar

### 4. Connect Database

Vercel will automatically connect to your Supabase project if you have the connection string set in environment variables.

## Testing in Staging

### 1. Create Staging Environment

```bash
# Create staging branch
git checkout -b staging

# Deploy to staging.yourdomain.com via Vercel
```

### 2. Create Test Supabase Project

Use a separate Supabase project for staging.

### 3. Test Full Flow

- [ ] Signup with email
- [ ] Email verification
- [ ] Login
- [ ] Password reset
- [ ] Complete checkout
- [ ] Verify webhook processing
- [ ] Check emails delivered
- [ ] Delete account
- [ ] Verify data deleted

### 4. Load Testing

```bash
# Install k6
brew install k6

# Run load test
k6 run tests/load-test.js

# Monitor performance dashboard
```

## Migration Checklist

Before going live:

```bash
# 1. Test everything
npm run test
npm run test:e2e

# 2. Build for production
npm run build

# 3. Check for errors
npm run typecheck
npm run lint

# 4. Check bundle size
npm run build -- --analyze
```

## Monitoring & Logging

### 1. Set Up GlitchTip (Error Tracking)

```bash
# Create account at glitchtip.com
# Create new project
# Copy DSN to GLITCHTIP_DSN env variable
```

### 2. Implement Custom Dashboards

- Vercel Analytics for web vitals
- Custom dashboard at `/admin` for key metrics
- Set up alerts in GlitchTip

### 3. Health Checks

```bash
# Monitor with external service like
# Better Stack: https://betterstack.com/
# StatusPage: https://www.statuspage.io/

# Use: https://yourdomain.com/api/health
```

## Post-Deployment Steps

### 1. Verify Everything Works

```bash
curl https://yourdomain.com/api/health
```

### 2. Test Payment Workflow

1. Create test account
2. Attempt upgrade
3. Complete payment
4. Verify subscription status updated
5. Check webhook in logs

### 3. Test Email Delivery

1. Password reset email
2. Welcome email
3. Payment confirmation email
4. Check bounce/delivery logs

### 4. Security Checklist

- [ ] HTTPS enabled
- [ ] Security headers returned
- [ ] CORS configured
- [ ] Rate limiting active
- [ ] CSRF protection enabled
- [ ] RLS policies enforced

### 5. Update Legal Documents

- [ ] Terms of Service (update with real company info)
- [ ] Privacy Policy (update with real company info)
- [ ] Add Cookies Policy
- [ ] Add GDPR compliance notice

## Backups & Disaster Recovery

### 1. Database Backups (Supabase)

Supabase provides automated backups and Point-in-Time Recovery (PITR).

#### Enable PITR (Point-in-Time Recovery)

1. Go to Supabase Dashboard → Project Settings
2. Select your project
3. Go to **Backups** tab
4. Enable "Point-in-Time Recovery"
5. This allows recovery to any point in the last 7 days

#### Automated Daily Backups

Supabase automatically creates backups:
- Daily at 00:00 UTC (timezone of your database)
- Retained for 14, 30, or 90 days (depends on plan)
- Stored in geographically redundant storage

#### Manual Backup

To create manual backup before major changes:

```sql
-- In Supabase SQL Editor
-- This doesn't create backup directly, but document via comments
-- Run this query to log backup intent:
SELECT set_config('app.settings.backup_marker', 'before-major-change', false);
```

Then notify Supabase support if you need manual snapshot.

#### Restore from Backup

**If entire database is corrupted:**

1. Go to Supabase Dashboard → Backups
2. Click "Restore" next to desired backup date
3. Database will be restored (takes ~30 mins)
4. Check data integrity after restore

**If only specific rows deleted (PITR):**

1. Go to Supabase Dashboard → Backups → PITR
2. Select target recovery time
3. Click "Restore to point in time"
4. Existing database is renamed, new one created with recovered data

#### Testing Backup Restoration

Monthly, you should test that backups work:

```bash
# 1. In Supabase, create a separate "backup-test" database
# 2. Restore latest backup to it
# 3. Run test queries to verify data integrity
# 4. Delete test database

# This ensures backups can actually be restored if needed
```

### 2. Application Backups (Vercel)

Vercel maintains automatic backups of your code via GitHub.

#### Backup Strategy

```bash
# Always keep main branch deployable
git checkout main
git pull origin main

# Tag important releases
git tag v1.0.0 production-launch
git push origin v1.0.0

# Maintain branches
main          # Production
staging       # Pre-production testing
develop       # Development
feature/...   # Feature branches
```

#### Disaster Recovery

If production is compromised:

```bash
# 1. Identify last known good commit
git log main --oneline | head -20

# 2. Rollback to previous version
git revert <bad-commit-hash>
git push origin main
# Vercel auto-deploys

# OR create hotfix branch
git checkout -b hotfix/emergency-fix <old-commit>
# Make fixes
git push origin hotfix/emergency-fix
# Create PR, merge to main
```

### 3. Data Export (GDPR Compliance)

Users can request data export via `/api/me/export`:

```json
{
  "data": {
    "user": { all user fields },
    "subscriptions": [ all subscriptions ],
    "activities": [ all activity logs ],
    "exported_at": "2026-03-08T10:00:00Z"
  }
}
```

Store these exports:
- Keep for 30 days minimum
- Allow user download/delete
- Log all exports for compliance

### 4. Critical Infrastructure Status

Monitor these services for outages:

```bash
# Supabase Status
# https://status.supabase.com

# Vercel Status  
# https://vercelstatus.com

# AWS Status
# https://status.aws.amazon.com

# Stripe/LemonSqueezy Status
# https://status.stripe.com
# https://status.lemonsqueezy.com
```

Set up RSS feed alerts or check before deployments.

### 5. Database Corruption Recovery

If you detect data corruption:

#### Detection

```sql
-- Check for orphaned records
SELECT * FROM subscriptions 
WHERE user_id NOT IN (SELECT id FROM users);

-- Find NULL where NOT NULL expected
SELECT * FROM users 
WHERE email IS NULL;

-- Check for duplicate IDs
SELECT id, COUNT(*) 
FROM users 
GROUP BY id HAVING COUNT(*) > 1;
```

#### Quarantine

If found, immediately:
1. Enable maintenance mode (if available)
2. Stop writes to affected tables
3. Create diagnostic backup
4. Contact Supabase support

#### Recovery Steps

```sql
-- Only after backup confirmation!

-- Option 1: Restore from backup (preferred)
-- Use Supabase PITR feature

-- Option 2: Manual cleanup (only simple cases)
DELETE FROM subscriptions 
WHERE user_id NOT IN (SELECT id FROM users);

-- Option 3: Restore specific rows
-- From Supabase backup, export data, reimport
```

### 6. Disaster Recovery Checklist

- [ ] **Weekly**: Verify PITR is active
  ```bash
  # Check that automatic backups are running in Supabase Dashboard
  ```

- [ ] **Monthly**: Test backup restoration
  ```bash
  # Create a test database and restore latest backup to it
  # Run test queries
  # Delete test database
  ```

- [ ] **Monthly**: Test code rollback
  ```bash
  git log main --oneline | head -5
  # Verify you can identify and checkout old commits
  ```

- [ ] **Quarterly**: Full disaster recovery drill
  ```bash
  # Simulate database failure:
  # 1. Restore backup to test database
  # 2. Update DATABASE_URL to point to test DB
  # 3. Deploy to staging
  # 4. Verify app works correctly
  # 5. Rollback DATABASE_URL
  ```

- [ ] **Quarterly**: Test data export
  - [ ] Request data export via API
  - [ ] Verify all data is included
  - [ ] Check JSON is valid

### 7. Incident Response Plan

When disaster occurs:

```
1. IDENTIFY (5-10 minutes)
   - Is service down? Check status pages
   - Can users access app? Test login
   - Can users pay? Test checkout
   - Check logs for errors

2. COMMUNICATE (Immediately)
   - Update status page
   - Email users if applicable
   - Notify team via Slack

3. ASSESS (10-20 minutes)
   - Check Supabase dashboard
   - Check Vercel logs
   - Check error tracking (GlitchTip)
   - Determine scope of issue

4. MITIGATE (20-60 minutes)
   - Restart services if needed
   - Rollback if code issue
   - Restore backup if data issue
   - Scale up if load issue

5. VERIFY (10-15 minutes)
   - Test critical paths
   - Check health endpoint
   - Monitor error rates
   - Get user confirmation

6. DOCUMENT & IMPROVE (Post-incident)
   - Write incident report
   - Identify root cause
   - Implement preventive measures
   - Schedule post-mortem (24h later)
```

#### Communication Template

```
Subject: Service Incident Report

TIME: 2026-03-08 14:30 UTC
SEVERITY: [CRITICAL | HIGH | MEDIUM | LOW]
IMPACT: [X%] users affected for [Y] minutes

SYMPTOMS:
- [What users experienced]

ROOT CAUSE:
- [What went wrong]

RESOLUTION:
- [How it was fixed]
- Time to resolution: [X] minutes

IMPROVEMENT:
- [What we'll change to prevent this]

NEXT STEPS:
- [Follow-up actions]
```

---

## Troubleshooting

### 502 Bad Gateway

Usually indicates a cold start or database connection issue.

```bash
# Check logs
vercel logs <deployment-id>

# Verify database URL
vercel env list

# Restart deployment
vercel --prod
```

### Emails Not Sending

```bash
# Check SES sandbox/production status
aws ses describe-configuration-set --configuration-set-name default

# Check bounce/complaint logs
aws ses describe-suppressed-destination
```

### Payment Webhook Not Processing

```bash
# Check webhook logs in LemonSqueezy dashboard
# Verify signature secret matches LEMONSQUEEZY_WEBHOOK_SECRET
# Check database webhook_events table for duplicates
```

### High Memory Usage

Usually due to Redis connection pooling.

```bash
# Check active connections
redis-cli info stats | grep connections

# Restart Redis if needed
# Or adjust Cacheproxy settings in next.config.ts
```

## Security Best Practices

1. **Never commit .env.local** - Use Vercel environment variables
2. **Rotate secrets regularly** - Update API keys every 90 days
3. **Monitor logs** - Set up alerts for suspicious activity
4. **Update dependencies** - Run `npm audit` weekly
5. **Use SSL** - All connections should be HTTPS
6. **Rate limit** - Especially on auth endpoints
7. **Validate input** - Use Zod schemas (already implemented)
8. **Encrypt sensitive data** - Use Supabase encryption for PII

## Scaling Considerations

As you grow:

1. **Database**: Enable read replicas for read-heavy queries
2. **Redis**: Monitor memory usage, consider clustering
3. **Vercel**: Pro plan includes edge middleware for better performance
4. **CDN**: Enable Vercel's built-in CDN for assets
5. **Assets**: Store files in S3, serve via CloudFront
6. **Analytics**: Implement analytics database for reporting

## Getting Help

- [Supabase Docs](https://supabase.com/docs)
- [Vercel Docs](https://vercel.com/docs)
- [Next.js Docs](https://nextjs.org/docs)
- [LemonSqueezy Docs](https://docs.lemonsqueezy.com)
- GitHub Issues for this boilerplate

---

**Last Updated**: January 2024
**Estimated Deployment Time**: 2-4 hours
