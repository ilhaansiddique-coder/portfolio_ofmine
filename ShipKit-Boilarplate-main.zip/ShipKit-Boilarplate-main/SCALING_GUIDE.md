# Scaling Guide

As your SaaS grows, you'll need to handle increased traffic, data volume, and complexity. This guide covers strategies to scale each component.

---

## Architecture Overview

Your boilerplate is designed to scale horizontally:

```
Vercel (Next.js)     →  Supabase (PostgreSQL)
   ↓                       ↑
HTTP ← → API Routes        RLS Policies
   ↓                       ↓
Workers (BullMQ)     →  Redis
```

---

## 🚀 Scaling Steps by Layer

### 1. Application (Next.js on Vercel)

Vercel automatically scales your Next.js app horizontally.

#### What to Monitor
- **Response Time**: Target < 500ms (P95)
- **Error Rate**: Target < 0.1%
- **CPU Usage**: Should be < 80% consistently

#### Optimization Strategies

**A. Enable ISR (Incremental Static Regeneration)**

For frequently accessed, slow-to-generate pages:

```typescript
// app/dashboard/page.tsx
export const revalidate = 60 // Revalidate every 60 seconds

export default function DashboardPage() {
  // Expensive query here is cached for 60s
}
```

**B. Stream Heavy Pages**

For pages with slow API calls:

```typescript
import { Suspense } from 'react'

export default function Page() {
  return (
    <div>
      <h1>Dashboard</h1>
      <Suspense fallback={<p>Loading stats...</p>}>
        <ExpensiveStats />
      </Suspense>
    </div>
  )
}
```

**C. Bundle Analysis**

Check for large dependencies bloating your bundle:

```bash
npm install --save-dev @next/bundle-analyzer

# In next.config.ts:
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
})
export default withBundleAnalyzer({})

# Run: ANALYZE=true npm run build
```

**D. Image Optimization**

Use Next.js Image component:

```typescript
import Image from 'next/image'

<Image
  src="/logo.png"
  alt="Logo"
  width={100}
  height={100}
  priority  // Only for above-fold images
/>
```

**E. Code Splitting**

Lazy-load heavy components:

```typescript
import dynamic from 'next/dynamic'

const ExpensiveChart = dynamic(() => import('@/components/Chart'), {
  loading: () => <p>Loading chart...</p>,
})
```

---

### 2. Database (Supabase PostgreSQL)

Supabase uses managed PostgreSQL. You control performance through schema design and queries.

#### Connection Pooling

Critical for scaling. **Always use the pooled connection** for app queries:

```env
# Use pooled connection for queries (6543 port)
DATABASE_URL=postgresql://user:pass@host:6543/postgres

# Use direct connection only for migrations (5432 port)
DIRECT_DATABASE_URL=postgresql://user:pass@host:5432/postgres
```

**Supabase PgBouncer settings** (in Supabase dashboard):
- Mode: `transaction` (recommended for serverless)
- Pool size: `20` (start here, adjust based on load)

#### Query Optimization

**A. Add Strategic Indexes**

```sql
-- Most common queries need indexes
CREATE INDEX users_email_idx ON users(email);
CREATE INDEX subscriptions_user_id_idx ON subscriptions(user_id);
CREATE INDEX webhook_events_processor_idx ON webhook_events(processor, created_at);

-- Composite index for pagination
CREATE INDEX activities_user_created_idx ON user_activity(user_id, created_at DESC);
```

**B. Use EXPLAIN PLAN**

Before/after optimizing:

```sql
EXPLAIN ANALYZE
SELECT * FROM subscriptions 
WHERE user_id = $1 AND status = 'active'
ORDER BY created_at DESC;
```

Look for "Seq Scan" (bad) vs "Index Scan" (good).

**C. Query Optimization Patterns**

```typescript
// ❌ Bad: N+1 query problem
const subscriptions = await supabase
  .from('subscriptions')
  .select('*')
  .eq('user_id', userId)

for (const sub of subscriptions) {
  const user = await supabase  // One query per subscription!
    .from('users')
    .select('*')
    .eq('id', sub.user_id)
}

// ✅ Good: Single join query
const subscriptions = await supabase
  .from('subscriptions')
  .select('*, users(email, full_name)')
  .eq('user_id', userId)
```

**D. Pagination for Large Result Sets**

```typescript
const pageSize = 50
const page = 1
const start = (page - 1) * pageSize

const { data, count } = await supabase
  .from('activities')
  .select('*', { count: 'exact' })
  .eq('user_id', userId)
  .order('created_at', { ascending: false })
  .range(start, start + pageSize - 1)
```

#### Row-Level Security (RLS) Performance

RLS has a small overhead. Measurements show 5-10% slower queries.

**Best practices:**
- ✅ Use simple policies: `auth.uid() = user_id`
- ❌ Avoid complex joins in policies
- ✅ Make sure policies have the same indexes as base table

#### Database Backups & PITR

Supabase provides **Point-in-Time Recovery (PITR)**.

**To enable:**
1. Go to Supabase dashboard → Project Settings → Backups
2. Enable "Point-in-Time Recovery"
3. Allows restore to any point in last 7 days

**Backup strategy:**
- Daily automated backups via Supabase
- Weekly snapshots exported to cloud storage
- Test restore weekly

---

### 3. Cache Layer (Redis)

Redis handles:
- Rate limiting
- Session storage
- Queue jobs (BullMQ)
- User cache

#### Scaling Redis

**Single Instance (Up to ~50K concurrent):**
- Use Upstash or Redis Labs managed service
- Monitor CPU/memory usage in admin panel

**Redis Cluster (50K+ concurrent):**

```typescript
// Switch to Redis Cluster
import { Cluster } from 'ioredis'

const redis = new Cluster([
  { host: 'node1.redis.service', port: 6379 },
  { host: 'node2.redis.service', port: 6379 },
  { host: 'node3.redis.service', port: 6379 },
])
```

#### Memory Management

```typescript
// Set expiration on all cache keys (prevent memory bloat)
redis.setex('user_settings:123', 3600, JSON.stringify(data))  // 1h TTL

// Monitor memory usage
redis.info('memory')

// Clear cache if needed
redis.flushdb()  // Careful! Only in development
```

#### Rate Limiting at Scale

Current implementation stores per-IP limiter state in Redis. Scales well up to 1M RPS. For higher:

```typescript
// Switch to sliding window with Redis Streams (more efficient)
const key = `rate_limit:${ip}:${Math.floor(Date.now() / 1000)}`
redis.incr(key)
redis.expire(key, 60)
```

---

### 4. Background Jobs (BullMQ)

For sending emails, webhooks, etc.

#### Queue Architecture

**Single Queue → Multiple Workers:**

```typescript
// app/api/billing/webhook/route.ts
await webhookQueue.add('process-webhook', { event }, {
  attempts: 3,  // Retry 3 times
  backoff: {
    type: 'exponential',
    delay: 2000,  // Start 2s, exponential backoff
  },
  removeOnComplete: true,  // Clean up completed jobs
})

// workers/webhook.worker.ts
worker.process(async (job) => {
  // Process webhook
  // Auto-retries on failure
})
```

#### Scaling Workers

**Single worker instance:**
- Processes 1 job at a time
- Suitable for < 1K jobs/day

**Multiple concurrency:**

```typescript
// app/workers/email.worker.ts
worker.process(5, async (job) => {  // Process 5 emails in parallel
  await sendEmail(job.data)
})
```

**Multiple worker instances:**

```bash
# Terminal 1: Start worker 1
npm run worker:email

# Terminal 2: Start worker 2
npm run worker:email

# BullMQ automatically distributes jobs across instances
```

#### Monitoring Jobs

```typescript
// Check queue health
const failedCount = await emailQueue.getFailedCount()
const activeCount = await emailQueue.getActiveCount()
const waitingCount = await emailQueue.getWaitingCount()

logger.info(
  { failed: failedCount, active: activeCount, waiting: waitingCount },
  'Email queue status'
)
```

---

### 5. API Rate Limiting at Scale

Current: Simple Redis-based rate limiter.

**For 10K+ RPS, use adaptive rate limiting:**

```typescript
// lib/ratelimit.ts - Enhanced version
export async function rateLimit(key: string, limit: number, windowSeconds: number) {
  const now = Math.floor(Date.now() / 1000)
  const windowKey = `rl:${key}:${now}`
  
  // Count requests in current window
  const count = await redis.incr(windowKey)
  
  if (count === 1) {
    // First request in window, set expiration
    await redis.expire(windowKey, windowSeconds + 1)
  }
  
  // Return remaining quota
  return {
    success: count <= limit,
    remaining: Math.max(0, limit - count),
    reset: now + windowSeconds,
  }
}
```

---

## 📊 Monitoring & Observability

### Key Metrics to Watch

```typescript
// app/api/metrics/route.ts
const metrics = {
  // Application
  responseTime: measure(),
  errorRate: failures / totalRequests,
  
  // Database
  slowQueries: count(duration > 1000),
  connectionPoolUsage: activeConnections / maxConnections,
  
  // Cache
  cacheMissRate: misses / (hits + misses),
  redisMemoryUsage: redis.info().used_memory,
  
  // Jobs
  queueDepth: emailQueue.getWaitingCount(),
  failedJobs: emailQueue.getFailedCount(),
  
  // Payments
  webhookSuccessRate: successful / total,
}
```

### Setup Monitoring

**1. Enable Vercel Analytics:**

In [app/layout.tsx](app/layout.tsx):

```typescript
import { Analytics } from '@vercel/analytics/react'

export default function RootLayout() {
  return (
    <html>
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
```

**2. GlitchTip for Error Tracking:**

```env
GLITCHTIP_DSN=https://your-key@glitchtip.yourhost.com/1
```

**3. Custom Dashboards:**

Create a monitoring page to track your SaaS health:

```typescript
// app/(dashboard)/admin/monitoring/page.tsx
export default function MonitoringPage() {
  const [metrics, setMetrics] = useState(null)
  
  useEffect(() => {
    fetchMetrics().then(setMetrics)
  }, [])
  
  return (
    <div>
      <h1>System Monitoring</h1>
      <StatsGrid metrics={metrics} />
    </div>
  )
}
```

---

## 🎯 Scaling Checklist

### Phase 1: 0-1K Users
- ✅ Single Vercel deployment
- ✅ Supabase free tier
- ✅ Basic monitoring

### Phase 2: 1K-10K Users
- [ ] Enable Vercel Analytics
- [ ] Set up GlitchTip for error tracking
- [ ] Add indexes to frequently queried tables
- [ ] Enable connection pooling (5-10 threads)
- [ ] Monitor Redis memory (upgrade if > 80% used)
- [ ] Test with load testing tool (k6, Artillery)

### Phase 3: 10K-100K Users
- [ ] Migrate to Supabase paid tier
- [ ] Set up read replicas for analytics queries
- [ ] Implement caching layer (Redis Cluster)
- [ ] Auto-scale workers based on queue depth
- [ ] Set up CDN for static assets (Vercel default)
- [ ] Database optimization (query profiling, index analysis)

### Phase 4: 100K+ Users
- [ ] Horizontal scaling: Multiple Vercel regions
- [ ] Database: Consider sharding if single table > 10GB
- [ ] Redis: Cluster with 3+ nodes
- [ ] Workers: Auto-scaling based on queue metrics
- [ ] API: Rate limiting per plan tier
- [ ] Caching: Multi-layer (CDN → Redis → Database)

---

## 🧪 Load Testing

Test your infrastructure before launch:

### Using k6

```bash
npm install --save-dev k6
```

```typescript
// tests/load/spike.js
import http from 'k6/http'
import { check } from 'k6'

export const options = {
  stages: [
    { duration: '2m', target: 100 },    // Ramp up
    { duration: '5m', target: 100 },    // Hold
    { duration: '2m', target: 200 },    // Spike
    { duration: '5m', target: 200 },    // Hold
    { duration: '2m', target: 0 },      // Ramp down
  ],
}

export default function () {
  const res = http.get(__ENV.BASE_URL || 'http://localhost:3000/api/health')
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  })
}
```

Run it:

```bash
k6 run tests/load/spike.js --vus 10 --duration 10s
```

---

## 💰 Cost Optimization

### Vercel
- $20/month for hobby + pay-as-you-go
- Pro: $20/month (recommended for production)
- Enterprise: Custom pricing

### Supabase
- Free: 500MB DB, 5M requests/month
- Pro: $25/month + $0.125 per 1M requests
- Scale your database as you grow

### AWS SES
- First 62K emails/month free
- Then $0.1 per 1K emails

### Redis (Upstash)
- Free: 100 commands/day
- Pay-as-you-go: $0.2 per 100K commands
- Recommended: ~$10-50/month for production

### Domain & SSL
- Domain: $10-15/year (GoDaddy, Namecheap)
- SSL: Free (automatic with Vercel)

---

## 🚨 Troubleshooting Performance

### High Database Load

```sql
-- Find slow queries
SELECT query, mean_time, calls
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 10;

-- Kill long-running queries
SELECT pg_terminate_backend(pid) 
FROM pg_stat_activity 
WHERE duration > interval '5 minutes';
```

### High Memory Usage

```bash
# Check Redis memory
redis-cli info memory

# Find large keys
redis-cli --bigkeys

# Clean up old cache keys
redis-cli flushdb
```

### Queue Backlog

```typescript
const depth = await emailQueue.getWaitingCount()
if (depth > 1000) {
  // Scale workers or reduce job enqueue rate
  logger.warn('Queue backlog detected', { depth })
}
```

---

## 📚 Additional Resources

- [Vercel Scaling Guide](https://vercel.com/guides/how-to-improve-performance)
- [Supabase Performance Tips](https://supabase.com/docs/guides/database/best-practices)
- [BullMQ Best Practices](https://docs.bullmq.io/)
- [Redis Memory Optimization](https://redis.io/topics/memory-optimization)
- [k6 Load Testing](https://k6.io/docs/)

---

## Questions?

See [TROUBLESHOOTING_GUIDE.md](TROUBLESHOOTING_GUIDE.md) for common scaling issues and solutions.
