# SaaS Boilerplate - 100% Production Ready

A complete, battle-tested SaaS foundation built with modern technologies. Ship your product in days, not months.

**Deployment-ready** | **Full-stack** | **Type-safe** | **Open source**

---

## 🚀 What's Included

### Frontend
- ✅ **Auth Pages** - Login, signup, password reset (Supabase)
- ✅ **Landing Page** - Hero, features, pricing, CTA
- ✅ **Dashboard** - Stats, activity feed, organizations
- ✅ **Billing Portal** - Subscription management, checkout, invoices
- ✅ **Settings** - Profile, password, account deletion, data export
- ✅ **Organization Portal** - Team management, member invitations
- ✅ **Admin Dashboard** - Key metrics and analytics
- ✅ **Legal Pages** - Terms, Privacy Policy, customizable

### Backend & APIs
- ✅ **REST APIs** - 18+ endpoints for all operations
- ✅ **Authentication** - Supabase Auth with OAuth support
- ✅ **Payment Processing** - LemonSqueezy webhooks, plan upgrades, refunds
- ✅ **Email System** - AWS SES with transaction emails
- ✅ **Background Jobs** - BullMQ workers for async processing
- ✅ **Webhook Handler** - Signed, idempotent processing

### Database
- ✅ **Supabase Postgres** - Type-safe, managed database
- ✅ **Row-Level Security** - Data isolation per user
- ✅ **8 Migrations** - Users, subscriptions, organizations, invoices, activity, webhooks
- ✅ **Auto Triggers** - Account creation, activity logging, notifications

### Security
- ✅ **CSRF Protection** - Timing-safe token validation
- ✅ **Rate Limiting** - Configurable per endpoint
- ✅ **Input Validation** - Zod schemas on every API
- ✅ **Security Headers** - CSP, HSTS, X-Frame-Options, etc.
- ✅ **Encrypted Logs** - Email, API keys, passwords redacted
- ✅ **HMAC Verification** - Secure webhook signature checking

### Developer Experience
- ✅ **TypeScript Strict Mode** - Full type safety
- ✅ **Testing** - Vitest + Playwright (unit, integration, E2E)
- ✅ **Structured Logging** - Pino with JSON output
- ✅ **Error Tracking** - GlitchTip (Sentry-compatible)
- ✅ **Environment Validation** - Zod-based with fail-fast startup
- ✅ **Database Types** - Auto-generated from Supabase

### AI-Ready
- ✅ **Claude Integration** - Anthropic AI ready
- ✅ **Groq API** - Ultra-fast LLM inference
- ✅ **ElevenLabs** - Text-to-speech capabilities (optional)

---

## 🔧 Tech Stack

| Layer | Technology |
|-------|-----------|
| **Framework** | Next.js 15, React 19 |
| **Language** | TypeScript (strict) |
| **Database** | Supabase (Postgres) |
| **Auth** | Supabase Auth (Oauth) |
| **Payments** | LemonSqueezy |
| **Email** | AWS SES |
| **Styling** | Scoped CSS + Tailwind |
| **Forms** | React Hook Form + Zod |
| **State** | React Query + Zustand |
| **Jobs** | BullMQ + Redis |
| **Logging** | Pino v9 |
| **Errors** | GlitchTip (Sentry) |
| **Testing** | Vitest + Playwright |
| **Deployment** | Vercel |

---

## 📋 Project Structure

```
app/
  (auth)/                  # Auth routes (login, signup)
  (dashboard)/             # Dashboard layout with sidebar
    billing/              # Subscription management
    settings/             # User settings
    dashboard/            # Main dashboard
    organizations/        # Team management
    admin/                # Admin dashboard
  api/                    # REST API routes
    auth/                 # OAuth callback
    me/                   # User profile operations
    billing/              # Payment operations
    webhooks/             # LemonSqueezy webhooks
    admin/                # Admin stats
  (legal)/                # Legal pages (terms, privacy)
  
components/
  auth/                   # AuthForm component
  shared/                 # Navbar, Sidebar, Toast, etc.
  providers/              # React Query provider
  ui/                     # shadcn components
  
lib/
  supabase/              # Supabase clients
  queries/               # React Query hooks
  env.ts                 # Environment validation
  csrf.ts / csrf-client.ts
  email.ts               # Email templates
  lemonsqueezy.ts        # Payment integration
  logger.ts              # Pino logger
  error-tracking.ts      # GlitchTip setup
  
supabase/
  migrations/            # SQL migrations
  seed.sql               # Demo data
  
workers/                 # BullMQ background jobs
  email.worker.ts
  automation.worker.ts
  
tests/
  unit/                  # Unit tests
  integration/           # API tests
  e2e/                   # Playwright tests
```

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <repo>
cd saas-boilerplate
npm install
```

### 2. Set Up Environment

```bash
cp .env.example .env.local
# Fill in all required variables
```

**Required env vars:**
- Supabase URL & keys
- LemonSqueezy API key & webhook secret
- AWS SES credentials
- Redis URL
- App URL & name

### 3. Set Up Database

```bash
# Create Supabase project first
# Copy project URL and keys to .env.local

# Run migrations
npm run db:push

# Generate types
npm run db:types
```

### 4. Run Development Server

```bash
npm run dev
# Open http://localhost:3000
```

### 5. Test

```bash
# Unit & integration tests
npm run test

# E2E tests
npm run test:e2e

# Watch mode
npm run test:watch
```

---

## 🎯 Key Features Explained

### Authentication
- **Email/Password** - Built-in with Supabase
- **OAuth** - Google, GitHub, etc. via Supabase
- **Session Management** - Secure cookies + Redis
- **Password Reset** - Email-based with secure links

### Payments
- **Checkout Flow** - Seamless LemonSqueezy integration
- **Plan Upgrades** - Instant plan changes
- **Webhook Processing** - Idempotent with duplicate detection
- **Invoice Tracking** - All transactions recorded
- **Subscription Management** - Users can upgrade, downgrade, cancel

### Multi-Tenancy
- **Organizations** - Teams with multiple users
- **Role-Based Access** - Owner, Admin, Member
- **Member Invitations** - Email-based invites
- **RLS Policies** - Database-level data isolation

### User Activity
- **Auto-Logging** - Actions tracked via triggers
- **Audit Trail** - Complete user history
- **Activity Feed** - Display on dashboard

---

## 📊 Dashboard Features

### User Dashboard
- Statistics (orgs, users, plan, days since signup)
- Recent activity feed
- Current plan display
- Quick access to settings

### Billing Portal
- Current subscription status
- Plan comparison and upgrade options
- Billing history
- Payment method management
- Cancel subscription option

### Admin Dashboard
- Total users count
- Active subscriptions
- Monthly Recurring Revenue (MRR)
- Free vs paid breakdown
- Conversion rate metrics

### Organization Dashboard
- Team member list
- Member roles
- Invite new members
- Remove members
- Organization settings

---

## 🔒 Security Features

### Built-In Protection
1. **CSRF Tokens** - Every state-changing request
2. **Rate Limiting** - Configurable per endpoint
3. **Input Validation** - Zod schemas with type coercion
4. **SQL Injection** - Parameterized queries via Supabase SDK
5. **XSS Prevention** - React's built-in escaping
6. **CORS** - Configurable by origin
7. **Security Headers** - CSP, HSTS, X-Frame-Options
8. **HTTPS Only** - Automatic with Vercel/production

### Database Security
- Row-Level Security (RLS) enforced
- Service role for admin operations only
- Anon role for public operations
- User session role for private operations

### Webhook Security
- HMAC-SHA256 signature verification
- Timing-safe constant comparison
- Endpoint authentication
- Idempotency via event deduplication

---

## 📈 Monitoring & Observability

### Logging
- Structured JSON logging with Pino
- Log levels: debug, info, warn, error
- Sensitive data redaction
- Request/response logging

### Error Tracking
- GlitchTip integration (Sentry-compatible)
- Automatic error capture
- Client and server errors
- Source map support

### Health Checks
- `/api/health` endpoint
- Database connectivity
- Redis connectivity
- External service status

---

## 🧪 Testing

### Unit Tests (Vitest)
```bash
npm run test              # Run all tests
npm run test:watch       # Watch mode
npm run test:coverage    # Coverage report
```

Includes tests for:
- API responses
- Error handling
- Validation
- Utilities

### Integration Tests
- Database operations
- API endpoints
- Webhook processing
- Email delivery

### E2E Tests (Playwright)
```bash
npm run test:e2e          # Run E2E tests
npm run test:e2e:ui       # UI mode
```

Covers:
- Sign up flow
- Login flow
- Checkout flow
- Settings management

---

## 📚 API Documentation

### Authentication Endpoints
- `POST /auth/callback` - OAuth callback handler
- `GET /api/me` - Get current user
- `PATCH /api/me` - Update profile
- `POST /api/me/delete-account` - Delete account
- `GET /api/me/export-data` - GDPR data export

### Billing Endpoints
- `POST /api/billing/checkout` - Create checkout session
- `POST /api/billing/cancel` - Cancel subscription
- `GET /api/billing/subscriptions` - Get subscription details

### Organization Endpoints
- `GET /api/orgs` - List user's organizations
- `POST /api/orgs` - Create organization
- `GET /api/orgs/[orgId]` - Get organization
- `PATCH /api/orgs/[orgId]` - Update organization
- `DELETE /api/orgs/[orgId]` - Delete organization
- `GET /api/orgs/[orgId]/members` - List members
- `POST /api/orgs/[orgId]/members` - Invite member
- `DELETE /api/orgs/[orgId]/members` - Remove member
- `PATCH /api/orgs/[orgId]/members` - Update member role

### Webhook Endpoints
- `POST /api/webhooks/lemonsqueezy` - Payment webhooks
- `POST /api/automations/user-created` - User creation hook
- `POST /api/automations/subscription-changed` - Subscription hook

### Admin Endpoints
- `GET /api/admin/stats` - Key metrics (requires auth)

---

## 🚀 Deployment

### To Vercel (Recommended)

1. **Push to GitHub**
```bash
git push origin main
```

2. **Import to Vercel**
   - Go to vercel.com
   - Click "Add New" → "Project"
   - Select your GitHub repo
   - Add environment variables
   - Click "Deploy"

3. **Configure Domain**
   - Domain settings → Add your domain
   - Update DNS records at registrar

4. **Verify Everything**
   - Test signup flow
   - Test payment webhook
   - Check email delivery

See [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for complete instructions.

---

## 📋 Pre-Flight Checklist

Before launching to production:

- [ ] All environment variables configured
- [ ] Database migrations run successfully
- [ ] LemonSqueezy webhook configured
- [ ] SES domain verified and production mode enabled
- [ ] SSL certificate active
- [ ] Redis instance running
- [ ] Error tracking (GlitchTip) set up
- [ ] All tests passing
- [ ] Terms of Service updated
- [ ] Privacy Policy updated
- [ ] Admin user created
- [ ] Backup and disaster recovery plan

See [PRODUCTION_CHECKLIST.md](./PRODUCTION_CHECKLIST.md) for full checklist.

---

## 🐛 Troubleshooting

### Database connection error
```bash
# Verify DATABASE_URL in .env.local
# Check Supabase connection pooling is enabled
npm run db:types  # Regenerate types
```

### Payment webhook not processing
```bash
# Verify LEMONSQUEEZY_WEBHOOK_SECRET matches LemonSqueezy dashboard
# Check webhook endpoint in LemonSqueezy: https://yourdomain.com/api/webhooks/lemonsqueezy
# Review logs: vercel logs
```

### Emails not sending
```bash
# Verify SES_FROM_EMAIL is verified in AWS SES
# Check SES is in production mode (not sandbox)
# Review SES metrics: aws ses describe-configuration-set
```

### Auth not working
```bash
# Verify NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
# Check Supabase Auth providers are enabled
# Review Supabase logs
```

---

## 📚 Learning Resources

- [Next.js Guide](https://nextjs.org/docs)
- [Supabase Guide](https://supabase.com/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [React Query Docs](https://tanstack.com/query/latest)
- [Zod Validation](https://zod.dev)

---

## 🤝 Contributing

This is a boilerplate - customize it for your needs!

Recommended customizations:
1. Update branding (colors, fonts, logo)
2. Modify plan limits and pricing
3. Add your features
4. Customize email templates
5. Update legal documents

---

## 📄 License

This boilerplate is provided as-is. Modify freely for commercial use.

---

## 🎓 Where to Go From Here

1. **Customize branding** - Update CLAUDE.md color palette
2. **Add features** - Use API patterns already established
3. **Deploy to staging** - Test real payment flow
4. **Set up monitoring** - Enable error tracking and logs
5. **Go live** - Follow DEPLOYMENT_GUIDE.md

---

## 🚀 Next Steps

1. Clone the repository
2. Copy `.env.example` to `.env.local`
3. Fill in environment variables
4. Run `npm install && npm run db:push`
5. Start development: `npm run dev`
6. Visit http://localhost:3000

**Ready to ship!** 🎉

---

**Last Updated**: January 2024
**Status**: Production Ready ✅
**Maintenance**: Active
