import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

export const metadata = { title: 'Refund Policy' }

function RefundStyles() {
  return (
    <ScopedStyle>{`
      .refund-root {
        max-width: 900px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
      }
      .refund-header {
        margin-bottom: 3rem;
      }
      .refund-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2.5rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        margin: 0 0 0.5rem;
      }
      .refund-updated {
        font-size: 0.85rem;
        color: #8b7fa8;
        margin: 0;
      }
      .refund-content {
        color: #4b4466;
        line-height: 1.7;
      }
      .refund-content h2 {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.3rem;
        font-weight: 800;
        color: #1a1625;
        margin: 2rem 0 1rem;
        letter-spacing: -0.02em;
      }
      .refund-content p {
        margin: 1rem 0;
      }
      .refund-content ul {
        margin: 1rem 0 1rem 1.5rem;
      }
      .refund-content li {
        margin: 0.5rem 0;
      }
      .refund-content a {
        color: #7c3aed;
        text-decoration: none;
      }
      .refund-content a:hover {
        text-decoration: underline;
      }
      .refund-footer {
        margin-top: 3rem;
        padding-top: 2rem;
        border-top: 1px solid rgba(124, 58, 237, 0.1);
        font-size: 0.9rem;
        color: #8b7fa8;
      }
      .refund-footer a {
        color: #7c3aed;
        text-decoration: none;
      }
      .refund-footer a:hover {
        text-decoration: underline;
      }
    `}</ScopedStyle>
  )
}

export default function RefundPolicyPage() {
  return (
    <div className="refund-root">
      <RefundStyles />
      
      <header className="refund-header">
        <h1 className="refund-title">Refund Policy</h1>
        <p className="refund-updated">Last updated: March 8, 2026</p>
      </header>

      <article className="refund-content">
        <h2>30-Day Money-Back Guarantee</h2>
        <p>
          We stand behind the quality of SassKit. If you're not completely satisfied with your purchase, 
          we offer a full refund within 30 days of purchase—no questions asked.
        </p>

        <h2>Refund Eligibility</h2>
        <p>Refunds are available if:</p>
        <ul>
          <li>The product does not work as documented or presented</li>
          <li>Critical bugs prevent the product from functioning</li>
          <li>License key activation fails and cannot be restored</li>
          <li>Request is made within 30 days of original purchase</li>
        </ul>

        <p>
          We believe this is more than fair—it lets you evaluate SassKit risk-free before committing 
          to a commercial license.
        </p>

        <h2>What's NOT Refundable</h2>
        <p>Refunds are NOT available for:</p>
        <ul>
          <li>Change of mind or project cancellation</li>
          <li>Difficulty understanding documentation or integration</li>
          <li>Incompatibility with your existing tools or services</li>
          <li>Feature requests (we welcome feedback, but refunds aren't the solution)</li>
          <li>Requests made after 30 days from purchase</li>
        </ul>

        <h2>How to Request a Refund</h2>
        <p>Requesting a refund is simple:</p>
        <ol style={{ marginLeft: '1.5rem' }}>
          <li>Email us at <a href="mailto:refunds@sasskit.io">refunds@sasskit.io</a></li>
          <li>Include your order ID and reason for refund</li>
          <li>We'll review and respond within 2 business days</li>
          <li>Once approved, refund lands in your account within 5-7 business days</li>
        </ol>

        <h2>Refund Timeline</h2>
        <ul>
          <li><strong>Response Time:</strong> 2 business days</li>
          <li><strong>Processing Time:</strong> 5-7 business days after approval</li>
          <li><strong>Refund Method:</strong> Same payment method used for purchase</li>
        </ul>

        <h2>Subscription Cancellations</h2>
        <p>
          For annual subscriptions ($19/month tier), you can cancel anytime. 
          Refunds for partial months are prorated.
        </p>
        <ul>
          <li>Cancel anytime in your account dashboard</li>
          <li>No cancellation fee</li>
          <li>Access continues through end of billing period</li>
          <li>Refund for unused time processed within 7 days</li>
        </ul>

        <h2>Questions?</h2>
        <p>
          Have questions about refunds? We're here to help! Contact us at{' '}
          <a href="mailto:support@sasskit.io">support@sasskit.io</a> or visit our{' '}
          <Link href="/legal/contact">contact page</Link>.
        </p>

        <h2>Our Commitment</h2>
        <p>
          We want you to feel confident purchasing SassKit. This 30-day guarantee reflects 
          our confidence in the product and our commitment to customer satisfaction.
        </p>
      </article>

      <footer className="refund-footer">
        <p>
          Have other questions? Check out our{' '}
          <Link href="/legal/terms">Terms of Service</Link> or{' '}
          <Link href="/legal/privacy">Privacy Policy</Link>.
        </p>
      </footer>
    </div>
  )
}
