import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'
import { clientEnv } from '@/lib/env'

export const metadata = { title: 'Terms of Service' }

function TermsStyles() {
  return (
    <ScopedStyle>{`
      .terms-root {
        max-width: 900px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
      }
      .terms-header {
        margin-bottom: 3rem;
      }
      .terms-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2.5rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        margin: 0 0 0.5rem;
      }
      .terms-updated {
        font-size: 0.85rem;
        color: #8b7fa8;
        margin: 0;
      }
      .terms-content {
        color: #4b4466;
        line-height: 1.7;
      }
      .terms-content h2 {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.3rem;
        font-weight: 800;
        color: #1a1625;
        margin: 2rem 0 1rem;
        letter-spacing: -0.02em;
      }
      .terms-content p {
        margin: 1rem 0;
      }
      .terms-content ol {
        margin: 1rem 0 1rem 1.5rem;
      }
      .terms-content li {
        margin: 0.5rem 0;
      }
      .terms-link {
        color: #7c3aed;
        text-decoration: none;
        font-weight: 600;
      }
      .terms-link:hover {
        text-decoration: underline;
      }
      .terms-footer {
        margin-top: 3rem;
        padding-top: 2rem;
        border-top: 1px solid rgba(124,58,237,0.1);
        text-align: center;
        font-size: 0.85rem;
        color: #8b7fa8;
      }
    `}</ScopedStyle>
  )
}

export default function TermsPage() {
  const appName = clientEnv.NEXT_PUBLIC_APP_NAME

  return (
    <div className="terms-root">
      <TermsStyles />

      <div className="terms-header">
        <h1 className="terms-title">Terms of Service</h1>
        <p className="terms-updated">Last updated: March 8, 2026</p>
      </div>

      <div className="terms-content">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or using {appName}, you agree to these Terms of Service. If you do not agree, do not use the
          service.
        </p>

        <h2>2. License and Permitted Use</h2>
        <p>
          Subject to these terms, we grant you a limited, non-exclusive, non-transferable license to access and use
          the service for your internal business operations. This license does not transfer any ownership rights.
        </p>
        <ol>
          <li>Do not copy, resell, sublicense, or commercially exploit the service except as expressly permitted.</li>
          <li>Do not reverse engineer, disable security controls, or interfere with platform operations.</li>
          <li>Do not use the service in violation of law, contract, or third-party rights.</li>
          <li>Do not remove copyright, trademark, or other proprietary notices.</li>
        </ol>

        <h2>3. Disclaimer</h2>
        <p>
          The service is provided on an &apos;as is&apos; and &apos;as available&apos; basis without warranties of any kind, whether express
          or implied, including warranties of merchantability, fitness for a particular purpose, and non-infringement.
        </p>

        <h2>4. Limitation of Liability</h2>
        <p>
          To the maximum extent permitted by law, we are not liable for indirect, incidental, special, consequential,
          or punitive damages, or for any loss of profits, revenues, data, or goodwill arising from your use of the
          service.
        </p>

        <h2>5. Changes</h2>
        <p>
          We may update these terms from time to time. Continued use of the service after an update means you accept
          the revised terms.
        </p>

        <h2>6. Contact</h2>
        <p>
          If you have questions about these terms, please <Link href="/support" className="terms-link">contact support</Link>.
        </p>
      </div>

      <div className="terms-footer">
        <p>
          Copyright {new Date().getFullYear()} {appName}. All rights reserved.{' '}
          <Link href="/privacy" className="terms-link">Privacy Policy</Link>
        </p>
      </div>
    </div>
  )
}
