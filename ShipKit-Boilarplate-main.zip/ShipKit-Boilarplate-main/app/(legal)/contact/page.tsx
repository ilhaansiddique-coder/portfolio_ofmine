import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

export const metadata = { title: 'Contact & Support' }

function ContactStyles() {
  return (
    <ScopedStyle>{`
      .contact-root {
        max-width: 900px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
      }
      .contact-header {
        margin-bottom: 3rem;
      }
      .contact-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2.5rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        margin: 0 0 0.5rem;
      }
      .contact-subtitle {
        font-size: 1.1rem;
        color: #6b5f80;
        margin: 1rem 0 0;
      }
      .contact-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        margin: 3rem 0;
      }
      .contact-card {
        background: #fff;
        border: 1.5px solid rgba(124, 58, 237, 0.07);
        border-radius: 1.125rem;
        padding: 2rem;
        transition: all 0.2s ease;
      }
      .contact-card:hover {
        border: 1.5px solid rgba(124, 58, 237, 0.15);
        transform: translateY(-2px);
        box-shadow: 0 8px 16px rgba(124, 58, 237, 0.08);
      }
      .contact-card h3 {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.2rem;
        font-weight: 800;
        color: #1a1625;
        margin: 0 0 0.5rem;
      }
      .contact-card p {
        color: #6b5f80;
        margin: 0.5rem 0;
        font-size: 0.95rem;
      }
      .contact-card a {
        color: #7c3aed;
        text-decoration: none;
        font-weight: 500;
      }
      .contact-card a:hover {
        text-decoration: underline;
      }
      .contact-content {
        color: #4b4466;
        line-height: 1.7;
      }
      .contact-content h2 {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.3rem;
        font-weight: 800;
        color: #1a1625;
        margin: 2rem 0 1rem;
        letter-spacing: -0.02em;
      }
      .contact-content p {
        margin: 1rem 0;
      }
      .contact-form {
        background: #fff;
        border: 1.5px solid rgba(124, 58, 237, 0.07);
        border-radius: 1.125rem;
        padding: 2rem;
        margin: 2rem 0;
      }
      .contact-form-group {
        margin-bottom: 1.5rem;
      }
      .contact-form-group label {
        display: block;
        font-weight: 600;
        color: #1a1625;
        margin-bottom: 0.5rem;
        font-size: 0.95rem;
      }
      .contact-form-group input,
      .contact-form-group textarea {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid rgba(124, 58, 237, 0.2);
        border-radius: 0.75rem;
        font-family: inherit;
        font-size: 0.95rem;
        color: #1a1625;
        transition: border 0.2s ease;
      }
      .contact-form-group input:focus,
      .contact-form-group textarea:focus {
        outline: none;
        border: 1.5px solid #7c3aed;
        box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.1);
      }
      .contact-form-group textarea {
        resize: vertical;
        min-height: 120px;
      }
      .contact-button {
        background: #7c3aed;
        color: white;
        border: none;
        padding: 0.75rem 2rem;
        border-radius: 0.75rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 0.95rem;
      }
      .contact-button:hover {
        background: #6d28d9;
        transform: translateY(-2px);
      }
      .contact-button:active {
        transform: translateY(0);
      }
      .contact-sla {
        background: rgba(124, 58, 237, 0.05);
        border-left: 4px solid #7c3aed;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin: 2rem 0;
      }
      .contact-sla h3 {
        font-family: var(--font-heading), sans-serif;
        font-weight: 800;
        color: #1a1625;
        margin: 0 0 0.5rem;
      }
      .contact-sla p {
        color: #6b5f80;
        margin: 0.5rem 0;
      }
      .contact-footer {
        margin-top: 3rem;
        padding-top: 2rem;
        border-top: 1px solid rgba(124, 58, 237, 0.1);
        font-size: 0.9rem;
        color: #8b7fa8;
      }
      .contact-footer a {
        color: #7c3aed;
        text-decoration: none;
      }
      .contact-footer a:hover {
        text-decoration: underline;
      }
    `}</ScopedStyle>
  )
}

export default function ContactPage() {
  return (
    <div className="contact-root">
      <ContactStyles />
      
      <header className="contact-header">
        <h1 className="contact-title">Contact & Support</h1>
        <p className="contact-subtitle">
          We're here to help. Get in touch with our support team.
        </p>
      </header>

      <div className="contact-grid">
        <div className="contact-card">
          <h3>📧 Email</h3>
          <p>support@sasskit.io</p>
          <p style={{ fontSize: '0.85rem', color: '#8b7fa8' }}>
            Response time: Typically 2 hours, max 24 hours
          </p>
        </div>

        <div className="contact-card">
          <h3>🔗 Community</h3>
          <p>
            <a href="https://discord.gg/sasskit" target="_blank" rel="noopener noreferrer">
              Join Discord
            </a>
          </p>
          <p style={{ fontSize: '0.85rem', color: '#8b7fa8' }}>
            Connect with other developers, ask questions, share tips
          </p>
        </div>

        <div className="contact-card">
          <h3>💬 GitHub</h3>
          <p>
            <a href="https://github.com/aknirob/SassKit/issues" target="_blank" rel="noopener noreferrer">
              Issues & Discussions
            </a>
          </p>
          <p style={{ fontSize: '0.85rem', color: '#8b7fa8' }}>
            Report bugs, request features, contribute
          </p>
        </div>

        <div className="contact-card">
          <h3>📊 Status</h3>
          <p>
            <a href="https://status.sasskit.io" target="_blank" rel="noopener noreferrer">
              System Status Page
            </a>
          </p>
          <p style={{ fontSize: '0.85rem', color: '#8b7fa8' }}>
            Real-time service status and updates
          </p>
        </div>

        <div className="contact-card">
          <h3>💳 Refunds</h3>
          <p>
            <a href="mailto:refunds@sasskit.io">refunds@sasskit.io</a>
          </p>
          <p style={{ fontSize: '0.85rem', color: '#8b7fa8' }}>
            30-day money-back guarantee
          </p>
        </div>

        <div className="contact-card">
          <h3>🚨 Security</h3>
          <p>
            <a href="mailto:security@sasskit.io">security@sasskit.io</a>
          </p>
          <p style={{ fontSize: '0.85rem', color: '#8b7fa8' }}>
            Report security vulnerabilities responsibly
          </p>
        </div>
      </div>

      <div className="contact-sla">
        <h3>Our Support Commitment</h3>
        <p>
          <strong>Response Time:</strong> We aim to respond to all inquiries within 2 hours during business hours,
          and within 24 hours for all other times.
        </p>
        <p>
          <strong>Business Hours:</strong> Monday - Friday, 9am - 5pm CST
        </p>
        <p>
          <strong>Holidays:</strong> We may have slower response times on major holidays.
        </p>
      </div>

      <article className="contact-content">
        <h2>How We Can Help</h2>
        <ul style={{ marginLeft: '1.5rem' }}>
          <li><strong>Setup Issues:</strong> Problems getting started or deploying the boilerplate</li>
          <li><strong>Technical Questions:</strong> How to customize, extend, or integrate with other services</li>
          <li><strong>Bug Reports:</strong> Issues with the codebase that need to be fixed</li>
          <li><strong>License Questions:</strong> Questions about your commercial license</li>
          <li><strong>Billing & Refunds:</strong> Questions about your purchase or refund eligibility</li>
          <li><strong>Feature Requests:</strong> Ideas for improvements (we'd love to hear them!)</li>
        </ul>

        <h2>Before Reaching Out</h2>
        <p>
          To help us serve you faster, please check our resources first:
        </p>
        <ul style={{ marginLeft: '1.5rem' }}>
          <li><Link href="/legal/refund-policy">Refund Policy</Link> - If asking about refunds</li>
          <li><a href="/QUICKSTART.md">Quick Start Guide</a> - If setting up for the first time</li>
          <li><a href="/TROUBLESHOOTING_GUIDE.md">Troubleshooting Guide</a> - Common issues & solutions</li>
          <li><a href="/API_DOCUMENTATION.md">API Documentation</a> - Complete API reference</li>
          <li><a href="/CUSTOMIZATION_GUIDE.md">Customization Guide</a> - How to customize everything</li>
        </ul>

        <h2>Response Time</h2>
        <p>
          Here's what to expect based on the type of inquiry:
        </p>
        <ul style={{ marginLeft: '1.5rem' }}>
          <li><strong>Billing & Refund Requests:</strong> 2 business hours (priority)</li>
          <li><strong>Setup & Configuration:</strong> 2-4 hours</li>
          <li><strong>Bug Reports:</strong> 4-24 hours (depends on severity)</li>
          <li><strong>Feature Requests:</strong> 1-2 business days</li>
          <li><strong>Security Reports:</strong> 1 hour (critical)</li>
        </ul>

        <h2>Getting the Best Support</h2>
        <p>
          When reaching out, including these details helps us help you faster:
        </p>
        <ul style={{ marginLeft: '1.5rem' }}>
          <li>Your order/license ID</li>
          <li>What you're trying to do</li>
          <li>What's not working (error messages, screenshots)</li>
          <li>Your setup (Node version, OS, deployment platform)</li>
          <li>Steps to reproduce the issue</li>
        </ul>

        <h2>Questions?</h2>
        <p>
          Don't see your question answered? Email us at{' '}
          <a href="mailto:support@sasskit.io">support@sasskit.io</a> or join our{' '}
          <a href="https://discord.gg/sasskit" target="_blank" rel="noopener noreferrer">
            Discord community
          </a>{' '}
          where you can chat with other developers and our team.
        </p>
      </article>

      <footer className="contact-footer">
        <p>
          See also: <Link href="/legal/refund-policy">Refund Policy</Link>,{' '}
          <Link href="/legal/terms">Terms of Service</Link>, and{' '}
          <Link href="/legal/privacy">Privacy Policy</Link>.
        </p>
      </footer>
    </div>
  )
}
