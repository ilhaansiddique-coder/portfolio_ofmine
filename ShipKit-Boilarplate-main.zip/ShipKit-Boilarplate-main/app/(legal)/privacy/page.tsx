import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'
import { clientEnv } from '@/lib/env'

export const metadata = { title: 'Privacy Policy' }

function PrivacyStyles() {
  return (
    <ScopedStyle>{`
      .privacy-root {
        max-width: 900px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
      }
      .privacy-header {
        margin-bottom: 3rem;
      }
      .privacy-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2.5rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        margin: 0 0 0.5rem;
      }
      .privacy-updated {
        font-size: 0.85rem;
        color: #8b7fa8;
        margin: 0;
      }
      .privacy-content {
        color: #4b4466;
        line-height: 1.7;
      }
      .privacy-content h2 {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.3rem;
        font-weight: 800;
        color: #1a1625;
        margin: 2rem 0 1rem;
        letter-spacing: -0.02em;
      }
      .privacy-content p {
        margin: 1rem 0;
      }
      .privacy-content ul {
        margin: 1rem 0 1rem 1.5rem;
      }
      .privacy-content li {
        margin: 0.5rem 0;
      }
      .privacy-link {
        color: #7c3aed;
        text-decoration: none;
        font-weight: 600;
      }
      .privacy-link:hover {
        text-decoration: underline;
      }
      .privacy-footer {
        margin-top: 3rem;
        padding-top: 2rem;
        border-top: 1px solid rgba(124,58,237,0.1);
        text-align: center;
        font-size: 0.85rem;
        color: #8b7fa8;
      }
    `}</ScopedStyle>
  )
}

export default function PrivacyPage() {
  const appName = clientEnv.NEXT_PUBLIC_APP_NAME

  return (
    <div className="privacy-root">
      <PrivacyStyles />

      <div className="privacy-header">
        <h1 className="privacy-title">Privacy Policy</h1>
        <p className="privacy-updated">Last updated: March 8, 2026</p>
      </div>

      <div className="privacy-content">
        <h2>1. Information We Collect</h2>
        <p>We may collect account details, profile information, billing metadata, usage data, and support messages.</p>
        <ul>
          <li>Name, email address, and profile details you provide.</li>
          <li>Authentication and account metadata required to operate the service.</li>
          <li>Billing and subscription metadata from payment providers.</li>
          <li>Logs, device information, and product usage events.</li>
        </ul>

        <h2>2. How We Use Information</h2>
        <p>We use personal data to operate, secure, improve, and support the service.</p>
        <ul>
          <li>Provide access to {appName} and its core features.</li>
          <li>Process subscriptions, invoices, and account changes.</li>
          <li>Respond to support requests and service communications.</li>
          <li>Monitor abuse, fraud, reliability, and security events.</li>
        </ul>

        <h2>3. Sharing</h2>
        <p>
          We may share information with infrastructure, payment, analytics, and support vendors as needed to operate the
          service, subject to contractual and security controls.
        </p>

        <h2>4. Retention</h2>
        <p>
          We retain data for as long as needed to provide the service, comply with legal obligations, resolve disputes,
          and enforce agreements.
        </p>

        <h2>5. Your Rights</h2>
        <p>
          Depending on your location, you may have rights to access, correct, delete, restrict, or export your
          information.
        </p>

        <h2>6. Contact</h2>
        <p>
          If you have questions about this policy, please <Link href="/support" className="privacy-link">contact support</Link>.
        </p>
      </div>

      <div className="privacy-footer">
        <p>
          Copyright {new Date().getFullYear()} {appName}. All rights reserved.{' '}
          <Link href="/terms" className="privacy-link">Terms of Service</Link>
        </p>
      </div>
    </div>
  )
}
