'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import { useCurrentUser, useUserSubscriptions } from '@/lib/queries/hooks'
import { PLAN_DISPLAY, PLAN_LIMITS, normalizePlan } from '@/lib/plans'
import type { PlanName } from '@/lib/plans'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

type PaymentProcessor = 'lemonsqueezy' | 'stripe'
type BillingInterval = 'monthly' | 'yearly'

function BillingStyles() {
  return (
    <ScopedStyle>{`
      .bl-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 900px;
        padding-bottom: 2rem;
      }

      /* Header */
      .bl-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .bl-eyebrow__dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: bl-pulse 2s ease-in-out infinite;
      }
      @keyframes bl-pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
      }
      .bl-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .bl-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }

      /* Current Plan Card */
      .bl-current-plan {
        background: linear-gradient(135deg, #f8f4eb 0%, #fff 100%);
        border: 1.5px solid rgba(124,58,237,0.12);
        border-radius: 1.125rem;
        padding: 2rem;
        animation: bl-fade-up 0.4s ease both;
      }
      .bl-plan-label {
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.5rem;
      }
      .bl-plan-name {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.5rem;
        font-weight: 900;
        color: #1a1625;
        margin-bottom: 0.5rem;
      }
      .bl-plan-price {
        font-size: 1.25rem;
        font-weight: 700;
        color: #7c3aed;
        margin-bottom: 1rem;
      }
      .bl-plan-features {
        list-style: none;
        padding: 0;
        margin: 1rem 0;
      }
      .bl-plan-features li {
        padding: 0.35rem 0;
        font-size: 0.85rem;
        color: #4b4466;
        display: flex;
        align-items: center;
        gap: 0.4rem;
      }
      .bl-plan-features li::before {
        content: '✓';
        color: #7c3aed;
        font-weight: 900;
      }
      .bl-status {
        display: inline-block;
        padding: 0.4rem 0.8rem;
        background: rgba(124,58,237,0.1);
        color: #7c3aed;
        border-radius: 0.5rem;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        margin-top: 1rem;
      }
      .bl-status.active {
        background: rgba(34,197,94,0.1);
        color: #22c55e;
      }
      .bl-status.inactive {
        background: rgba(239,68,68,0.1);
        color: #ef4444;
      }

      /* Action Button */
      .bl-btn {
        padding: 0.7rem 1.5rem;
        font-size: 0.85rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.18s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        font-family: var(--font-body), sans-serif;
        margin-top: 1rem;
      }
      .bl-btn--primary {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
      }
      .bl-btn--primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .bl-btn--secondary {
        background: rgba(124,58,237,0.06);
        color: #7c3aed;
        border: 1.5px solid rgba(124,58,237,0.12);
      }
      .bl-btn--secondary:hover {
        background: rgba(124,58,237,0.1);
      }

      /* Upgrade Plans Section */
      .bl-section {
        margin-top: 2rem;
      }
      .bl-section-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.25rem;
        font-weight: 800;
        color: #1a1625;
        letter-spacing: -0.02em;
        margin-bottom: 1rem;
      }
      .bl-plans-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 1rem;
      }
      .bl-plan-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        transition: all 0.25s ease;
        animation: bl-fade-up 0.4s ease both;
      }
      .bl-plan-card:nth-child(2) {
        animation-delay: 0.1s;
      }
      .bl-plan-card:nth-child(3) {
        animation-delay: 0.2s;
      }
      .bl-plan-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(26,22,37,0.08);
        border-color: rgba(124,58,237,0.15);
      }
      .bl-plan-card.current {
        border-color: rgba(124,58,237,0.25);
        background: rgba(124,58,237,0.02);
      }
      .bl-card-name {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.1rem;
        font-weight: 800;
        color: #1a1625;
        margin-bottom: 0.5rem;
      }
      .bl-card-price {
        font-size: 1.3rem;
        font-weight: 700;
        color: #7c3aed;
        margin-bottom: 1rem;
      }
      .bl-card-features {
        list-style: none;
        padding: 0;
        margin: 1rem 0;
        font-size: 0.8rem;
      }
      .bl-card-features li {
        padding: 0.25rem 0;
        color: #6b5f80;
        display: flex;
        align-items: center;
        gap: 0.35rem;
      }
      .bl-card-features li::before {
        content: '✓';
        color: #7c3aed;
        font-weight: 900;
      }
      .bl-card-btn {
        width: 100%;
        padding: 0.65rem 1rem;
        margin-top: 1rem;
        border: 1.5px solid rgba(124,58,237,0.12);
        background: rgba(124,58,237,0.06);
        color: #7c3aed;
        border-radius: 0.5rem;
        font-size: 0.8rem;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .bl-card-btn:hover {
        background: rgba(124,58,237,0.1);
      }
      .bl-card-btn.current {
        opacity: 0.5;
        cursor: default;
        pointer-events: none;
      }
      .bl-card-btn--primary {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        border: none;
      }
      .bl-card-btn--primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
      }

      /* Billing History */
      .bl-history {
        margin-top: 2rem;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        animation: bl-fade-up 0.4s ease 0.3s both;
      }
      .bl-history-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.1rem;
        font-weight: 800;
        color: #1a1625;
        margin-bottom: 1rem;
      }
      .bl-invoice-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.85rem;
      }
      .bl-invoice-table thead {
        border-bottom: 1.5px solid rgba(124,58,237,0.1);
      }
      .bl-invoice-table thead th {
        text-align: left;
        padding: 0.75rem 0;
        font-weight: 700;
        color: #6b5f80;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
      }
      .bl-invoice-table tbody tr {
        border-bottom: 1px solid rgba(124,58,237,0.05);
        transition: background 0.2s ease;
      }
      .bl-invoice-table tbody tr:hover {
        background: rgba(124,58,237,0.02);
      }
      .bl-invoice-table td {
        padding: 1rem 0;
        color: #4b4466;
      }
      .bl-invoice-empty {
        text-align: center;
        padding: 2rem 1rem;
        color: #8b7fa8;
      }

      /* Payment Method */
      .bl-payment {
        margin-top: 2rem;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        animation: bl-fade-up 0.4s ease 0.4s both;
      }
      .bl-payment-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.1rem;
        font-weight: 800;
        color: #1a1625;
        margin-bottom: 1rem;
      }
      .bl-payment-method {
        background: rgba(124,58,237,0.02);
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        padding: 1rem;
        margin-bottom: 1rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .bl-payment-info {
        font-size: 0.9rem;
      }
      .bl-payment-info strong {
        color: #1a1625;
        display: block;
      }
      .bl-payment-info span {
        color: #8b7fa8;
        font-size: 0.8rem;
      }
      .bl-payment-link {
        color: #7c3aed;
        text-decoration: none;
        font-weight: 600;
        font-size: 0.85rem;
        cursor: pointer;
        transition: color 0.18s ease;
      }
      .bl-payment-link:hover {
        color: #6d28d9;
      }

      /* Processor & Interval Selection */
      .bl-selector {
        margin-bottom: 2rem;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        animation: bl-fade-up 0.4s ease 0.15s both;
      }
      .bl-selector-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        margin-bottom: 1rem;
      }
      .bl-selector-group {
        margin-bottom: 1.5rem;
      }
      .bl-selector-label {
        display: block;
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #6b5f80;
        margin-bottom: 0.75rem;
      }
      .bl-selector-options {
        display: flex;
        gap: 0.75rem;
        flex-wrap: wrap;
      }
      .bl-selector-btn {
        padding: 0.65rem 1.25rem;
        border: 1.5px solid rgba(124,58,237,0.12);
        background: rgba(124,58,237,0.04);
        color: #6b5f80;
        border-radius: 0.75rem;
        font-size: 0.8rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .bl-selector-btn:hover {
        background: rgba(124,58,237,0.08);
        border-color: rgba(124,58,237,0.2);
      }
      .bl-selector-btn.active {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        border-color: #7c3aed;
      }
      .bl-selector-hint {
        font-size: 0.75rem;
        color: #8b7fa8;
        margin-top: 0.5rem;
        padding-left: 0;
      }

      @keyframes bl-fade-up {
        from {
          opacity: 0;
          transform: translateY(8px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
    `}</ScopedStyle>
  )
}

export default function BillingPage() {
  const { data: user, isLoading: userLoading } = useCurrentUser()
  const { data: subscription } = useUserSubscriptions()
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [selectedProcessor, setSelectedProcessor] = useState<PaymentProcessor>('lemonsqueezy')
  const [billingInterval, setBillingInterval] = useState<BillingInterval>('monthly')

  const currentPlan = useMemo(() => normalizePlan(user?.plan), [user?.plan])

  if (userLoading) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center' }}>
        <p style={{ color: '#8b7fa8' }}>Loading billing information...</p>
      </div>
    )
  }

  if (!user) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center' }}>
        <p style={{ color: '#ef4444' }}>Unable to load billing information</p>
      </div>
    )
  }

  const handleCheckout = async (plan: PlanName) => {
    if (plan === currentPlan) return

    try {
      const response = await fetch('/api/billing/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: plan,
          processor: selectedProcessor,
          billingInterval,
        }),
      })

      const data = await response.json()
      if (data.error) {
        setToastMessage(`Error: ${data.error}`)
        return
      }

      if (data.data?.checkoutUrl) {
        window.location.href = data.data.checkoutUrl
      }
    } catch (error) {
      setToastMessage('Failed to initiate checkout')
      console.error(error)
    }
  }

  const handleCancelSubscription = async () => {
    if (!confirm('Are you sure? You will lose access to paid features.')) return

    try {
      const response = await fetch('/api/billing/cancel', {
        method: 'POST',
      })

      const data = await response.json()
      if (data.error) {
        setToastMessage(`Error: ${data.error}`)
      } else {
        setToastMessage('Subscription cancelled. Changes will take effect at end of billing period.')
      }
    } catch (error) {
      setToastMessage('Failed to cancel subscription')
      console.error(error)
    }
  }

  const plans: PlanName[] = ['free', 'basic', 'pro']
  const statusDisplay =
    user.subscription_status === 'active'
      ? { label: 'Active', class: 'active' }
      : user.subscription_status === 'paused'
        ? { label: 'Paused', class: 'inactive' }
        : user.subscription_status === 'cancelled'
          ? { label: 'Cancelled', class: 'inactive' }
          : { label: 'Inactive', class: 'inactive' }

  return (
    <>
      <BillingStyles />
      <div className="bl-root">
        {/* Header */}
        <div>
          <div className="bl-eyebrow">
            <span className="bl-eyebrow__dot" />
            Billing
          </div>
          <h1 className="bl-title">Billing & Subscription</h1>
          <p className="bl-subtitle">Manage your plan and payment method</p>
        </div>

        {/* Current Plan */}
        <div className="bl-current-plan">
          <div className="bl-plan-label">Current Plan</div>
          <div className="bl-plan-name">{PLAN_DISPLAY[currentPlan].name}</div>
          <div className="bl-plan-price">{PLAN_DISPLAY[currentPlan].price}</div>

          <ul className="bl-plan-features">
            {PLAN_LIMITS[currentPlan].features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>

          <div className={`bl-status ${statusDisplay.class}`}>
            {statusDisplay.label}
          </div>

          {currentPlan !== 'free' && user.subscription_status === 'active' && (
            <>
              <p style={{ fontSize: '0.8rem', color: '#8b7fa8', marginTop: '1rem' }}>
                {subscription?.current_period_end &&
                  `Renews on ${new Date(subscription.current_period_end).toLocaleDateString()}`}
              </p>
              <button className="bl-btn bl-btn--secondary" onClick={handleCancelSubscription}>
                Cancel Subscription
              </button>
            </>
          )}

          {currentPlan === 'free' && (
            <p style={{ fontSize: '0.8rem', color: '#8b7fa8', marginTop: '1rem' }}>
              Upgrade to Pro to unlock unlimited projects and advanced features
            </p>
          )}
        </div>

        {/* Upgrade Section */}
        {currentPlan !== 'pro' && (
          <>
            {/* Processor & Interval Selection */}
            <div className="bl-selector">
              <div className="bl-selector-title">Checkout Options</div>

              <div className="bl-selector-group">
                <label className="bl-selector-label">Payment Processor</label>
                <div className="bl-selector-options">
                  <button
                    className={`bl-selector-btn ${selectedProcessor === 'lemonsqueezy' ? 'active' : ''}`}
                    onClick={() => setSelectedProcessor('lemonsqueezy')}
                  >
                    🍋 LemonSqueezy
                  </button>
                  <button
                    className={`bl-selector-btn ${selectedProcessor === 'stripe' ? 'active' : ''}`}
                    onClick={() => setSelectedProcessor('stripe')}
                  >
                    ⛓️ Stripe
                  </button>
                </div>
                <p className="bl-selector-hint">
                  Choose your preferred payment processor for checkout and billing
                </p>
              </div>

              <div className="bl-selector-group">
                <label className="bl-selector-label">Billing Interval</label>
                <div className="bl-selector-options">
                  <button
                    className={`bl-selector-btn ${billingInterval === 'monthly' ? 'active' : ''}`}
                    onClick={() => setBillingInterval('monthly')}
                  >
                    📅 Monthly
                  </button>
                  <button
                    className={`bl-selector-btn ${billingInterval === 'yearly' ? 'active' : ''}`}
                    onClick={() => setBillingInterval('yearly')}
                  >
                    📊 Yearly (Save 17%)
                  </button>
                </div>
                <p className="bl-selector-hint">
                  Yearly plans offer a 17% discount compared to monthly billing
                </p>
              </div>
            </div>

            {/* Plans Grid */}
            <div className="bl-section">
              <h2 className="bl-section-title">Upgrade Your Plan</h2>
              <div className="bl-plans-grid">
                {plans.map((plan) => (
                  <div
                    key={plan}
                    className={`bl-plan-card ${plan === currentPlan ? 'current' : ''}`}
                  >
                    <div className="bl-card-name">{PLAN_DISPLAY[plan].name}</div>
                    <div className="bl-card-price">{PLAN_DISPLAY[plan].price}</div>
                    <ul className="bl-card-features">
                      {PLAN_LIMITS[plan].features.map((feature) => (
                        <li key={feature}>{feature}</li>
                      ))}
                    </ul>
                    <button
                      className={`bl-card-btn ${plan === currentPlan ? 'current' : ''} ${plan !== 'free' ? 'bl-card-btn--primary' : ''}`}
                      onClick={() => handleCheckout(plan)}
                      disabled={plan === currentPlan}
                    >
                      {plan === currentPlan ? 'Current Plan' : `Upgrade to ${PLAN_DISPLAY[plan].name}`}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Billing History */}
        <div className="bl-history">
          <h2 className="bl-history-title">Billing History</h2>
          <table className="bl-invoice-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {subscription ? (
                <>
                  <tr>
                    <td>{new Date(subscription.created_at).toLocaleDateString()}</td>
                    <td>{PLAN_DISPLAY[subscription.plan as PlanName].name} Plan</td>
                    <td>{PLAN_DISPLAY[subscription.plan as PlanName].price}</td>
                    <td>
                      <span style={{ color: '#22c55e', fontWeight: '600' }}>Paid</span>
                    </td>
                  </tr>
                </>
              ) : (
                <tr>
                  <td colSpan={4}>
                    <div className="bl-invoice-empty">No billing history yet</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Payment Method */}
        <div className="bl-payment">
          <h2 className="bl-payment-title">Payment Method & Processor</h2>
          {user.ls_customer_id || user.stripe_customer_id ? (
            <>
              {user.ls_customer_id && (
                <div className="bl-payment-method">
                  <div className="bl-payment-info">
                    <strong>🍋 LemonSqueezy</strong>
                    <span>Card on file managed by LemonSqueezy</span>
                  </div>
                  <a
                    href="https://app.lemonsqueezy.com/settings/billing"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bl-payment-link"
                  >
                    Update →
                  </a>
                </div>
              )}
              {user.stripe_customer_id && (
                <div className="bl-payment-method">
                  <div className="bl-payment-info">
                    <strong>⛓️ Stripe</strong>
                    <span>Card on file managed by Stripe</span>
                  </div>
                  <a
                    href="https://billing.stripe.com/p/login/test_51234567890"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bl-payment-link"
                  >
                    Update →
                  </a>
                </div>
              )}
              <p style={{ fontSize: '0.75rem', color: '#8b7fa8', marginTop: '1rem' }}>
                {user.payment_processor === 'stripe'
                  ? 'Your current payment processor is Stripe. To change processors, select a different option during checkout.'
                  : 'Your current payment processor is LemonSqueezy. To change processors, select a different option during checkout.'}
              </p>
            </>
          ) : (
            <div style={{ color: '#8b7fa8', fontSize: '0.9rem' }}>
              <p>No payment method on file. Upgrade to a paid plan to add one.</p>
            </div>
          )}
        </div>

        {/* Help Section */}
        <div style={{ marginTop: '2rem', padding: '1rem', background: 'rgba(124,58,237,0.02)', borderRadius: '0.75rem' }}>
          <p style={{ fontSize: '0.85rem', color: '#6b5f80', margin: 0 }}>
            Have questions? <Link href="/support" style={{ color: '#7c3aed', fontWeight: '600' }}>
              Contact support
            </Link>{' '}
            or check our <Link href="/faq" style={{ color: '#7c3aed', fontWeight: '600' }}>
              billing FAQ
            </Link>
          </p>
        </div>
      </div>

      {toastMessage && (
        <div
          style={{
            position: 'fixed',
            right: '1rem',
            bottom: '1rem',
            zIndex: 70,
            maxWidth: '360px',
            padding: '0.9rem 1rem',
            borderRadius: '0.875rem',
            background: 'rgba(255,255,255,0.98)',
            border: '1.5px solid rgba(239,68,68,0.18)',
            boxShadow: '0 10px 32px rgba(26,22,37,0.12)',
            color: '#7f1d1d',
            fontSize: '0.85rem',
            fontWeight: 600,
          }}
        >
          {toastMessage}
        </div>
      )}
    </>
  )
}
