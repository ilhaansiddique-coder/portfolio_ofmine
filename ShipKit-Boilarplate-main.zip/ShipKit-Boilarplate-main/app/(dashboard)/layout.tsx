import { Sidebar } from '@/components/shared/Sidebar'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function DashboardLayoutStyles() {
  return (
    <ScopedStyle>{`
      .dl-grid {
        display: grid;
        grid-template-columns: 260px 1fr;
        min-height: 100vh;
      }
      .dl-content {
        padding: 2rem 2rem 3rem;
        min-width: 0;
      }
      @media (max-width: 768px) {
        .dl-grid {
          grid-template-columns: 1fr;
        }
        .dl-content {
          padding: 1.25rem 1rem 2rem;
        }
      }
    `}</ScopedStyle>
  )
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      <DashboardLayoutStyles />
      <div className="dl-grid">
        <Sidebar />
        <main className="dl-content">{children}</main>
      </div>
    </>
  )
}
