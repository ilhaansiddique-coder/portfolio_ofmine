'use client'

import { useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import {
  useOrganization,
  useOrgMembers,
  useInviteMember,
  useRemoveMember,
  useUpdateMemberRole,
} from '@/lib/queries/hooks'
import { useAppStore } from '@/stores/app-store'
import { Toast } from '@/components/shared/Toast'
import type { OrgRole } from '@/types'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function OdStyles() {
  return (
    <ScopedStyle>{`
      .od-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 900px;
        padding-bottom: 2rem;
      }
      .od-back {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        font-size: 0.75rem;
        font-weight: 600;
        color: #6b5f80;
        text-decoration: none;
        cursor: pointer;
        background: none;
        border: none;
        padding: 0;
        font-family: var(--font-body), sans-serif;
        transition: color 0.15s ease;
      }
      .od-back:hover { color: #7c3aed; }
      .od-header-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1rem;
      }
      .od-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .od-eyebrow__dot {
        width: 6px; height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: od-pulse 2s ease-in-out infinite;
      }
      .od-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .od-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }
      .od-role-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.3rem 0.7rem;
        font-size: 0.65rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        border-radius: 999px;
        text-transform: uppercase;
      }
      .od-role-badge--owner {
        background: rgba(124,58,237,0.08);
        color: #7c3aed;
      }
      .od-role-badge--admin {
        background: rgba(245,158,11,0.1);
        color: #92400e;
      }
      .od-role-badge--member {
        background: rgba(107,95,128,0.08);
        color: #6b5f80;
      }

      /* Cards */
      .od-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        animation: od-fade-up 0.4s ease both;
      }
      .od-card-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        letter-spacing: -0.02em;
        margin: 0 0 0.25rem;
      }
      .od-card-desc {
        font-size: 0.78rem;
        color: #6b5f80;
        margin: 0 0 1.25rem;
      }
      .od-card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1.25rem;
      }

      /* Members list */
      .od-member-list {
        display: flex;
        flex-direction: column;
      }
      .od-member {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 0.85rem 0;
        border-bottom: 1px solid rgba(124,58,237,0.04);
        animation: od-fade-up 0.3s ease both;
      }
      .od-member:last-child { border-bottom: none; }
      .od-member__avatar {
        width: 36px; height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(168,85,247,0.14));
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 0.8rem;
        color: #7c3aed;
        font-family: var(--font-heading), sans-serif;
        flex-shrink: 0;
      }
      .od-member__info {
        flex: 1;
        min-width: 0;
      }
      .od-member__name {
        font-size: 0.82rem;
        font-weight: 700;
        color: #1a1625;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .od-member__email {
        font-size: 0.72rem;
        color: #8b7fa8;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .od-member__actions {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        flex-shrink: 0;
      }
      .od-select {
        padding: 0.3rem 0.5rem;
        font-size: 0.72rem;
        font-weight: 600;
        color: #6b5f80;
        background: rgba(124,58,237,0.04);
        border: 1px solid rgba(124,58,237,0.1);
        border-radius: 0.5rem;
        cursor: pointer;
        font-family: var(--font-body), sans-serif;
        outline: none;
      }
      .od-select:focus { border-color: rgba(124,58,237,0.3); }
      .od-btn-icon {
        width: 30px; height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid rgba(239,68,68,0.15);
        border-radius: 0.5rem;
        background: none;
        cursor: pointer;
        color: #ef4444;
        transition: all 0.15s ease;
      }
      .od-btn-icon:hover { background: rgba(239,68,68,0.06); }

      /* Invite form */
      .od-invite-row {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px solid rgba(124,58,237,0.06);
      }
      .od-input {
        flex: 1;
        padding: 0.5rem 0.75rem;
        font-size: 0.8rem;
        color: #1a1625;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        outline: none;
        transition: all 0.2s ease;
        font-family: var(--font-body), sans-serif;
        min-width: 0;
      }
      .od-input:focus {
        border-color: rgba(124,58,237,0.3);
        box-shadow: 0 0 0 3px rgba(124,58,237,0.06);
      }
      .od-btn--primary {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        padding: 0.5rem 1rem;
        font-size: 0.78rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
        flex-shrink: 0;
      }
      .od-btn--primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .od-btn--primary:disabled { opacity: 0.5; cursor: default; }

      /* Danger zone */
      .od-card--danger {
        border-color: rgba(239,68,68,0.15);
      }
      .od-card--danger .od-card-title { color: #ef4444; }
      .od-btn--danger {
        padding: 0.55rem 1.1rem;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: 1.5px solid rgba(239,68,68,0.2);
        background: none;
        color: #ef4444;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .od-btn--danger:hover:not(:disabled) { background: rgba(239,68,68,0.06); }

      .od-error {
        font-size: 0.72rem;
        color: #ef4444;
        margin-top: 0.3rem;
      }

      /* Skeleton */
      .od-skeleton {
        background: linear-gradient(90deg, #f5f0ff 25%, #ede8f8 50%, #f5f0ff 75%);
        background-size: 200% 100%;
        animation: od-shimmer 1.8s ease infinite;
        border-radius: 0.75rem;
      }

      @keyframes od-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes od-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%      { opacity: 0.4; transform: scale(0.85); }
      }
      @keyframes od-shimmer {
        0%   { background-position: -200% 0; }
        100% { background-position: 200% 0; }
      }
    `}</ScopedStyle>
  )
}

export default function OrgDetailPage() {
  const { orgId } = useParams<{ orgId: string }>()
  const router = useRouter()
  const { data: org, isLoading: orgLoading } = useOrganization(orgId)
  const { data: members, isLoading: membersLoading } = useOrgMembers(orgId)
  const inviteMember = useInviteMember(orgId)
  const removeMember = useRemoveMember(orgId)
  const updateRole = useUpdateMemberRole(orgId)
  const addToast = useAppStore((s) => s.addToast)
  const [inviteEmail, setInviteEmail] = useState('')

  const isOwner = org?.currentUserRole === 'owner'
  const isAdmin = org?.currentUserRole === 'admin'
  const canManage = isOwner || isAdmin

  async function handleInvite(e: React.FormEvent) {
    e.preventDefault()
    if (!inviteEmail.trim()) return
    try {
      await inviteMember.mutateAsync({ email: inviteEmail.trim() })
      addToast('Member invited successfully')
      setInviteEmail('')
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Failed to invite member', 'error')
    }
  }

  async function handleRemove(userId: string, memberName: string) {
    try {
      await removeMember.mutateAsync(userId)
      addToast(`${memberName} removed`)
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Failed to remove member', 'error')
    }
  }

  async function handleRoleChange(userId: string, role: 'admin' | 'member') {
    try {
      await updateRole.mutateAsync({ userId, role })
      addToast('Role updated')
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Failed to update role', 'error')
    }
  }

  async function handleDelete() {
    if (!confirm('Are you sure you want to delete this organization? This action cannot be undone.')) return
    try {
      const res = await fetch(`/api/orgs/${orgId}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      if (!res.ok) {
        const payload = await res.json()
        throw new Error(payload.error ?? 'Failed to delete')
      }
      addToast('Organization deleted')
      router.push('/dashboard/organizations')
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Failed to delete organization', 'error')
    }
  }

  if (orgLoading) {
    return (
      <div className="od-root">
        <OdStyles />
        <div className="od-skeleton" style={{ width: 100, height: 14 }} />
        <div>
          <div className="od-skeleton" style={{ width: 140, height: 16, marginBottom: 8 }} />
          <div className="od-skeleton" style={{ width: 260, height: 32 }} />
        </div>
        <div className="od-skeleton" style={{ height: 300 }} />
      </div>
    )
  }

  if (!org) {
    return (
      <div className="od-root">
        <OdStyles />
        <button className="od-back" onClick={() => router.push('/dashboard/organizations')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back to Organizations
        </button>
        <div style={{ textAlign: 'center', padding: '3rem', color: '#6b5f80' }}>
          Organization not found.
        </div>
      </div>
    )
  }

  function getInitial(name: string | null, email: string) {
    return (name || email).charAt(0).toUpperCase()
  }

  return (
    <div className="od-root">
      <OdStyles />

      <button className="od-back" onClick={() => router.push('/dashboard/organizations')}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
          <polyline points="15 18 9 12 15 6" />
        </svg>
        Back to Organizations
      </button>

      <div className="od-header-row">
        <div>
          <div className="od-eyebrow">
            <span className="od-eyebrow__dot" />
            Organization
          </div>
          <h1 className="od-title">{org.name}</h1>
          <p className="od-subtitle">/{org.slug}</p>
        </div>
        <span className={`od-role-badge od-role-badge--${org.currentUserRole}`}>
          {org.currentUserRole}
        </span>
      </div>

      {/* Members card */}
      <div className="od-card" style={{ animationDelay: '50ms' }}>
        <div className="od-card-header">
          <div>
            <h2 className="od-card-title">Members</h2>
            <p className="od-card-desc" style={{ margin: 0 }}>
              {members ? `${members.length} member${members.length !== 1 ? 's' : ''}` : 'Loading...'}
            </p>
          </div>
        </div>

        {membersLoading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {[0, 1, 2].map((i) => (
              <div key={i} className="od-skeleton" style={{ height: 44 }} />
            ))}
          </div>
        ) : (
          <div className="od-member-list">
            {(members ?? []).map((m, i) => {
              const memberRole = m.role as OrgRole
              return (
                <div key={m.id} className="od-member" style={{ animationDelay: `${i * 40}ms` }}>
                  <div className="od-member__avatar">
                    {getInitial(m.user?.full_name ?? null, m.user?.email ?? '?')}
                  </div>
                  <div className="od-member__info">
                    <div className="od-member__name">
                      {m.user?.full_name || m.user?.email || 'Unknown'}
                    </div>
                    <div className="od-member__email">{m.user?.email}</div>
                  </div>
                  <div className="od-member__actions">
                    {memberRole === 'owner' ? (
                      <span className={`od-role-badge od-role-badge--owner`}>Owner</span>
                    ) : isOwner ? (
                      <>
                        <select
                          className="od-select"
                          value={memberRole}
                          onChange={(e) => handleRoleChange(m.user_id, e.target.value as 'admin' | 'member')}
                        >
                          <option value="member">Member</option>
                          <option value="admin">Admin</option>
                        </select>
                        <button
                          className="od-btn-icon"
                          onClick={() => handleRemove(m.user_id, m.user?.full_name || m.user?.email || 'user')}
                          title="Remove member"
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                            <polyline points="3 6 5 6 21 6" />
                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                            <line x1="10" y1="11" x2="10" y2="17" />
                            <line x1="14" y1="11" x2="14" y2="17" />
                          </svg>
                        </button>
                      </>
                    ) : canManage && memberRole === 'member' ? (
                      <button
                        className="od-btn-icon"
                        onClick={() => handleRemove(m.user_id, m.user?.full_name || m.user?.email || 'user')}
                        title="Remove member"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                        </svg>
                      </button>
                    ) : (
                      <span className={`od-role-badge od-role-badge--${memberRole}`}>
                        {memberRole}
                      </span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {canManage && (
          <form className="od-invite-row" onSubmit={handleInvite}>
            <input
              className="od-input"
              type="email"
              placeholder="Invite by email..."
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
            />
            <button
              type="submit"
              className="od-btn--primary"
              disabled={inviteMember.isPending || !inviteEmail.trim()}
            >
              {inviteMember.isPending ? 'Inviting...' : 'Invite'}
            </button>
          </form>
        )}
        {inviteMember.error && (
          <p className="od-error">{inviteMember.error.message}</p>
        )}
      </div>

      {/* Danger zone — owner only */}
      {isOwner && (
        <div className="od-card od-card--danger" style={{ animationDelay: '150ms' }}>
          <h2 className="od-card-title">Danger Zone</h2>
          <p className="od-card-desc">
            Permanently delete this organization and all associated data. This cannot be undone.
          </p>
          <button className="od-btn--danger" onClick={handleDelete}>
            Delete Organization
          </button>
        </div>
      )}

      <Toast />
    </div>
  )
}
