'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useParams } from 'next/navigation'
import { useOrganization, useOrgMembers, useInviteMember, useRemoveMember } from '@/lib/queries/hooks'
import { useAppStore } from '@/stores/app-store'
import { Toast } from '@/components/shared/Toast'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

const orgSchema = z.object({
  name: z.string().min(1, 'Organization name is required').max(100),
})

const inviteSchema = z.object({
  email: z.string().email('Invalid email address'),
  role: z.enum(['member', 'admin']).default('member'),
})

type OrgForm = z.infer<typeof orgSchema>
type InviteForm = z.infer<typeof inviteSchema>

function OrgSettingsStyles() {
  return (
    <ScopedStyle>{`
      .os-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 900px;
        padding-bottom: 2rem;
      }
      .os-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .os-eyebrow__dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: os-pulse 2s ease-in-out infinite;
      }
      .os-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .os-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }
      .os-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        animation: os-fade-up 0.4s ease both;
      }
      .os-card-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        letter-spacing: -0.02em;
        margin: 0 0 0.25rem;
      }
      .os-card-desc {
        font-size: 0.78rem;
        color: #6b5f80;
        margin: 0 0 1.25rem;
      }
      .os-field {
        margin-bottom: 1rem;
      }
      .os-label {
        display: block;
        font-size: 0.75rem;
        font-weight: 700;
        color: #1a1625;
        margin-bottom: 0.35rem;
      }
      .os-input {
        width: 100%;
        padding: 0.6rem 0.85rem;
        font-size: 0.82rem;
        color: #1a1625;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        outline: none;
        transition: all 0.2s ease;
        font-family: var(--font-body), sans-serif;
        box-sizing: border-box;
      }
      .os-input:focus {
        border-color: rgba(124,58,237,0.3);
        box-shadow: 0 0 0 3px rgba(124,58,237,0.06);
      }
      .os-error {
        font-size: 0.72rem;
        color: #ef4444;
        margin-top: 0.3rem;
      }
      .os-btn {
        padding: 0.55rem 1.1rem;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .os-btn--primary {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
      }
      .os-btn--primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .os-btn--danger {
        background: none;
        color: #ef4444;
        border: 1.5px solid rgba(239,68,68,0.2);
        padding: 0.4rem 0.8rem;
      }
      .os-btn--danger:hover:not(:disabled) {
        background: rgba(239,68,68,0.06);
      }
      .os-btn:disabled {
        opacity: 0.5;
        cursor: default;
      }
      .os-members-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.85rem;
        margin-top: 1rem;
      }
      .os-members-table thead {
        border-bottom: 1.5px solid rgba(124,58,237,0.1);
      }
      .os-members-table thead th {
        text-align: left;
        padding: 0.75rem 0;
        font-weight: 700;
        color: #6b5f80;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
      }
      .os-members-table tbody tr {
        border-bottom: 1px solid rgba(124,58,237,0.05);
        transition: background 0.2s ease;
      }
      .os-members-table tbody tr:hover {
        background: rgba(124,58,237,0.02);
      }
      .os-members-table td {
        padding: 1rem 0;
        color: #4b4466;
      }
      .os-role-badge {
        display: inline-block;
        padding: 0.25rem 0.6rem;
        background: rgba(124,58,237,0.1);
        color: #7c3aed;
        border-radius: 999px;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
      }
      .os-empty {
        text-align: center;
        padding: 2rem 1rem;
        color: #8b7fa8;
      }
      @keyframes os-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes os-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.4; transform: scale(0.85); }
      }
    `}</ScopedStyle>
  )
}

export default function OrgSettingsPage() {
  const params = useParams()
  const orgId = Array.isArray(params.orgId) ? (params.orgId[0] ?? '') : (params.orgId ?? '')

  const { data: org, isLoading: orgLoading } = useOrganization(orgId)
  const { data: members = [] } = useOrgMembers(orgId)
  const inviteMember = useInviteMember(orgId)
  const removeMember = useRemoveMember(orgId)
  const addToast = useAppStore((s) => s.addToast)

  const [showInviteForm, setShowInviteForm] = useState(false)

  const {
    register: registerOrg,
    handleSubmit: handleOrgSubmit,
    formState: { errors: orgErrors },
  } = useForm<OrgForm>({
    resolver: zodResolver(orgSchema),
    values: { name: org?.name ?? '' },
  })

  const {
    register: registerInvite,
    handleSubmit: handleInviteSubmit,
    reset: resetInvite,
    formState: { errors: inviteErrors },
  } = useForm<InviteForm>({
    resolver: zodResolver(inviteSchema),
  })

  async function onOrgSubmit(data: OrgForm) {
    void data
    try {
      // Implement update org API
      addToast('Organization updated successfully')
    } catch {
      addToast('Failed to update organization', 'error')
    }
  }

  async function onInviteSubmit(data: InviteForm) {
    try {
      await inviteMember.mutateAsync(data)
      addToast('Invitation sent successfully')
      resetInvite()
      setShowInviteForm(false)
    } catch {
      addToast('Failed to send invitation', 'error')
    }
  }

  async function handleRemove(userId: string) {
    if (!confirm('Are you sure you want to remove this member?')) return
    try {
      await removeMember.mutateAsync(userId)
      addToast('Member removed successfully')
    } catch {
      addToast('Failed to remove member', 'error')
    }
  }

  if (orgLoading) {
    return (
      <div className="os-root">
        <OrgSettingsStyles />
        <div style={{ color: '#8b7fa8' }}>Loading organization...</div>
      </div>
    )
  }

  if (!org) {
    return (
      <div className="os-root">
        <OrgSettingsStyles />
        <div style={{ color: '#ef4444' }}>Organization not found</div>
      </div>
    )
  }

  const isOwner = org.currentUserRole === 'owner'

  return (
    <div className="os-root">
      <OrgSettingsStyles />

      <div>
        <div className="os-eyebrow">
          <span className="os-eyebrow__dot" />
          Team
        </div>
        <h1 className="os-title">{org.name}</h1>
        <p className="os-subtitle">Manage organization settings and team members</p>
      </div>

      {/* Organization Settings */}
      {isOwner && (
        <div className="os-card">
          <h2 className="os-card-title">Organization Details</h2>
          <p className="os-card-desc">Update your organization information.</p>

          <form onSubmit={handleOrgSubmit(onOrgSubmit)}>
            <div className="os-field">
              <label className="os-label" htmlFor="name">
                Organization Name
              </label>
              <input id="name" className="os-input" {...registerOrg('name')} />
              {orgErrors.name && <p className="os-error">{orgErrors.name.message}</p>}
            </div>

            <button type="submit" className="os-btn os-btn--primary">
              Save Changes
            </button>
          </form>
        </div>
      )}

      {/* Members */}
      <div className="os-card" style={{ animationDelay: '100ms' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '1rem' }}>
          <div>
            <h2 className="os-card-title">Team Members</h2>
            <p className="os-card-desc">Manage who has access to your organization.</p>
          </div>
          {isOwner && (
            <button className="os-btn os-btn--primary" onClick={() => setShowInviteForm(!showInviteForm)}>
              {showInviteForm ? 'Cancel' : 'Invite Member'}
            </button>
          )}
        </div>

        {showInviteForm && isOwner && (
          <form onSubmit={handleInviteSubmit(onInviteSubmit)} style={{ marginBottom: '1.5rem' }}>
            <div className="os-field">
              <label className="os-label" htmlFor="email">
                Email Address
              </label>
              <input
                id="email"
                className="os-input"
                type="email"
                placeholder="colleague@example.com"
                {...registerInvite('email')}
              />
              {inviteErrors.email && <p className="os-error">{inviteErrors.email.message}</p>}
            </div>

            <div className="os-field">
              <label className="os-label" htmlFor="role">
                Role
              </label>
              <select className="os-input" id="role" {...registerInvite('role')}>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <button type="submit" className="os-btn os-btn--primary" disabled={inviteMember.isPending}>
              {inviteMember.isPending ? 'Sending...' : 'Send Invitation'}
            </button>
          </form>
        )}

        {members.length > 0 ? (
          <table className="os-members-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                {isOwner && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {members.map((member) => (
                <tr key={member.id}>
                  <td>{member.user?.full_name || 'Unknown'}</td>
                  <td>{member.user?.email}</td>
                  <td>
                    <span className="os-role-badge">{member.role}</span>
                  </td>
                  {isOwner && member.role !== 'owner' && (
                    <td>
                      <button
                        className="os-btn os-btn--danger"
                        onClick={() => handleRemove(member.user_id)}
                        disabled={removeMember.isPending}
                      >
                        Remove
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="os-empty">No members yet</div>
        )}
      </div>

      <Toast />
    </div>
  )
}
