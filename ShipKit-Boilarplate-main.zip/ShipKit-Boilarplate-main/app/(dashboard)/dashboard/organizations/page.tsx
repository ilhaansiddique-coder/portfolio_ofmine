'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useOrganizations, useCreateOrg } from '@/lib/queries/hooks'
import { useAppStore } from '@/stores/app-store'
import { Toast } from '@/components/shared/Toast'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function OgStyles() {
  return (
    <ScopedStyle>{`
      .og-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 1200px;
        padding-bottom: 2rem;
      }
      .og-header-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1rem;
      }
      .og-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .og-eyebrow__dot {
        width: 6px; height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: og-pulse 2s ease-in-out infinite;
      }
      .og-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .og-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }
      .og-header-actions {
        display: flex;
        gap: 0.625rem;
      }

      /* Create button */
      .og-btn--primary {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        padding: 0.55rem 1.1rem;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .og-btn--primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .og-btn--primary:disabled { opacity: 0.5; cursor: default; }

      /* Count badge */
      .og-count-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.4rem 0.85rem;
        font-size: 0.75rem;
        font-weight: 700;
        background: rgba(124,58,237,0.08);
        color: #7c3aed;
        border-radius: 999px;
      }

      /* Org grid */
      .og-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 1rem;
      }
      .og-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.25rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        transition: all 0.25s ease;
        animation: og-fade-up 0.4s ease both;
        position: relative;
        overflow: hidden;
        text-decoration: none;
        display: block;
        color: inherit;
      }
      .og-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, #7c3aed, #a855f7, #ec4899);
        opacity: 0;
        transition: opacity 0.25s ease;
      }
      .og-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(26,22,37,0.08);
        border-color: rgba(124,58,237,0.15);
      }
      .og-card:hover::before { opacity: 1; }
      .og-card__header {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
      }
      .og-card__avatar {
        width: 40px; height: 40px;
        border-radius: 10px;
        background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(168,85,247,0.14));
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        font-size: 1rem;
        color: #7c3aed;
        font-family: var(--font-heading), sans-serif;
        flex-shrink: 0;
      }
      .og-card__name {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        margin: 0;
      }
      .og-card__slug {
        font-size: 0.72rem;
        color: #8b7fa8;
        margin: 0;
      }
      .og-card__footer {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-top: 0.75rem;
        padding-top: 0.75rem;
        border-top: 1px solid rgba(124,58,237,0.04);
      }
      .og-card__role {
        display: inline-flex;
        align-items: center;
        padding: 0.2rem 0.6rem;
        font-size: 0.65rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        border-radius: 999px;
        text-transform: uppercase;
      }
      .og-card__role--owner {
        background: rgba(124,58,237,0.08);
        color: #7c3aed;
      }
      .og-card__role--admin {
        background: rgba(245,158,11,0.1);
        color: #92400e;
      }
      .og-card__role--member {
        background: rgba(107,95,128,0.08);
        color: #6b5f80;
      }
      .og-card__plan {
        font-size: 0.68rem;
        font-weight: 600;
        color: #6b5f80;
      }

      /* Create modal */
      .og-modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 50;
        background: rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        animation: og-fade-in 0.2s ease;
      }
      .og-modal {
        background: #fff;
        border-radius: 1.25rem;
        padding: 1.75rem;
        width: 100%;
        max-width: 440px;
        box-shadow: 0 8px 32px rgba(26,22,37,0.14);
        animation: og-scale-in 0.25s ease;
      }
      .og-modal__title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.15rem;
        font-weight: 800;
        color: #1a1625;
        margin: 0 0 0.25rem;
      }
      .og-modal__desc {
        font-size: 0.78rem;
        color: #6b5f80;
        margin: 0 0 1.25rem;
      }
      .og-field {
        margin-bottom: 1rem;
      }
      .og-label {
        display: block;
        font-size: 0.75rem;
        font-weight: 700;
        color: #1a1625;
        margin-bottom: 0.35rem;
      }
      .og-input {
        width: 100%;
        padding: 0.6rem 0.85rem;
        font-size: 0.82rem;
        color: #1a1625;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        outline: none;
        transition: all 0.2s ease;
        font-family: var(--font-body), sans-serif;
        box-sizing: border-box;
      }
      .og-input:focus {
        border-color: rgba(124,58,237,0.3);
        box-shadow: 0 0 0 3px rgba(124,58,237,0.06);
      }
      .og-input-hint {
        font-size: 0.7rem;
        color: #a89bbe;
        margin-top: 0.25rem;
      }
      .og-modal__actions {
        display: flex;
        gap: 0.625rem;
        justify-content: flex-end;
        margin-top: 1.25rem;
      }
      .og-btn--ghost {
        padding: 0.55rem 1.1rem;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: 1.5px solid rgba(124,58,237,0.12);
        background: none;
        color: #6b5f80;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .og-btn--ghost:hover { background: rgba(124,58,237,0.04); }
      .og-error {
        font-size: 0.72rem;
        color: #ef4444;
        margin-top: 0.3rem;
      }

      /* Empty state */
      .og-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        padding: 3.5rem 2rem;
        text-align: center;
        background: #fff;
        border-radius: 1.25rem;
        border: 1.5px dashed rgba(124,58,237,0.2);
      }
      .og-empty__icon {
        width: 60px; height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(168,85,247,0.14));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #7c3aed;
      }
      .og-empty__title {
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        font-family: var(--font-heading), sans-serif;
      }
      .og-empty__desc {
        font-size: 0.8rem;
        color: #6b5f80;
        max-width: 320px;
      }

      /* Skeleton */
      .og-skeleton {
        background: linear-gradient(90deg, #f5f0ff 25%, #ede8f8 50%, #f5f0ff 75%);
        background-size: 200% 100%;
        animation: og-shimmer 1.8s ease infinite;
        border-radius: 0.75rem;
      }

      @keyframes og-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes og-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%      { opacity: 0.4; transform: scale(0.85); }
      }
      @keyframes og-shimmer {
        0%   { background-position: -200% 0; }
        100% { background-position: 200% 0; }
      }
      @keyframes og-fade-in {
        from { opacity: 0; }
        to   { opacity: 1; }
      }
      @keyframes og-scale-in {
        from { opacity: 0; transform: scale(0.96); }
        to   { opacity: 1; transform: scale(1); }
      }
    `}</ScopedStyle>
  )
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 50)
}

export default function OrganizationsPage() {
  const { data: orgs, isLoading } = useOrganizations()
  const createOrg = useCreateOrg()
  const addToast = useAppStore((s) => s.addToast)
  const [showCreate, setShowCreate] = useState(false)
  const [name, setName] = useState('')
  const [slug, setSlug] = useState('')
  const [slugTouched, setSlugTouched] = useState(false)

  function handleNameChange(val: string) {
    setName(val)
    if (!slugTouched) setSlug(slugify(val))
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim() || !slug.trim()) return
    try {
      await createOrg.mutateAsync({ name: name.trim(), slug: slug.trim() })
      addToast('Organization created')
      setShowCreate(false)
      setName('')
      setSlug('')
      setSlugTouched(false)
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Failed to create organization', 'error')
    }
  }

  if (isLoading) {
    return (
      <div className="og-root">
        <OgStyles />
        <div>
          <div className="og-skeleton" style={{ width: 140, height: 16, marginBottom: 8 }} />
          <div className="og-skeleton" style={{ width: 220, height: 32 }} />
        </div>
        <div className="og-grid">
          {[0, 1, 2].map((i) => (
            <div key={i} className="og-skeleton" style={{ height: 130 }} />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="og-root">
      <OgStyles />

      <div className="og-header-row">
        <div>
          <div className="og-eyebrow">
            <span className="og-eyebrow__dot" />
            Workspace
          </div>
          <h1 className="og-title">Organizations</h1>
          <p className="og-subtitle">Manage your teams and workspaces.</p>
        </div>
        <div className="og-header-actions">
          {orgs && orgs.length > 0 && (
            <span className="og-count-badge">{orgs.length} org{orgs.length !== 1 ? 's' : ''}</span>
          )}
          <button className="og-btn--primary" onClick={() => setShowCreate(true)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            New Organization
          </button>
        </div>
      </div>

      {!orgs || orgs.length === 0 ? (
        <div className="og-empty">
          <span className="og-empty__icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </span>
          <div className="og-empty__title">No organizations yet</div>
          <p className="og-empty__desc">Create your first organization to start collaborating with your team.</p>
          <button className="og-btn--primary" onClick={() => setShowCreate(true)}>
            Create Organization
          </button>
        </div>
      ) : (
        <div className="og-grid">
          {orgs.map((org, i) => (
            <Link
              key={org.id}
              href={`/dashboard/organizations/${org.id}`}
              className="og-card"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="og-card__header">
                <div className="og-card__avatar">
                  {org.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="og-card__name">{org.name}</h3>
                  <p className="og-card__slug">/{org.slug}</p>
                </div>
              </div>
              <div className="og-card__footer">
                <span className={`og-card__role og-card__role--${org.currentUserRole}`}>
                  {org.currentUserRole}
                </span>
                <span className="og-card__plan">{org.plan} plan</span>
              </div>
            </Link>
          ))}
        </div>
      )}

      {showCreate && (
        <div className="og-modal-backdrop" onClick={() => setShowCreate(false)}>
          <form className="og-modal" onClick={(e) => e.stopPropagation()} onSubmit={handleCreate}>
            <h2 className="og-modal__title">Create Organization</h2>
            <p className="og-modal__desc">Set up a new workspace for your team.</p>

            <div className="og-field">
              <label className="og-label" htmlFor="org-name">Organization name</label>
              <input
                id="org-name"
                className="og-input"
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="Acme Inc"
                autoFocus
              />
            </div>

            <div className="og-field">
              <label className="og-label" htmlFor="org-slug">URL slug</label>
              <input
                id="org-slug"
                className="og-input"
                value={slug}
                onChange={(e) => { setSlug(e.target.value); setSlugTouched(true) }}
                placeholder="acme-inc"
              />
              <p className="og-input-hint">Lowercase letters, numbers, and hyphens only.</p>
            </div>

            {createOrg.error && (
              <p className="og-error">{createOrg.error.message}</p>
            )}

            <div className="og-modal__actions">
              <button type="button" className="og-btn--ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </button>
              <button
                type="submit"
                className="og-btn--primary"
                disabled={createOrg.isPending || !name.trim() || !slug.trim()}
              >
                {createOrg.isPending ? 'Creating...' : 'Create'}
              </button>
            </div>
          </form>
        </div>
      )}

      <Toast />
    </div>
  )
}
