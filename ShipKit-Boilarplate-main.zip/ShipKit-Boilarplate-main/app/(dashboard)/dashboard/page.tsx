'use client'

import { useCurrentUser, useDashboardStats, useRecentActivity } from '@/lib/queries/hooks'
import { PLAN_DISPLAY, normalizePlan } from '@/lib/plans'
import { Toast } from '@/components/shared/Toast'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function DashboardStyles() {
  return (
    <ScopedStyle>{`
      .db-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 1200px;
        padding-bottom: 2rem;
      }
      .db-header-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1rem;
      }
      .db-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .db-eyebrow__dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: db-pulse 2s ease-in-out infinite;
      }
      .db-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .db-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }

      /* Stats grid */
      .db-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
      }
      .db-stat-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.25rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        transition: all 0.25s ease;
        animation: db-fade-up 0.4s ease both;
      }
      .db-stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(26,22,37,0.08);
        border-color: rgba(124,58,237,0.15);
      }
      .db-stat-label {
        font-size: 0.72rem;
        font-weight: 600;
        color: #6b5f80;
        margin-bottom: 0.5rem;
      }
      .db-stat-value {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.75rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.02em;
      }
      .db-stat-sub {
        font-size: 0.68rem;
        font-weight: 600;
        color: #8b7fa8;
        margin-top: 0.35rem;
      }

      /* Activity feed */
      .db-section-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        letter-spacing: -0.02em;
        margin: 0;
      }
      .db-activity {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        overflow: hidden;
        animation: db-fade-up 0.4s ease both;
        animation-delay: 200ms;
      }
      .db-activity-item {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 1rem 1.25rem;
        border-bottom: 1px solid rgba(124,58,237,0.04);
        transition: background 0.15s ease;
      }
      .db-activity-item:last-child { border-bottom: none; }
      .db-activity-item:hover { background: rgba(124,58,237,0.02); }
      .db-activity-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }
      .db-activity-text {
        font-size: 0.8rem;
        color: #4b4466;
        flex: 1;
      }
      .db-activity-time {
        font-size: 0.68rem;
        color: #a89bbe;
        flex-shrink: 0;
      }

      /* Empty state */
      .db-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        padding: 3.5rem 2rem;
        text-align: center;
        background: #fff;
        border-radius: 1.25rem;
        border: 1.5px dashed rgba(124,58,237,0.2);
      }
      .db-empty__icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(168,85,247,0.14));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #7c3aed;
      }
      .db-empty__title {
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        font-family: var(--font-heading), sans-serif;
      }
      .db-empty__desc {
        font-size: 0.8rem;
        color: #6b5f80;
      }

      /* Skeleton */
      .db-skeleton {
        background: linear-gradient(90deg, #f5f0ff 25%, #ede8f8 50%, #f5f0ff 75%);
        background-size: 200% 100%;
        animation: db-shimmer 1.8s ease infinite;
        border-radius: 0.75rem;
      }

      @keyframes db-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes db-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%      { opacity: 0.4; transform: scale(0.85); }
      }
      @keyframes db-shimmer {
        0%   { background-position: -200% 0; }
        100% { background-position: 200% 0; }
      }
    `}</ScopedStyle>
  )
}

/** Map activity action types to dot colors */
function getActivityColor(action: string): string {
  switch (action) {
    case 'account.created':
      return '#10b981'
    case 'profile.updated':
      return '#7c3aed'
    case 'org.created':
      return '#3b82f6'
    case 'org.joined':
      return '#06b6d4'
    case 'plan.changed':
      return '#f59e0b'
    default:
      return '#8b7fa8'
  }
}

/** Format a timestamp as relative time (e.g. "2 hours ago") */
function formatTimeAgo(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (seconds < 60) return 'Just now'
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}d ago`
  const months = Math.floor(days / 30)
  return `${months}mo ago`
}

export default function DashboardPage() {
  const { data: user, isLoading: userLoading } = useCurrentUser()
  const { data: stats, isLoading: statsLoading } = useDashboardStats()
  const { data: activity, isLoading: activityLoading } = useRecentActivity()

  const isLoading = userLoading || statsLoading

  if (isLoading) {
    return (
      <div className="db-root">
        <DashboardStyles />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div className="db-skeleton" style={{ width: 200, height: 28 }} />
          <div className="db-skeleton" style={{ width: 300, height: 16 }} />
        </div>
        <div className="db-stats">
          {[0,1,2,3].map((i) => (
            <div key={i} className="db-skeleton" style={{ height: 100 }} />
          ))}
        </div>
        <div className="db-skeleton" style={{ height: 200 }} />
      </div>
    )
  }

  const plan = normalizePlan(stats?.plan)
  const planDisplay = PLAN_DISPLAY[plan]

  const statCards = [
    {
      label: 'Organizations',
      value: String(stats?.organizations ?? 0),
      sub: stats?.organizations === 1 ? '1 workspace' : `${stats?.organizations ?? 0} workspaces`,
    },
    {
      label: 'Team Members',
      value: String(stats?.teamMembers ?? 0),
      sub: 'across all orgs',
    },
    {
      label: 'Current Plan',
      value: planDisplay.name,
      sub: planDisplay.price,
    },
    {
      label: 'Active Since',
      value: stats?.memberSinceDays === 0 ? 'Today' : `${stats?.memberSinceDays}d`,
      sub: stats?.memberSinceDays === 0 ? 'Welcome!' : `${stats?.memberSinceDays} days ago`,
    },
  ]

  return (
    <div className="db-root">
      <DashboardStyles />

      <div className="db-header-row">
        <div>
          <div className="db-eyebrow">
            <span className="db-eyebrow__dot" />
            Overview
          </div>
          <h1 className="db-title">
            Welcome back{user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ''}
          </h1>
          <p className="db-subtitle">Here is what is happening with your account today.</p>
        </div>
      </div>

      <div className="db-stats">
        {statCards.map((stat, i) => (
          <div key={stat.label} className="db-stat-card" style={{ animationDelay: `${i * 50}ms` }}>
            <div className="db-stat-label">{stat.label}</div>
            <div className="db-stat-value">{stat.value}</div>
            <div className="db-stat-sub">{stat.sub}</div>
          </div>
        ))}
      </div>

      <div>
        <h2 className="db-section-title" style={{ marginBottom: '0.75rem' }}>Recent Activity</h2>

        {activityLoading ? (
          <div className="db-skeleton" style={{ height: 200 }} />
        ) : activity && activity.length > 0 ? (
          <div className="db-activity">
            {activity.map((item) => (
              <div key={item.id} className="db-activity-item">
                <span
                  className="db-activity-dot"
                  style={{ background: getActivityColor(item.action) }}
                />
                <span className="db-activity-text">{item.description}</span>
                <span className="db-activity-time">{formatTimeAgo(item.created_at)}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="db-empty">
            <span className="db-empty__icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
            </span>
            <div className="db-empty__title">No activity yet</div>
            <p className="db-empty__desc">Activity will appear here as you use the app.</p>
          </div>
        )}
      </div>

      <Toast />
    </div>
  )
}
