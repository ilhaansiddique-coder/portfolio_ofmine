'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useCurrentUser, useUpdateProfile } from '@/lib/queries/hooks'
import { useAppStore } from '@/stores/app-store'
import { PLAN_DISPLAY } from '@/lib/plans'
import type { PlanName } from '@/lib/plans'
import { Toast } from '@/components/shared/Toast'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

const profileSchema = z.object({
  full_name: z.string().min(1, 'Name is required').max(100),
  email: z.string().email('Invalid email'),
})

type ProfileForm = z.infer<typeof profileSchema>

function SettingsStyles() {
  return (
    <ScopedStyle>{`
      .st-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 720px;
        padding-bottom: 2rem;
      }
      .st-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .st-eyebrow__dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: st-pulse 2s ease-in-out infinite;
      }
      .st-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .st-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }

      /* Card sections */
      .st-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        animation: st-fade-up 0.4s ease both;
      }
      .st-card-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        letter-spacing: -0.02em;
        margin: 0 0 0.25rem;
      }
      .st-card-desc {
        font-size: 0.78rem;
        color: #6b5f80;
        margin: 0 0 1.25rem;
      }

      /* Form */
      .st-field {
        margin-bottom: 1rem;
      }
      .st-label {
        display: block;
        font-size: 0.75rem;
        font-weight: 700;
        color: #1a1625;
        margin-bottom: 0.35rem;
      }
      .st-input {
        width: 100%;
        padding: 0.6rem 0.85rem;
        font-size: 0.82rem;
        color: #1a1625;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        outline: none;
        transition: all 0.2s ease;
        font-family: var(--font-body), sans-serif;
        box-sizing: border-box;
      }
      .st-input:focus {
        border-color: rgba(124,58,237,0.3);
        box-shadow: 0 0 0 3px rgba(124,58,237,0.06);
      }
      .st-input:disabled {
        background: #f8f6fc;
        color: #8b7fa8;
        cursor: not-allowed;
      }
      .st-error {
        font-size: 0.72rem;
        color: #ef4444;
        margin-top: 0.3rem;
      }
      .st-btn {
        padding: 0.55rem 1.1rem;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .st-btn--primary {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
      }
      .st-btn--primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .st-btn:disabled {
        opacity: 0.5;
        cursor: default;
      }

      /* Plan display */
      .st-plan-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.75rem;
      }
      .st-plan-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.4rem 0.85rem;
        font-size: 0.75rem;
        font-weight: 700;
        background: rgba(124,58,237,0.08);
        color: #7c3aed;
        border-radius: 999px;
      }
      .st-plan-price {
        font-size: 0.82rem;
        color: #6b5f80;
      }
      .st-plan-status {
        font-size: 0.72rem;
        font-weight: 600;
        margin-top: 0.5rem;
      }
      .st-plan-status--active { color: #10b981; }
      .st-plan-status--inactive { color: #8b7fa8; }

      /* Danger zone */
      .st-card--danger {
        border-color: rgba(239,68,68,0.15);
      }
      .st-card--danger .st-card-title { color: #ef4444; }
      .st-btn--danger {
        background: none;
        color: #ef4444;
        border: 1.5px solid rgba(239,68,68,0.2);
      }
      .st-btn--danger:hover:not(:disabled) {
        background: rgba(239,68,68,0.06);
      }

      /* Skeleton */
      .st-skeleton {
        background: linear-gradient(90deg, #f5f0ff 25%, #ede8f8 50%, #f5f0ff 75%);
        background-size: 200% 100%;
        animation: st-shimmer 1.8s ease infinite;
        border-radius: 0.75rem;
      }

      @keyframes st-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes st-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%      { opacity: 0.4; transform: scale(0.85); }
      }
      @keyframes st-shimmer {
        0%   { background-position: -200% 0; }
        100% { background-position: 200% 0; }
      }
    `}</ScopedStyle>
  )
}

export default function SettingsPage() {
  const [isDeletingAccount, setIsDeletingAccount] = useState(false)
  const { data: user, isLoading } = useCurrentUser()
  const updateProfile = useUpdateProfile()
  const addToast = useAppStore((s) => s.addToast)
  const router = useRouter()

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    values: {
      full_name: user?.full_name ?? '',
      email: user?.email ?? '',
    },
  })

  async function onSubmit(data: ProfileForm) {
    try {
      await updateProfile.mutateAsync({ full_name: data.full_name })
      addToast('Profile updated successfully')
    } catch {
      addToast('Failed to update profile', 'error')
    }
  }

  async function handleDeleteAccount() {
    if (!confirm('Are you sure you want to delete your account? This action cannot be undone.')) return
    if (!confirm('This will permanently delete all your data. Are you absolutely sure?')) return

    setIsDeletingAccount(true)
    try {
      const response = await fetch('/api/me/delete-account', { method: 'POST' })
      const data = await response.json()

      if (!response.ok) {
        addToast(data.error || 'Failed to delete account', 'error')
        setIsDeletingAccount(false)
        return
      }

      // Sign out
      const supabase = createClient()
      await supabase.auth.signOut()

      addToast('Account deleted successfully')
      router.push('/')
    } catch {
      addToast('Failed to delete account', 'error')
      setIsDeletingAccount(false)
    }
  }

  const plan = (user?.plan ?? 'free') as PlanName
  const planDisplay = PLAN_DISPLAY[plan]
  const subStatus = user?.subscription_status ?? 'inactive'

  if (isLoading) {
    return (
      <div className="st-root">
        <SettingsStyles />
        <div>
          <div className="st-skeleton" style={{ width: 120, height: 16, marginBottom: 8 }} />
          <div className="st-skeleton" style={{ width: 200, height: 32 }} />
        </div>
        <div className="st-skeleton" style={{ height: 240 }} />
        <div className="st-skeleton" style={{ height: 100 }} />
      </div>
    )
  }

  return (
    <div className="st-root">
      <SettingsStyles />

      <div>
        <div className="st-eyebrow">
          <span className="st-eyebrow__dot" />
          Account
        </div>
        <h1 className="st-title">Settings</h1>
        <p className="st-subtitle">Manage your profile and subscription.</p>
      </div>

      {/* Profile card */}
      <div className="st-card">
        <h2 className="st-card-title">Profile</h2>
        <p className="st-card-desc">Update your personal information.</p>

        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="st-field">
            <label className="st-label" htmlFor="full_name">Full name</label>
            <input
              id="full_name"
              className="st-input"
              {...register('full_name')}
            />
            {errors.full_name && <p className="st-error">{errors.full_name.message}</p>}
          </div>

          <div className="st-field">
            <label className="st-label" htmlFor="email">Email</label>
            <input
              id="email"
              className="st-input"
              type="email"
              disabled
              {...register('email')}
            />
            <p style={{ fontSize: '0.7rem', color: '#a89bbe', marginTop: '0.25rem' }}>
              Email cannot be changed.
            </p>
          </div>

          <button
            type="submit"
            className="st-btn st-btn--primary"
            disabled={updateProfile.isPending}
          >
            {updateProfile.isPending ? 'Saving...' : 'Save changes'}
          </button>
        </form>
      </div>

      {/* Plan card */}
      <div className="st-card" style={{ animationDelay: '100ms' }}>
        <h2 className="st-card-title">Subscription</h2>
        <p className="st-card-desc">Your current plan and billing details.</p>
        <div className="st-plan-row">
          <div>
            <span className="st-plan-badge">{planDisplay.name}</span>
            <span className="st-plan-price" style={{ marginLeft: '0.5rem' }}>{planDisplay.price}</span>
            {user?.is_paid && (
              <p className={`st-plan-status ${subStatus === 'active' ? 'st-plan-status--active' : 'st-plan-status--inactive'}`}>
                Status: {subStatus.charAt(0).toUpperCase() + subStatus.slice(1)}
              </p>
            )}
          </div>
          {plan !== 'pro' && (
            <Link href="/billing" className="st-btn st-btn--primary">
              Manage Subscription
            </Link>
          )}
        </div>
      </div>

      {/* Danger zone */}
      <div className="st-card st-card--danger" style={{ animationDelay: '200ms' }}>
        <h2 className="st-card-title">Danger Zone</h2>
        <p className="st-card-desc">Export your data or permanently delete your account.</p>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <button
            className="st-btn st-btn--secondary"
            onClick={async () => {
              try {
                const response = await fetch('/api/me/export-data')
                const data = await response.json()
                const blob = new Blob([JSON.stringify(data, null, 2)], {
                  type: 'application/json',
                })
                const url = URL.createObjectURL(blob)
                const a = document.createElement('a')
                a.href = url
                a.download = `data-export-${new Date().toISOString().split('T')[0]}.json`
                a.click()
                URL.revokeObjectURL(url)
                addToast('Data exported successfully')
              } catch {
                addToast('Failed to export data', 'error')
              }
            }}
            style={{ marginRight: 'auto' }}
          >
            Export Data (GDPR)
          </button>
          <button
            className="st-btn st-btn--danger"
            onClick={handleDeleteAccount}
            disabled={isDeletingAccount}
          >
            {isDeletingAccount ? 'Deleting...' : 'Delete account'}
          </button>
        </div>
      </div>

      <Toast />
    </div>
  )
}
