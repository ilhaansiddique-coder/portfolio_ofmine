'use client'

import { useCurrentUser } from '@/lib/queries/hooks'
import { ScopedStyle } from '@/components/shared/ScopedStyle'
import { useEffect, useState } from 'react'

type AdminStats = {
  totalUsers: number
  activeSubscriptions: number
  freeUsers: number
  paidUsers: number
  mrr: number
  conversionRate: number
  avgPlanValue: number
  churnRate: number
}

function AdminStyles() {
  return (
    <ScopedStyle>{`
      .admin-root {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        max-width: 1200px;
        padding-bottom: 2rem;
      }
      .admin-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.3rem;
      }
      .admin-eyebrow__dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: admin-pulse 2s ease-in-out infinite;
      }
      .admin-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin: 0;
      }
      .admin-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        margin: 0.25rem 0 0;
      }
      .admin-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1rem;
      }
      .admin-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        animation: admin-fade-up 0.4s ease both;
      }
      .admin-card:nth-child(2) { animation-delay: 0.1s; }
      .admin-card:nth-child(3) { animation-delay: 0.2s; }
      .admin-card:nth-child(4) { animation-delay: 0.3s; }
      .admin-stat-label {
        font-size: 0.72rem;
        font-weight: 600;
        color: #6b5f80;
        margin-bottom: 0.5rem;
      }
      .admin-stat-value {
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.02em;
      }
      .admin-stat-sub {
        font-size: 0.68rem;
        font-weight: 600;
        color: #8b7fa8;
        margin-top: 0.35rem;
      }
      @keyframes admin-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes admin-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.4; transform: scale(0.85); }
      }
    `}</ScopedStyle>
  )
}

export default function AdminPage() {
  const { data: user } = useCurrentUser()
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    if (!user) {
      setIsLoading(false)
      return
    }

    async function fetchStats() {
      try {
        const response = await fetch('/api/admin/stats')
        const payload = await response.json()
        if (!response.ok) {
          setErrorMessage(payload.error ?? 'You do not have access to admin statistics.')
          return
        }
        setStats(payload.data)
      } catch (error) {
        console.error('Error fetching stats:', error)
        setErrorMessage('Failed to fetch admin statistics.')
      } finally {
        setIsLoading(false)
      }
    }

    fetchStats()
  }, [user])

  if (!user) {
    return (
      <div className="admin-root">
        <AdminStyles />
        <div style={{ color: '#ef4444' }}>Unauthorized</div>
      </div>
    )
  }

  return (
    <div className="admin-root">
      <AdminStyles />

      <div>
        <div className="admin-eyebrow">
          <span className="admin-eyebrow__dot" />
          Administration
        </div>
        <h1 className="admin-title">Admin Dashboard</h1>
        <p className="admin-subtitle">Monitor your SaaS metrics and user activity</p>
      </div>

      {errorMessage ? (
        <div style={{ color: '#ef4444' }}>{errorMessage}</div>
      ) : isLoading ? (
        <div style={{ color: '#8b7fa8' }}>Loading statistics...</div>
      ) : (
        <>
          {/* Key Metrics */}
          <div className="admin-grid">
            <div className="admin-card">
              <div className="admin-stat-label">Total Users</div>
              <div className="admin-stat-value">{stats?.totalUsers ?? 0}</div>
              <div className="admin-stat-sub">Registered accounts</div>
            </div>

            <div className="admin-card">
              <div className="admin-stat-label">Active Subscriptions</div>
              <div className="admin-stat-value">{stats?.activeSubscriptions ?? 0}</div>
              <div className="admin-stat-sub">Paid plans</div>
            </div>

            <div className="admin-card">
              <div className="admin-stat-label">Monthly Recurring Revenue</div>
              <div className="admin-stat-value">${stats?.mrr?.toFixed(2) ?? '0.00'}</div>
              <div className="admin-stat-sub">USD equivalent</div>
            </div>

            <div className="admin-card">
              <div className="admin-stat-label">Free Plan Users</div>
              <div className="admin-stat-value">{stats?.freeUsers ?? 0}</div>
              <div className="admin-stat-sub">Upgrade potential</div>
            </div>
          </div>

          {/* Summary */}
          <div className="admin-card">
            <h2 style={{ fontSize: '1rem', fontWeight: 800, margin: '0 0 1rem' }}>Summary</h2>
            <div style={{ fontSize: '0.85rem', color: '#6b5f80', lineHeight: 1.8 }}>
              <p>
                <strong style={{ color: '#1a1625' }}>Conversion Rate:</strong>{' '}
                {stats?.conversionRate ? `${(stats.conversionRate * 100).toFixed(2)}%` : 'N/A'}
              </p>
              <p>
                <strong style={{ color: '#1a1625' }}>Average Plan Value:</strong> $
                {stats?.avgPlanValue?.toFixed(2) ?? '0.00'}
              </p>
              <p>
                <strong style={{ color: '#1a1625' }}>Churn Rate:</strong>{' '}
                {stats?.churnRate ? `${(stats.churnRate * 100).toFixed(2)}%` : 'N/A'}
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
