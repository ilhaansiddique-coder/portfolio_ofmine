import { withErrorHandler } from '@/lib/with-error-handler'
import { generateCsrfToken } from '@/lib/csrf'
import { ok } from '@/lib/api-response'

/** GET /api/csrf — generate a CSRF token (sets httpOnly cookie, returns token in body). */
export const GET = withErrorHandler(
  async () => {
    const token = await generateCsrfToken()
    return ok({ token })
  },
  { rateLimit: { limit: 20, windowSeconds: 60 } }
)
