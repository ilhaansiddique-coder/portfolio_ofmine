import { NextRequest } from 'next/server'
import { timingSafeEqual } from 'crypto'
import { env } from '@/lib/env'
import { enqueueEmail, enqueueNotification } from '@/lib/queue'
import { welcomeEmail } from '@/lib/email'
import { logger } from '@/lib/logger'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'

function verifyInternalWebhook(req: NextRequest): boolean {
  const secret = req.headers.get('x-webhook-secret') ?? ''
  const expected = env.INTERNAL_WEBHOOK_SECRET
  if (!secret || !expected) return false
  try {
    return timingSafeEqual(Buffer.from(secret), Buffer.from(expected))
  } catch {
    return false
  }
}

export const POST = withErrorHandler(
  async (req: NextRequest) => {
    if (!verifyInternalWebhook(req)) {
      return err('Unauthorized', 401)
    }

    const { record } = await req.json()

    await enqueueEmail(
      record.email,
      'Welcome to the app!',
      welcomeEmail(record.full_name ?? 'there')
    )

    await enqueueNotification('slack', {
      channel: '#signups',
      text: `New signup: ${record.email}`,
    })

    logger.info({ userId: record.id, email: record.email }, 'User created automation triggered')
    return ok({ received: true })
  },
  { rateLimit: { limit: 10 } }
)
