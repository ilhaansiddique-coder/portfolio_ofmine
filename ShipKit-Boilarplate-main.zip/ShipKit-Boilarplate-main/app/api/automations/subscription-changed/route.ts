import { NextRequest } from 'next/server'
import { timingSafeEqual } from 'crypto'
import { env } from '@/lib/env'
import { enqueueNotification, enqueueDelayedJob } from '@/lib/queue'
import { logger } from '@/lib/logger'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'

function verifyInternalWebhook(req: NextRequest): boolean {
  const secret = req.headers.get('x-webhook-secret') ?? ''
  const expected = env.INTERNAL_WEBHOOK_SECRET
  if (!secret || !expected) return false
  try {
    return timingSafeEqual(Buffer.from(secret), Buffer.from(expected))
  } catch {
    return false
  }
}

export const POST = withErrorHandler(
  async (req: NextRequest) => {
    if (!verifyInternalWebhook(req)) {
      return err('Unauthorized', 401)
    }

    const { record, old_record } = await req.json()

    if (record.subscription_status === 'cancelled' && old_record.subscription_status !== 'cancelled') {
      await enqueueNotification('slack', {
        channel: '#churn',
        text: `Subscription cancelled: ${record.email} (was ${old_record.plan})`,
      })

      await enqueueDelayedJob('win-back-email', {
        userId: record.id,
        email: record.email,
        name: record.full_name,
      }, 3 * 24 * 60 * 60 * 1000)
    }

    logger.info({ userId: record.id, status: record.subscription_status }, 'Subscription change automation triggered')
    return ok({ received: true })
  },
  { rateLimit: { limit: 10 } }
)
