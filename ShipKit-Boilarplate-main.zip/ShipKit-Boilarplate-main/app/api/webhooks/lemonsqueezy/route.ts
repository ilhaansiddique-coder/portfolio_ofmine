import { createHmac, timingSafeEqual } from 'crypto'
import { NextRequest } from 'next/server'
import { z } from 'zod'
import { createAdminClient } from '@/lib/supabase/admin'
import { env } from '@/lib/env'
import { logger } from '@/lib/logger'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'

const webhookEventSchema = z.object({
  meta: z.object({
    event_name: z.string(),
    webhook_id: z.string().optional(),
    custom_data: z.object({ user_id: z.string().optional() }).optional(),
  }),
  data: z.object({
    attributes: z.object({
      customer_id: z.coerce.string(),
      status: z.string().optional(),
    }),
  }),
})

export const POST = withErrorHandler(
  async (req: NextRequest) => {
  const rawBody = await req.text()
  const signature = req.headers.get('x-signature') ?? ''

  const hmac = createHmac('sha256', env.LEMONSQUEEZY_WEBHOOK_SECRET)
  const digest = hmac.update(rawBody).digest('hex')

  let isValid = false
  try {
    isValid = timingSafeEqual(
      Buffer.from(signature, 'hex'),
      Buffer.from(digest, 'hex')
    )
  } catch {
    isValid = false
  }

  if (!isValid) {
    logger.warn('Invalid LemonSqueezy webhook signature')
    return err('Invalid signature', 401)
  }

  const parsed = webhookEventSchema.safeParse(JSON.parse(rawBody))
  if (!parsed.success) {
    logger.warn({ error: parsed.error.flatten() }, 'Webhook payload failed schema validation')
    return err('Invalid webhook payload', 400)
  }

  const event = parsed.data
  const eventName = event.meta.event_name
  const eventId = event.meta.webhook_id ?? `${eventName}-${Date.now()}`
  const userId = event.meta.custom_data?.user_id
  const customerId = event.data.attributes.customer_id
  const status = event.data.attributes.status ?? ''

  if (!userId) {
    logger.warn({ eventName, eventId }, 'Webhook missing user_id in custom_data')
    return err('Missing user_id', 400)
  }

  const supabase = createAdminClient()

  // Atomic idempotency: INSERT with ON CONFLICT so concurrent duplicates are safe.
  // upsert with ignoreDuplicates returns an empty array when the row already existed.
  const { data: inserted } = await supabase
    .from('webhook_events')
    .upsert(
      { event_id: eventId, event_name: eventName },
      { onConflict: 'event_id', ignoreDuplicates: true }
    )
    .select('id')

  if (!inserted || inserted.length === 0) {
    logger.info({ eventId }, 'Webhook event already processed, skipping')
    return ok({ received: true, duplicate: true })
  }

  switch (eventName) {
    case 'order_created':
      await supabase
        .from('users')
        .update({ is_paid: true, plan: 'basic', ls_customer_id: customerId })
        .eq('id', userId)
      logger.info({ userId, plan: 'basic' }, 'Order created — user upgraded')
      break

    case 'subscription_created':
    case 'subscription_updated':
    case 'subscription_resumed':
      await supabase
        .from('users')
        .update({
          plan: status === 'active' ? 'pro' : 'free',
          ls_customer_id: customerId,
          subscription_status: status,
          is_paid: status === 'active',
        })
        .eq('id', userId)
      logger.info({ userId, status, eventName }, 'Subscription updated')
      break

    case 'subscription_cancelled':
      await supabase
        .from('users')
        .update({ subscription_status: 'cancelled' })
        .eq('id', userId)
      logger.info({ userId }, 'Subscription cancelled — active until period end')
      break

    case 'subscription_expired':
      await supabase
        .from('users')
        .update({ plan: 'free', is_paid: false, subscription_status: 'expired' })
        .eq('id', userId)
      logger.info({ userId }, 'Subscription expired — downgraded to free')
      break

    default:
      logger.warn({ eventName }, 'Unhandled webhook event')
  }

  return ok({ received: true })
  },
  { rateLimit: { limit: 20 } }
)
