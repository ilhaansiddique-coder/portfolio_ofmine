import { NextRequest } from 'next/server'
import Stripe from 'stripe'
import { createAdminClient } from '@/lib/supabase/admin'
import { logger } from '@/lib/logger'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import {
  getPlanFromPriceId,
  getStripeClient,
  getStripeWebhookSecret,
  getSubscriptionStatus,
} from '@/lib/stripe'

export const POST = withErrorHandler(
  async (req: NextRequest) => {
    const rawBody = await req.text()
    const sig = req.headers.get('stripe-signature') ?? ''
    const stripe = getStripeClient()

    let event: Stripe.Event
    try {
      event = stripe.webhooks.constructEvent(
        rawBody,
        sig,
        getStripeWebhookSecret()
      )
    } catch (error) {
      logger.warn({ error }, 'Invalid Stripe webhook signature')
      return err('Invalid signature', 401)
    }

    const supabase = createAdminClient()

    // Idempotency: Stripe event IDs are unique, so we use them to prevent duplicate processing
    const { data: inserted } = await supabase
      .from('webhook_events')
      .upsert(
        {
          event_id: event.id,
          event_name: event.type,
          processor: 'stripe',
        },
        { onConflict: 'event_id', ignoreDuplicates: true }
      )
      .select('id')

    if (!inserted || inserted.length === 0) {
      logger.info({ eventId: event.id }, 'Webhook event already processed, skipping')
      return ok({ received: true, duplicate: true })
    }

    try {
      switch (event.type) {
        // Customer subscription created
        case 'customer.subscription.created': {
          const subscription = event.data.object as Stripe.Subscription

          if (!subscription.customer || typeof subscription.customer !== 'string') {
            logger.warn({ subscriptionId: subscription.id }, 'Missing customer ID')
            break
          }

          let userId: string | undefined

          // Try to get userId from subscription metadata
          if (subscription.metadata?.userId) {
            userId = subscription.metadata.userId
          } else {
            // Try to get userId from customer metadata
            const customer = await stripe.customers.retrieve(subscription.customer)
            if (!customer.deleted && customer.metadata?.userId) {
              userId = customer.metadata.userId
            }
          }

          if (!userId) {
            logger.warn(
              { customerId: subscription.customer, subscriptionId: subscription.id },
              'Unable to find userId in subscription or customer metadata'
            )
            break
          }

          const priceId = subscription.items.data[0]?.price.id
          const plan = priceId ? getPlanFromPriceId(priceId) : 'basic'
          const status = getSubscriptionStatus(subscription)

          // Upsert subscription record
          await supabase.from('subscriptions').upsert(
            [{
              user_id: userId,
              stripe_subscription_id: subscription.id,
              stripe_customer_id: subscription.customer,
              payment_processor: 'stripe',
              plan,
              status,
              current_period_start: new Date(
                subscription.current_period_start * 1000
              ).toISOString(),
              current_period_end: new Date(
                subscription.current_period_end * 1000
              ).toISOString(),
            }],
            { onConflict: 'stripe_subscription_id' }
          )

          // Update user's subscription info
          await supabase.from('users').update({
            payment_processor: 'stripe',
            plan,
            is_paid: status === 'active',
            subscription_status: status,
          }).eq('id', userId)

          logger.info(
            { userId, subscriptionId: subscription.id, plan, status },
            'Stripe subscription created'
          )
          break
        }

        // Customer subscription updated
        case 'customer.subscription.updated': {
          const subscription = event.data.object as Stripe.Subscription

          if (!subscription.customer || typeof subscription.customer !== 'string') {
            logger.warn({ subscriptionId: subscription.id }, 'Missing customer ID')
            break
          }

          const priceId = subscription.items.data[0]?.price.id
          const plan = priceId ? getPlanFromPriceId(priceId) : 'basic'
          const status = getSubscriptionStatus(subscription)

          // Update subscription record
          const { data: subscriptions } = await supabase
            .from('subscriptions')
            .update({
              plan,
              status,
              current_period_start: new Date(
                subscription.current_period_start * 1000
              ).toISOString(),
              current_period_end: new Date(
                subscription.current_period_end * 1000
              ).toISOString(),
            })
            .eq('stripe_subscription_id', subscription.id)
            .select('user_id')

          if (subscriptions && subscriptions.length > 0) {
            const userId = subscriptions[0].user_id

            // Update user's subscription info
            await supabase.from('users').update({
              plan,
              is_paid: status === 'active',
              subscription_status: status,
            }).eq('id', userId)

            logger.info(
              { userId, subscriptionId: subscription.id, plan, status },
              'Stripe subscription updated'
            )
          }
          break
        }

        // Subscription deleted (manual cancellation, not cancellation at period end)
        case 'customer.subscription.deleted': {
          const subscription = event.data.object as Stripe.Subscription

          // Update subscription record
          const { data: subscriptions } = await supabase
            .from('subscriptions')
            .update({
              status: 'cancelled',
            })
            .eq('stripe_subscription_id', subscription.id)
            .select('user_id')

          if (subscriptions && subscriptions.length > 0) {
            const userId = subscriptions[0].user_id

            // Downgrade to free plan
            await supabase.from('users').update({
              plan: 'free',
              is_paid: false,
              subscription_status: 'cancelled',
            }).eq('id', userId)

            logger.info(
              { userId, subscriptionId: subscription.id },
              'Stripe subscription cancelled'
            )
          }
          break
        }

        // Payment failed
        case 'invoice.payment_failed': {
          const invoice = event.data.object as Stripe.Invoice

          if (!invoice.customer || typeof invoice.customer !== 'string') {
            logger.warn({ invoiceId: invoice.id }, 'Missing customer ID')
            break
          }

          const { data: subscriptions } = await supabase
            .from('subscriptions')
            .update({
              status: 'past_due',
            })
            .eq('stripe_customer_id', invoice.customer)
            .select('user_id')

          if (subscriptions && subscriptions.length > 0) {
            const userId = subscriptions[0].user_id
            await supabase.from('users').update({
              subscription_status: 'past_due',
            }).eq('id', userId)

            logger.warn(
              { userId, invoiceId: invoice.id },
              'Stripe invoice payment failed'
            )
          }
          break
        }

        // Payment succeeded (after retry)
        case 'invoice.payment_succeeded': {
          const invoice = event.data.object as Stripe.Invoice

          if (
            !invoice.customer ||
            typeof invoice.customer !== 'string' ||
            !invoice.subscription ||
            typeof invoice.subscription !== 'string'
          ) {
            break
          }

          const subscription = await stripe.subscriptions.retrieve(
            invoice.subscription
          )
          const status = getSubscriptionStatus(subscription)

          const { data: subscriptions } = await supabase
            .from('subscriptions')
            .update({
              status,
            })
            .eq('stripe_customer_id', invoice.customer)
            .select('user_id')

          if (subscriptions && subscriptions.length > 0) {
            const userId = subscriptions[0].user_id
            await supabase.from('users').update({
              subscription_status: status,
              is_paid: status === 'active',
            }).eq('id', userId)

            logger.info(
              { userId, invoiceId: invoice.id },
              'Stripe invoice payment succeeded'
            )
          }
          break
        }

        default:
          logger.debug({ eventType: event.type }, 'Unhandled Stripe webhook event')
      }

      return ok({ received: true })
    } catch (error) {
      logger.error(
        { eventId: event.id, eventType: event.type, error },
        'Error processing Stripe webhook'
      )
      throw error
    }
  },
  { rateLimit: { limit: 20 } }
)
