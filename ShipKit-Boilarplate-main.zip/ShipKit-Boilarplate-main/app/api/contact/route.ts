import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
import { sendEmail } from '@/lib/email'
import { z } from 'zod'
import { validateBody } from '@/lib/validate'

const contactSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  subject: z.string().min(5).max(200),
  message: z.string().min(20).max(5000),
  type: z.enum(['support', 'refund', 'bug', 'feature', 'other']).default('support'),
})

export const POST = withErrorHandler(
  async (req: NextRequest) => {
    const body = await req.json()
    const validation = validateBody(contactSchema, body)
    if (!validation.success) return validation.response

    const { name, email, subject, message } = validation.data
    const type = validation.data.type ?? 'support'

    try {
      // Create contact record in database (optional but recommended)
      // const supabase = await createClient()
      // await supabase.from('contact_submissions').insert({
      //   name,
      //   email,
      //   subject,
      //   message,
      //   type,
      //   ip_address: getClientIp(req),
      //   created_at: new Date().toISOString(),
      // })

      // Send confirmation email to user
      const confirmationHtml = `
        <h2>Thank you for contacting us, ${name}!</h2>
        <p>We've received your message and will get back to you shortly.</p>
        
        <hr style="margin: 2rem 0; border: none; border-top: 1px solid #eee;">
        
        <h3>Your message:</h3>
        <p><strong>Subject:</strong> ${subject}</p>
        <p><strong>Type:</strong> ${type}</p>
        <p><strong>Message:</strong></p>
        <blockquote style="border-left: 4px solid #7c3aed; padding-left: 1rem; color: #666;">
          ${message.replace(/\n/g, '<br/>')}
        </blockquote>
        
        <hr style="margin: 2rem 0; border: none; border-top: 1px solid #eee;">
        
        <p>
          <strong>Response time:</strong> We typically respond within 2 hours during business hours (9am-5pm CST).
        </p>
        <p>
          <strong>In the meantime:</strong><br/>
          - Check our <a href="https://sasskit.io/docs/troubleshooting">Troubleshooting Guide</a><br/>
          - Join our <a href="https://discord.gg/sasskit">Discord community</a> for quick help<br/>
          - Review the <a href="https://sasskit.io/docs">documentation</a>
        </p>
        
        <p>Thanks,<br/>The SassKit Team</p>
      `

      const confirmationText = `
Thank you for contacting us, ${name}!

We've received your message and will get back to you shortly.

Subject: ${subject}
Type: ${type}

Message:
${message}

---

Response time: We typically respond within 2 hours during business hours.

In the meantime, check our documentation or join our community Discord.

Thanks,
The SassKit Team
      `

      await sendEmail({
        to: email,
        subject: `Thank you for contacting SassKit - ${subject}`,
        html: confirmationHtml,
        text: confirmationText,
      })

      // Send notification to support team
      const supportHtml = `
        <h2>New Contact Form Submission</h2>
        
        <p>
          <strong>Name:</strong> ${name}<br/>
          <strong>Email:</strong> <a href="mailto:${email}">${email}</a><br/>
          <strong>Type:</strong> ${type}<br/>
          <strong>Subject:</strong> ${subject}
        </p>
        
        <h3>Message:</h3>
        <blockquote style="border-left: 4px solid #7c3aed; padding-left: 1rem; color: #666;">
          ${message.replace(/\n/g, '<br/>')}
        </blockquote>
        
        <hr style="margin: 2rem 0; border: none; border-top: 1px solid #eee;">
        
        <p>
          <a href="mailto:${email}">Reply to ${name}</a>
        </p>
      `

      await sendEmail({
        to: 'support@sasskit.io',
        subject: `[${type.toUpperCase()}] ${subject} - ${name}`,
        html: supportHtml,
        replyTo: email,
      })

      logger.info(
        {
          email,
          name,
          type,
          subject,
        },
        'Contact form submission received'
      )

      return ok({
        success: true,
        message: 'Thank you for your message. We will be in touch soon!',
      })
    } catch (error) {
      logger.error(
        {
          err: error,
          email,
          name,
        },
        'Failed to process contact form'
      )
      return err('Failed to send message. Please try again later.', 500)
    }
  },
  {
    rateLimit: { limit: 5, windowSeconds: 3600 }, // 5 messages per hour per IP
    csrf: true,
  }
)
