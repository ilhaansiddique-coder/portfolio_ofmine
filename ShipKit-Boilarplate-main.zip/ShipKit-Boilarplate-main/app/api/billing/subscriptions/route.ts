import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'

export const GET = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    try {
      const { data: subscription, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', authUser.id)
        .single()

      if (error && error.code !== 'PGRST116') {
        logger.error({ err: error, userId: authUser.id }, 'Failed to fetch subscription')
        return err('Failed to fetch subscription', 500)
      }

      // If no subscription exists, user is on free plan
      if (!subscription) {
        return ok({
          id: '',
          user_id: authUser.id,
          ls_subscription_id: null,
          ls_customer_id: null,
          plan: 'free',
          status: 'inactive',
          current_period_start: null,
          current_period_end: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
      }

      return ok(subscription)
    } catch (error) {
      logger.error({ err: error, userId: authUser.id }, 'Error fetching subscription')
      return err('Failed to fetch subscription', 500)
    }
  },
  { rateLimit: { limit: 30 } }
)
