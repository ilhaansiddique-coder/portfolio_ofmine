import { NextRequest } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
import { getCheckoutUrl, PLANS } from '@/lib/lemonsqueezy'
import { createCheckoutSession, getStripePriceId } from '@/lib/stripe'
import { z } from 'zod'
import { validateBody } from '@/lib/validate'

const checkoutSchema = z.object({
  planId: z.enum(['free', 'basic', 'pro']),
  processor: z.enum(['lemonsqueezy', 'stripe']).default('lemonsqueezy'),
  billingInterval: z.enum(['monthly', 'yearly']).default('monthly'),
})

export const POST = withErrorHandler(
  async (req: NextRequest) => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    const body = await req.json()
    const validation = validateBody(checkoutSchema, body)
    if (!validation.success) return validation.response

    const { planId, processor, billingInterval } = validation.data

    if (planId === 'free') {
      return err('Cannot checkout free plan', 400)
    }

    try {
      const { data: profile } = await supabase
        .from('users')
        .select('email, full_name')
        .eq('id', authUser.id)
        .single()

      if (!profile) {
        return err('User profile not found', 404)
      }

      let checkoutUrl: string

      if (processor === 'stripe') {
        // Stripe checkout
        const priceId = getStripePriceId(
          planId as 'basic' | 'pro',
          billingInterval as 'monthly' | 'yearly'
        )
        checkoutUrl = await createCheckoutSession(priceId, authUser.id, profile.email)
      } else {
        // LemonSqueezy checkout (default)
        let variantId: string

        if (billingInterval === 'yearly') {
          variantId = PLANS[`${planId}_yearly` as keyof typeof PLANS]
        } else {
          variantId = PLANS[planId as keyof typeof PLANS]
        }

        checkoutUrl = await getCheckoutUrl(
          variantId,
          authUser.id,
          profile.email,
          profile.full_name ?? undefined
        )
      }

      // Update user's preferred payment processor
      await supabase.from('users').update({ payment_processor: processor }).eq('id', authUser.id)

      logger.info(
        { userId: authUser.id, planId, processor, billingInterval },
        'Checkout URL generated'
      )
      return ok({ checkoutUrl })
    } catch (error) {
      logger.error(
        { err: error, userId: authUser.id, planId, processor },
        'Failed to generate checkout URL'
      )
      return err('Failed to generate checkout URL', 500)
    }
  },
  { rateLimit: { limit: 10, windowSeconds: 60 }, csrf: true }
)
