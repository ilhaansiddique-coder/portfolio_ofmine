import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
import { cancelSubscription as stripeCancelSubscription } from '@/lib/stripe'
import { getCustomerPortalUrl } from '@/lib/lemonsqueezy'

export const POST = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    try {
      const { data: user } = await supabase
        .from('users')
        .select('payment_processor, ls_customer_id')
        .eq('id', authUser.id)
        .single()

      if (!user) {
        return err('User not found', 404)
      }

      const { data: subscription } = await supabase
        .from('subscriptions')
        .select('stripe_subscription_id, payment_processor')
        .eq('user_id', authUser.id)
        .single()

      const processor =
        user.payment_processor ??
        subscription?.payment_processor ??
        'lemonsqueezy'

      if (processor === 'lemonsqueezy' && user.ls_customer_id) {
        logger.info(
          { userId: authUser.id },
          'LemonSqueezy cancellation must be completed in the customer portal'
        )

        return ok({
          message: 'Manage LemonSqueezy cancellations in the customer portal.',
          portalUrl: getCustomerPortalUrl(),
          managedBy: 'lemonsqueezy',
        })
      }

      if (!subscription?.stripe_subscription_id) {
        return err('No active subscription found', 404)
      }

      await stripeCancelSubscription(subscription.stripe_subscription_id, true)

      const { error: subscriptionError } = await supabase
        .from('subscriptions')
        .update({ status: 'cancelled' })
        .eq('stripe_subscription_id', subscription.stripe_subscription_id)

      if (subscriptionError) {
        logger.error(
          { err: subscriptionError, userId: authUser.id },
          'Failed to update Stripe subscription status'
        )
        return err('Failed to cancel subscription', 500)
      }

      const { error: userError } = await supabase
        .from('users')
        .update({ subscription_status: 'cancelled' })
        .eq('id', authUser.id)

      if (userError) {
        logger.error(
          { err: userError, userId: authUser.id },
          'Failed to update subscription status'
        )
        return err('Failed to cancel subscription', 500)
      }

      logger.info(
        {
          userId: authUser.id,
          processor,
          subscriptionId: subscription.stripe_subscription_id,
        },
        'Subscription cancellation initiated'
      )

      return ok({
        message:
          'Subscription cancellation initiated. It will remain active until the end of your billing period.',
        managedBy: 'stripe',
      })
    } catch (error) {
      logger.error({ err: error, userId: authUser.id }, 'Error cancelling subscription')
      return err('Failed to cancel subscription', 500)
    }
  },
  { rateLimit: { limit: 5, windowSeconds: 60 }, csrf: true }
)
