import { NextRequest } from 'next/server'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { validateBody } from '@/lib/validate'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
import type { OrgRole } from '@/types'

const addMemberSchema = z.object({
  email: z.string().email(),
  role: z.enum(['admin', 'member']).default('member'),
})

const updateMemberSchema = z.object({
  role: z.enum(['admin', 'member']),
})

async function getCallerRole(
  supabase: Awaited<ReturnType<typeof createClient>>,
  userId: string,
  orgId: string
): Promise<OrgRole | null> {
  const { data } = await supabase
    .from('memberships')
    .select('role')
    .eq('user_id', userId)
    .eq('org_id', orgId)
    .maybeSingle()
  return data?.role ?? null
}

/** GET /api/orgs/:orgId/members — list all members */
export const GET = withErrorHandler(
  async (_req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params

  const callerRole = await getCallerRole(supabase, user.id, orgId)
  if (!callerRole) return err('Not found', 404)

  const { data: memberships, error } = await supabase
    .from('memberships')
    .select('id, user_id, org_id, role, created_at')
    .eq('org_id', orgId)
    .order('created_at', { ascending: true })

  if (error) {
    logger.error({ err: error, orgId }, 'Failed to fetch members')
    return err('Failed to load members', 500)
  }

  // Fetch user details for each member
  const userIds = (memberships ?? []).map((m) => m.user_id)
  const { data: users } = await supabase
    .from('users')
    .select('id, email, full_name, avatar_url')
    .in('id', userIds)
  const userMap = new Map((users ?? []).map((u) => [u.id, u]))

  const result = (memberships ?? []).map((m) => ({
    ...m,
    user: userMap.get(m.user_id) ?? null,
  }))

  return ok(result)
  },
  { rateLimit: { limit: 30 } }
)

/** POST /api/orgs/:orgId/members — invite a member by email */
export const POST = withErrorHandler(
  async (req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params

  const callerRole = await getCallerRole(supabase, user.id, orgId)
  if (!callerRole) return err('Not found', 404)
  if (!['owner', 'admin'].includes(callerRole)) return err('Forbidden', 403)

  const body = await req.json()
  const validation = validateBody(addMemberSchema, body)
  if (!validation.success) return validation.response

  const { email, role } = validation.data

  // Only owners can add admins
  if (role === 'admin' && callerRole !== 'owner') {
    return err('Only the owner can add admins', 403)
  }

  // Find user by email
  const { data: targetUser } = await supabase
    .from('users')
    .select('id')
    .eq('email', email)
    .maybeSingle()

  if (!targetUser) return err('User not found', 404)

  // Check if already a member
  const { data: existing } = await supabase
    .from('memberships')
    .select('id')
    .eq('user_id', targetUser.id)
    .eq('org_id', orgId)
    .maybeSingle()

  if (existing) return err('User is already a member', 409)

  const { data: membership, error } = await supabase
    .from('memberships')
    .insert({ user_id: targetUser.id, org_id: orgId, role })
    .select()
    .single()

  if (error) {
    logger.error({ err: error, orgId, email }, 'Failed to add member')
    return err('Failed to add member', 500)
  }

  logger.info({ orgId, email, role, addedBy: user.id }, 'Member added')
    return ok(membership, 201)
  },
  { rateLimit: { limit: 10 }, csrf: true }
)

/** DELETE /api/orgs/:orgId/members?userId=xxx — remove a member */
export const DELETE = withErrorHandler(
  async (req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params
  const targetUserId = new URL(req.url).searchParams.get('userId')
  if (!targetUserId) return err('userId query parameter is required', 400)

  const callerRole = await getCallerRole(supabase, user.id, orgId)
  if (!callerRole) return err('Not found', 404)

  // Users can remove themselves, or admins/owners can remove others
  const isSelf = targetUserId === user.id
  if (!isSelf && !['owner', 'admin'].includes(callerRole)) {
    return err('Forbidden', 403)
  }

  // Can't remove the owner
  const { data: rawTarget } = await supabase
    .from('memberships')
    .select('role')
    .eq('user_id', targetUserId)
    .eq('org_id', orgId)
    .maybeSingle()

  if (!rawTarget) return err('Member not found', 404)
  if (rawTarget.role === 'owner') {
    return err('Cannot remove the organization owner', 400)
  }

  const { error } = await supabase
    .from('memberships')
    .delete()
    .eq('user_id', targetUserId)
    .eq('org_id', orgId)

  if (error) {
    logger.error({ err: error, orgId, targetUserId }, 'Failed to remove member')
    return err('Failed to remove member', 500)
  }

  logger.info({ orgId, removedUserId: targetUserId, removedBy: user.id }, 'Member removed')
    return ok({ removed: true })
  },
  { rateLimit: { limit: 10 }, csrf: true }
)

/** PATCH /api/orgs/:orgId/members?userId=xxx — update a member's role */
export const PATCH = withErrorHandler(
  async (req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params
  const targetUserId = new URL(req.url).searchParams.get('userId')
  if (!targetUserId) return err('userId query parameter is required', 400)

  const callerRole = await getCallerRole(supabase, user.id, orgId)
  if (!callerRole) return err('Not found', 404)
  if (callerRole !== 'owner') return err('Only the owner can change roles', 403)

  const body = await req.json()
  const validation = validateBody(updateMemberSchema, body)
  if (!validation.success) return validation.response

  // Can't change the owner's role
  if (targetUserId === user.id) return err('Cannot change your own role', 400)

  const { data: updated, error } = await supabase
    .from('memberships')
    .update({ role: validation.data.role })
    .eq('user_id', targetUserId)
    .eq('org_id', orgId)
    .select()
    .single()

  if (error) {
    logger.error({ err: error, orgId, targetUserId }, 'Failed to update member role')
    return err('Failed to update role', 500)
  }

  logger.info({ orgId, targetUserId, newRole: validation.data.role, changedBy: user.id }, 'Member role updated')
    return ok(updated)
  },
  { rateLimit: { limit: 10 }, csrf: true }
)
