import { NextRequest } from 'next/server'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { validateBody } from '@/lib/validate'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
import type { OrgRole } from '@/types'

const updateOrgSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  slug: z
    .string()
    .min(2)
    .max(50)
    .regex(/^[a-z0-9-]+$/, 'Slug must be lowercase alphanumeric with hyphens')
    .optional(),
  logo_url: z.string().url().nullable().optional(),
})

async function getOrgMembership(
  supabase: Awaited<ReturnType<typeof createClient>>,
  userId: string,
  orgId: string
): Promise<{ role: OrgRole } | null> {
  const { data } = await supabase
    .from('memberships')
    .select('role')
    .eq('user_id', userId)
    .eq('org_id', orgId)
    .maybeSingle()
  return data
}

/** GET /api/orgs/:orgId — get single org details */
export const GET = withErrorHandler(
  async (_req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params

  const membership = await getOrgMembership(supabase, user.id, orgId)
  if (!membership) return err('Not found', 404)

  const { data: org, error } = await supabase
    .from('organizations')
    .select('*')
    .eq('id', orgId)
    .single()

  if (error || !org) return err('Not found', 404)

  return ok({ ...org, currentUserRole: membership.role })
  },
  { rateLimit: { limit: 30 } }
)

/** PATCH /api/orgs/:orgId — update org (admin/owner only) */
export const PATCH = withErrorHandler(
  async (req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params

  const membership = await getOrgMembership(supabase, user.id, orgId)
  if (!membership) return err('Not found', 404)
  if (!['owner', 'admin'].includes(membership.role)) {
    return err('Forbidden', 403)
  }

  const body = await req.json()
  const validation = validateBody(updateOrgSchema, body)
  if (!validation.success) return validation.response

  // If slug is being changed, check uniqueness
  if (validation.data.slug) {
    const { data: existing } = await supabase
      .from('organizations')
      .select('id')
      .eq('slug', validation.data.slug)
      .neq('id', orgId)
      .maybeSingle()
    if (existing) return err('Slug already taken', 409)
  }

  const { data: updated, error } = await supabase
    .from('organizations')
    .update(validation.data)
    .eq('id', orgId)
    .select()
    .single()

  if (error) {
    logger.error({ err: error, orgId }, 'Failed to update organization')
    return err('Failed to update organization', 500)
  }

  logger.info({ orgId, userId: user.id }, 'Organization updated')
    return ok(updated)
  },
  { rateLimit: { limit: 20 }, csrf: true }
)

/** DELETE /api/orgs/:orgId — delete org (owner only) */
export const DELETE = withErrorHandler(
  async (_req: NextRequest, ctx) => {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { orgId } = await ctx.params

  const membership = await getOrgMembership(supabase, user.id, orgId)
  if (!membership) return err('Not found', 404)
  if (membership.role !== 'owner') return err('Only the owner can delete this organization', 403)

  const { error } = await supabase
    .from('organizations')
    .delete()
    .eq('id', orgId)

  if (error) {
    logger.error({ err: error, orgId }, 'Failed to delete organization')
    return err('Failed to delete organization', 500)
  }

  logger.info({ orgId, userId: user.id }, 'Organization deleted')
    return ok({ deleted: true })
  },
  { rateLimit: { limit: 5 }, csrf: true }
)
