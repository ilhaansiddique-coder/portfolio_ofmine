import { NextRequest } from 'next/server'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { validateBody } from '@/lib/validate'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'

const createOrgSchema = z.object({
  name: z.string().min(1).max(100),
  slug: z
    .string()
    .min(2)
    .max(50)
    .regex(/^[a-z0-9-]+$/, 'Slug must be lowercase alphanumeric with hyphens'),
})

/** GET /api/orgs — list orgs the current user belongs to */
export const GET = withErrorHandler(
  async () => {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const { data: memberships, error: mErr } = await supabase
    .from('memberships')
    .select('org_id, role')
    .eq('user_id', user.id)

  if (mErr) {
    logger.error({ err: mErr, userId: user.id }, 'Failed to fetch memberships')
    return err('Failed to load organizations', 500)
  }
  const orgIds = (memberships ?? []).map((m) => m.org_id)
  if (orgIds.length === 0) return ok([])

  const { data: orgs, error: oErr } = await supabase
    .from('organizations')
    .select('*')
    .in('id', orgIds)
    .order('created_at', { ascending: false })

  if (oErr) {
    logger.error({ err: oErr, userId: user.id }, 'Failed to fetch organizations')
    return err('Failed to load organizations', 500)
  }

  const roleMap = new Map((memberships ?? []).map((m) => [m.org_id, m.role]))
  const result = (orgs ?? []).map((org) => ({
    ...org,
    currentUserRole: roleMap.get(org.id) ?? 'member',
  }))

  return ok(result)
  },
  { rateLimit: { limit: 30 } }
)

/** POST /api/orgs — create a new org and add the creator as owner */
export const POST = withErrorHandler(
  async (req: NextRequest) => {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return err('Unauthorized', 401)

  const body = await req.json()
  const validation = validateBody(createOrgSchema, body)
  if (!validation.success) return validation.response

  const { name, slug } = validation.data

  // Check slug uniqueness
  const { data: existing } = await supabase
    .from('organizations')
    .select('id')
    .eq('slug', slug)
    .maybeSingle()

  if (existing) return err('Slug already taken', 409)

  const { data: org, error: orgErr } = await supabase
    .from('organizations')
    .insert({ name, slug, owner_id: user.id })
    .select()
    .single()

  if (orgErr || !org) {
    logger.error({ err: orgErr, userId: user.id }, 'Failed to create organization')
    return err('Failed to create organization', 500)
  }

  const { error: memErr } = await supabase
    .from('memberships')
    .insert({ user_id: user.id, org_id: org.id, role: 'owner' })

  if (memErr) {
    logger.error({ err: memErr, orgId: org.id }, 'Failed to create owner membership')
    await supabase.from('organizations').delete().eq('id', org.id)
    return err('Failed to create organization', 500)
  }

  logger.info({ orgId: org.id, userId: user.id, slug }, 'Organization created')
    return ok(org, 201)
  },
  { rateLimit: { limit: 10 }, csrf: true }
)
