import { createClient } from '@/lib/supabase/server'
import redis from '@/lib/redis'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'

export const GET = withErrorHandler(
  async () => {
  const checks: Record<string, boolean> = {}

  try {
    const supabase = await createClient()
    await supabase.from('users').select('id').limit(1)
    checks.database = true
  } catch {
    checks.database = false
  }

  try {
    await redis.ping()
    checks.redis = true
  } catch {
    checks.redis = false
  }

  const allHealthy = Object.values(checks).every(Boolean)

  if (!allHealthy) {
    return err('Service degraded', 503, 'DEGRADED')
  }

  return ok({ status: 'ok', checks, timestamp: new Date().toISOString() })
  },
  { rateLimit: { limit: 60 } }
)
