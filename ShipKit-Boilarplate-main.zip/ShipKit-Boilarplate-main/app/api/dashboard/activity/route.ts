import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'

export const GET = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    const { data: activity, error } = await supabase
      .from('user_activity')
      .select('id, action, description, metadata, created_at')
      .eq('user_id', authUser.id)
      .order('created_at', { ascending: false })
      .limit(20)

    if (error) {
      logger.error(
        { err: error, userId: authUser.id },
        'Failed to fetch user activity'
      )
      return err('Failed to fetch activity', 500)
    }

    return ok(activity ?? [])
  },
  { rateLimit: { limit: 30 } }
)
