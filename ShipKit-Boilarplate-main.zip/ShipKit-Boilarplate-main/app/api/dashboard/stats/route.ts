import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'

export const GET = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    // Run all queries concurrently
    const [orgCountResult, profileResult, userMembershipsResult] =
      await Promise.all([
        // Count organizations user belongs to
        supabase
          .from('memberships')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', authUser.id),

        // User profile for plan + created_at
        supabase
          .from('users')
          .select('plan, created_at')
          .eq('id', authUser.id)
          .single(),

        // Get org_ids for team member count
        supabase
          .from('memberships')
          .select('org_id')
          .eq('user_id', authUser.id),
      ])

    // Calculate total team members across all orgs
    let teamMembers = 0
    const userMemberships = userMembershipsResult.data
    if (userMemberships && userMemberships.length > 0) {
      const orgIds = userMemberships.map((m) => m.org_id)
      const { count } = await supabase
        .from('memberships')
        .select('*', { count: 'exact', head: true })
        .in('org_id', orgIds)
      teamMembers = count ?? 0
    }

    const profile = profileResult.data
    const createdAt = profile?.created_at
      ? new Date(profile.created_at)
      : new Date()
    const now = new Date()
    const memberSinceDays = Math.floor(
      (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24)
    )

    logger.debug({ userId: authUser.id }, 'Dashboard stats fetched')

    return ok({
      organizations: orgCountResult.count ?? 0,
      teamMembers,
      plan: profile?.plan ?? 'free',
      memberSinceDays,
    })
  },
  { rateLimit: { limit: 30 } }
)
