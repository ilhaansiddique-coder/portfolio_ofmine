import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
import { isAdminEmail } from '@/lib/admin'

export const GET = withErrorHandler(
  async () => {
    try {
      const authClient = await createClient()
      const {
        data: { user },
      } = await authClient.auth.getUser()

      if (!user) return err('Unauthorized', 401)
      if (!isAdminEmail(user.email)) return err('Forbidden', 403)

      const supabase = createAdminClient()

      // Get total users
      const { count: totalUsers } = await supabase
        .from('users')
        .select('id', { count: 'exact', head: true })

      // Get active subscriptions
      const { count: activeSubscriptions } = await supabase
        .from('users')
        .select('id', { count: 'exact', head: true })
        .eq('subscription_status', 'active')

      // Get free plan users
      const { count: freeUsers } = await supabase
        .from('users')
        .select('id', { count: 'exact', head: true })
        .eq('plan', 'free')

      // Get paid users (basic + pro)
      const { count: paidUsers } = await supabase
        .from('users')
        .select('id', { count: 'exact', head: true })
        .in('plan', ['basic', 'pro'])

      // Calculate MRR (Monthly Recurring Revenue) - simple calculation
      const { data: subscriptions } = await supabase
        .from('users')
        .select('plan')
        .eq('subscription_status', 'active')

      const mrr = (subscriptions ?? []).reduce((total, subscription) => {
        if (subscription.plan === 'basic') return total + 19
        if (subscription.plan === 'pro') return total + 49
        return total
      }, 0)

      const conversionRate = totalUsers ? (paidUsers || 0) / (totalUsers || 1) : 0
      const avgPlanValue = (paidUsers && paidUsers > 0) ? mrr / paidUsers : 0

      return ok({
        totalUsers: totalUsers || 0,
        activeSubscriptions: activeSubscriptions || 0,
        freeUsers: freeUsers || 0,
        paidUsers: paidUsers || 0,
        mrr: mrr,
        conversionRate: conversionRate,
        avgPlanValue: avgPlanValue,
        churnRate: 0, // Would need historical data to calculate
      })
    } catch (error) {
      logger.error({ err: error }, 'Failed to fetch admin stats')
      return err('Failed to fetch statistics', 500)
    }
  },
  { rateLimit: { limit: 20 } }
)
