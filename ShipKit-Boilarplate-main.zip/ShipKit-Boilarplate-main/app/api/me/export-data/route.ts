import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { err } from '@/lib/api-response'
import { logger } from '@/lib/logger'

export const GET = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    try {
      // Fetch all user data
      const [userProfile, subscriptions, organizations, activity] = await Promise.all([
        supabase
          .from('users')
          .select('*')
          .eq('id', authUser.id)
          .single(),
        supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', authUser.id),
        supabase
          .from('organizations')
          .select('*')
          .eq('owner_id', authUser.id),
        supabase
          .from('user_activity')
          .select('*')
          .eq('user_id', authUser.id),
      ])

      const exportData = {
        exportedAt: new Date().toISOString(),
        user: userProfile.data,
        subscriptions: subscriptions.data,
        organizations: organizations.data,
        activity: activity.data,
      }

      logger.info({ userId: authUser.id }, 'User data exported')

      return new NextResponse(JSON.stringify(exportData, null, 2), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': 'attachment; filename=data-export.json',
        },
      })
    } catch (error) {
      logger.error({ err: error, userId: authUser.id }, 'Failed to export user data')
      return err('Failed to export data', 500)
    }
  },
  { rateLimit: { limit: 5, windowSeconds: 3600 } }
)
