import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'

export const POST = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    try {
      const admin = createAdminClient()

      // First, delete the user from the database (cascade will handle related data)
      const { error: dbError } = await admin
        .from('users')
        .delete()
        .eq('id', authUser.id)

      if (dbError) {
        logger.error({ err: dbError, userId: authUser.id }, 'Failed to delete user from database')
        return err('Failed to delete account', 500)
      }

      // Delete the auth user
      const { error: authError } = await admin.auth.admin.deleteUser(authUser.id)

      if (authError) {
        logger.error({ err: authError, userId: authUser.id }, 'Failed to delete auth user')
        return err('Failed to delete account', 500)
      }

      logger.info({ userId: authUser.id }, 'User account deleted')
      return ok({ message: 'Account deleted successfully' })
    } catch (error) {
      logger.error({ err: error, userId: authUser.id }, 'Error deleting account')
      return err('Failed to delete account', 500)
    }
  },
  { rateLimit: { limit: 2, windowSeconds: 3600 }, csrf: true }
)
