import { NextRequest } from 'next/server'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { withErrorHandler } from '@/lib/with-error-handler'
import { validateBody } from '@/lib/validate'
import { ok, err } from '@/lib/api-response'
import { logger } from '@/lib/logger'
const updateProfileSchema = z.object({
  full_name: z.string().min(1).max(100).optional(),
  avatar_url: z.string().url().nullable().optional(),
})

export const GET = withErrorHandler(
  async () => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    const { data: profile, error } = await supabase
      .from('users')
      .select('id, email, full_name, avatar_url, plan, is_paid, ls_customer_id, stripe_customer_id, payment_processor, subscription_status')
      .eq('id', authUser.id)
      .single()

    if (error || !profile) {
      logger.error({ err: error, userId: authUser.id }, 'Failed to fetch user profile')
      return err('Profile not found', 404)
    }

    return ok(profile)
  },
  { rateLimit: { limit: 30 } }
)

export const PATCH = withErrorHandler(
  async (req: NextRequest) => {
    const supabase = await createClient()
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser()

    if (!authUser) return err('Unauthorized', 401)

    const body = await req.json()
    const validation = validateBody(updateProfileSchema, body)
    if (!validation.success) return validation.response

    const { data: updated, error } = await supabase
      .from('users')
      .update(validation.data)
      .eq('id', authUser.id)
      .select('id, email, full_name, avatar_url, plan, is_paid, ls_customer_id, stripe_customer_id, payment_processor, subscription_status')
      .single()

    if (error) {
      logger.error({ err: error, userId: authUser.id }, 'Failed to update user profile')
      return err('Failed to update profile', 500)
    }

    logger.info({ userId: authUser.id }, 'Profile updated')
    return ok(updated)
  },
  { rateLimit: { limit: 20 }, csrf: true }
)
