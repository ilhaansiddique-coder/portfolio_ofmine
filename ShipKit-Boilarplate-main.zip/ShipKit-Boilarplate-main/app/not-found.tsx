import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function NotFoundStyles() {
  return (
    <ScopedStyle>{`
      .nf-root {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        text-align: center;
        padding: 2rem;
        font-family: var(--font-body), sans-serif;
      }
      .nf-icon {
        width: 68px;
        height: 68px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(168,85,247,0.14));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #7c3aed;
        margin-bottom: 1.25rem;
      }
      .nf-code {
        font-family: var(--font-heading), sans-serif;
        font-size: 4rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1;
        margin-bottom: 0.5rem;
      }
      .nf-title {
        font-size: 1.1rem;
        font-weight: 800;
        color: #1a1625;
        margin-bottom: 0.5rem;
        font-family: var(--font-heading), sans-serif;
      }
      .nf-desc {
        font-size: 0.85rem;
        color: #6b5f80;
        line-height: 1.55;
        margin-bottom: 1.5rem;
        max-width: 360px;
      }
      .nf-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.6rem 1.25rem;
        font-size: 0.82rem;
        font-weight: 700;
        color: #fff;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        border: none;
        border-radius: 0.75rem;
        text-decoration: none;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .nf-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
    `}</ScopedStyle>
  )
}

export default function NotFound() {
  return (
    <>
      <NotFoundStyles />
      <div className="nf-root">
        <div className="nf-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
            <circle cx="12" cy="12" r="10" />
            <path d="M16 16s-1.5-2-4-2-4 2-4 2" />
            <line x1="9" y1="9" x2="9.01" y2="9" />
            <line x1="15" y1="9" x2="15.01" y2="9" />
          </svg>
        </div>
        <div className="nf-code">404</div>
        <h1 className="nf-title">Page not found</h1>
        <p className="nf-desc">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link href="/" className="nf-btn">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="19" y1="12" x2="5" y2="12" />
            <polyline points="12 19 5 12 12 5" />
          </svg>
          Back to home
        </Link>
      </div>
    </>
  )
}
