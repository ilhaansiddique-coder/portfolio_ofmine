import Link from 'next/link'
import { NavbarClient } from '@/components/shared/NavbarClient'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function LandingStyles() {
  return (
    <ScopedStyle>{`
      .lp-root {
        min-height: 100vh;
        font-family: var(--font-body), sans-serif;
      }

      /* Hero */
      .lp-hero {
        max-width: 1200px;
        margin: 0 auto;
        padding: 5rem 1.5rem 3.5rem;
        text-align: center;
      }
      .lp-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 1rem;
      }
      .lp-eyebrow__dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #7c3aed;
        animation: lp-pulse 2s ease-in-out infinite;
      }
      .lp-hero-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 3.25rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.08;
        margin: 0 0 1rem;
      }
      .lp-hero-title span {
        background: linear-gradient(135deg, #7c3aed, #a855f7);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }
      .lp-hero-sub {
        max-width: 540px;
        margin: 0 auto 2rem;
        font-size: 1.05rem;
        color: #6b5f80;
        line-height: 1.6;
      }
      .lp-hero-actions {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        flex-wrap: wrap;
      }
      .lp-btn {
        padding: 0.7rem 1.5rem;
        font-size: 0.85rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.18s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        font-family: var(--font-body), sans-serif;
      }
      .lp-btn--primary {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
      }
      .lp-btn--primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .lp-btn--ghost {
        background: rgba(124,58,237,0.06);
        color: #7c3aed;
        border: 1.5px solid rgba(124,58,237,0.12);
      }
      .lp-btn--ghost:hover {
        background: rgba(124,58,237,0.1);
      }

      /* Features */
      .lp-features {
        max-width: 1200px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
      }
      .lp-section-label {
        text-align: center;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #7c3aed;
        margin-bottom: 0.5rem;
      }
      .lp-section-title {
        text-align: center;
        font-family: var(--font-heading), sans-serif;
        font-size: 2rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        margin: 0 0 2rem;
      }
      .lp-features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 1.25rem;
      }
      .lp-feature-card {
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.125rem;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        transition: all 0.25s ease;
        animation: lp-fade-up 0.4s ease both;
      }
      .lp-feature-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(26,22,37,0.08);
        border-color: rgba(124,58,237,0.15);
      }
      .lp-feature-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: linear-gradient(135deg, rgba(124,58,237,0.08), rgba(168,85,247,0.12));
        display: flex;
        align-items: center;
        justify-content: center;
        color: #7c3aed;
        margin-bottom: 0.75rem;
      }
      .lp-feature-name {
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 800;
        color: #1a1625;
        margin-bottom: 0.35rem;
      }
      .lp-feature-desc {
        font-size: 0.8rem;
        color: #6b5f80;
        line-height: 1.55;
      }

      /* Pricing */
      .lp-pricing {
        max-width: 1200px;
        margin: 0 auto;
        padding: 3rem 1.5rem 4rem;
      }
      .lp-pricing-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 1.25rem;
        max-width: 900px;
        margin: 0 auto;
      }

      /* FAQ */
      .lp-faq {
        max-width: 680px;
        margin: 0 auto;
        padding: 2rem 1.5rem 3rem;
      }
      .lp-faq-item {
        border-bottom: 1px solid rgba(124,58,237,0.06);
        padding: 1.25rem 0;
      }
      .lp-faq-q {
        font-size: 0.9rem;
        font-weight: 700;
        color: #1a1625;
        margin-bottom: 0.5rem;
      }
      .lp-faq-a {
        font-size: 0.82rem;
        color: #6b5f80;
        line-height: 1.6;
      }

      /* CTA */
      .lp-cta-section {
        max-width: 680px;
        margin: 0 auto;
        padding: 3rem 1.5rem 5rem;
        text-align: center;
      }
      .lp-cta-card {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        border-radius: 1.25rem;
        padding: 3rem 2rem;
        color: #fff;
      }
      .lp-cta-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 1.75rem;
        font-weight: 900;
        margin-bottom: 0.75rem;
        letter-spacing: -0.02em;
      }
      .lp-cta-sub {
        font-size: 0.9rem;
        opacity: 0.85;
        margin-bottom: 1.5rem;
        line-height: 1.5;
      }
      .lp-cta-btn {
        display: inline-flex;
        padding: 0.7rem 1.5rem;
        font-size: 0.85rem;
        font-weight: 700;
        color: #7c3aed;
        background: #fff;
        border: none;
        border-radius: 0.75rem;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .lp-cta-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(0,0,0,0.15);
      }

      /* Footer */
      .lp-footer {
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 1.5rem;
        border-top: 1px solid rgba(124,58,237,0.06);
      }
      .lp-footer-content {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
      }
      .lp-footer-links {
        display: flex;
        justify-content: center;
        gap: 1.5rem;
        flex-wrap: wrap;
      }
      .lp-footer-link {
        font-size: 0.75rem;
        color: #6b5f80;
        text-decoration: none;
        transition: color 0.2s ease;
        font-weight: 500;
      }
      .lp-footer-link:hover {
        color: #7c3aed;
      }
      .lp-footer-bottom {
        text-align: center;
        font-size: 0.75rem;
        color: #a89bbe;
      }
      .lp-footer-divider {
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: rgba(124,58,237,0.2);
      }
      @media (max-width: 640px) {
        .lp-footer-links {
          gap: 1rem;
        }
      }

      @keyframes lp-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      @keyframes lp-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%      { opacity: 0.4; transform: scale(0.85); }
      }

      @media (max-width: 640px) {
        .lp-hero-title { font-size: 2.25rem; }
        .lp-hero { padding: 3rem 1rem 2rem; }
        .lp-section-title { font-size: 1.5rem; }
      }
    `}</ScopedStyle>
  )
}

const features = [
  {
    name: 'Authentication',
    desc: 'Complete auth flow with email/password and social logins. Protected routes out of the box.',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0110 0v4" />
      </svg>
    ),
  },
  {
    name: 'Payments',
    desc: 'LemonSqueezy integration with webhook processing, idempotent event handling, and plan management.',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <rect x="1" y="4" width="22" height="16" rx="2" /><line x1="1" y1="10" x2="23" y2="10" />
      </svg>
    ),
  },
  {
    name: 'Database & RLS',
    desc: 'Supabase with row-level security, migrations, and type-safe queries. Production-ready schema.',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <ellipse cx="12" cy="5" rx="9" ry="3" /><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" /><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
      </svg>
    ),
  },
  {
    name: 'Background Jobs',
    desc: 'BullMQ workers for emails, notifications, and automation. Redis-backed job processing.',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
      </svg>
    ),
  },
  {
    name: 'AI-Ready',
    desc: 'Pre-configured Claude, Groq, and ElevenLabs integrations. Build AI features instantly.',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <path d="M12 2a4 4 0 014 4c0 1.95-2 3-2 8h-4c0-5-2-6.05-2-8a4 4 0 014-4z" /><line x1="10" y1="18" x2="14" y2="18" /><line x1="10" y1="22" x2="14" y2="22" /><line x1="11" y1="18" x2="11" y2="22" /><line x1="13" y1="18" x2="13" y2="22" />
      </svg>
    ),
  },
  {
    name: 'Observability',
    desc: 'Structured logging with Pino, error tracking with GlitchTip, and health check endpoints.',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
      </svg>
    ),
  },
]

const faqs = [
  {
    q: 'What do I need to get started?',
    a: 'A Supabase instance (self-hosted or cloud), Redis, and Node.js 20+. Everything else is included.',
  },
  {
    q: 'Can I use Stripe instead of LemonSqueezy?',
    a: 'Yes. The webhook handler follows a standard pattern. Swap the signature verification and event mapping.',
  },
  {
    q: 'Is the UI customizable?',
    a: 'Every component uses scoped CSS with design tokens. Change the color palette in globals.css and all components update.',
  },
  {
    q: 'Does it include testing?',
    a: 'Vitest for unit and integration tests, Playwright for E2E. CI-ready with typecheck and lint scripts.',
  },
]

export default function LandingPage() {
  return (
    <div className="lp-root">
      <LandingStyles />
      <NavbarClient isAuthenticated={false} profileInitial="?" />

      {/* Hero */}
      <section className="lp-hero">
        <div className="lp-eyebrow">
          <span className="lp-eyebrow__dot" />
          Production-Ready SaaS
        </div>
        <h1 className="lp-hero-title">
          Ship your <span>SaaS</span> in days,<br />not months
        </h1>
        <p className="lp-hero-sub">
          Auth, payments, database, background jobs, AI integrations, and a beautiful UI.
          Everything you need to launch your product.
        </p>
        <div className="lp-hero-actions">
          <Link href="/signup" className="lp-btn lp-btn--primary">
            Get started free
          </Link>
          <Link href="#features" className="lp-btn lp-btn--ghost">
            See features
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="lp-features" id="features">
        <div className="lp-section-label">Features</div>
        <h2 className="lp-section-title">Everything you need, built in</h2>
        <div className="lp-features-grid">
          {features.map((f, i) => (
            <div
              key={f.name}
              className="lp-feature-card"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="lp-feature-icon">{f.icon}</div>
              <div className="lp-feature-name">{f.name}</div>
              <p className="lp-feature-desc">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="lp-pricing" id="pricing">
        <div className="lp-section-label">Pricing</div>
        <h2 className="lp-section-title">Simple, transparent pricing</h2>
        <div className="lp-pricing-grid">
          {(['free', 'basic', 'pro'] as const).map((plan, i) => (
            <PricingCardInline key={plan} plan={plan} popular={plan === 'pro'} index={i} />
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="lp-faq" id="faq">
        <div className="lp-section-label">FAQ</div>
        <h2 className="lp-section-title">Common questions</h2>
        {faqs.map((faq) => (
          <div key={faq.q} className="lp-faq-item">
            <div className="lp-faq-q">{faq.q}</div>
            <p className="lp-faq-a">{faq.a}</p>
          </div>
        ))}
      </section>

      {/* CTA */}
      <section className="lp-cta-section">
        <div className="lp-cta-card">
          <h2 className="lp-cta-title">Ready to build?</h2>
          <p className="lp-cta-sub">
            Start with the free plan and upgrade as you grow. No credit card required.
          </p>
          <Link href="/signup" className="lp-cta-btn">
            Get started
          </Link>
        </div>
      </section>

      <footer className="lp-footer">
        <div className="lp-footer-content">
          <div className="lp-footer-links">
            <Link href="/legal/terms" className="lp-footer-link">Terms of Service</Link>
            <div className="lp-footer-divider" aria-hidden="true" />
            <Link href="/legal/privacy" className="lp-footer-link">Privacy Policy</Link>
            <div className="lp-footer-divider" aria-hidden="true" />
            <Link href="/legal/refund-policy" className="lp-footer-link">Refund Policy</Link>
            <div className="lp-footer-divider" aria-hidden="true" />
            <Link href="/legal/contact" className="lp-footer-link">Contact</Link>
          </div>
          <div className="lp-footer-bottom">
            MySaaS. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}

/* Inline pricing card for server component usage */
function PricingCardInline({
  plan,
  popular,
  index,
}: {
  plan: 'free' | 'basic' | 'pro'
  popular?: boolean
  index: number
}) {
  const limits: Record<string, { features: string[] }> = {
    free: { features: ['1 project', '100MB storage', 'Community support'] },
    basic: { features: ['5 projects', '1GB storage', 'Priority support', 'API access'] },
    pro: { features: ['Unlimited projects', '10GB storage', 'Dedicated support', 'Custom integrations', 'Advanced analytics'] },
  }
  const display: Record<string, { name: string; price: string }> = {
    free: { name: 'Free', price: '$0' },
    basic: { name: 'Basic', price: '$19' },
    pro: { name: 'Pro', price: '$49' },
  }

  const d = display[plan]
  const l = limits[plan]

  return (
    <div
      className={`lp-feature-card ${popular ? 'lp-feature-card--popular' : ''}`}
      style={{
        animationDelay: `${index * 80}ms`,
        padding: '1.75rem 1.5rem',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        ...(popular ? { borderColor: 'rgba(124,58,237,0.2)', boxShadow: '0 4px 16px rgba(124,58,237,0.1)' } : {}),
      }}
    >
      {popular && (
        <span style={{
          position: 'absolute', top: -10, right: '1.25rem',
          padding: '0.25rem 0.75rem', fontSize: '0.6rem', fontWeight: 700,
          letterSpacing: '0.08em', textTransform: 'uppercase', color: '#fff',
          background: 'linear-gradient(135deg, #7c3aed, #a855f7)',
          borderRadius: 999,
        }}>
          Most Popular
        </span>
      )}
      <div style={{ fontSize: '0.78rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#7c3aed', marginBottom: '0.5rem' }}>
        {d.name}
      </div>
      <div style={{ fontFamily: 'var(--font-heading), sans-serif', fontSize: '2.25rem', fontWeight: 900, color: '#1a1625', letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: '0.25rem' }}>
        {d.price}
        {plan !== 'free' && <span style={{ fontSize: '0.8rem', fontWeight: 400, color: '#8b7fa8' }}>/mo</span>}
      </div>
      <div style={{ height: 1, background: 'rgba(124,58,237,0.06)', margin: '1.25rem 0' }} />
      <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 1.5rem', display: 'flex', flexDirection: 'column', gap: '0.6rem', flex: 1 }}>
        {l.features.map((f) => (
          <li key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.8rem', color: '#4b4466', lineHeight: 1.5 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" style={{ flexShrink: 0, marginTop: 1 }}>
              <path d="M20 6L9 17l-5-5" />
            </svg>
            {f}
          </li>
        ))}
      </ul>
      <Link
        href="/signup"
        style={{
          display: 'block', textAlign: 'center', padding: '0.65rem',
          fontSize: '0.8rem', fontWeight: 700, borderRadius: '0.75rem',
          textDecoration: 'none', transition: 'all 0.18s ease',
          ...(popular
            ? { background: 'linear-gradient(135deg, #7c3aed, #6d28d9)', color: '#fff', boxShadow: '0 2px 8px rgba(124,58,237,0.25)' }
            : { background: 'rgba(124,58,237,0.06)', color: '#7c3aed', border: '1.5px solid rgba(124,58,237,0.12)' }),
        }}
      >
        {plan === 'free' ? 'Get started' : `Upgrade to ${d.name}`}
      </Link>
    </div>
  )
}
