import { ScopedStyle } from '@/components/shared/ScopedStyle'
import { clientEnv } from '@/lib/env'

export const metadata = { title: 'Support' }

function SupportStyles() {
  return (
    <ScopedStyle>{`
      .support-root {
        max-width: 760px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
      }
      .support-title {
        font-family: var(--font-heading), sans-serif;
        font-size: 2.25rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        margin: 0 0 0.75rem;
      }
      .support-copy {
        color: #4b4466;
        line-height: 1.7;
        margin: 0.75rem 0;
      }
      .support-note {
        margin-top: 1.5rem;
        padding: 1rem 1.125rem;
        border-radius: 1rem;
        background: rgba(124,58,237,0.06);
        color: #5b4d74;
      }
    `}</ScopedStyle>
  )
}

export default function SupportPage() {
  const appName = clientEnv.NEXT_PUBLIC_APP_NAME

  return (
    <div className="support-root">
      <SupportStyles />
      <h1 className="support-title">Support</h1>
      <p className="support-copy">
        Contact the {appName} team through your configured support channel. This page exists as a boilerplate placeholder
        so legal and billing links resolve correctly out of the box.
      </p>
      <p className="support-copy">
        Before launching your own app, replace this page with your actual support workflow, contact details, and
        response-time policy.
      </p>
      <div className="support-note">
        Recommended: add a help email address, in-app support form, status page link, and billing contact details.
      </div>
    </div>
  )
}
