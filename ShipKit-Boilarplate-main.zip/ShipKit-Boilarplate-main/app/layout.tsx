import type { Metadata } from 'next'
import { headers } from 'next/headers'
import { Bricolage_Grotesque, Source_Sans_3 } from 'next/font/google'
import { env } from '@/lib/env'
import { NonceProvider } from '@/lib/nonce'
import './globals.css'

const heading = Bricolage_Grotesque({
  subsets: ['latin'],
  variable: '--font-heading',
})

const body = Source_Sans_3({
  subsets: ['latin'],
  variable: '--font-body',
})

export const metadata: Metadata = {
  title: {
    default: 'MySaaS',
    template: '%s | MySaaS',
  },
  description: 'Your SaaS application',
  metadataBase: new URL(env.NEXT_PUBLIC_APP_URL),
  openGraph: {
    title: 'MySaaS',
    description: 'Your SaaS application',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
  },
  other: {
    'theme-color': '#7c3aed',
  },
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const hdrs = await headers()
  const nonce = hdrs.get('x-nonce') ?? ''

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${heading.variable} ${body.variable} bg-brand-paper`} suppressHydrationWarning>
        <NonceProvider nonce={nonce}>{children}</NonceProvider>
      </body>
    </html>
  )
}
