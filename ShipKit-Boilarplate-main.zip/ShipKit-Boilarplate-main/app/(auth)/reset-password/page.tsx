'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function ResetPasswordStyles() {
  return (
    <ScopedStyle>{`
      .rp-card {
        max-width: 420px;
        width: 100%;
        margin: 0 auto;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.25rem;
        padding: 2rem 1.75rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
      }
      .rp-title {
        font-size: 1.5rem;
        font-weight: 900;
        letter-spacing: -0.03em;
        color: #1a1625;
        text-align: center;
        margin-bottom: 0.25rem;
      }
      .rp-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        text-align: center;
        margin-bottom: 1.5rem;
      }
      .rp-label {
        display: block;
        font-size: 0.75rem;
        font-weight: 700;
        color: #6b5f80;
        letter-spacing: 0.02em;
        margin-bottom: 0.35rem;
      }
      .rp-input {
        width: 100%;
        padding: 0.6rem 0.85rem;
        font-size: 0.82rem;
        color: #1a1625;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        outline: none;
        transition: all 0.2s ease;
        margin-bottom: 1rem;
        font-family: var(--font-body), sans-serif;
      }
      .rp-input:focus {
        border-color: rgba(124,58,237,0.3);
        box-shadow: 0 0 0 3px rgba(124,58,237,0.06);
      }
      .rp-btn {
        width: 100%;
        padding: 0.65rem;
        font-size: 0.82rem;
        font-weight: 700;
        color: #fff;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        border: none;
        border-radius: 0.75rem;
        cursor: pointer;
        transition: all 0.18s ease;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
        font-family: var(--font-body), sans-serif;
      }
      .rp-btn:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .rp-btn:disabled { opacity: 0.6; cursor: not-allowed; }
      .rp-success {
        padding: 0.6rem 0.85rem;
        font-size: 0.75rem;
        font-weight: 600;
        color: #065f46;
        background: #d1fae5;
        border: 1px solid #a7f3d0;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
      }
      .rp-error {
        padding: 0.6rem 0.85rem;
        font-size: 0.75rem;
        font-weight: 600;
        color: #991b1b;
        background: #fee2e2;
        border: 1px solid #fca5a5;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
      }
      .rp-back {
        display: block;
        text-align: center;
        font-size: 0.78rem;
        color: #7c3aed;
        font-weight: 700;
        margin-top: 1.25rem;
      }
      .rp-back:hover { color: #5b21b6; }
    `}</ScopedStyle>
  )
}

export default function ResetPasswordPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/auth/callback?next=/dashboard/settings`,
    })

    if (error) {
      setError(error.message)
    } else {
      setSuccess(true)
    }
    setLoading(false)
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2rem 1rem',
      }}
    >
      <ResetPasswordStyles />
      <div className="rp-card">
        <h1 className="rp-title">Reset password</h1>
        <p className="rp-subtitle">
          Enter your email and we&apos;ll send you a reset link
        </p>

        {success && (
          <div className="rp-success">
            Check your email for a password reset link.
          </div>
        )}

        {error && <div className="rp-error">{error}</div>}

        {!success && (
          <form onSubmit={handleSubmit}>
            <label htmlFor="rp-email" className="rp-label">Email</label>
            <input
              id="rp-email"
              className="rp-input"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button type="submit" className="rp-btn" disabled={loading}>
              {loading ? 'Sending...' : 'Send reset link'}
            </button>
          </form>
        )}

        <Link href="/login" className="rp-back">
          Back to sign in
        </Link>
      </div>
    </div>
  )
}
