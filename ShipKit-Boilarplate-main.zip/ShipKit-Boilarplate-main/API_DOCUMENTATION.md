# API Documentation

Complete reference for all API endpoints in your SaaS boilerplate.

---

## Authentication

All protected endpoints require:
- **Method**: POST, PATCH, DELETE require CSRF token
- **Header**: `x-csrf-token: <token>`
- **Cookie**: Session cookie (Supabase manages this)
- **User**: Must be authenticated via Supabase Auth

Get CSRF token:
```typescript
import { getCsrfToken } from '@/lib/csrf-client'
const token = await getCsrfToken()
```

---

## Response Format

All responses follow this format:

### Success (2xx)
```json
{
  "data": { /* response payload */ },
  "error": null
}
```

### Error (4xx/5xx)
```json
{
  "data": null,
  "error": "Human-readable error message",
  "code": "ERROR_CODE" // Optional
}
```

---

## Endpoints

### Health Check

#### GET `/api/health`

Check if system is healthy (DB, Redis, etc.)

**Response:**
```json
{
  "data": {
    "status": "ok",
    "checks": {
      "database": true,
      "redis": true
    },
    "timestamp": "2026-03-08T10:00:00Z"
  }
}
```

**Rate Limit**: 60 requests/minute

---

### User Profile

#### GET `/api/me`

Get current user profile

**Response:**
```json
{
  "data": {
    "id": "user-uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "avatar_url": "https://...",
    "created_at": "2025-01-01T00:00:00Z",
    "subscription": {
      "plan": "pro",
      "status": "active",
      "current_period_start": "2025-03-01T00:00:00Z",
      "current_period_end": "2025-04-01T00:00:00Z",
      "cancel_at_period_end": false
    }
  }
}
```

**Rate Limit**: 100 requests/minute

---

#### PATCH `/api/me`

Update current user profile

**Request:**
```json
{
  "full_name": "Jane Doe"
}
```

**Response:**
```json
{
  "data": {
    "id": "user-uuid",
    "full_name": "Jane Doe",
    "updated_at": "2026-03-08T10:00:00Z"
  }
}
```

**Rate Limit**: 10 requests/minute
**Requires**: CSRF token

---

#### POST `/api/me/password`

Change password

**Request:**
```json
{
  "current_password": "old-password",
  "new_password": "new-secure-password"
}
```

**Response:**
```json
{
  "data": { "success": true }
}
```

**Rate Limit**: 5 requests/minute
**Requires**: CSRF token

---

#### POST `/api/me/delete`

Delete user account (irreversible)

**Request:**
```json
{
  "confirm": "DELETE"
}
```

**Response:**
```json
{
  "data": { "deleted": true }
}
```

**Rate Limit**: 1 request/minute
**Requires**: CSRF token

---

#### POST `/api/me/export`

Export user data (GDPR compliance)

**Response:**
```json
{
  "data": {
    "user": { /* user data */ },
    "subscriptions": [ /* subscriptions */ ],
    "activities": [ /* activity logs */ ],
    "exported_at": "2026-03-08T10:00:00Z"
  }
}
```

**Rate Limit**: 5 requests/day
**Requires**: CSRF token

---

### Authentication

#### POST `/auth/callback`

OAuth callback endpoint (Supabase handles this)

**Query Params:**
- `code`: Authorization code
- `state`: State parameter (CSRF protection)

Automatically redirects to dashboard on success.

---

### Billing & Subscriptions

#### GET `/api/billing/subscriptions`

Get user's subscriptions

**Response:**
```json
{
  "data": [
    {
      "id": "sub-uuid",
      "plan": "pro",
      "status": "active",
      "processor": "stripe",
      "stripe_subscription_id": "sub_xxx",
      "current_period_start": "2025-03-01T00:00:00Z",
      "current_period_end": "2025-04-01T00:00:00Z",
      "created_at": "2025-02-01T00:00:00Z"
    }
  ]
}
```

**Rate Limit**: 30 requests/minute

---

#### POST `/api/billing/checkout`

Generate checkout URL for payment processor

**Request:**
```json
{
  "planId": "basic" | "pro",
  "processor": "lemonsqueezy" | "stripe",
  "billingInterval": "monthly" | "yearly"
}
```

**Response:**
```json
{
  "data": {
    "checkoutUrl": "https://checkout.stripe.com/pay/cs_..."
  }
}
```

**Rate Limit**: 10 requests/minute
**Requires**: CSRF token
**Note**: User must be authenticated

---

#### POST `/api/billing/cancel`

Cancel subscription (user's subscription only)

**Response:**
```json
{
  "data": {
    "cancelled": true,
    "effective_date": "2025-04-01T00:00:00Z"
  }
}
```

**Rate Limit**: 5 requests/minute
**Requires**: CSRF token

---

### Invoices

#### GET `/api/billing/invoices`

Get user's invoices

**Response:**
```json
{
  "data": [
    {
      "id": "inv-uuid",
      "amount_paid": 4900,
      "status": "paid",
      "currency": "usd",
      "invoice_url": "https://...",
      "created_at": "2025-03-01T00:00:00Z"
    }
  ]
}
```

**Rate Limit**: 30 requests/minute

---

### Organizations

#### GET `/api/orgs`

List user's organizations

**Response:**
```json
{
  "data": [
    {
      "id": "org-uuid",
      "name": "Acme Corp",
      "slug": "acme-corp",
      "currentUserRole": "owner",
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```

**Rate Limit**: 30 requests/minute

---

#### POST `/api/orgs`

Create new organization

**Request:**
```json
{
  "name": "New Company",
  "slug": "new-company"
}
```

**Response:**
```json
{
  "data": {
    "id": "org-uuid",
    "name": "New Company",
    "slug": "new-company",
    "currentUserRole": "owner"
  }
}
```

**Rate Limit**: 10 requests/minute
**Requires**: CSRF token

---

#### GET `/api/orgs/:orgId`

Get organization details

**Response:**
```json
{
  "data": {
    "id": "org-uuid",
    "name": "Acme Corp",
    "slug": "acme-corp",
    "currentUserRole": "owner"
  }
}
```

**Rate Limit**: 100 requests/minute

---

#### PATCH `/api/orgs/:orgId`

Update organization (owner only)

**Request:**
```json
{
  "name": "Updated Name"
}
```

**Response:**
```json
{
  "data": {
    "id": "org-uuid",
    "name": "Updated Name"
  }
}
```

**Rate Limit**: 10 requests/minute
**Requires**: CSRF token, owner role

---

#### GET `/api/orgs/:orgId/members`

List organization members

**Response:**
```json
{
  "data": [
    {
      "id": "member-uuid",
      "role": "owner",
      "user": {
        "id": "user-uuid",
        "email": "owner@example.com",
        "full_name": "Owner Name"
      },
      "joined_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```

**Rate Limit**: 30 requests/minute

---

#### POST `/api/orgs/:orgId/members`

Invite member (owner/admin only)

**Request:**
```json
{
  "email": "newmember@example.com",
  "role": "member" | "admin"
}
```

**Response:**
```json
{
  "data": {
    "id": "member-uuid",
    "role": "member",
    "user": { "email": "newmember@example.com" }
  }
}
```

**Rate Limit**: 10 requests/minute
**Requires**: CSRF token, owner/admin role

---

#### DELETE `/api/orgs/:orgId/members`

Remove member (owner only)

**Query Params:**
- `userId`: User UUID to remove

**Response:**
```json
{
  "data": { "removed": true }
}
```

**Rate Limit**: 10 requests/minute
**Requires**: CSRF token, owner role

---

### Admin Endpoints

#### GET `/api/admin/stats`

Get system-wide statistics (admin only)

**Response:**
```json
{
  "data": {
    "total_users": 1234,
    "active_subscriptions": 567,
    "mrr": 27840,
    "free_users": 667,
    "paid_users": 567,
    "conversion_rate": 45.9,
    "average_plan_value": 49,
    "growth_percentage": 12.5
  }
}
```

**Rate Limit**: 5 requests/minute
**Requires**: Admin email in `ADMIN_EMAILS` env var

---

### Dashboard

#### GET `/api/dashboard/stats`

Get user's dashboard statistics

**Response:**
```json
{
  "data": {
    "total_projects": 5,
    "storage_used_mb": 256,
    "api_calls_month": 15000,
    "active_organizations": 2
  }
}
```

**Rate Limit**: 30 requests/minute

---

### Webhooks

#### POST `/api/webhooks/lemonsqueezy`

LemonSqueezy webhook endpoint

Automatically handles:
- `order.created` - Create subscription
- `subscription.updated` - Update subscription
- `subscription.cancelled` - Cancel subscription

**Headers (auto-verified):**
- `X-Signature`: HMAC-SHA256 signature

**Rate Limit**: Unlimited (webhook)

---

#### POST `/api/webhooks/stripe`

Stripe webhook endpoint

Automatically handles:
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `invoice.payment_succeeded`
- `invoice.payment_failed`

**Headers (auto-verified):**
- `stripe-signature`: Stripe signature

**Rate Limit**: Unlimited (webhook)

---

## Common Patterns

### Error Handling

```typescript
try {
  const res = await fetch('/api/endpoint', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-csrf-token': token,
    },
    body: JSON.stringify(data),
  })
  
  const json = await res.json()
  
  if (!res.ok) {
    console.error('API Error:', json.error)
    return
  }
  
  // Use json.data
  console.log('Success:', json.data)
} catch (error) {
  console.error('Network error:', error)
}
```

### Using React Query

```typescript
import { useQuery, useMutation } from '@tanstack/react-query'

// Query
const { data, isLoading, error } = useQuery({
  queryKey: ['user'],
  queryFn: () => fetch('/api/me').then(r => r.json()).then(j => j.data),
})

// Mutation
const mutation = useMutation({
  mutationFn: (newName) => 
    fetch('/api/me', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ full_name: newName }),
    }).then(r => r.json()).then(j => j.data),
})
```

### Rate Limiting

If you receive a 429 response:

```json
{
  "data": null,
  "error": "Too many requests",
  "code": "RATE_LIMITED"
}
```

Wait for the `Retry-After` header in seconds, then retry.

---

## SDKs & Client Libraries

### JavaScript/TypeScript Hook

Included in `lib/queries/hooks.ts`:

```typescript
import { useCurrentUser, useBilling, useOrganizations } from '@/lib/queries/hooks'

function MyComponent() {
  const { data: user } = useCurrentUser()
  const { data: plans } = useBilling()
  const { data: orgs } = useOrganizations()
  
  return <div>{/* Your UI */}</div>
}
```

---

## Versioning

Current API Version: **v0.1.0**

No breaking changes planned. Changes will be:
- Additive (new endpoints)
- Backward compatible
- Announced in changelog

---

## Questions?

- See [TROUBLESHOOTING_GUIDE.md](TROUBLESHOOTING_GUIDE.md)
- Check [CUSTOMIZATION_GUIDE.md](CUSTOMIZATION_GUIDE.md) for adding endpoints
- Read source code in `app/api/`
