# Troubleshooting Guide

Common issues and solutions when setting up, deploying, or running your SaaS.

---

## 🔧 Setup Issues

### Issue: npm install fails with dependency conflicts

**Error:**
```
npm ERR! peer dep missing: @types/react@^18.0.0
npm ERR! peer dep missing: @types/react-dom@^18.0.0
```

**Solution:**

```bash
npm install --legacy-peer-deps

# OR: Update to latest peer dependencies
npm install @types/react@latest @types/react-dom@latest
```

---

### Issue: `npm run build` fails with TypeScript errors

**Error:**
```
error TS2322: Type 'string' is not assignable to type 'never'
```

**Solution:**

1. **Check tsconfig.json:**
   ```bash
   npm run typecheck  # Get full error list
   ```

2. **Fix type errors manually** or use strict null checks:
   ```typescript
   // ❌ Bad
   const value: never = 'something'
   
   // ✅ Good
   const value: string = 'something'
   ```

3. **Clear cache and try again:**
   ```bash
   rm -rf .next
   npm run build
   ```

---

### Issue: Cannot find module '@/lib/env'

**Error:**
```
Module not found: Can't resolve '@/lib/env'
```

**Solution:**

Verify path alias in `tsconfig.json`:

```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./*"]  // Ensures @/ points to root
    }
  }
}
```

---

### Issue: Database connection pooling not working

**Error:**
```
Error: too many connections on superuser role
```

**Solution:**

1. **Always use pooled connection in .env:**
   ```env
   DATABASE_URL=postgresql://user:pass@host:6543/postgres  # Port 6543 = pooled
   ```

2. **For migrations, use direct connection:**
   ```env
   DIRECT_DATABASE_URL=postgresql://user:pass@host:5432/postgres  # Port 5432 = direct
   ```

3. **Check Supabase Settings → Database → Connection Pooling:**
   - Mode: `Transaction`
   - Pool: `20`

---

### Issue: Supabase migrations fail

**Error:**
```
Error: [42P01] relation "users" does not exist
```

**Solution:**

1. **Verify migration order:** Migrations run alphabetically by filename
   ```bash
   ls supabase/migrations/
   # Should be: 00001_*, 00002_*, etc. in dependency order
   ```

2. **Check if migration was skipped:**
   ```bash
   npm run db:push
   ```

3. **Manual migration via Supabase Dashboard:**
   - SQL Editor → Paste migration content → Run

---

### Issue: npm run dev fails silently

**Error:**
```
(no error, but dev server doesn't start)
```

**Solution:**

1. **Check if port 3000 is in use:**
   ```bash
   lsof -i :3000  # macOS/Linux
   netstat -ano | findstr :3000  # Windows
   
   # Kill process:
   kill -9 <PID>  # macOS/Linux
   taskkill /PID <PID> /F  # Windows
   ```

2. **Check for .env errors:**
   ```bash
   node -e "require('./lib/env.ts')"  # Will error if env is invalid
   ```

3. **Clear Node cache:**
   ```bash
   rm -rf node_modules .next
   npm install
   npm run dev
   ```

---

## 🔐 Authentication Issues

### Issue: Supabase Auth not working

**Error:**
```
AuthError: Auth session missing
```

**Solution:**

1. **Check .env variables:**
   ```bash
   echo $NEXT_PUBLIC_SUPABASE_URL
   echo $NEXT_PUBLIC_SUPABASE_ANON_KEY
   ```

2. **Verify Supabase project:**
   - Go to Supabase dashboard
   - Check that project is active (green dot)
   - Copy correct URL and ANON_KEY

3. **Check auth cookie settings in middleware:**
   ```typescript
   // middleware.ts - verify cookies are set correctly
   const { setAll } = cookies
   ```

---

### Issue: OAuth login fails

**Error:**
```
AuthError: Invalid redirect URI
```

**Solution:**

1. **Update redirect URI in Supabase:**
   - Settings → Auth → Redirect URLs
   - Add: `http://localhost:3000/auth/callback`
   - Add: `https://yourdomain.com/auth/callback`

2. **Check OAuth provider settings:**
   - Google: Authorized JavaScript origins + Authorized Redirect URIs
   - GitHub: Authorization callback URL
   - Both must match EXACTLY

---

### Issue: Session expires too quickly

**Error:**
```
User logs out after 1 hour
```

**Solution:**

Supabase sessions are 1 hour by default. To extend:

1. **In Supabase dashboard:**
   - Settings → Auth → JWT Settings
   - Increase "Access token expiration time"

2. **Refresh tokens periodically:**
   ```typescript
   // lib/supabase/client.ts
   const { data } = await supabase.auth.refreshSession()
   ```

---

## 💳 Payment Issues

### Issue: LemonSqueezy webhook not firing

**Error:**
```
Webhook not received after payment
```

**Solution:**

1. **Check webhook configuration:**
   - LemonSqueezy Dashboard → Settings → Webhooks
   - URL: `https://yourdomain.com/api/webhooks/lemonsqueezy`
   - Select events: `order.created`, `subscription.*`

2. **Verify webhook secret in .env:**
   ```env
   LEMONSQUEEZY_WEBHOOK_SECRET=correct_secret_here
   ```

3. **Test webhook manually:**
   ```bash
   # From Lemonsqueezy Dashboard, click "Send test event"
   # Check logs for error
   npm run dev  # Watch logs
   ```

4. **Check webhook_events table:**
   ```sql
   SELECT * FROM webhook_events 
   WHERE processor = 'lemonsqueezy' 
   ORDER BY created_at DESC LIMIT 10;
   ```

---

### Issue: Stripe webhook fails

**Error:**
```
Error: No signatures found matching the expected signature for payload
```

**Solution:**

1. **Verify webhook signing secret:**
   - Stripe Dashboard → Webhooks
   - Signing secret must match `STRIPE_WEBHOOK_SECRET`

2. **Be careful with endpoint URL:**
   - Must be HTTPS in production
   - Cannot have query params
   - Must match exactly in Stripe settings

3. **Test in Stripe CLI:**
   ```bash
   stripe listen --forward-to localhost:3000/api/webhooks/stripe
   stripe trigger payment_intent.succeeded
   ```

---

### Issue: Payment processor not charging

**Error:**
```
Customer clicks checkout but is not charged
```

**Solution:**

1. **For LemonSqueezy:**
   - Check variant IDs are correct
   - Go to Products → Edit → Copy Variant ID
   - Paste into .env: `LEMONSQUEEZY_VARIANT_BASIC=variant_id`

2. **For Stripe:**
   - Check price IDs in Stripe Dashboard
   - Products → Click product → Copy Price ID
   - Paste into .env: `STRIPE_PRICE_BASIC_MONTHLY=price_xxx`

3. **Test checkout flow:**
   - With test card: `4242 4242 4242 4242` (any future date, any CVC)

---

## 📧 Email Issues

### Issue: Emails not being sent

**Error:**
```
Email send failed: Missing credentials
```

**Solution:**

1. **Check AWS SES configuration:**
   ```env
   AWS_ACCESS_KEY_ID=correct_id
   AWS_SECRET_ACCESS_KEY=correct_secret
   AWS_REGION=us-east-1
   SES_FROM_EMAIL=noreply@yourdomain.com
   ```

2. **Verify SES is not in sandbox mode:**
   - AWS Console → SES → Account Dashboard
   - Check if status shows "In Sandbox"
   - Request production access if needed

3. **Test email sending directly:**
   ```typescript
   import { sendEmail } from '@/lib/email'
   
   await sendEmail({
     to: 'your@email.com',
     subject: 'Test',
     html: '<p>Test email</p>',
   })
   ```

4. **Check email bounces:**
   - AWS Console → SES → Bounce notifications
   - If emails are bouncing, verify recipient addresses

---

### Issue: Emails going to spam

**Error:**
```
Users receive emails in spam folder
```

**Solution:**

1. **Set up SPF/DKIM/DMARC:**
   - AWS SES Console → Verified Identities
   - Click your domain → DKIM & SPF settings
   - Add records to your DNS provider

2. **Verify domain ownership:**
   - AWS SES requires domain verification tokens

3. **Use reply-to address:**
   ```typescript
   await sendEmail({
     to: 'user@example.com',
     replyTo: 'support@yourdomain.com',
     subject: 'Hello',
     html: '<p>Hello</p>',
   })
   ```

---

## 📦 Redis/Jobs Issues

### Issue: BullMQ jobs are stuck in queue

**Error:**
```
Email queue shows 1000 waiting jobs, no processing
```

**Solution:**

1. **Check if worker is running:**
   ```bash
   npm run workers  # Start all workers
   ```

2. **Verify Redis connection:**
   ```bash
   redis-cli ping  # Should return "PONG"
   ```

3. **Check queue length:**
   ```typescript
   const count = await emailQueue.getWaitingCount()
   console.log('Waiting jobs:', count)
   ```

4. **Clear stuck jobs:**
   ```bash
   redis-cli DEL bull:email  # WARNING: Deletes entire queue
   ```

---

### Issue: Redis connection times out

**Error:**
```
Error: Redis connection timeout
```

**Solution:**

1. **Check Redis URL format:**
   ```env
   REDIS_URL=redis://localhost:6379  # Local
   REDIS_URL=rediss://key:password@host:port  # Upstash (note: rediss = SSL)
   ```

2. **For Upstash, use correct protocol:**
   - Click "Redis" database
   - Copy "Node.js" connection string
   - Ensure it starts with `rediss://`

3. **Test Redis connection:**
   ```bash
   redis-cli -u $REDIS_URL ping
   ```

---

## 🚀 Deployment Issues

### Issue: Vercel build fails

**Error:**
```
Error: Build failed during next build
```

**Solution:**

1. **Check build logs in Vercel:**
   - Vercel Dashboard → Deployments → Click failed deployment
   - Scroll to build logs for actual error

2. **Common causes:**
   - Missing environment variables
   - TypeScript errors
   - CSS/asset import issues

3. **Set missing env vars:**
   - Vercel Dashboard → Settings → Environment Variables
   - Add all vars from `.env.example`

4. **Test build locally:**
   ```bash
   npm run build
   npm run start  # Test production server
   ```

---

### Issue: "Cannot find module" after deploy

**Error:**
```
Error: Cannot find module '@/lib/env'
```

**Solution:**

1. **Check file exists:**
   ```bash
   ls -la lib/env.ts
   ```

2. **Verify tsconfig.json paths:**
   ```json
   "paths": { "@/*": ["./*"] }
   ```

3. **Hard reset and rebuild:**
   ```bash
   git clean -fd
   npm install
   npm run build
   git push  # To Vercel
   ```

---

### Issue: Environment variables not loading in Vercel

**Error:**
```
Error: process.env.SUPABASE_URL is undefined
```

**Solution:**

1. **Vercel Dashboard → Settings → Environment Variables**
2. **Add ALL variables from `.env.example`**
3. **For Supabase/payment keys, use secret values** (Vercel will encrypt)
4. **Redeploy after updating variables:**
   ```bash
   git push  # Triggers new Vercel build
   ```

---

## 🐛 Runtime Errors

### Issue: 500 error on API route

**Error:**
```
Error: [500] Internal Server Error
```

**Solution:**

1. **Check server logs:**
   ```bash
   npm run dev  # Watch logs in terminal
   # Trigger error, check console output
   ```

2. **Check Supabase logs:**
   - Supabase Dashboard → Logs → API errors

3. **Check error tracking (GlitchTip/Sentry):**
   - Dashboard should show error details

4. **Use descriptive error handling:**
   ```typescript
   try {
     // Your code
   } catch (error) {
     logger.error({ err: error }, 'Detailed context')
     return err('Human-readable message', 500)
   }
   ```

---

### Issue: Type error "Property does not exist"

**Error:**
```
Property 'users' does not exist on type 'Database'
```

**Solution:**

1. **Regenerate Supabase types:**
   ```bash
   npm run db:types
   ```

2. **Verify migration ran on Supabase:**
   ```bash
   npm run db:push
   ```

3. **Check types/supabase.ts was updated:**
   ```bash
   ls -la types/supabase.ts
   ```

---

## 🧪 Testing Issues

### Issue: Tests fail with "Cannot find module"

**Error:**
```
FAIL tests/unit/api-response.test.ts
Error: Cannot find module '@/lib/api-response'
```

**Solution:**

1. **Check vitest.config.ts has path alias:**
   ```typescript
   resolve: {
     alias: {
       '@': path.resolve(__dirname, '.'),
     },
   },
   ```

2. **Ensure test files exist:**
   ```bash
   ls lib/api-response.ts
   ```

3. **Run tests:**
   ```bash
   npm run test
   ```

---

### Issue: E2E tests timeout

**Error:**
```
TimeoutError: Test timeout exceeded
```

**Solution:**

1. **Increase timeout in playwright.config.ts:**
   ```typescript
   timeout: 30000,  // 30 seconds
   ```

2. **Check if server is running:**
   ```bash
   npm run dev  # In separate terminal
   npm run test:e2e
   ```

3. **Run single test:**
   ```bash
   npm run test:e2e -- tests/e2e/smoke.spec.ts
   ```

---

## 📊 Performance Issues

### Issue: Website loads slowly

**Error:**
```
Page load time > 3 seconds
```

**Solution:**

1. **Check Vercel Analytics:**
   - Vercel Dashboard → Analytics tab
   - Identify slowest pages and API routes

2. **Optimize database queries:**
   ```sql
   EXPLAIN ANALYZE SELECT ...  -- Check for full table scans
   CREATE INDEX ... ON ...      -- Add indexes
   ```

3. **Enable ISR for static pages:**
   ```typescript
   export const revalidate = 60  // Revalidate every 60s
   ```

4. **Lazy load heavy components:**
   ```typescript
   const Chart = dynamic(() => import('@/components/Chart'))
   ```

---

### Issue: High CPU/Memory usage

**Error:**
```
Vercel Function timeout or Supabase connection limit exceeded
```

**Solution:**

1. **Check for infinite loops:**
   ```bash
   npm run typecheck
   npm run lint
   ```

2. **Monitor function duration:**
   - Vercel Dashboard → Functions → See runtimes

3. **Optimize slow queries:**
   - Add indexes
   - Use pagination
   - Reduce JOIN complexity

---

## 💬 Getting Help

If you can't find your issue here:

1. **Check logs:**
   - Local: `npm run dev` terminal output
   - Vercel: Dashboard → Deployments → Function logs
   - Supabase: Logs tab in dashboard
   - Sentry/GlitchTip: Error dashboard

2. **Reproduce the issue:**
   - What exact steps trigger it?
   - Does it happen on other browsers?
   - Check browser console (F12)

3. **Ask for help:**
   - GitHub Issues (if open source)
   - Discord/community channels
   - Support email for premium customers

---

## 📚 Resources

- [Next.js Troubleshooting](https://nextjs.org/docs/messages)
- [Supabase Docs](https://supabase.com/docs)
- [Vercel Docs](https://vercel.com/docs)
- [BullMQ Docs](https://docs.bullmq.io/)
- [AWS SES Docs](https://docs.aws.amazon.com/ses/)
