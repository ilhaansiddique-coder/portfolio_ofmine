import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'
import { createHmac } from 'crypto'

// Mock Supabase admin client
const mockFrom = vi.fn()
vi.mock('@/lib/supabase/admin', () => ({
  createAdminClient: vi.fn(() => ({ from: mockFrom })),
}))

vi.mock('@/lib/logger', () => ({
  logger: {
    error: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
  },
}))

vi.mock('@/lib/error-tracking', () => ({
  captureError: vi.fn(),
}))

vi.mock('@/lib/ratelimit', () => ({
  rateLimit: vi.fn(async () => ({ success: true, remaining: 10, reset: 0 })),
  getClientIp: vi.fn(() => '127.0.0.1'),
}))

vi.mock('@/lib/csrf', () => ({
  validateCsrfToken: vi.fn(async () => true),
  generateCsrfToken: vi.fn(async () => 'test-csrf-token'),
}))

const WEBHOOK_SECRET = 'test-webhook-secret'

function signPayload(body: string): string {
  return createHmac('sha256', WEBHOOK_SECRET).update(body).digest('hex')
}

function webhookEvent(eventName: string, options: { userId?: string; webhookId?: string; customerId?: string; status?: string } = {}) {
  return {
    meta: {
      event_name: eventName,
      webhook_id: options.webhookId ?? `evt-${Date.now()}`,
      custom_data: options.userId ? { user_id: options.userId } : {},
    },
    data: {
      attributes: {
        customer_id: options.customerId ?? 'cust-123',
        status: options.status ?? 'active',
      },
    },
  }
}

function signedRequest(body: string): NextRequest {
  const sig = signPayload(body)
  return new NextRequest('http://localhost:3000/api/webhooks/lemonsqueezy', {
    method: 'POST',
    body,
    headers: { 'x-signature': sig, 'content-type': 'application/json' },
  })
}

function mockChain(result: { data?: unknown; error?: unknown }) {
  const chain: Record<string, unknown> = {}
  chain.select = vi.fn().mockReturnValue(chain)
  chain.insert = vi.fn().mockReturnValue(chain)
  chain.upsert = vi.fn().mockReturnValue(chain)
  chain.update = vi.fn().mockReturnValue(chain)
  chain.eq = vi.fn().mockReturnValue(chain)
  chain.single = vi.fn().mockResolvedValue(result)
  chain.maybeSingle = vi.fn().mockResolvedValue(result)
  chain.then = vi.fn((resolve) => resolve(result))
  return chain
}

const mockCtx = { params: Promise.resolve({}) } as { params: Promise<Record<string, string>> }

describe('LemonSqueezy Webhook', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('rejects invalid signature', async () => {
    const body = JSON.stringify(webhookEvent('order_created', { userId: 'u-1' }))
    const req = new NextRequest('http://localhost:3000/api/webhooks/lemonsqueezy', {
      method: 'POST',
      body,
      headers: { 'x-signature': 'invalid-signature', 'content-type': 'application/json' },
    })

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)
    const data = await res.json()

    expect(res.status).toBe(401)
    expect(data.error).toContain('signature')
  })

  it('rejects missing signature', async () => {
    const body = JSON.stringify(webhookEvent('order_created', { userId: 'u-1' }))
    const req = new NextRequest('http://localhost:3000/api/webhooks/lemonsqueezy', {
      method: 'POST',
      body,
      headers: { 'content-type': 'application/json' },
    })

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)

    expect(res.status).toBe(401)
  })

  it('rejects events without user_id', async () => {
    const event = webhookEvent('order_created') // no userId
    const body = JSON.stringify(event)
    const req = signedRequest(body)

    // Mock idempotency check — no existing event
    mockFrom.mockReturnValue(mockChain({ data: null, error: null }))

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)
    const data = await res.json()

    expect(res.status).toBe(400)
    expect(data.error).toContain('user_id')
  })

  it('returns duplicate:true for already-processed events (idempotency)', async () => {
    const event = webhookEvent('order_created', { userId: 'u-1', webhookId: 'evt-abc' })
    const body = JSON.stringify(event)
    const req = signedRequest(body)

    // upsert with ignoreDuplicates returns empty array when row already exists
    mockFrom.mockImplementation((table: string) => {
      if (table === 'webhook_events') {
        return mockChain({ data: [], error: null })
      }
      return mockChain({ data: null, error: null })
    })

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.data.duplicate).toBe(true)
  })

  it('processes order_created event', async () => {
    const event = webhookEvent('order_created', { userId: 'u-1', customerId: 'cust-456' })
    const body = JSON.stringify(event)
    const req = signedRequest(body)

    const usersChain = mockChain({ data: null, error: null })
    // upsert returns the inserted row when it's new
    const webhookChain = mockChain({ data: [{ id: 'evt-1' }], error: null })

    mockFrom.mockImplementation((table: string) => {
      if (table === 'webhook_events') return webhookChain
      if (table === 'users') return usersChain
      return mockChain({ data: null, error: null })
    })

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.data.received).toBe(true)
    expect(data.data.duplicate).toBeUndefined()
  })

  it('processes subscription_cancelled event', async () => {
    const event = webhookEvent('subscription_cancelled', { userId: 'u-1' })
    const body = JSON.stringify(event)
    const req = signedRequest(body)

    const usersChain = mockChain({ data: null, error: null })
    mockFrom.mockImplementation((table: string) => {
      if (table === 'webhook_events') return mockChain({ data: [{ id: 'evt-1' }], error: null })
      if (table === 'users') return usersChain
      return mockChain({ data: null, error: null })
    })

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.data.received).toBe(true)
  })

  it('processes subscription_expired event', async () => {
    const event = webhookEvent('subscription_expired', { userId: 'u-1' })
    const body = JSON.stringify(event)
    const req = signedRequest(body)

    const usersChain = mockChain({ data: null, error: null })
    mockFrom.mockImplementation((table: string) => {
      if (table === 'webhook_events') return mockChain({ data: [{ id: 'evt-1' }], error: null })
      if (table === 'users') return usersChain
      return mockChain({ data: null, error: null })
    })

    const { POST } = await import('@/app/api/webhooks/lemonsqueezy/route')
    const res = await POST(req, mockCtx)
    const data = await res.json()

    expect(res.status).toBe(200)
    expect(data.data.received).toBe(true)
  })
})
