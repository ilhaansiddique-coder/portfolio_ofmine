import { describe, it, expect, vi } from 'vitest'

vi.mock('@/lib/supabase/server', () => ({
  createClient: vi.fn(() => ({
    from: () => ({
      select: () => ({ limit: () => ({ data: [], error: null }) }),
    }),
  })),
}))

vi.mock('@/lib/redis', () => ({
  default: { ping: vi.fn(() => Promise.resolve('PONG')) },
}))

vi.mock('@/lib/ratelimit', () => ({
  rateLimit: vi.fn(async () => ({ success: true, remaining: 10, reset: 0 })),
  getClientIp: vi.fn(() => '127.0.0.1'),
}))

describe('GET /api/health', () => {
  it('returns 200 when all services are healthy', async () => {
    const { GET } = await import('@/app/api/health/route')
    const mockReq = new Request('http://localhost:3000/api/health') as never
    const mockCtx = { params: Promise.resolve({}) } as never
    const response = await GET(mockReq, mockCtx)
    const body = await response.json()

    expect(response.status).toBe(200)
    expect(body.data.status).toBe('ok')
    expect(body.data.checks.database).toBe(true)
    expect(body.data.checks.redis).toBe(true)
    expect(body.data.timestamp).toBeDefined()
    expect(body.error).toBeNull()
  })
})
