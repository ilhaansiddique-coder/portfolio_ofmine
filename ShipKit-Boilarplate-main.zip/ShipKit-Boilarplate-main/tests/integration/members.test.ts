import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// Mock Supabase server client
const mockFrom = vi.fn()
const mockGetUser = vi.fn()
const mockSupabase = {
  auth: { getUser: mockGetUser },
  from: mockFrom,
}

vi.mock('@/lib/supabase/server', () => ({
  createClient: vi.fn(async () => mockSupabase),
}))

vi.mock('@/lib/logger', () => ({
  logger: {
    error: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
  },
}))

vi.mock('@/lib/error-tracking', () => ({
  captureError: vi.fn(),
}))

vi.mock('@/lib/ratelimit', () => ({
  rateLimit: vi.fn(async () => ({ success: true, remaining: 10, reset: 0 })),
  getClientIp: vi.fn(() => '127.0.0.1'),
}))

vi.mock('@/lib/csrf', () => ({
  validateCsrfToken: vi.fn(async () => true),
  generateCsrfToken: vi.fn(async () => 'test-csrf-token'),
}))

function mockChain(result: { data?: unknown; error?: unknown }) {
  const chain: Record<string, unknown> = {}
  chain.select = vi.fn().mockReturnValue(chain)
  chain.insert = vi.fn().mockReturnValue(chain)
  chain.update = vi.fn().mockReturnValue(chain)
  chain.delete = vi.fn().mockReturnValue(chain)
  chain.eq = vi.fn().mockReturnValue(chain)
  chain.neq = vi.fn().mockReturnValue(chain)
  chain.in = vi.fn().mockReturnValue(chain)
  chain.order = vi.fn().mockReturnValue(chain)
  chain.single = vi.fn().mockResolvedValue(result)
  chain.maybeSingle = vi.fn().mockResolvedValue(result)
  chain.then = vi.fn((resolve) => resolve(result))
  return chain
}

function jsonRequest(url: string, method: string, body?: unknown): NextRequest {
  return new NextRequest(`http://localhost:3000${url}`, {
    method,
    ...(body ? { body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } } : {}),
  })
}

const mockCtx = { params: Promise.resolve({ orgId: 'org-1' }) } as { params: Promise<Record<string, string>> }

describe('POST /api/orgs/:orgId/members', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 401 if not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { POST } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = jsonRequest('/api/orgs/org-1/members', 'POST', { email: 'test@test.com' })
    const res = await POST(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(401)
    expect(body.error).toBe('Unauthorized')
  })

  it('returns 404 if caller is not a member of the org', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: null, error: null }))

    const { POST } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = jsonRequest('/api/orgs/org-1/members', 'POST', { email: 'test@test.com' })
    const res = await POST(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(404)
    expect(body.error).toBe('Not found')
  })

  it('returns 403 if caller is a regular member (not admin/owner)', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    let callCount = 0
    mockFrom.mockImplementation(() => {
      callCount++
      // First call: getCallerRole — return 'member'
      if (callCount === 1) return mockChain({ data: { role: 'member' }, error: null })
      return mockChain({ data: null, error: null })
    })

    const { POST } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = jsonRequest('/api/orgs/org-1/members', 'POST', { email: 'test@test.com' })
    const res = await POST(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(403)
    expect(body.error).toBe('Forbidden')
  })

  it('validates email in request body', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: { role: 'admin' }, error: null }))

    const { POST } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = jsonRequest('/api/orgs/org-1/members', 'POST', { email: 'not-an-email' })
    const res = await POST(req, mockCtx)

    expect(res.status).toBe(400)
  })
})

describe('DELETE /api/orgs/:orgId/members', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('requires userId query parameter', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { DELETE } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = new NextRequest('http://localhost:3000/api/orgs/org-1/members', { method: 'DELETE' })
    const res = await DELETE(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(400)
    expect(body.error).toContain('userId')
  })

  it('prevents removing the owner', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    let callCount = 0
    mockFrom.mockImplementation(() => {
      callCount++
      // First: getCallerRole → admin
      if (callCount === 1) return mockChain({ data: { role: 'admin' }, error: null })
      // Second: check target membership → owner
      if (callCount === 2) return mockChain({ data: { role: 'owner' }, error: null })
      return mockChain({ data: null, error: null })
    })

    const { DELETE } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = new NextRequest('http://localhost:3000/api/orgs/org-1/members?userId=owner-1', { method: 'DELETE' })
    const res = await DELETE(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(400)
    expect(body.error).toContain('owner')
  })
})

describe('PATCH /api/orgs/:orgId/members', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('only allows owner to change roles', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: { role: 'admin' }, error: null }))

    const { PATCH } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = jsonRequest('/api/orgs/org-1/members?userId=user-2', 'PATCH', { role: 'admin' })
    const res = await PATCH(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(403)
    expect(body.error).toContain('owner')
  })

  it('prevents owner from changing their own role', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: { role: 'owner' }, error: null }))

    const { PATCH } = await import('@/app/api/orgs/[orgId]/members/route')
    const req = jsonRequest('/api/orgs/org-1/members?userId=user-1', 'PATCH', { role: 'member' })
    const res = await PATCH(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(400)
    expect(body.error).toContain('own role')
  })
})
