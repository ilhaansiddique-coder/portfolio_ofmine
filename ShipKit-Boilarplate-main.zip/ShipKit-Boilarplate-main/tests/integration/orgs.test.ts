import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// Mock Supabase server client
const mockFrom = vi.fn()
const mockGetUser = vi.fn()
const mockSupabase = {
  auth: { getUser: mockGetUser },
  from: mockFrom,
}

vi.mock('@/lib/supabase/server', () => ({
  createClient: vi.fn(async () => mockSupabase),
}))

vi.mock('@/lib/logger', () => ({
  logger: {
    error: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
  },
}))

vi.mock('@/lib/error-tracking', () => ({
  captureError: vi.fn(),
}))

vi.mock('@/lib/ratelimit', () => ({
  rateLimit: vi.fn(async () => ({ success: true, remaining: 10, reset: 0 })),
  getClientIp: vi.fn(() => '127.0.0.1'),
}))

vi.mock('@/lib/csrf', () => ({
  validateCsrfToken: vi.fn(async () => true),
  generateCsrfToken: vi.fn(async () => 'test-csrf-token'),
}))

// Helper to build chained supabase query mocks
function mockChain(result: { data?: unknown; error?: unknown }) {
  const chain: Record<string, unknown> = {}
  chain.select = vi.fn().mockReturnValue(chain)
  chain.insert = vi.fn().mockReturnValue(chain)
  chain.update = vi.fn().mockReturnValue(chain)
  chain.delete = vi.fn().mockReturnValue(chain)
  chain.eq = vi.fn().mockReturnValue(chain)
  chain.neq = vi.fn().mockReturnValue(chain)
  chain.in = vi.fn().mockReturnValue(chain)
  chain.order = vi.fn().mockReturnValue(chain)
  chain.single = vi.fn().mockResolvedValue(result)
  chain.maybeSingle = vi.fn().mockResolvedValue(result)
  // For queries that don't end with single/maybeSingle
  chain.then = vi.fn((resolve) => resolve(result))
  return chain
}

function jsonRequest(url: string, method: string, body?: unknown): NextRequest {
  return new NextRequest(`http://localhost:3000${url}`, {
    method,
    ...(body ? { body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } } : {}),
  })
}

const mockCtx = { params: Promise.resolve({}) } as { params: Promise<Record<string, string>> }
const mockOrgCtx = { params: Promise.resolve({ orgId: 'org-1' }) } as { params: Promise<Record<string, string>> }

describe('GET /api/orgs', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 401 if not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { GET } = await import('@/app/api/orgs/route')
    const res = await GET(new NextRequest('http://localhost:3000/api/orgs'), mockCtx)
    const body = await res.json()

    expect(res.status).toBe(401)
    expect(body.error).toBe('Unauthorized')
  })

  it('returns empty array when user has no orgs', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    const membershipsChain = mockChain({ data: [], error: null })
    mockFrom.mockImplementation((table: string) => {
      if (table === 'memberships') return membershipsChain
      return mockChain({ data: null, error: null })
    })

    const { GET } = await import('@/app/api/orgs/route')
    const res = await GET(new NextRequest('http://localhost:3000/api/orgs'), mockCtx)
    const body = await res.json()

    expect(res.status).toBe(200)
    expect(body.data).toEqual([])
  })
})

describe('POST /api/orgs', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 401 if not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { POST } = await import('@/app/api/orgs/route')
    const req = jsonRequest('/api/orgs', 'POST', { name: 'Test', slug: 'test' })
    const res = await POST(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(401)
    expect(body.error).toBe('Unauthorized')
  })

  it('validates request body', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { POST } = await import('@/app/api/orgs/route')
    const req = jsonRequest('/api/orgs', 'POST', { name: '' })
    const res = await POST(req, mockCtx)

    expect(res.status).toBe(400)
  })

  it('rejects invalid slug characters', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { POST } = await import('@/app/api/orgs/route')
    const req = jsonRequest('/api/orgs', 'POST', { name: 'Test Org', slug: 'Test_Org!' })
    const res = await POST(req, mockCtx)

    expect(res.status).toBe(400)
  })
})

describe('GET /api/orgs/:orgId', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 401 if not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { GET } = await import('@/app/api/orgs/[orgId]/route')
    const req = new NextRequest('http://localhost:3000/api/orgs/org-1')
    const res = await GET(req, mockOrgCtx)
    const body = await res.json()

    expect(res.status).toBe(401)
    expect(body.error).toBe('Unauthorized')
  })

  it('returns 404 if user is not a member', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: null, error: null }))

    const { GET } = await import('@/app/api/orgs/[orgId]/route')
    const req = new NextRequest('http://localhost:3000/api/orgs/org-1')
    const res = await GET(req, mockOrgCtx)
    const body = await res.json()

    expect(res.status).toBe(404)
    expect(body.error).toBe('Not found')
  })
})

describe('DELETE /api/orgs/:orgId', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 403 if user is not the owner', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: { role: 'member' }, error: null }))

    const { DELETE } = await import('@/app/api/orgs/[orgId]/route')
    const req = new NextRequest('http://localhost:3000/api/orgs/org-1', { method: 'DELETE' })
    const res = await DELETE(req, mockOrgCtx)
    const body = await res.json()

    expect(res.status).toBe(403)
    expect(body.error).toContain('owner')
  })
})
