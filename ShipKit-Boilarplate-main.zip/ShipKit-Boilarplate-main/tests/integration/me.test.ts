import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

// Mock Supabase server client
const mockFrom = vi.fn()
const mockGetUser = vi.fn()
const mockSupabase = {
  auth: { getUser: mockGetUser },
  from: mockFrom,
}

vi.mock('@/lib/supabase/server', () => ({
  createClient: vi.fn(async () => mockSupabase),
}))

vi.mock('@/lib/logger', () => ({
  logger: {
    error: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
  },
}))

vi.mock('@/lib/error-tracking', () => ({
  captureError: vi.fn(),
}))

vi.mock('@/lib/ratelimit', () => ({
  rateLimit: vi.fn(async () => ({ success: true, remaining: 10, reset: 0 })),
  getClientIp: vi.fn(() => '127.0.0.1'),
}))

vi.mock('@/lib/csrf', () => ({
  validateCsrfToken: vi.fn(async () => true),
  generateCsrfToken: vi.fn(async () => 'test-csrf-token'),
}))

function mockChain(result: { data?: unknown; error?: unknown }) {
  const chain: Record<string, unknown> = {}
  chain.select = vi.fn().mockReturnValue(chain)
  chain.update = vi.fn().mockReturnValue(chain)
  chain.eq = vi.fn().mockReturnValue(chain)
  chain.single = vi.fn().mockResolvedValue(result)
  chain.maybeSingle = vi.fn().mockResolvedValue(result)
  return chain
}

const mockCtx = { params: Promise.resolve({}) } as { params: Promise<Record<string, string>> }

const mockProfile = {
  id: 'user-1',
  email: 'test@example.com',
  full_name: 'Test User',
  avatar_url: null,
  plan: 'free',
  is_paid: false,
  subscription_status: 'inactive',
}

describe('GET /api/me', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 401 if not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { GET } = await import('@/app/api/me/route')
    const res = await GET(new NextRequest('http://localhost:3000/api/me'), mockCtx)
    const body = await res.json()

    expect(res.status).toBe(401)
    expect(body.error).toBe('Unauthorized')
  })

  it('returns user profile for authenticated user', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: mockProfile, error: null }))

    const { GET } = await import('@/app/api/me/route')
    const res = await GET(new NextRequest('http://localhost:3000/api/me'), mockCtx)
    const body = await res.json()

    expect(res.status).toBe(200)
    expect(body.data.id).toBe('user-1')
    expect(body.data.email).toBe('test@example.com')
    expect(body.data.full_name).toBe('Test User')
    expect(body.error).toBeNull()
  })

  it('returns 404 if profile not found', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    mockFrom.mockReturnValue(mockChain({ data: null, error: null }))

    const { GET } = await import('@/app/api/me/route')
    const res = await GET(new NextRequest('http://localhost:3000/api/me'), mockCtx)
    const body = await res.json()

    expect(res.status).toBe(404)
    expect(body.error).toContain('not found')
  })
})

describe('PATCH /api/me', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('returns 401 if not authenticated', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { PATCH } = await import('@/app/api/me/route')
    const req = new NextRequest('http://localhost:3000/api/me', {
      method: 'PATCH',
      body: JSON.stringify({ full_name: 'New Name' }),
      headers: { 'Content-Type': 'application/json' },
    })
    const res = await PATCH(req, mockCtx)

    expect(res.status).toBe(401)
  })

  it('validates update payload', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { PATCH } = await import('@/app/api/me/route')
    const req = new NextRequest('http://localhost:3000/api/me', {
      method: 'PATCH',
      body: JSON.stringify({ full_name: '' }), // min 1 char
      headers: { 'Content-Type': 'application/json' },
    })
    const res = await PATCH(req, mockCtx)

    expect(res.status).toBe(400)
  })

  it('successfully updates profile', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    const updatedProfile = { ...mockProfile, full_name: 'Updated Name' }
    mockFrom.mockReturnValue(mockChain({ data: updatedProfile, error: null }))

    const { PATCH } = await import('@/app/api/me/route')
    const req = new NextRequest('http://localhost:3000/api/me', {
      method: 'PATCH',
      body: JSON.stringify({ full_name: 'Updated Name' }),
      headers: { 'Content-Type': 'application/json' },
    })
    const res = await PATCH(req, mockCtx)
    const body = await res.json()

    expect(res.status).toBe(200)
    expect(body.data.full_name).toBe('Updated Name')
  })

  it('strips unknown fields — plan cannot be set via PATCH', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })
    const chain = mockChain({ data: mockProfile, error: null })
    mockFrom.mockReturnValue(chain)

    const { PATCH } = await import('@/app/api/me/route')
    const req = new NextRequest('http://localhost:3000/api/me', {
      method: 'PATCH',
      body: JSON.stringify({ full_name: 'Valid Name', plan: 'pro' }),
      headers: { 'Content-Type': 'application/json' },
    })
    const res = await PATCH(req, mockCtx)

    // Zod strips unknown fields — plan should not reach .update()
    expect(res.status).toBe(200)
    expect(chain.update).toHaveBeenCalledWith({ full_name: 'Valid Name' })
  })
})
