import { test, expect } from '@playwright/test'

test.describe('smoke', () => {
  test('landing page renders primary marketing content', async ({ page }) => {
    await page.goto('/')

    await expect(
      page.getByRole('heading', { name: /ship your saas in days,? not months/i })
    ).toBeVisible()
    await expect(page.getByRole('link', { name: 'Sign in' })).toBeVisible()
    await expect(page.getByRole('link', { name: 'Get started free' })).toBeVisible()
  })

  test('unauthenticated users are redirected away from dashboard', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page).toHaveURL(/\/login$/)
    await expect(
      page.getByRole('heading', { name: 'Welcome back' })
    ).toBeVisible()
  })

  test('signup page renders the expected form fields', async ({ page }) => {
    await page.goto('/signup')

    await expect(
      page.getByRole('heading', { name: 'Create your account' })
    ).toBeVisible()
    await expect(page.getByPlaceholder('John Doe')).toBeVisible()
    await expect(page.getByPlaceholder('you@example.com')).toBeVisible()
    await expect(page.getByPlaceholder('Min 8 characters')).toBeVisible()
    await expect(
      page.getByRole('button', { name: 'Create account' })
    ).toBeVisible()
  })

  test('reset password page is reachable from login', async ({ page }) => {
    await page.goto('/login')
    await page.getByRole('link', { name: 'Forgot password?' }).click()

    await expect(page).toHaveURL(/\/reset-password$/)
    await expect(
      page.getByRole('heading', { name: 'Reset password' })
    ).toBeVisible()
    await expect(
      page.getByRole('button', { name: 'Send reset link' })
    ).toBeVisible()
  })
})
