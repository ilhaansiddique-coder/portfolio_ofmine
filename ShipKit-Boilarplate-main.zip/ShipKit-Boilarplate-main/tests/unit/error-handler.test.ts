import { describe, it, expect, vi } from 'vitest'
import { NextRequest, NextResponse } from 'next/server'
import { withErrorHandler } from '@/lib/with-error-handler'

// Mock logger and error tracking
vi.mock('@/lib/logger', () => ({
  logger: {
    error: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
  },
}))

vi.mock('@/lib/error-tracking', () => ({
  captureError: vi.fn(),
}))

describe('withErrorHandler', () => {
  const mockCtx = { params: Promise.resolve({}) } as { params: Promise<Record<string, string>> }

  it('passes through successful responses', async () => {
    const handler = withErrorHandler(async () => {
      return NextResponse.json({ ok: true }, { status: 200 })
    })

    const req = new NextRequest('http://localhost:3000/api/test')
    const response = await handler(req, mockCtx)

    expect(response.status).toBe(200)
  })

  it('catches thrown errors and returns 500', async () => {
    const handler = withErrorHandler(async () => {
      throw new Error('Something broke')
    })

    const req = new NextRequest('http://localhost:3000/api/test')
    const response = await handler(req, mockCtx)
    const body = await response.json()

    expect(response.status).toBe(500)
    expect(body.error).toBe('Internal server error')
  })

  it('catches non-Error throws and returns 500', async () => {
    const handler = withErrorHandler(async () => {
      throw 'string error'
    })

    const req = new NextRequest('http://localhost:3000/api/test')
    const response = await handler(req, mockCtx)

    expect(response.status).toBe(500)
  })

  it('passes request and context to handler', async () => {
    const spy = vi.fn(async () => NextResponse.json({ ok: true }))
    const handler = withErrorHandler(spy)

    const req = new NextRequest('http://localhost:3000/api/test')
    await handler(req, mockCtx)

    expect(spy).toHaveBeenCalledWith(req, mockCtx)
  })
})
