import { describe, it, expect } from 'vitest'
import { PLAN_LIMITS, normalizePlan } from '@/lib/plans'

describe('PLAN_LIMITS', () => {
  it('defines free, basic, and pro tiers', () => {
    expect(PLAN_LIMITS.free).toBeDefined()
    expect(PLAN_LIMITS.basic).toBeDefined()
    expect(PLAN_LIMITS.pro).toBeDefined()
  })

  it('free tier has the lowest storage', () => {
    expect(PLAN_LIMITS.free.maxStorageMb).toBeLessThan(PLAN_LIMITS.basic.maxStorageMb)
    expect(PLAN_LIMITS.basic.maxStorageMb).toBeLessThan(PLAN_LIMITS.pro.maxStorageMb)
  })

  it('each tier has at least one feature', () => {
    expect(PLAN_LIMITS.free.features.length).toBeGreaterThan(0)
    expect(PLAN_LIMITS.basic.features.length).toBeGreaterThan(0)
    expect(PLAN_LIMITS.pro.features.length).toBeGreaterThan(0)
  })
})

describe('normalizePlan', () => {
  it('returns valid plan names as-is', () => {
    expect(normalizePlan('free')).toBe('free')
    expect(normalizePlan('basic')).toBe('basic')
    expect(normalizePlan('pro')).toBe('pro')
  })

  it('defaults to free for unknown plans', () => {
    expect(normalizePlan('enterprise')).toBe('free')
    expect(normalizePlan('')).toBe('free')
    expect(normalizePlan(undefined)).toBe('free')
  })
})
