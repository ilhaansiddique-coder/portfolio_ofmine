import { describe, it, expect } from 'vitest'
import { ok, err } from '@/lib/api-response'

describe('ok()', () => {
  it('returns 200 with data wrapped in { data, error: null }', async () => {
    const response = ok({ name: 'test' })
    const body = await response.json()

    expect(response.status).toBe(200)
    expect(body.data).toEqual({ name: 'test' })
    expect(body.error).toBeNull()
  })

  it('accepts a custom status code', async () => {
    const response = ok({ id: '123' }, 201)
    const body = await response.json()

    expect(response.status).toBe(201)
    expect(body.data.id).toBe('123')
  })

  it('handles null data', async () => {
    const response = ok(null)
    const body = await response.json()

    expect(body.data).toBeNull()
    expect(body.error).toBeNull()
  })

  it('handles array data', async () => {
    const response = ok([1, 2, 3])
    const body = await response.json()

    expect(body.data).toEqual([1, 2, 3])
  })
})

describe('err()', () => {
  it('returns 500 with error message wrapped in { data: null, error }', async () => {
    const response = err('Something went wrong')
    const body = await response.json()

    expect(response.status).toBe(500)
    expect(body.data).toBeNull()
    expect(body.error).toBe('Something went wrong')
  })

  it('accepts a custom status code', async () => {
    const response = err('Not found', 404)
    const body = await response.json()

    expect(response.status).toBe(404)
    expect(body.error).toBe('Not found')
  })

  it('accepts an optional error code', async () => {
    const response = err('Rate limited', 429, 'RATE_LIMIT')
    const body = await response.json()

    expect(response.status).toBe(429)
    expect(body.error).toBe('Rate limited')
    expect(body.code).toBe('RATE_LIMIT')
  })

  it('returns 401 for unauthorized', async () => {
    const response = err('Unauthorized', 401)
    expect(response.status).toBe(401)
  })
})
