import { describe, it, expect, vi, beforeEach } from 'vitest'
import { NextRequest } from 'next/server'

const mockGetUser = vi.fn()
vi.mock('@supabase/ssr', () => ({
  createServerClient: vi.fn(() => ({
    auth: { getUser: mockGetUser },
  })),
}))

describe('middleware — auth redirects', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('redirects unauthenticated users from /dashboard to /login', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/dashboard')
    const res = await middleware(req)

    expect(res.status).toBe(307)
    expect(res.headers.get('location')).toContain('/login')
  })

  it('redirects unauthenticated users from /dashboard/settings to /login', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/dashboard/settings')
    const res = await middleware(req)

    expect(res.status).toBe(307)
    expect(res.headers.get('location')).toContain('/login')
  })

  it('redirects authenticated users from /login to /dashboard', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/login')
    const res = await middleware(req)

    expect(res.status).toBe(307)
    expect(res.headers.get('location')).toContain('/dashboard')
  })

  it('redirects authenticated users from /signup to /dashboard', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/signup')
    const res = await middleware(req)

    expect(res.status).toBe(307)
    expect(res.headers.get('location')).toContain('/dashboard')
  })

  it('allows authenticated users to access /dashboard', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/dashboard')
    const res = await middleware(req)

    // Should pass through (200), not redirect (307)
    expect(res.status).toBe(200)
  })

  it('allows unauthenticated users to access /login', async () => {
    mockGetUser.mockResolvedValue({ data: { user: null } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/login')
    const res = await middleware(req)

    expect(res.status).toBe(200)
  })
})

describe('middleware — CSP nonce', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('sets Content-Security-Policy with nonce on page routes', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/dashboard')
    const res = await middleware(req)

    const csp = res.headers.get('Content-Security-Policy')
    expect(csp).toBeTruthy()
    expect(csp).toContain("script-src 'self' 'nonce-")
    expect(csp).toContain("style-src 'self' 'nonce-")
    expect(csp).toContain("object-src 'none'")
    expect(csp).toContain("worker-src 'self'")
  })

  it('does not set CSP on API routes', async () => {
    process.env.CORS_ALLOWED_ORIGINS = ''

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/api/me')
    const res = await middleware(req)

    expect(res.headers.get('Content-Security-Policy')).toBeNull()

    delete process.env.CORS_ALLOWED_ORIGINS
  })

  it('generates unique nonce per request', async () => {
    mockGetUser.mockResolvedValue({ data: { user: { id: 'user-1' } } })

    const { middleware } = await import('@/middleware')
    const req1 = new NextRequest('http://localhost:3000/dashboard')
    const req2 = new NextRequest('http://localhost:3000/dashboard')
    const res1 = await middleware(req1)
    const res2 = await middleware(req2)

    const csp1 = res1.headers.get('Content-Security-Policy')!
    const csp2 = res2.headers.get('Content-Security-Policy')!
    expect(csp1).not.toBe(csp2)
  })
})

describe('middleware — CORS', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.resetModules()
  })

  it('sets CORS headers for API requests with allowed origin', async () => {
    process.env.CORS_ALLOWED_ORIGINS = 'https://app.example.com,https://staging.example.com'

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/api/me', {
      headers: { origin: 'https://app.example.com' },
    })
    const res = await middleware(req)

    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('https://app.example.com')
    expect(res.headers.get('Access-Control-Allow-Credentials')).toBe('true')

    delete process.env.CORS_ALLOWED_ORIGINS
  })

  it('supports multiple CORS origins', async () => {
    process.env.CORS_ALLOWED_ORIGINS = 'https://app.example.com,https://staging.example.com'

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/api/orgs', {
      headers: { origin: 'https://staging.example.com' },
    })
    const res = await middleware(req)

    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('https://staging.example.com')

    delete process.env.CORS_ALLOWED_ORIGINS
  })

  it('returns 204 for OPTIONS preflight', async () => {
    process.env.CORS_ALLOWED_ORIGINS = 'https://app.example.com'

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/api/me', {
      method: 'OPTIONS',
      headers: { origin: 'https://app.example.com' },
    })
    const res = await middleware(req)

    expect(res.status).toBe(204)
    expect(res.headers.get('Access-Control-Allow-Methods')).toContain('POST')
    expect(res.headers.get('Access-Control-Allow-Headers')).toContain('x-csrf-token')

    delete process.env.CORS_ALLOWED_ORIGINS
  })

  it('does not set CORS headers for disallowed origins', async () => {
    process.env.CORS_ALLOWED_ORIGINS = 'https://app.example.com'

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/api/me', {
      headers: { origin: 'https://evil.com' },
    })
    const res = await middleware(req)

    expect(res.headers.get('Access-Control-Allow-Origin')).toBeNull()

    delete process.env.CORS_ALLOWED_ORIGINS
  })

  it('denies all origins when CORS_ALLOWED_ORIGINS is empty', async () => {
    process.env.CORS_ALLOWED_ORIGINS = ''

    const { middleware } = await import('@/middleware')
    const req = new NextRequest('http://localhost:3000/api/me', {
      headers: { origin: 'https://any-site.com' },
    })
    const res = await middleware(req)

    expect(res.headers.get('Access-Control-Allow-Origin')).toBeNull()

    delete process.env.CORS_ALLOWED_ORIGINS
  })
})
