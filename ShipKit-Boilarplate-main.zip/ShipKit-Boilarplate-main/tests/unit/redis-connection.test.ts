import { describe, it, expect } from 'vitest'
import { parseRedisUrl, getBullMQConnection } from '@/lib/redis-connection'

describe('parseRedisUrl', () => {
  it('parses a standard Redis URL', () => {
    const result = parseRedisUrl('redis://localhost:6379')
    expect(result.host).toBe('localhost')
    expect(result.port).toBe(6379)
    expect(result.password).toBeUndefined()
  })

  it('parses a Redis URL with password', () => {
    const result = parseRedisUrl('redis://:mysecret@redis-host:6380')
    expect(result.host).toBe('redis-host')
    expect(result.port).toBe(6380)
    expect(result.password).toBe('mysecret')
  })

  it('parses a Redis URL with username and password', () => {
    const result = parseRedisUrl('redis://myuser:mypass@redis-host:6380')
    expect(result.host).toBe('redis-host')
    expect(result.port).toBe(6380)
    expect(result.username).toBe('myuser')
    expect(result.password).toBe('mypass')
  })

  it('defaults to localhost:6379 on invalid URL', () => {
    const result = parseRedisUrl('not-a-url')
    expect(result.host).toBe('localhost')
    expect(result.port).toBe(6379)
  })

  it('handles rediss:// (TLS) scheme', () => {
    const result = parseRedisUrl('rediss://default:token@cloud.redis.io:25061')
    expect(result.host).toBe('cloud.redis.io')
    expect(result.port).toBe(25061)
    expect(result.password).toBe('token')
  })
})

describe('getBullMQConnection', () => {
  it('returns a connection object with maxRetriesPerRequest: null', () => {
    const conn = getBullMQConnection()
    expect(conn.maxRetriesPerRequest).toBeNull()
    expect(conn.host).toBeDefined()
    expect(conn.port).toBeDefined()
  })
})
