import { describe, it, expect } from 'vitest'
import { validateBody } from '@/lib/validate'
import { z } from 'zod'

const schema = z.object({
  email: z.string().email(),
  name: z.string().min(2),
})

describe('validateBody', () => {
  it('returns success with valid data', () => {
    const result = validateBody(schema, {
      email: 'test@test.com',
      name: 'John',
    })
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.email).toBe('test@test.com')
      expect(result.data.name).toBe('John')
    }
  })

  it('returns error response with invalid data', () => {
    const result = validateBody(schema, { email: 'bad', name: '' })
    expect(result.success).toBe(false)
    if (!result.success) {
      expect(result.response.status).toBe(400)
    }
  })

  it('returns error for missing fields', () => {
    const result = validateBody(schema, {})
    expect(result.success).toBe(false)
  })

  it('returns error for null input', () => {
    const result = validateBody(schema, null)
    expect(result.success).toBe(false)
  })
})
