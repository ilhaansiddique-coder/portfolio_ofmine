import { describe, it, expect } from 'vitest'
import { createHmac, timingSafeEqual } from 'crypto'

// Test the webhook signature verification logic directly
// (same algorithm used in app/api/webhooks/lemonsqueezy/route.ts)
function verifyWebhookSignature(
  rawBody: string,
  signature: string,
  secret: string
): boolean {
  const hmac = createHmac('sha256', secret)
  const digest = hmac.update(rawBody).digest('hex')

  try {
    return timingSafeEqual(
      Buffer.from(signature, 'hex'),
      Buffer.from(digest, 'hex')
    )
  } catch {
    return false
  }
}

describe('Webhook HMAC Signature Verification', () => {
  const secret = 'test-webhook-secret'

  it('accepts a valid signature', () => {
    const body = '{"event":"order_created"}'
    const hmac = createHmac('sha256', secret)
    const validSig = hmac.update(body).digest('hex')

    expect(verifyWebhookSignature(body, validSig, secret)).toBe(true)
  })

  it('rejects an invalid signature', () => {
    const body = '{"event":"order_created"}'
    const fakeSig = 'a'.repeat(64)

    expect(verifyWebhookSignature(body, fakeSig, secret)).toBe(false)
  })

  it('rejects an empty signature', () => {
    const body = '{"event":"order_created"}'
    expect(verifyWebhookSignature(body, '', secret)).toBe(false)
  })

  it('rejects a tampered body', () => {
    const originalBody = '{"event":"order_created"}'
    const hmac = createHmac('sha256', secret)
    const sig = hmac.update(originalBody).digest('hex')

    const tamperedBody = '{"event":"subscription_cancelled"}'
    expect(verifyWebhookSignature(tamperedBody, sig, secret)).toBe(false)
  })

  it('rejects a signature from a different secret', () => {
    const body = '{"event":"order_created"}'
    const hmac = createHmac('sha256', 'wrong-secret')
    const wrongSig = hmac.update(body).digest('hex')

    expect(verifyWebhookSignature(body, wrongSig, secret)).toBe(false)
  })

  it('uses timing-safe comparison (same length buffers)', () => {
    const body = '{"test":true}'
    const hmac1 = createHmac('sha256', secret)
    const validSig = hmac1.update(body).digest('hex')

    // Ensure the digest and signature have the same length (64 hex chars for sha256)
    expect(validSig.length).toBe(64)

    const hmac2 = createHmac('sha256', secret)
    const digest = hmac2.update(body).digest('hex')

    const result = timingSafeEqual(
      Buffer.from(validSig, 'hex'),
      Buffer.from(digest, 'hex')
    )
    expect(result).toBe(true)
  })
})
