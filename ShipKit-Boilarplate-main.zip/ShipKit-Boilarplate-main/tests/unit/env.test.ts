import { describe, it, expect } from 'vitest'
import { z } from 'zod'

// Test the env validation schema logic (same schema used in lib/env.ts)
// We test the schema directly rather than importing env (which crashes if vars are missing)
const serverSchema = z
  .object({
    NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
    NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
    SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
    DATABASE_URL: z.string().startsWith('postgresql://'),
    LEMONSQUEEZY_API_KEY: z.string().min(1),
    LEMONSQUEEZY_WEBHOOK_SECRET: z.string().min(1),
    LEMONSQUEEZY_STORE_ID: z.string().min(1),
    LEMONSQUEEZY_VARIANT_BASIC: z.string().min(1),
    LEMONSQUEEZY_VARIANT_PRO: z.string().min(1),
    LEMONSQUEEZY_VARIANT_MONTHLY: z.string().min(1),
    LEMONSQUEEZY_VARIANT_YEARLY: z.string().min(1),
    EMAIL_PROVIDER: z.enum(['ses', 'resend', 'mailgun']).default('ses'),
    EMAIL_FROM: z.string().email().optional(),
    AWS_ACCESS_KEY_ID: z.string().min(1).optional(),
    AWS_SECRET_ACCESS_KEY: z.string().min(1).optional(),
    AWS_REGION: z.string().min(1).optional(),
    SES_FROM_EMAIL: z.string().email().optional(),
    RESEND_API_KEY: z.string().min(1).optional(),
    MAILGUN_API_KEY: z.string().min(1).optional(),
    MAILGUN_DOMAIN: z.string().min(1).optional(),
    MAILGUN_API_BASE_URL: z.string().url().default('https://api.mailgun.net'),
    REDIS_URL: z.string().min(1),
    ANTHROPIC_API_KEY: z.string().min(1),
    GROQ_API_KEY: z.string().min(1),
    INTERNAL_WEBHOOK_SECRET: z.string().min(1),
    NEXT_PUBLIC_APP_URL: z.string().url(),
    NEXT_PUBLIC_APP_NAME: z.string().default('MySaaS'),
    NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
    LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
    CORS_ALLOWED_ORIGINS: z.string().default('http://localhost:3000'),
    GLITCHTIP_DSN: z.string().optional(),
    ELEVENLABS_API_KEY: z.string().optional(),
    SLACK_WEBHOOK_URL: z.string().url().optional(),
    DIRECT_DATABASE_URL: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    if (!data.EMAIL_FROM && !data.SES_FROM_EMAIL) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['EMAIL_FROM'],
        message: 'EMAIL_FROM is required (or set SES_FROM_EMAIL for backward compatibility).',
      })
    }

    if (data.EMAIL_PROVIDER === 'ses') {
      if (!data.AWS_ACCESS_KEY_ID) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['AWS_ACCESS_KEY_ID'],
          message: 'AWS_ACCESS_KEY_ID is required when EMAIL_PROVIDER=ses.',
        })
      }
      if (!data.AWS_SECRET_ACCESS_KEY) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['AWS_SECRET_ACCESS_KEY'],
          message: 'AWS_SECRET_ACCESS_KEY is required when EMAIL_PROVIDER=ses.',
        })
      }
      if (!data.AWS_REGION) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['AWS_REGION'],
          message: 'AWS_REGION is required when EMAIL_PROVIDER=ses.',
        })
      }
    }

    if (data.EMAIL_PROVIDER === 'resend' && !data.RESEND_API_KEY) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['RESEND_API_KEY'],
        message: 'RESEND_API_KEY is required when EMAIL_PROVIDER=resend.',
      })
    }

    if (data.EMAIL_PROVIDER === 'mailgun') {
      if (!data.MAILGUN_API_KEY) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['MAILGUN_API_KEY'],
          message: 'MAILGUN_API_KEY is required when EMAIL_PROVIDER=mailgun.',
        })
      }
      if (!data.MAILGUN_DOMAIN) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['MAILGUN_DOMAIN'],
          message: 'MAILGUN_DOMAIN is required when EMAIL_PROVIDER=mailgun.',
        })
      }
    }
  })

const validEnv = {
  NEXT_PUBLIC_SUPABASE_URL: 'http://localhost:54321',
  NEXT_PUBLIC_SUPABASE_ANON_KEY: 'test-anon-key',
  SUPABASE_SERVICE_ROLE_KEY: 'test-service-key',
  DATABASE_URL: 'postgresql://postgres:postgres@localhost:54321/postgres',
  LEMONSQUEEZY_API_KEY: 'test-ls-key',
  LEMONSQUEEZY_WEBHOOK_SECRET: 'test-webhook-secret',
  LEMONSQUEEZY_STORE_ID: 'test-store',
  LEMONSQUEEZY_VARIANT_BASIC: 'test-basic',
  LEMONSQUEEZY_VARIANT_PRO: 'test-pro',
  LEMONSQUEEZY_VARIANT_MONTHLY: 'test-monthly',
  LEMONSQUEEZY_VARIANT_YEARLY: 'test-yearly',
  EMAIL_PROVIDER: 'ses' as const,
  EMAIL_FROM: 'noreply@example.com',
  AWS_ACCESS_KEY_ID: 'test-key',
  AWS_SECRET_ACCESS_KEY: 'test-secret',
  AWS_REGION: 'us-east-1',
  SES_FROM_EMAIL: 'noreply@example.com',
  REDIS_URL: 'redis://localhost:6379',
  ANTHROPIC_API_KEY: 'test-key',
  GROQ_API_KEY: 'test-key',
  INTERNAL_WEBHOOK_SECRET: 'test-secret',
  NEXT_PUBLIC_APP_URL: 'http://localhost:3000',
}

describe('Server Env Schema', () => {
  it('passes with all required vars set', () => {
    const result = serverSchema.safeParse(validEnv)
    expect(result.success).toBe(true)
  })

  it('applies defaults for optional vars', () => {
    const result = serverSchema.safeParse(validEnv)
    expect(result.success).toBe(true)
    if (result.success) {
      expect(result.data.NEXT_PUBLIC_APP_NAME).toBe('MySaaS')
      expect(result.data.NODE_ENV).toBe('development')
      expect(result.data.LOG_LEVEL).toBe('info')
    }
  })

  it('fails when NEXT_PUBLIC_SUPABASE_URL is missing', () => {
    const rest = { ...validEnv }
    delete (rest as Partial<typeof validEnv>).NEXT_PUBLIC_SUPABASE_URL
    const result = serverSchema.safeParse(rest)
    expect(result.success).toBe(false)
  })

  it('fails when DATABASE_URL has wrong prefix', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      DATABASE_URL: 'mysql://localhost/db',
    })
    expect(result.success).toBe(false)
  })

  it('fails when EMAIL_FROM and SES_FROM_EMAIL are both missing', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      EMAIL_FROM: undefined,
      SES_FROM_EMAIL: undefined,
    })
    expect(result.success).toBe(false)
  })

  it('fails when EMAIL_FROM is not a valid email', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      EMAIL_FROM: 'not-an-email',
    })
    expect(result.success).toBe(false)
  })

  it('passes with resend when RESEND_API_KEY is set', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      EMAIL_PROVIDER: 'resend',
      AWS_ACCESS_KEY_ID: undefined,
      AWS_SECRET_ACCESS_KEY: undefined,
      AWS_REGION: undefined,
      RESEND_API_KEY: 're_test_key',
    })
    expect(result.success).toBe(true)
  })

  it('fails with resend when RESEND_API_KEY is missing', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      EMAIL_PROVIDER: 'resend',
      AWS_ACCESS_KEY_ID: undefined,
      AWS_SECRET_ACCESS_KEY: undefined,
      AWS_REGION: undefined,
      RESEND_API_KEY: undefined,
    })
    expect(result.success).toBe(false)
  })

  it('passes with mailgun when required vars are set', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      EMAIL_PROVIDER: 'mailgun',
      AWS_ACCESS_KEY_ID: undefined,
      AWS_SECRET_ACCESS_KEY: undefined,
      AWS_REGION: undefined,
      MAILGUN_API_KEY: 'mailgun-key',
      MAILGUN_DOMAIN: 'mg.example.com',
    })
    expect(result.success).toBe(true)
  })

  it('fails with mailgun when domain is missing', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      EMAIL_PROVIDER: 'mailgun',
      AWS_ACCESS_KEY_ID: undefined,
      AWS_SECRET_ACCESS_KEY: undefined,
      AWS_REGION: undefined,
      MAILGUN_API_KEY: 'mailgun-key',
      MAILGUN_DOMAIN: undefined,
    })
    expect(result.success).toBe(false)
  })

  it('accepts valid optional SLACK_WEBHOOK_URL', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      SLACK_WEBHOOK_URL: 'https://hooks.slack.com/services/xxx',
    })
    expect(result.success).toBe(true)
  })

  it('fails when SLACK_WEBHOOK_URL is not a valid URL', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      SLACK_WEBHOOK_URL: 'not-a-url',
    })
    expect(result.success).toBe(false)
  })

  it('fails when NODE_ENV is an invalid value', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      NODE_ENV: 'staging',
    })
    expect(result.success).toBe(false)
  })

  it('fails when LOG_LEVEL is an invalid value', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      LOG_LEVEL: 'verbose',
    })
    expect(result.success).toBe(false)
  })

  it('fails when any required key is empty string', () => {
    const result = serverSchema.safeParse({
      ...validEnv,
      ANTHROPIC_API_KEY: '',
    })
    expect(result.success).toBe(false)
  })
})
