# Quick Start Guide

Get your SaaS running in 5 minutes.

---

## 1. Prerequisites

- Node.js 20+
- Supabase account (free tier OK)
- LemonSqueezy account (for payments)
- AWS account (for email via SES)
- Redis instance (Upstash recommended)

---

## 2. Clone & Setup

```bash
# Clone repository
git clone <your-repo>
cd saas-boilerplate

# Install dependencies
npm install

# Copy environment template
cp .env.example .env.local
```

---

## 3. Configure Environment

Edit `.env.local` with your credentials:

### Supabase (Required)
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-key
SUPABASE_SERVICE_ROLE_KEY=your-key
DATABASE_URL=postgresql://...
```

### Payments (LemonSqueezy)
```
LEMONSQUEEZY_API_KEY=your-key
LEMONSQUEEZY_WEBHOOK_SECRET=your-secret
LEMONSQUEEZY_STORE_ID=your-id
LEMONSQUEEZY_VARIANT_BASIC=basic-variant-id
LEMONSQUEEZY_VARIANT_PRO=pro-variant-id
LEMONSQUEEZY_VARIANT_MONTHLY=monthly-id
LEMONSQUEEZY_VARIANT_YEARLY=yearly-id
```

### Email (AWS SES)
```
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_REGION=us-east-1
SES_FROM_EMAIL=noreply@yourdomain.com
```

### Redis
```
REDIS_URL=redis://your-redis-url
```

### App
```
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME=YourSaaS
```

### Security
```
INTERNAL_WEBHOOK_SECRET=generate-a-random-secret-string
```

---

## 4. Database Setup

```bash
# Push migrations to your Supabase database
npm run db:push

# Generate TypeScript types
npm run db:types
```

---

## 5. Run Development Server

```bash
# Start Next.js dev server
npm run dev

# Open http://localhost:3000
```

---

## 6. Test Everything Works

### Sign Up
- Go to http://localhost:3000/signup
- Create account with email/password
- You should receive welcome email

### Dashboard
- After signup, you should be on dashboard
- See stats and activity feed

### Billing
- Go to http://localhost:3000/billing
- See plan options
- Try upgrade (will fail without LemonSqueezy configured)

### Settings
- Go to http://localhost:3000/dashboard/settings
- Edit profile
- Export data
- Delete account (be careful!)

---

## Useful Commands

```bash
# Development
npm run dev                    # Start dev server
npm run build                  # Build for production
npm run start                  # Start production server

# Testing
npm run test                   # Run unit tests
npm run test:watch            # Watch mode
npm run test:coverage         # Coverage report
npm run test:e2e              # End-to-end tests
npm run test:e2e:ui           # E2E with UI

# Code Quality
npm run lint                   # Run ESLint
npm run typecheck             # TypeScript check
npm run test:coverage         # Coverage report

# Database
npm run db:push               # Push migrations
npm run db:pull               # Pull remote schema
npm run db:reset              # Reset database
npm run db:types              # Generate types
npm run db:migrate            # Create new migration

# Background Jobs
npm run worker:email          # Run email worker
npm run worker:automation     # Run automation worker
npm run workers               # Run all workers
```

---

## Project Structure

```
app/                          # Next.js app directory
├── page.tsx                  # Landing page
├── (auth)/                   # Auth routes
│   ├── login/
│   ├── signup/
│   └── reset-password/
├── (dashboard)/              # Dashboard routes (protected)
│   ├── billing/              # Subscription management
│   ├── dashboard/            # Main dashboard
│   ├── settings/             # User settings
│   ├── organizations/        # Team management
│   └── admin/                # Admin dashboard
├── (legal)/                  # Legal pages
│   ├── terms/
│   └── privacy/
└── api/                      # API routes
    ├── auth/
    ├── me/                   # User endpoints
    ├── billing/              # Payment endpoints
    ├── webhooks/             # Webhook handlers
    ├── orgs/                 # Organization endpoints
    └── admin/                # Admin endpoints

lib/                          # Utilities & logic
├── supabase/                 # Database clients
├── queries/                  # React Query hooks
├── email.ts                  # Email templates
├── lemonsqueezy.ts           # Payments
├── csrf.ts                   # Security
├── logger.ts                 # Logging
└── env.ts                    # Environment validation

components/                   # React components
├── shared/                   # Navbar, Sidebar, etc
├── auth/                     # Auth form
├── ui/                       # UI components (shadcn)
└── providers/                # React Query provider

supabase/                     # Database
├── migrations/               # SQL migrations
└── seed.sql                  # Demo data

workers/                      # Background jobs
├── email.worker.ts
├── automation.worker.ts
└── notification.worker.ts

tests/                        # All tests
├── unit/                     # Unit tests
├── integration/              # API tests
└── e2e/                      # Playwright tests

types/                        # TypeScript types
stores/                       # Zustand stores
public/                       # Static assets
```

---

## Common Tasks

### Add a New Page

1. Create folder under `app/(dashboard)/your-page/`
2. Create `page.tsx` with client or server component
3. Add to sidebar navigation in `components/shared/Sidebar.tsx`
4. Use `ScopedStyle` component for styling

Example:
```tsx
'use client'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function YourStyles() {
  return (
    <ScopedStyle>{`
      .yp-title { /* your styles */ }
    `}</ScopedStyle>
  )
}

export default function YourPage() {
  return (
    <div className="yp-root">
      <YourStyles />
      {/* content */}
    </div>
  )
}
```

### Add a New API Endpoint

1. Create route at `app/api/your-endpoint/route.ts`
2. Use `withErrorHandler` for error handling
3. Use `ok()` and `err()` response helpers
4. Add Zod validation with `validateBody()`

Example:
```typescript
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { validateBody } from '@/lib/validate'
import { z } from 'zod'

const schema = z.object({ name: z.string() })

export const POST = withErrorHandler(async (req) => {
  const body = await req.json()
  const validation = validateBody(schema, body)
  if (!validation.success) return validation.response

  // your logic here
  return ok({ message: 'success' })
}, { rateLimit: { limit: 10 } })
```

### Query Data from Database

```typescript
'use client'
import { useQuery } from '@tanstack/react-query'

function MyComponent() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['my-data'],
    queryFn: () => fetch('/api/my-endpoint').then(r => r.json()),
  })

  if (isLoading) return <p>Loading...</p>
  if (error) return <p>Error: {error.message}</p>
  return <div>{data}</div>
}
```

### Add a Background Job

```typescript
// workers/my-job.worker.ts
import { Worker } from 'bullmq'
import { redis } from '@/lib/redis'

const worker = new Worker(
  'my-queue',
  async (job) => {
    console.log(`Processing job ${job.id}`)
    // your async work here
  },
  { connection: redis }
)
```

### Send an Email

```typescript
import { sendEmail, welcomeEmail } from '@/lib/email'

await sendEmail({
  to: user.email,
  subject: 'Welcome!',
  html: welcomeEmail(user.full_name)
})
```

---

## Deployment to Vercel

```bash
# 1. Push to GitHub
git add .
git commit -m "Production ready"
git push origin main

# 2. Go to vercel.com and connect GitHub repo
# 3. Add environment variables from .env.local
# 4. Click Deploy
# 5. Custom domain → Update DNS records
```

See [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for complete instructions.

---

## Environment Variables Checklist

Required for development:
- [ ] NEXT_PUBLIC_SUPABASE_URL
- [ ] NEXT_PUBLIC_SUPABASE_ANON_KEY
- [ ] SUPABASE_SERVICE_ROLE_KEY
- [ ] DATABASE_URL
- [ ] REDIS_URL
- [ ] NEXT_PUBLIC_APP_URL

Optional but recommended:
- [ ] LEMONSQUEEZY_API_KEY
- [ ] AWS credentials (for email)
- [ ] GLITCHTIP_DSN (for error tracking)
- [ ] ANTHROPIC_API_KEY (for AI features)

---

## Troubleshooting

### Port 3000 already in use
```bash
npm run dev -- -p 3001  # Use different port
```

### Database migration fails
```bash
npm run db:types        # Regenerate types
npm run db:reset        # Reset database
npm run db:push         # Re-push migrations
```

### Authentication not working
- Verify Supabase URL and keys
- Check database has auth enabled
- Clear browser cookies and try again

### Build fails
```bash
rm -rf .next node_modules
npm install
npm run build
```

---

## Getting Help

1. **Documentation**: [README_PRODUCTION.md](./README_PRODUCTION.md)
2. **Deployment**: [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)
3. **Checklist**: [PRODUCTION_CHECKLIST.md](./PRODUCTION_CHECKLIST.md)
4. **Guidelines**: [CLAUDE.md](./CLAUDE.md)
5. **Summary**: [IMPLEMENTATION_SUMMARY.md](./IMPLEMENTATION_SUMMARY.md)

---

## Next Steps

1. ✅ Clone repo and install
2. ✅ Set up environment variables
3. ✅ Run database migrations
4. ✅ Start dev server
5. ✅ Test signup flow
6. ✅ Customize branding
7. ✅ Deploy to staging
8. 📊 Test payment flow
9. 🚀 Deploy to production
10. 🎉 Go live!

---

**You're all set!** 🚀

Start by running `npm run dev` and visiting http://localhost:3000

---

Questions? See the full documentation files for detailed information.
