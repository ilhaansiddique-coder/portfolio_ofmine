'use client'

import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

const loginSchema = z.object({
  email: z.string().email('Please enter a valid email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
})

const signupSchema = loginSchema.extend({
  fullName: z.string().min(2, 'Name must be at least 2 characters'),
})

type LoginData = z.infer<typeof loginSchema>
type SignupData = z.infer<typeof signupSchema>

interface AuthFormProps {
  mode: 'login' | 'signup'
}

function AuthFormStyles() {
  return (
    <ScopedStyle>{`
      .af-card {
        max-width: 420px;
        width: 100%;
        margin: 0 auto;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.25rem;
        padding: 2rem 1.75rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
      }
      .af-title {
        font-size: 1.5rem;
        font-weight: 900;
        letter-spacing: -0.03em;
        color: #1a1625;
        margin-bottom: 0.25rem;
        text-align: center;
      }
      .af-subtitle {
        font-size: 0.8rem;
        color: #8b7fa8;
        text-align: center;
        margin-bottom: 1.5rem;
      }
      .af-field {
        display: flex;
        flex-direction: column;
        gap: 0.35rem;
        margin-bottom: 1rem;
      }
      .af-label {
        font-size: 0.75rem;
        font-weight: 700;
        color: #6b5f80;
        letter-spacing: 0.02em;
      }
      .af-input {
        width: 100%;
        padding: 0.6rem 0.85rem;
        font-size: 0.82rem;
        color: #1a1625;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        outline: none;
        transition: all 0.2s ease;
        font-family: var(--font-body), sans-serif;
      }
      .af-input:focus {
        border-color: rgba(124,58,237,0.3);
        box-shadow: 0 0 0 3px rgba(124,58,237,0.06);
      }
      .af-error-text {
        font-size: 0.7rem;
        color: #ef4444;
        margin-top: 0.15rem;
      }
      .af-alert {
        padding: 0.6rem 0.85rem;
        font-size: 0.75rem;
        font-weight: 600;
        color: #991b1b;
        background: #fee2e2;
        border: 1px solid #fca5a5;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
      }
      .af-btn {
        width: 100%;
        padding: 0.65rem;
        font-size: 0.82rem;
        font-weight: 700;
        color: #fff;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        border: none;
        border-radius: 0.75rem;
        cursor: pointer;
        transition: all 0.18s ease;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
        font-family: var(--font-body), sans-serif;
      }
      .af-btn:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .af-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      .af-footer {
        text-align: center;
        font-size: 0.78rem;
        color: #8b7fa8;
        margin-top: 1.25rem;
      }
      .af-footer a {
        color: #7c3aed;
        font-weight: 700;
        text-decoration: none;
      }
      .af-footer a:hover {
        color: #5b21b6;
      }
      .af-divider {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin: 1.25rem 0;
        color: #a89bbe;
        font-size: 0.7rem;
      }
      .af-divider::before,
      .af-divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: rgba(124,58,237,0.08);
      }
      .af-oauth-btn {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.55rem;
        font-size: 0.8rem;
        font-weight: 700;
        color: #6b5f80;
        background: rgba(124,58,237,0.04);
        border: 1.5px solid rgba(124,58,237,0.1);
        border-radius: 0.75rem;
        cursor: pointer;
        transition: all 0.18s ease;
        margin-bottom: 0.5rem;
        font-family: var(--font-body), sans-serif;
      }
      .af-oauth-btn:hover {
        background: rgba(124,58,237,0.08);
        border-color: rgba(124,58,237,0.18);
      }
    `}</ScopedStyle>
  )
}

export function AuthForm({ mode }: AuthFormProps) {
  const [serverError, setServerError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()
  const isLogin = mode === 'login'

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<SignupData>({
    resolver: zodResolver(isLogin ? loginSchema : signupSchema),
  })

  async function onSubmit(data: LoginData | SignupData) {
    setServerError(null)

    if (isLogin) {
      const { error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      })
      if (error) {
        setServerError(error.message)
        return
      }
    } else {
      const d = data as SignupData
      const { error } = await supabase.auth.signUp({
        email: d.email,
        password: d.password,
        options: {
          data: { full_name: d.fullName },
          emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/auth/callback`,
        },
      })
      if (error) {
        setServerError(error.message)
        return
      }
    }

    router.push('/dashboard')
    router.refresh()
  }

  async function handleOAuth(provider: 'google' | 'github') {
    await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${process.env.NEXT_PUBLIC_APP_URL}/auth/callback`,
      },
    })
  }

  return (
    <>
      <AuthFormStyles />
      <div className="af-card">
        <h1 className="af-title">
          {isLogin ? 'Welcome back' : 'Create your account'}
        </h1>
        <p className="af-subtitle">
          {isLogin
            ? 'Sign in to access your dashboard'
            : 'Get started in just a few seconds'}
        </p>

        <button
          type="button"
          className="af-oauth-btn"
          onClick={() => handleOAuth('google')}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
          </svg>
          Continue with Google
        </button>

        <button
          type="button"
          className="af-oauth-btn"
          onClick={() => handleOAuth('github')}
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          >
            <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" />
          </svg>
          Continue with GitHub
        </button>

        <div className="af-divider">or</div>

        {serverError && <div className="af-alert">{serverError}</div>}

        <form onSubmit={handleSubmit(onSubmit)}>
          {!isLogin && (
            <div className="af-field">
              <label className="af-label" htmlFor="af-fullName">Full name</label>
              <input
                id="af-fullName"
                className="af-input"
                type="text"
                placeholder="John Doe"
                {...register('fullName')}
              />
              {errors.fullName && (
                <span className="af-error-text">{errors.fullName.message}</span>
              )}
            </div>
          )}

          <div className="af-field">
            <label className="af-label" htmlFor="af-email">Email</label>
            <input
              id="af-email"
              className="af-input"
              type="email"
              placeholder="you@example.com"
              {...register('email')}
            />
            {errors.email && (
              <span className="af-error-text">{errors.email.message}</span>
            )}
          </div>

          <div className="af-field">
            <label className="af-label" htmlFor="af-password">Password</label>
            <input
              id="af-password"
              className="af-input"
              type="password"
              placeholder="Min 8 characters"
              {...register('password')}
            />
            {errors.password && (
              <span className="af-error-text">{errors.password.message}</span>
            )}
          </div>

          {isLogin && (
            <div style={{ textAlign: 'right', marginBottom: '1rem' }}>
              <Link
                href="/reset-password"
                style={{
                  fontSize: '0.75rem',
                  color: '#7c3aed',
                  fontWeight: 600,
                }}
              >
                Forgot password?
              </Link>
            </div>
          )}

          <button type="submit" className="af-btn" disabled={isSubmitting}>
            {isSubmitting
              ? isLogin
                ? 'Signing in...'
                : 'Creating account...'
              : isLogin
                ? 'Sign in'
                : 'Create account'}
          </button>
        </form>

        <p className="af-footer">
          {isLogin ? (
            <>
              Don&apos;t have an account?{' '}
              <Link href="/signup">Sign up</Link>
            </>
          ) : (
            <>
              Already have an account?{' '}
              <Link href="/login">Sign in</Link>
            </>
          )}
        </p>
      </div>
    </>
  )
}
