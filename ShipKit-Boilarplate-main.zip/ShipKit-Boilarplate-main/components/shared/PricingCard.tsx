'use client'

import type { PlanName } from '@/lib/plans'
import { PLAN_LIMITS, PLAN_DISPLAY } from '@/lib/plans'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

interface PricingCardProps {
  plan: PlanName
  popular?: boolean
  currentPlan?: PlanName
  onSelect?: (plan: PlanName) => void
}

function PricingCardStyles() {
  return (
    <ScopedStyle>{`
      .pc-card {
        position: relative;
        background: #fff;
        border: 1.5px solid rgba(124,58,237,0.07);
        border-radius: 1.25rem;
        padding: 1.75rem 1.5rem;
        box-shadow: 0 2px 8px rgba(26,22,37,0.04);
        transition: all 0.25s ease;
        display: flex;
        flex-direction: column;
        animation: pc-fade-up 0.4s ease both;
      }
      .pc-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 28px rgba(26,22,37,0.09);
        border-color: rgba(124,58,237,0.15);
      }
      .pc-card--popular {
        border-color: rgba(124,58,237,0.2);
        box-shadow: 0 4px 16px rgba(124,58,237,0.1);
      }
      .pc-popular-badge {
        position: absolute;
        top: -10px;
        right: 1.25rem;
        padding: 0.25rem 0.75rem;
        font-size: 0.6rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #fff;
        background: linear-gradient(135deg, #7c3aed, #a855f7);
        border-radius: 999px;
      }
      .pc-plan-name {
        font-size: 0.78rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #7c3aed;
        margin-bottom: 0.5rem;
      }
      .pc-price {
        font-family: var(--font-heading), sans-serif;
        font-size: 2.25rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        line-height: 1.1;
        margin-bottom: 0.25rem;
      }
      .pc-price-period {
        font-size: 0.8rem;
        font-weight: 400;
        color: #8b7fa8;
      }
      .pc-divider {
        height: 1px;
        background: rgba(124,58,237,0.06);
        margin: 1.25rem 0;
      }
      .pc-features {
        list-style: none;
        padding: 0;
        margin: 0 0 1.5rem;
        display: flex;
        flex-direction: column;
        gap: 0.6rem;
        flex: 1;
      }
      .pc-feature {
        display: flex;
        align-items: flex-start;
        gap: 0.5rem;
        font-size: 0.8rem;
        color: #4b4466;
        line-height: 1.5;
      }
      .pc-check {
        width: 16px;
        height: 16px;
        flex-shrink: 0;
        color: #10b981;
        margin-top: 1px;
      }
      .pc-cta {
        width: 100%;
        padding: 0.65rem;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 0.75rem;
        border: none;
        cursor: pointer;
        transition: all 0.18s ease;
        font-family: var(--font-body), sans-serif;
      }
      .pc-cta--primary {
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
      }
      .pc-cta--primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
      }
      .pc-cta--secondary {
        background: rgba(124,58,237,0.06);
        color: #7c3aed;
        border: 1.5px solid rgba(124,58,237,0.12);
      }
      .pc-cta--secondary:hover:not(:disabled) {
        background: rgba(124,58,237,0.1);
      }
      .pc-cta:disabled {
        opacity: 0.5;
        cursor: default;
      }
      .pc-current {
        text-align: center;
        font-size: 0.72rem;
        font-weight: 700;
        color: #10b981;
        margin-top: 0.5rem;
      }
      @keyframes pc-fade-up {
        from { opacity: 0; transform: translateY(14px); }
        to   { opacity: 1; transform: translateY(0); }
      }
    `}</ScopedStyle>
  )
}

export function PricingCard({ plan, popular, currentPlan, onSelect }: PricingCardProps) {
  const display = PLAN_DISPLAY[plan]
  const limits = PLAN_LIMITS[plan]
  const isCurrent = currentPlan === plan

  return (
    <>
      <PricingCardStyles />
      <div className={`pc-card ${popular ? 'pc-card--popular' : ''}`}>
        {popular && <span className="pc-popular-badge">Most Popular</span>}

        <div className="pc-plan-name">{display.name}</div>
        <div className="pc-price">
          {display.price.replace('/mo', '')}
          {plan !== 'free' && <span className="pc-price-period">/mo</span>}
        </div>

        <div className="pc-divider" />

        <ul className="pc-features">
          {limits.features.map((f) => (
            <li key={f} className="pc-feature">
              <svg className="pc-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <path d="M20 6L9 17l-5-5" />
              </svg>
              {f}
            </li>
          ))}
        </ul>

        {isCurrent ? (
          <div className="pc-current">Current plan</div>
        ) : (
          <button
            className={`pc-cta ${popular ? 'pc-cta--primary' : 'pc-cta--secondary'}`}
            onClick={() => onSelect?.(plan)}
          >
            {plan === 'free' ? 'Get started' : `Upgrade to ${display.name}`}
          </button>
        )}
      </div>
    </>
  )
}
