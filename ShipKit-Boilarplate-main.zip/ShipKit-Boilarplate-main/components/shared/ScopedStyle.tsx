'use client'

import { useNonce } from '@/lib/nonce'

/**
 * Renders a <style> tag with the current CSP nonce.
 * Use this instead of raw <style> tags to comply with nonce-based CSP.
 *
 * suppressHydrationWarning is required because browsers intentionally
 * clear nonce attributes from the DOM after applying them (security measure),
 * causing an expected mismatch during React hydration.
 */
export function ScopedStyle({ children }: { children: string }) {
  const nonce = useNonce()
  return <style nonce={nonce} suppressHydrationWarning>{children}</style>
}
