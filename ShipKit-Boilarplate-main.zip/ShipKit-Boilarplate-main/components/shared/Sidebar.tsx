'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useAppStore } from '@/stores/app-store'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

const navItems = [
  {
    label: 'Dashboard',
    href: '/dashboard',
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </svg>
    ),
  },
  {
    label: 'Organizations',
    href: '/dashboard/organizations',
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
  },
  {
    label: 'Settings',
    href: '/dashboard/settings',
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
      </svg>
    ),
  },
]

function SidebarStyles() {
  return (
    <ScopedStyle>{`
      .sb-root {
        position: sticky;
        top: 0;
        height: 100vh;
        overflow-y: auto;
        padding: 1.25rem 0.75rem;
        display: flex;
        flex-direction: column;
        background: #fff;
      }
      .sb-brand {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0 0.5rem 1.25rem;
        font-family: var(--font-heading), sans-serif;
        font-size: 1rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        text-decoration: none;
        border-bottom: 1px solid rgba(124,58,237,0.06);
        margin-bottom: 1rem;
      }
      .sb-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: linear-gradient(135deg, #7c3aed, #a855f7);
        flex-shrink: 0;
      }
      .sb-nav {
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
        flex: 1;
      }
      .sb-item {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        padding: 0.55rem 0.7rem;
        font-size: 0.8rem;
        font-weight: 600;
        color: #6b5f80;
        border-radius: 0.5rem;
        text-decoration: none;
        transition: all 0.15s ease;
        position: relative;
      }
      .sb-item:hover {
        color: #7c3aed;
        background: rgba(124,58,237,0.05);
      }
      .sb-item--active {
        color: #7c3aed;
        background: rgba(124,58,237,0.08);
        font-weight: 700;
      }
      .sb-item--active::before {
        content: '';
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 3px;
        height: 18px;
        border-radius: 0 3px 3px 0;
        background: linear-gradient(180deg, #7c3aed, #a855f7);
      }
      .sb-icon {
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: rgba(124,58,237,0.06);
        flex-shrink: 0;
      }
      .sb-item--active .sb-icon {
        background: rgba(124,58,237,0.12);
      }
      .sb-logout {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        padding: 0.55rem 0.7rem;
        font-size: 0.78rem;
        font-weight: 600;
        color: #ef4444;
        background: none;
        border: none;
        border-radius: 0.5rem;
        cursor: pointer;
        transition: all 0.15s ease;
        width: 100%;
        text-align: left;
        font-family: var(--font-body), sans-serif;
        border-top: 1px solid rgba(124,58,237,0.06);
        margin-top: 0.5rem;
        padding-top: 1rem;
      }
      .sb-logout:hover { background: rgba(239,68,68,0.06); }
      .sb-fab {
        display: none;
        position: fixed;
        bottom: 1.25rem;
        left: 1.25rem;
        z-index: 40;
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        color: #fff;
        border: none;
        box-shadow: 0 4px 16px rgba(124,58,237,0.35);
        cursor: pointer;
        align-items: center;
        justify-content: center;
      }
      .sb-backdrop {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 30;
        background: rgba(0,0,0,0.3);
      }
      @media (max-width: 768px) {
        .sb-fab { display: flex; }
        .sb-root {
          position: fixed;
          left: 0;
          top: 0;
          z-index: 35;
          width: 260px;
          transform: translateX(-100%);
          transition: transform 0.25s ease;
          border-right: 1px solid rgba(124,58,237,0.08);
        }
        .sb-root--open { transform: translateX(0); }
        .sb-backdrop--open { display: block; }
      }
    `}</ScopedStyle>
  )
}

export function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { sidebarOpen, setSidebarOpen } = useAppStore()
  const supabase = createClient()

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <>
      <SidebarStyles />

      <button
        className="sb-fab"
        onClick={() => setSidebarOpen(true)}
        aria-label="Open menu"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="6" x2="21" y2="6" />
          <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>

      <div
        className={`sb-backdrop ${sidebarOpen ? 'sb-backdrop--open' : ''}`}
        onClick={() => setSidebarOpen(false)}
      />

      <aside className={`sb-root ${sidebarOpen ? 'sb-root--open' : ''}`}>
        <Link href="/" className="sb-brand">
          <span className="sb-dot" />
          MySaaS
        </Link>

        <nav className="sb-nav">
          {navItems.map((item) => {
            const isActive = item.href === '/dashboard'
              ? pathname === '/dashboard'
              : pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`sb-item ${isActive ? 'sb-item--active' : ''}`}
                onClick={() => setSidebarOpen(false)}
              >
                <span className="sb-icon">{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        <button className="sb-logout" onClick={handleLogout}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </svg>
          Sign out
        </button>
      </aside>
    </>
  )
}
