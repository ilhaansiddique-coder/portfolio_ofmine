'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

interface NavbarClientProps {
  isAuthenticated: boolean
  profileInitial: string
}

function NavbarStyles() {
  return (
    <ScopedStyle>{`
      .nb-root {
        position: sticky;
        top: 0;
        z-index: 50;
        background: rgba(248,244,235,0.85);
        backdrop-filter: blur(14px);
        border-bottom: 1px solid rgba(124,58,237,0.06);
      }
      .nb-inner {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.7rem 1.25rem;
      }
      .nb-brand {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-family: var(--font-heading), sans-serif;
        font-size: 1.1rem;
        font-weight: 900;
        color: #1a1625;
        letter-spacing: -0.03em;
        text-decoration: none;
      }
      .nb-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: linear-gradient(135deg, #7c3aed, #a855f7);
        flex-shrink: 0;
      }
      .nb-nav {
        display: flex;
        align-items: center;
        gap: 0.25rem;
      }
      .nb-link {
        padding: 0.4rem 0.85rem;
        font-size: 0.78rem;
        font-weight: 600;
        color: #6b5f80;
        border-radius: 999px;
        text-decoration: none;
        transition: all 0.15s ease;
      }
      .nb-link:hover {
        color: #7c3aed;
        background: rgba(124,58,237,0.06);
      }
      .nb-link--active {
        color: #7c3aed;
        background: rgba(124,58,237,0.08);
      }
      .nb-actions {
        display: flex;
        align-items: center;
        gap: 0.5rem;
      }
      .nb-btn-login {
        padding: 0.4rem 0.9rem;
        font-size: 0.78rem;
        font-weight: 700;
        color: #6b5f80;
        background: transparent;
        border: 1.5px solid rgba(124,58,237,0.12);
        border-radius: 0.5rem;
        cursor: pointer;
        transition: all 0.18s ease;
        text-decoration: none;
        font-family: var(--font-body), sans-serif;
      }
      .nb-btn-login:hover {
        border-color: rgba(124,58,237,0.25);
        color: #7c3aed;
      }
      .nb-btn-cta {
        padding: 0.4rem 0.9rem;
        font-size: 0.78rem;
        font-weight: 700;
        color: #fff;
        background: linear-gradient(135deg, #7c3aed, #6d28d9);
        border: none;
        border-radius: 0.5rem;
        cursor: pointer;
        transition: all 0.18s ease;
        box-shadow: 0 2px 8px rgba(124,58,237,0.25);
        text-decoration: none;
        font-family: var(--font-body), sans-serif;
      }
      .nb-btn-cta:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(124,58,237,0.35);
      }
      .nb-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: linear-gradient(135deg, #7c3aed, #a855f7);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.7rem;
        font-weight: 800;
        color: #fff;
        text-decoration: none;
      }
      @media (max-width: 640px) {
        .nb-nav { display: none; }
      }
    `}</ScopedStyle>
  )
}

export function NavbarClient({
  isAuthenticated,
  profileInitial,
}: NavbarClientProps) {
  const pathname = usePathname()
  const isDashboard = pathname?.startsWith('/dashboard')

  if (isDashboard) return null

  return (
    <>
      <NavbarStyles />
      <nav className="nb-root">
        <div className="nb-inner">
          <Link href="/" className="nb-brand">
            <span className="nb-dot" />
            MySaaS
          </Link>

          <div className="nb-nav">
            <Link
              href="/#features"
              className={`nb-link ${pathname === '/#features' ? 'nb-link--active' : ''}`}
            >
              Features
            </Link>
            <Link
              href="/#pricing"
              className={`nb-link ${pathname === '/#pricing' ? 'nb-link--active' : ''}`}
            >
              Pricing
            </Link>
          </div>

          <div className="nb-actions">
            {isAuthenticated ? (
              <Link href="/dashboard" className="nb-avatar">
                {profileInitial}
              </Link>
            ) : (
              <>
                <Link href="/login" className="nb-btn-login">
                  Sign in
                </Link>
                <Link href="/signup" className="nb-btn-cta">
                  Get started
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>
    </>
  )
}
