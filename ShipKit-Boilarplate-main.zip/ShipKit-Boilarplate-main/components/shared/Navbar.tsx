import { createClient } from '@/lib/supabase/server'
import { NavbarClient } from './NavbarClient'

export async function Navbar() {
  let isAuthenticated = false
  let profileInitial = '?'

  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    isAuthenticated = !!user
    profileInitial =
      user?.user_metadata?.full_name?.[0]?.toUpperCase() ??
      user?.email?.[0]?.toUpperCase() ??
      '?'
  } catch {
    // Supabase not available — render unauthenticated state
  }

  return (
    <NavbarClient
      isAuthenticated={isAuthenticated}
      profileInitial={profileInitial}
    />
  )
}
