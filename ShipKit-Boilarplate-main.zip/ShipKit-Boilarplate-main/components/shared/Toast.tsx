'use client'

import { useAppStore } from '@/stores/app-store'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

function ToastStyles() {
  return (
    <ScopedStyle>{`
      .ts-container {
        position: fixed;
        bottom: 1.5rem;
        right: 1rem;
        z-index: 60;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        pointer-events: none;
      }
      .ts-item {
        pointer-events: auto;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.65rem 1.1rem;
        font-size: 0.8rem;
        font-weight: 700;
        color: #1a1625;
        background: rgba(255,255,255,0.97);
        border: 1.5px solid rgba(124,58,237,0.12);
        border-radius: 0.875rem;
        box-shadow: 0 8px 32px rgba(26,22,37,0.14);
        backdrop-filter: blur(12px);
        animation: ts-toast-in 0.3s ease;
        font-family: var(--font-body), sans-serif;
      }
      .ts-icon {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
      }
      .ts-icon--success { color: #10b981; }
      .ts-icon--error { color: #ef4444; }
      .ts-icon--info { color: #7c3aed; }
      .ts-close {
        margin-left: 0.5rem;
        background: none;
        border: none;
        color: #a89bbe;
        cursor: pointer;
        padding: 0;
        display: flex;
        transition: color 0.15s ease;
      }
      .ts-close:hover { color: #6b5f80; }
      @keyframes ts-toast-in {
        from { opacity: 0; transform: translateY(10px) scale(0.96); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
      }
    `}</ScopedStyle>
  )
}

const icons = {
  success: (
    <svg className="ts-icon ts-icon--success" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  ),
  error: (
    <svg className="ts-icon ts-icon--error" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="15" y1="9" x2="9" y2="15" />
      <line x1="9" y1="9" x2="15" y2="15" />
    </svg>
  ),
  info: (
    <svg className="ts-icon ts-icon--info" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  ),
}

export function Toast() {
  const { toasts, removeToast } = useAppStore()

  if (toasts.length === 0) return null

  return (
    <>
      <ToastStyles />
      <div className="ts-container">
        {toasts.map((toast) => (
          <div key={toast.id} className="ts-item">
            {icons[toast.type]}
            {toast.message}
            <button className="ts-close" onClick={() => removeToast(toast.id)} aria-label="Dismiss">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
        ))}
      </div>
    </>
  )
}
