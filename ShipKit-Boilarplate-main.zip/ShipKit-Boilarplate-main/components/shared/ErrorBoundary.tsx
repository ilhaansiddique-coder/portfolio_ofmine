'use client'

import React from 'react'
import { ScopedStyle } from '@/components/shared/ScopedStyle'

interface Props {
  children: React.ReactNode
  fallback?: React.ReactNode
}

interface State {
  hasError: boolean
  error: Error | null
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback

      return (
        <>
          <ScopedStyle>{`
            .eb-root {
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              gap: 0.75rem;
              padding: 3.5rem 2rem;
              text-align: center;
              background: #fff;
              border-radius: 1.25rem;
              border: 1.5px dashed rgba(124,58,237,0.2);
              margin: 2rem auto;
              max-width: 480px;
            }
            .eb-icon {
              width: 60px;
              height: 60px;
              border-radius: 50%;
              background: linear-gradient(135deg, rgba(239,68,68,0.08), rgba(239,68,68,0.14));
              display: flex;
              align-items: center;
              justify-content: center;
              color: #ef4444;
            }
            .eb-title {
              font-size: 1rem;
              font-weight: 800;
              color: #1a1625;
              font-family: var(--font-heading), sans-serif;
            }
            .eb-msg {
              font-size: 0.8rem;
              color: #6b5f80;
              line-height: 1.55;
            }
            .eb-retry {
              margin-top: 0.5rem;
              padding: 0.5rem 1.1rem;
              font-size: 0.8rem;
              font-weight: 700;
              color: #fff;
              background: linear-gradient(135deg, #7c3aed, #6d28d9);
              border: none;
              border-radius: 0.75rem;
              cursor: pointer;
              box-shadow: 0 2px 8px rgba(124,58,237,0.25);
              transition: all 0.18s ease;
              font-family: var(--font-body), sans-serif;
            }
            .eb-retry:hover {
              transform: translateY(-1px);
              box-shadow: 0 4px 16px rgba(124,58,237,0.35);
            }
          `}</ScopedStyle>
          <div className="eb-root">
            <span className="eb-icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
            </span>
            <h2 className="eb-title">Something went wrong</h2>
            <p className="eb-msg">An unexpected error occurred. Please try again.</p>
            <button
              className="eb-retry"
              onClick={() => this.setState({ hasError: false, error: null })}
            >
              Try again
            </button>
          </div>
        </>
      )
    }

    return this.props.children
  }
}
