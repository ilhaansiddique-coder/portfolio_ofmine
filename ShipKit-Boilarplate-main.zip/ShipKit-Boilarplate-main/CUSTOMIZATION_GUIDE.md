# Customization Guide

Learn how to customize every aspect of this SaaS boilerplate to match your product vision.

---

## 🎨 Styling & Branding

### Colors

Update the color palette in [app/globals.css](app/globals.css):

```css
:root {
  --brand: #7c3aed;              /* Primary brand color */
  --brand-dark: #6d28d9;         /* Darker shade for gradients */
  --brand-hover: #5b21b6;        /* Hover state */
  --brand-deep: #4c1d95;         /* Deepest shade */
  --bg-page: #f8f4eb;            /* Page background */
  --bg-card: #fff;               /* Card background */
  --text-primary: #1a1625;       /* Headings */
  --text-secondary: #6b5f80;     /* Muted labels */
  --text-tertiary: #8b7fa8;      /* Subtitles */
  --text-quaternary: #a89bbe;    /* Light text */
  --text-body: #4b4466;          /* Body text */
}
```

Replace these hex values with your brand colors. All colors automatically cascade throughout the app.

### Fonts

Update fonts in [app/globals.css](app/globals.css):

```css
:root {
  --font-heading: 'Bricolage Grotesque', sans-serif;  /* Headings */
  --font-body: 'Source Sans 3', sans-serif;           /* Body text */
}
```

**To add custom Google Fonts:**

1. Import in [app/layout.tsx](app/layout.tsx):
```typescript
import { YOUR_FONT } from 'next/font/google'

const myFont = YOUR_FONT({
  subsets: ['latin'],
  display: 'swap',
})
```

2. Add to className:
```typescript
<html className={myFont.className}>
```

### Logo & Favicon

1. Replace [public/favicon.ico](public/favicon.ico) with your favicon
2. Update logo in [components/shared/Navbar.tsx](components/shared/Navbar.tsx) - look for `<Logo />`
3. Add your logo SVG to a new component `components/shared/Logo.tsx`

---

## 📦 App Settings

### App Name & URL

Update in [.env.example](.env.example) and deploy to [lib/env.ts](lib/env.ts):

```env
NEXT_PUBLIC_APP_NAME=Your Product Name
NEXT_PUBLIC_APP_URL=https://yourdomain.com
```

These variables are used throughout:
- Email templates
- Navbar branding
- Meta tags
- Legal page footers

### Plan Configuration

Customize plans in [lib/plans.ts](lib/plans.ts):

```typescript
export const PLAN_LIMITS: Record<PlanName, PlanLimits> = {
  free: {
    maxProjects: 1,
    maxStorageMb: 100,
    features: ['Basic features', 'Community support'],
  },
  basic: {
    maxProjects: 5,
    maxStorageMb: 1024,
    features: ['Everything in Free', 'Priority support', 'Custom branding'],
  },
  pro: {
    maxProjects: 'unlimited',
    maxStorageMb: 10240,
    features: ['Everything in Basic', 'Advanced analytics', 'Dedicated support'],
  },
}

export const PLAN_DISPLAY: Record<PlanName, { name: string; price: string }> = {
  free: { name: 'Free', price: '$0' },
  basic: { name: 'Basic', price: '$19/mo' },
  pro: { name: 'Pro', price: '$49/mo' },
}
```

Update:
- `maxProjects` - Storage/usage limits
- `features` - Feature list per plan
- `price` - Pricing display

**NOTE**: Actual payment amounts are controlled by your payment processor (LemonSqueezy/Stripe).

---

## 📧 Email Templates

Located in [lib/email.ts](lib/email.ts):

### Template Functions

```typescript
export function welcomeEmail(name: string): string {
  return `<h1>Welcome, ${name}!</h1>...`
}

export function passwordResetEmail(resetUrl: string): string {
  return `<a href="${resetUrl}">Reset your password</a>...`
}

export function invoiceEmail(invoiceUrl: string, amount: string): string {
  return `<p>Invoice for $${amount}</p>...`
}
```

**To customize:**

1. Edit the HTML template in the function
2. Update colors to match your brand (use CSS inline styles)
3. Keep `${variable}` placeholders for dynamic content
4. Test by triggering the email action (signup, password reset, etc.)

**To add new templates:**

```typescript
export function newTemplateEmail(data: SomeType): string {
  return `<html>
    <body style="font-family: var(--font-body)">
      <!-- Your HTML -->
    </body>
  </html>`
}
```

Then use it in the appropriate API route or worker.

---

## 📄 Legal Pages

Located in `app/(legal)/`:

### Terms of Service

Update [app/(legal)/terms/page.tsx](app/%28legal%29/terms/page.tsx):

```typescript
export default function TermsPage() {
  return (
    <article>
      <h1>Terms of Service</h1>
      <section>
        <h2>1. User Accounts</h2>
        <p>You are responsible for maintaining account security...</p>
      </section>
      {/* Add your sections */}
    </article>
  )
}
```

**Key sections to customize:**
- Company name, address, contact
- Service description
- Usage restrictions
- Payment terms
- Warranty disclaimers
- Limitation of liability
- Governing law

### Privacy Policy

Update [app/(legal)/privacy/page.tsx](app/%28legal%29/privacy/page.tsx):

Similar structure. Key sections:
- Data collection practices
- How data is used
- Third-party services (Supabase, AWS, etc.)
- User rights (GDPR, CCPA)
- Data retention
- Contact for privacy inquiries

---

## 🔐 Security Settings

### Rate Limiting

Configure per endpoint in [lib/with-error-handler.ts](lib/with-error-handler.ts):

```typescript
export const POST = withErrorHandler(
  async (req) => { /* ... */ },
  { 
    rateLimit: { 
      limit: 10,           // Requests allowed
      windowSeconds: 60    // Per time window
    } 
  }
)
```

Adjust based on your use case:
- **Auth endpoints**: `{ limit: 5, windowSeconds: 60 }` (strict)
- **Read endpoints**: `{ limit: 100, windowSeconds: 60 }` (relaxed)
- **Checkout**: `{ limit: 3, windowSeconds: 60 }` (strict)

### CORS Origins

Update [middleware.ts](middleware.ts):

```env
CORS_ALLOWED_ORIGINS=https://yourdomain.com,https://api.partner.com
```

Add comma-separated list of allowed origins for API calls from other domains.

### CSP (Content Security Policy)

Located in [middleware.ts](middleware.ts) - the `buildCsp()` function:

```typescript
"connect-src 'self' https://*.supabase.co https://api.stripe.com https://api.yourdomain.com"
```

Add origins for:
- External APIs you call
- Analytics/monitoring services
- CDN domains

---

## 🔄 API Endpoints

### Adding a New Endpoint

**1. Create the route file:**

```typescript
// app/api/custom/action/route.ts
import { withErrorHandler } from '@/lib/with-error-handler'
import { ok, err } from '@/lib/api-response'
import { validateBody } from '@/lib/validate'
import { z } from 'zod'

const schema = z.object({
  userId: z.string().uuid(),
  action: z.string().min(1),
})

export const POST = withErrorHandler(
  async (req) => {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) return err('Unauthorized', 401)

    const body = await req.json()
    const validation = validateBody(schema, body)
    if (!validation.success) return validation.response

    const { userId, action } = validation.data

    // Your logic here

    return ok({ success: true })
  },
  { 
    rateLimit: { limit: 30, windowSeconds: 60 },
    csrf: true  // Require CSRF token for mutations
  }
)
```

**2. Use in frontend:**

```typescript
const response = await fetch('/api/custom/action', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-csrf-token': csrfToken,
  },
  credentials: 'include',
  body: JSON.stringify({ userId: '...', action: '...' }),
})
```

---

## 💾 Database Changes

### Adding a New Table

**1. Create migration:**

```bash
npm run db:migrate -- create_my_table
```

**2. Edit migration file in `supabase/migrations/`:**

```sql
-- Enable RLS
CREATE TABLE my_table (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  data JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE my_table ENABLE ROW LEVEL SECURITY;

-- Policies (isolate by user)
CREATE POLICY "Users can view own data" ON my_table
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own data" ON my_table
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Index for performance
CREATE INDEX my_table_user_id_idx ON my_table(user_id);
```

**3. Push to database:**

```bash
npm run db:push
```

**4. Generate TypeScript types:**

```bash
npm run db:types
```

---

## 🎯 Dashboard Pages

### Custom Dashboard Stats

Edit [app/api/dashboard/stats/route.ts](app/api/dashboard/stats/route.ts):

```typescript
// Add your custom metrics
const customMetric = await supabase
  .from('your_table')
  .select('COUNT(*)')
  .eq('user_id', user.id)

return ok({
  projectCount: 42,
  storageUsedMb: 256,
  customMetric: customMetric.count,
})
```

Then display in [app/(dashboard)/dashboard/page.tsx](app/%28dashboard%29/dashboard/page.tsx).

---

## 🛠️ Workers & Background Jobs

### Email Worker

Located in [workers/email.worker.ts](workers/email.worker.ts):

```typescript
worker.process(async (job) => {
  const { to, subject, html } = job.data
  await sendEmail({ to, subject, html })
})
```

Add more email jobs by enqueueing from API routes:

```typescript
await emailQueue.add('send-email', {
  to: 'user@example.com',
  subject: 'Hello',
  html: '<p>Hello there</p>',
})
```

### Creating New Workers

**1. Create worker file:**

```typescript
// workers/custom.worker.ts
import { Worker } from 'bullmq'
import { redis } from '@/lib/redis'

const myQueue = new Queue('my-queue', { connection: redis })

myQueue.process(async (job) => {
  console.log('Processing job', job.id, job.data)
  // Your logic
})

export default myQueue
```

**2. Add to workers script in `package.json`:**

```json
"worker:custom": "tsx workers/custom.worker.ts"
```

**3. Run all workers:**

```bash
npm run workers
```

---

## 🧪 Testing Your Changes

### Unit Tests

```bash
npm run test
npm run test:watch  # Watch mode
npm run test:coverage
```

### E2E Tests

```bash
npm run test:e2e
npm run test:e2e:ui  # Visual mode
```

### Type Checking

```bash
npm run typecheck
npm run lint
```

---

## 📋 Common Customization Checklist

- [ ] Update brand colors in `app/globals.css`
- [ ] Update fonts in `app/globals.css`
- [ ] Add your logo to `public/` and update `Navbar.tsx`
- [ ] Update plan limits in `lib/plans.ts`
- [ ] Customize email templates in `lib/email.ts`
- [ ] Update Terms of Service in `app/(legal)/terms/page.tsx`
- [ ] Update Privacy Policy in `app/(legal)/privacy/page.tsx`
- [ ] Set `NEXT_PUBLIC_APP_NAME` and `NEXT_PUBLIC_APP_URL` env vars
- [ ] Configure payment processor (LemonSqueezy/Stripe)
- [ ] Set up AWS SES for emails
- [ ] Test login, signup, payment, and email flows
- [ ] Run full test suite: `npm run test && npm run test:e2e`

---

## 🆘 Need Help?

See [TROUBLESHOOTING_GUIDE.md](TROUBLESHOOTING_GUIDE.md) for common issues and solutions.

See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for complete API reference.
