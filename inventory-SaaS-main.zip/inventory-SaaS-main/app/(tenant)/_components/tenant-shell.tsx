"use client";

import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import Link from "next/link";
import { NavLink } from "./nav-link";
import { NewSaleDialog } from "./new-sale-dialog";
import { NotificationBell } from "./notification-bell";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { OptimisticNavProvider, useOptimisticNav } from "./optimistic-nav";
import type { NotificationItem } from "@/lib/services/notifications.service";
import {
  Home,
  Package,
  Warehouse,
  ShoppingCart,
  PackageCheck,
  Users,
  FileText,
  BarChart3,
  Bell,
  Settings,
  LogOut,
  Shield,
  PanelLeft,
  Sun,
  Moon,
  ArrowUp,
  Building2,
  ChevronDown,
  List,
  Inbox,
  CheckCircle2,
  XCircle,
  Plus,
  UserCog,
  CalendarClock,
  CalendarDays,
  Wallet,
  Target,
  UserPlus,
  GraduationCap,
  FolderLock,
  ClipboardCheck,
  User,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarSeparator,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { DateRangePicker } from "../dashboard/_components/date-range-picker";
import { ProductsHeaderControls } from "../products/_components/products-header-controls";
import { InvoicesHeaderControls } from "../invoices/_components/invoices-header-controls";
import { InvoicesExportButton } from "../invoices/_components/invoices-export-button";
import { ProductsActionsCluster } from "../products/_components/products-actions-cluster";
import { InventoryHeaderControls } from "../inventory/_components/inventory-header-controls";
import { SalesHeaderControls } from "../sales/_components/sales-header-controls";
import { SalesCancelledToggle } from "../sales/_components/sales-cancelled-toggle";
import { ReportsHeaderControls } from "../reports/_components/reports-header-controls";
import { ReportsExportButton } from "../reports/_components/reports-export-button";
import { CustomersHeaderControls } from "../customers/_components/customers-header-controls";
import { CustomersActionsCluster } from "../customers/_components/customers-actions-cluster";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  applyThemeToDocument,
  getStoredTheme,
  resolveTheme,
  setStoredTheme,
  type DaisyThemeName,
} from "@/lib/utils";

const menuItems = [
  { title: "Dashboard", url: "/dashboard", icon: Home },
  { title: "Products", url: "/products", icon: Package },
  { title: "Inventory", url: "/inventory", icon: Warehouse },
  { title: "Sales", url: "/sales", icon: ShoppingCart },
  { title: "Packaging", url: "/packaging", icon: PackageCheck },
  { title: "Customers", url: "/customers", icon: Users },
  { title: "Invoices", url: "/invoices", icon: FileText },
  { title: "Reports", url: "/reports", icon: BarChart3 },
  { title: "Alerts", url: "/alerts", icon: Bell },
];

// Mobile bottom-nav entries — shown to every authenticated tenant user
// regardless of role. Order below matches the spec the user provided
// (deduplicated across the three reference screenshots). Admin gets
// appended for owner / admin / superadmin roles below.
const baseBottomNavItems = [
  { label: "Dashboard", to: "/dashboard", icon: Home },
  { label: "Products", to: "/products", icon: Package },
  { label: "Inventory", to: "/inventory", icon: Warehouse },
  { label: "Sales", to: "/sales", icon: ShoppingCart },
  { label: "Packaging", to: "/packaging", icon: PackageCheck },
  { label: "Customers", to: "/customers", icon: Users },
  { label: "Reports", to: "/reports", icon: BarChart3 },
  { label: "Invoices", to: "/invoices", icon: FileText },
  { label: "Alerts", to: "/alerts", icon: Bell },
  { label: "Profile", to: "/profile", icon: User },
  { label: "Settings", to: "/settings", icon: Settings },
];

export function TenantShell({
  businessName,
  userId,
  userName,
  userEmail,
  role,
  isSuperAdmin,
  pendingTenantCount,
  notifications,
  sidebarDefaultOpen,
  children,
}: {
  businessName: string;
  userId: string;
  userName: string;
  userEmail: string;
  role: string | null;
  isSuperAdmin: boolean;
  pendingTenantCount: number;
  notifications: NotificationItem[];
  sidebarDefaultOpen: boolean;
  children: ReactNode;
}) {
  return (
    <OptimisticNavProvider>
      <SidebarProvider
        persistKey={`sidebar:state:${userId}`}
        defaultOpen={sidebarDefaultOpen}
      >
        <div className="flex min-h-screen w-full">
          <AppSidebar
            businessName={businessName}
            role={role}
            isSuperAdmin={isSuperAdmin}
            pendingTenantCount={pendingTenantCount}
          />
          <div className="flex-1 flex flex-col min-w-0 bg-card">
            <TopBar
              userName={userName}
              userEmail={userEmail}
              role={role}
              notifications={notifications}
            />
            <main className="flex-1 p-4 nav-mb-safe lg:p-6 min-w-0">{children}</main>
          </div>
        </div>

        <MobileBottomNav role={role} isSuperAdmin={isSuperAdmin} />
      </SidebarProvider>
    </OptimisticNavProvider>
  );
}

function AppSidebar({
  businessName,
  role,
  isSuperAdmin,
  pendingTenantCount,
}: {
  businessName: string;
  role: string | null;
  isSuperAdmin: boolean;
  pendingTenantCount: number;
}) {
  const { state, toggleSidebar } = useSidebar();
  const { activePath: pathname } = useOptimisticNav();
  const isCollapsed = state === "collapsed";

  const isAdmin = role === "owner" || role === "admin" || role === "superadmin";
  const isRouteActive = (path: string) =>
    pathname === path || pathname.startsWith(`${path}/`);
  const isInTenantsAdmin = pathname.startsWith("/tenants");
  const [tenantsOpen, setTenantsOpen] = useState(isInTenantsAdmin);
  const isInHr = pathname.startsWith("/hr");
  const [hrOpen, setHrOpen] = useState(isInHr);

  const navClass = (active: boolean) =>
    active
      ? "bg-primary text-primary-foreground shadow-sm"
      : "text-sidebar-foreground/80 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground";

  return (
    <Sidebar
      data-lenis-prevent
      className="border-r border-sidebar-border/70 bg-sidebar/95"
      collapsible="icon"
    >
      <SidebarHeader className="px-3 py-3 group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-3">
        <div className="flex items-center gap-2.5 group-data-[collapsible=icon]:justify-center">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold">
            {businessName.charAt(0).toUpperCase()}
          </div>
          {!isCollapsed && (
            <div className="leading-tight min-w-0">
              <p className="text-[1rem] font-semibold text-sidebar-foreground leading-tight truncate">
                {businessName}
              </p>
              <p className="text-[11px] text-muted-foreground">Workspace</p>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarSeparator className="mb-2" />

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
            {!isCollapsed && "Menu"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isRouteActive(item.url)}
                    tooltip={isCollapsed ? item.title : undefined}
                    className={navClass(isRouteActive(item.url))}
                  >
                    <NavLink href={item.url}>
                      <span className="flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium transition-colors">
                        <item.icon className="h-[18px] w-[18px] flex-shrink-0" />
                        {!isCollapsed && <span>{item.title}</span>}
                      </span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}

              {/* HR Module — collapsible */}
              <Collapsible open={hrOpen} onOpenChange={setHrOpen}>
                <SidebarMenuItem>
                  <CollapsibleTrigger asChild>
                    <SidebarMenuButton
                      isActive={isInHr}
                      tooltip={isCollapsed ? "HR" : undefined}
                      className={navClass(isInHr)}
                    >
                      <span className="flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium w-full">
                        <UserCog className="h-[18px] w-[18px] flex-shrink-0" />
                        {!isCollapsed && (
                          <>
                            <span>HR</span>
                            <ChevronDown
                              className={`h-4 w-4 ml-auto transition-transform ${
                                hrOpen ? "rotate-180" : ""
                              }`}
                            />
                          </>
                        )}
                      </span>
                    </SidebarMenuButton>
                  </CollapsibleTrigger>
                  {!isCollapsed && (
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        <TenantSubLink href="/hr" icon={<Home className="h-4 w-4" />} label="Overview" active={pathname === "/hr"} />
                        <TenantSubLink href="/hr/employees" icon={<Users className="h-4 w-4" />} label="Employees" active={pathname.startsWith("/hr/employees")} />
                        <TenantSubLink href="/hr/departments" icon={<Building2 className="h-4 w-4" />} label="Departments" active={pathname.startsWith("/hr/departments")} />
                        <TenantSubLink href="/hr/positions" icon={<ClipboardCheck className="h-4 w-4" />} label="Positions" active={pathname.startsWith("/hr/positions")} />
                        <TenantSubLink href="/hr/attendance" icon={<CalendarClock className="h-4 w-4" />} label="Attendance" active={pathname.startsWith("/hr/attendance")} />
                        <TenantSubLink href="/hr/leave" icon={<CalendarDays className="h-4 w-4" />} label="Leave" active={pathname.startsWith("/hr/leave")} />
                        <TenantSubLink href="/hr/payroll" icon={<Wallet className="h-4 w-4" />} label="Payroll" active={pathname.startsWith("/hr/payroll")} />
                        <TenantSubLink href="/hr/performance" icon={<Target className="h-4 w-4" />} label="Performance" active={pathname.startsWith("/hr/performance")} />
                        <TenantSubLink href="/hr/recruitment" icon={<UserPlus className="h-4 w-4" />} label="Recruitment" active={pathname.startsWith("/hr/recruitment")} />
                        <TenantSubLink href="/hr/learning" icon={<GraduationCap className="h-4 w-4" />} label="Learning" active={pathname.startsWith("/hr/learning")} />
                        <TenantSubLink href="/hr/documents" icon={<FolderLock className="h-4 w-4" />} label="Documents" active={pathname.startsWith("/hr/documents")} />
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  )}
                </SidebarMenuItem>
              </Collapsible>

              {/* SUPER ADMIN ONLY: Tenants management */}
              {isSuperAdmin && (
                <Collapsible open={tenantsOpen} onOpenChange={setTenantsOpen}>
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton
                        isActive={isInTenantsAdmin}
                        tooltip={isCollapsed ? "Tenants" : undefined}
                        className={navClass(isInTenantsAdmin)}
                      >
                        <span className="flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium w-full">
                          <Building2 className="h-[18px] w-[18px] flex-shrink-0" />
                          {!isCollapsed && (
                            <>
                              <span>Tenants</span>
                              {pendingTenantCount > 0 && (
                                <Badge variant="default" className="ml-auto h-5 px-1.5 text-[10px]">
                                  {pendingTenantCount}
                                </Badge>
                              )}
                              <ChevronDown
                                className={`h-4 w-4 transition-transform ${
                                  tenantsOpen ? "rotate-180" : ""
                                } ${pendingTenantCount > 0 ? "" : "ml-auto"}`}
                              />
                            </>
                          )}
                        </span>
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    {!isCollapsed && (
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          <TenantSubLink
                            href="/tenants"
                            icon={<List className="h-4 w-4" />}
                            label="All Tenants"
                            active={pathname === "/tenants"}
                          />
                          <TenantSubLink
                            href="/tenants/requests"
                            icon={<Inbox className="h-4 w-4" />}
                            label="Requests"
                            active={pathname === "/tenants/requests"}
                            badge={pendingTenantCount > 0 ? pendingTenantCount : undefined}
                          />
                          <TenantSubLink
                            href="/tenants/approved"
                            icon={<CheckCircle2 className="h-4 w-4" />}
                            label="Approved"
                            active={pathname === "/tenants/approved"}
                          />
                          <TenantSubLink
                            href="/tenants/declined"
                            icon={<XCircle className="h-4 w-4" />}
                            label="Declined"
                            active={pathname === "/tenants/declined"}
                          />
                          <TenantSubLink
                            href="/tenants/create"
                            icon={<Plus className="h-4 w-4" />}
                            label="Create Tenant"
                            active={pathname === "/tenants/create"}
                          />
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    )}
                  </SidebarMenuItem>
                </Collapsible>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-auto">
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  isActive={isRouteActive("/settings")}
                  tooltip={isCollapsed ? "Settings" : undefined}
                  className={navClass(isRouteActive("/settings"))}
                >
                  <NavLink href="/settings">
                    <span className="flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium">
                      <Settings className="h-[18px] w-[18px]" />
                      {!isCollapsed && <span>Settings</span>}
                    </span>
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
              {isAdmin && (
                <SidebarMenuItem>
                  <SidebarMenuButton
                    asChild
                    isActive={isRouteActive("/admin")}
                    tooltip={isCollapsed ? "Administration" : undefined}
                    className={navClass(isRouteActive("/admin"))}
                  >
                    <NavLink href="/admin">
                      <span className="flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium">
                        <Shield className="h-[18px] w-[18px]" />
                        {!isCollapsed && <span>Administration</span>}
                      </span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={toggleSidebar}
              tooltip={isCollapsed ? "Expand sidebar" : undefined}
              className="flex items-center gap-3 rounded-md px-3 py-2"
            >
              <PanelLeft className="h-5 w-5 flex-shrink-0" />
              {!isCollapsed && <span>Collapse</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

// ─── TopBar ─────────────────────────────────────────────────
// Global header above page content. Shows on every tenant page.
// Holds the user-account controls that used to live in the
// SidebarFooter: theme picker, identity pill, sign-out button.
function TopBar({
  userName,
  userEmail,
  role,
  notifications,
}: {
  userName: string;
  userEmail: string;
  role: string | null;
  notifications: NotificationItem[];
}) {
  const roleLabel = formatRole(role);
  const [selectedTheme, setSelectedTheme] = useState<DaisyThemeName>("light");

  useEffect(() => {
    setSelectedTheme(resolveTheme(getStoredTheme()));
  }, []);

  const handleThemeChange = (name: DaisyThemeName) => {
    setSelectedTheme(name);
    applyThemeToDocument(name);
    setStoredTheme(name);
  };

  const initials = userName
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();

  // Show page-specific controls in the TopBar's left slot:
  //   /dashboard → DateRangePicker
  //   /products  → search input + stock filter (URL-synced with ProductList)
  //   /inventory → search input + stock filter (URL-synced with InventoryFilter)
  // Right cluster on /products and /inventory: Import / Export / Adjust Stock.
  const { activePath } = useOptimisticNav();
  const isDashboard = activePath === "/dashboard";
  const isProducts =
    activePath === "/products" || activePath.startsWith("/products/");
  const isInventory =
    activePath === "/inventory" || activePath.startsWith("/inventory/");
  const isSales =
    activePath === "/sales" || activePath.startsWith("/sales/");
  const isInvoices =
    activePath === "/invoices" || activePath.startsWith("/invoices/");
  const isReports =
    activePath === "/reports" || activePath.startsWith("/reports/");
  const isCustomers =
    activePath === "/customers" || activePath.startsWith("/customers/");
  // /products and /inventory share the same right-side actions cluster
  // (Import, Export, Adjust Stock). Both pages care about the same product
  // operations.
  const showProductActions = isProducts || isInventory;

  // Cart icon in the TopBar opens the New Sale dialog rather than
  // navigating to /sales. The dialog is rendered alongside the header
  // so the Tooltip+Button composition stays clean.
  const [newSaleOpen, setNewSaleOpen] = useState(false);

  return (
    <TooltipProvider delayDuration={150}>
      <header className="sticky top-0 z-30 hidden lg:flex items-center gap-1.5 border-b border-border/60 bg-card/80 px-4 py-3 backdrop-blur lg:px-6">
        {/* Left — page-specific controls. Hidden on mobile because each
            page renders its own mobile header below.
              /dashboard → DateRangePicker
              /products  → ProductsHeaderControls (search + stock filter) */}
        <div className="flex flex-1 items-center justify-start">
          {isDashboard && (
            <div className="hidden lg:block">
              <DateRangePicker />
            </div>
          )}
          {isProducts && (
            <div className="hidden lg:block">
              <ProductsHeaderControls />
            </div>
          )}
          {isInventory && (
            <div className="hidden lg:block">
              <InventoryHeaderControls />
            </div>
          )}
          {isSales && (
            <div className="hidden lg:block">
              <SalesHeaderControls />
            </div>
          )}
          {isInvoices && (
            <div className="hidden lg:block">
              <InvoicesHeaderControls />
            </div>
          )}
          {isReports && (
            <div className="hidden lg:block">
              <ReportsHeaderControls />
            </div>
          )}
          {isCustomers && (
            <div className="hidden lg:block">
              <CustomersHeaderControls />
            </div>
          )}
        </div>

        {/* Notifications bell — opens a dropdown of recent activity */}
        <NotificationBell notifications={notifications} />

        {/* Invoices export — popover with CSV / PDF options. Sits in
            the right cluster (after the bell) per the page convention,
            so its icon spacing matches the bell + new-sale + theme +
            user buttons that follow. */}
        {isInvoices && (
          <div className="hidden lg:block">
            <InvoicesExportButton />
          </div>
        )}

        {/* Reports export — Excel download of the current filtered view.
            Sits alongside InvoicesExportButton in the right cluster so
            both pages keep the same icon ordering. */}
        {isReports && (
          <div className="hidden lg:block">
            <ReportsExportButton />
          </div>
        )}

        {/* Cancelled-rows toggle — only meaningful on /sales, sits
            between the bell and the New Sale (+) button. URL-synced
            with the in-page sales list via the `cancelled` query param. */}
        {isSales && (
          <div className="hidden lg:block">
            <SalesCancelledToggle />
          </div>
        )}

        {/* Customers actions cluster — Export / Import / Refresh / +.
            The `+` here adds a customer (via ?action=add URL flag),
            replacing the generic New Sale shortcut on this page. */}
        {isCustomers && (
          <div className="hidden lg:block">
            <CustomersActionsCluster />
          </div>
        )}

        {/* Page-aware action cluster:
              /products & /inventory → Import / Export / Adjust Stock
              /reports*              → none (reports are read-only;
                                       the New Sale shortcut is noise
                                       for an analytics surface)
              /customers             → none (CustomersActionsCluster
                                       above provides + Add Customer)
              Elsewhere              → New Sale (cart)
            Reports / Customers / Add-Product shortcuts were removed —
            those destinations are reachable from the sidebar, and the
            global TopBar should stay focused on the current page. */}
        {showProductActions ? (
          <ProductsActionsCluster />
        ) : isReports || isCustomers ? null : (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setNewSaleOpen(true)}
                className="h-9 w-9 rounded-lg border-border/60 bg-background/80"
                aria-label="New Sale"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">New Sale</TooltipContent>
          </Tooltip>
        )}

        {/* Theme toggle — single click flips between Light ("light")
            and Dark ("night"). Sun icon shown while in dark mode (a
            click brings the sun back), Moon shown while in light mode
            (a click summons night). Replaces the previous HoverCard
            picker. */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              aria-label={
                selectedTheme === "night"
                  ? "Switch to light theme"
                  : "Switch to dark theme"
              }
              onClick={() =>
                handleThemeChange(
                  selectedTheme === "night" ? "light" : "night"
                )
              }
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-border/60 bg-background/80 text-foreground transition-colors hover:bg-muted"
            >
              {selectedTheme === "night" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom">
            {selectedTheme === "night" ? "Light mode" : "Dark mode"}
          </TooltipContent>
        </Tooltip>

        {/* User identity pill — clicking it opens the profile page.
            Name + role on top, email kept on hover via title attribute. */}
        <Link
          href="/profile"
          title={userEmail}
          className="flex items-center gap-2 rounded-lg border border-border/60 bg-background/80 px-2.5 py-1 shadow-sm transition-colors hover:bg-muted"
        >
          <Avatar className="h-7 w-7 border border-border/60">
            <AvatarFallback className="text-[10px]">{initials}</AvatarFallback>
          </Avatar>
          <div className="hidden min-w-0 leading-tight lg:block">
            <p className="truncate text-xs font-medium">{userName}</p>
            {roleLabel && (
              <p className="truncate text-[10px] text-muted-foreground">
                {roleLabel}
              </p>
            )}
          </div>
        </Link>

        {/* Sign out — icon-only on md+, icon + label on mobile. */}
        <button
          type="button"
          onClick={() => signOut({ callbackUrl: "/login" })}
          aria-label="Sign Out"
          title="Sign Out"
          className="flex h-9 items-center gap-2 rounded-lg border border-border/60 bg-background/80 px-3 text-sm text-foreground transition-colors hover:bg-muted lg:w-9 lg:justify-center lg:px-0"
        >
          <LogOut className="h-4 w-4" />
          <span className="lg:hidden">Sign Out</span>
        </button>
      </header>

      {/* New Sale dialog — controlled by the cart icon in the header */}
      <NewSaleDialog open={newSaleOpen} onOpenChange={setNewSaleOpen} />

    </TooltipProvider>
  );
}

// Format a role string for display under the user's name in the TopBar.
//   "superadmin" → "Super Admin"
//   "owner"      → "Owner"
//   null / ""    → null  (caller skips rendering)
function formatRole(role: string | null): string | null {
  if (!role) return null;
  if (role === "superadmin") return "Super Admin";
  return role.charAt(0).toUpperCase() + role.slice(1);
}


function MobileBottomNav({
  role,
  isSuperAdmin,
}: {
  role: string | null;
  isSuperAdmin: boolean;
}) {
  const { activePath: pathname } = useOptimisticNav();
  const [show, setShow] = useState(true);

  // Build the visible nav set per role:
  //   - everyone: Dashboard, Products, Sales, Customers, Reports
  //   - super admin: + Tenants (cross-tenant management)
  //   - any admin (owner / admin / super admin): + Admin
  // (Tenants is intentionally NOT in the mobile bar per the spec —
  //  super admins reach it via the desktop sidebar.)
  const isAdmin =
    role === "owner" || role === "admin" || role === "superadmin" || isSuperAdmin;
  const items = [
    ...baseBottomNavItems,
    ...(isAdmin ? [{ label: "Admin", to: "/admin", icon: Shield }] : []),
  ];

  useEffect(() => {
    let lastY = window.scrollY;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        const delta = y - lastY;
        if (y <= 0) setShow(true);
        else if (delta > 10) setShow(false);
        else if (delta < -10) setShow(true);
        lastY = y;
        ticking = false;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-40 lg:hidden transition-transform duration-200 gpu pb-safe ${
        show ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <nav className="flex items-center gap-2 overflow-x-auto border-t border-border/70 bg-card px-3 py-1.5 shadow-[0_-6px_20px_-16px_rgba(0,0,0,0.4)] scrollbar-hide">
        {items.map(({ label, to, icon: Icon }) => {
          const active = pathname === to || pathname.startsWith(`${to}/`);
          return (
            <NavLink
              key={to}
              href={to}
              className={`flex min-w-[64px] flex-col items-center gap-0.5 rounded-md px-2 py-1 text-[10px] font-medium transition-colors flex-shrink-0 ${
                active
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="truncate max-w-full">{label}</span>
            </NavLink>
          );
        })}
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="flex min-w-[64px] flex-col items-center gap-0.5 rounded-md px-2 py-1 text-[10px] font-medium text-muted-foreground hover:text-foreground flex-shrink-0"
        >
          <ArrowUp className="h-5 w-5" />
          <span>Top</span>
        </button>
      </nav>
    </div>
  );
}

function TenantSubLink({
  href,
  icon,
  label,
  active,
  badge,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
  badge?: number;
}) {
  return (
    <SidebarMenuSubItem>
      <SidebarMenuSubButton
        asChild
        isActive={active}
        className={
          active
            ? "bg-primary/15 text-primary font-medium"
            : "text-sidebar-foreground/70 hover:bg-sidebar-accent/70"
        }
      >
        <NavLink href={href}>
          <span className="flex items-center gap-2 w-full">
            {icon}
            <span>{label}</span>
            {badge !== undefined && badge > 0 && (
              <Badge variant="default" className="ml-auto h-5 px-1.5 text-[10px]">
                {badge}
              </Badge>
            )}
          </span>
        </NavLink>
      </SidebarMenuSubButton>
    </SidebarMenuSubItem>
  );
}
