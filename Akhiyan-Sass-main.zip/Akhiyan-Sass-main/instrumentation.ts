/**
 * Server + edge runtime instrumentation entry point.
 * Next.js calls register() once per worker boot.
 *
 * We send errors to GlitchTip (self-hosted, Sentry-protocol compatible).
 * Set GLITCHTIP_DSN in .env — when empty the SDK becomes a no-op so dev
 * never spams the production tracker.
 */
import * as Sentry from "@sentry/nextjs";

export async function register() {
  const dsn = process.env.GLITCHTIP_DSN || process.env.NEXT_PUBLIC_SENTRY_DSN || "";
  if (!dsn) return;

  if (process.env.NEXT_RUNTIME === "nodejs") {
    Sentry.init({
      dsn,
      // GlitchTip recommends keeping tracesSampleRate low — error monitoring
      // doesn't need full APM. Bump if you wire performance traces later.
      tracesSampleRate: 0,
      environment: process.env.NODE_ENV,
      release: process.env.SENTRY_RELEASE || process.env.VERCEL_GIT_COMMIT_SHA,
      // Multi-tenant: tenant_slug + tenant_id tags are attached per request
      // by setTenantContext() in src/lib/prisma-tenant.ts.
      ignoreErrors: [
        // Next.js redirect/notFound() control-flow exceptions are not bugs.
        "NEXT_REDIRECT",
        "NEXT_NOT_FOUND",
      ],
    });
  }

  if (process.env.NEXT_RUNTIME === "edge") {
    Sentry.init({
      dsn,
      tracesSampleRate: 0,
      environment: process.env.NODE_ENV,
      release: process.env.SENTRY_RELEASE,
    });
  }
}

// Required for Next.js 15 to capture errors thrown in React Server Components.
export const onRequestError = Sentry.captureRequestError;
