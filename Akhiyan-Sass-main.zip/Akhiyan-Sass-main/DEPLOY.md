# Deployment — CD Ecom

**The only supported way to deploy is `npm run deploy` (which runs `./deploy.sh`).** Do not run individual `prisma migrate`, `npm run build`, or `pm2 restart` commands by hand — they will silently skip steps and break tenants.

---

## TL;DR — every deploy is one command

On the production server:

```bash
cd /path/to/app
npm run deploy
```

That script does everything in the correct order with the correct flags. If it exits non-zero, the deploy did not finish — investigate the printed error before retrying. The old PM2 workers keep serving traffic until the new build replaces them, so a failed deploy is **safe** (no downtime, no half-broken state).

---

## What `./deploy.sh` actually does

| # | Step | Why this step matters |
|---|---|---|
| 1 | `git pull --ff-only origin main` | Fail fast if local has uncommitted edits or non-fast-forward history |
| 2 | `npm ci --include=dev` | Deterministic install from `package-lock.json` — never `npm install` in prod |
| 3 | `npm run db:generate` | Regenerates BOTH Prisma clients (tenant + control) |
| 4 | `npm run db:migrate:control` | Migrates the control DB (superadmin, tenants, plans, audit) |
| 5 | `npm run db:migrate-all` | Migrates EVERY active tenant DB (parallel, advisory-locked, transactional, idempotent) |
| 6 | `next build` | Build runs AFTER migrations so new code can rely on new columns |
| 7 | `pm2 reload cd-ecom --update-env` | Zero-downtime reload (cluster mode) — in-flight requests finish on old workers |
| 8 | `curl $HEALTH_URL` | Post-deploy health check — non-2xx/3xx fails the deploy + dumps last 50 log lines |

If **any** step fails the script halts (`set -euo pipefail`). Steps 1–5 happen **before** the new build is live, so a migration failure can't take a tenant down — the old workers keep serving.

---

## Env vars `deploy.sh` reads

| Var | Default | Purpose |
|---|---|---|
| `HEALTH_URL` | `https://cdeadmin.contradigital.agency/superadmin/login` | Hit after PM2 reload — should return 2xx/3xx |
| `PM2_APP_NAME` | `cd-ecom` | PM2 process name from `ecosystem.config.js` |

Set them in `.bashrc` / systemd unit / wherever your deploy runs from if the defaults don't match.

---

## Schema-change workflow (the only deploy that's not "just push")

A tenant DB column change is the only thing that can break customers. **Read [MIGRATIONS.md](MIGRATIONS.md) before touching `prisma/schema.prisma`.**

Short version of what's allowed in one deploy:

| Change | Safe in one deploy? |
|---|---|
| Add nullable column | ✅ yes |
| Add column with DEFAULT | ✅ yes |
| Add new table | ✅ yes |
| Add new index | ✅ yes |
| Rename column | ❌ no — two deploys (add new → backfill → switch reads → drop old) |
| Drop column | ❌ no — two deploys (stop writing → drop in next release) |
| Change column type | ❌ no — two deploys with backfill |
| `NOT NULL` on existing nullable | ❌ no — two deploys (backfill default → enforce) |

---

## What NEVER to do

- ❌ `prisma migrate deploy` by hand — only migrates the DB pointed to by `DATABASE_URL`, ignores tenant DBs.
- ❌ `npm run build` then `pm2 restart` without migrating — new code hits old DBs and 500s tenant-wide.
- ❌ `pm2 restart` (use `pm2 reload` — drops connections).
- ❌ Rolling back a tenant migration manually after success — write a new forward-migration instead.
- ❌ Editing files inside `prisma/migrations/*` after they've been applied to any production tenant — checksums won't match, future runs fail.
- ❌ Skipping the health check by editing `deploy.sh` — fix the cause instead.

---

## Code-only changes (no schema delta)

If `git diff main` shows zero changes under `prisma/` and no new env vars, the deploy is risk-free: every step that touches tenants is a no-op (migrate-all says "up to date" for every tenant), the build/reload happens, traffic continues.

---

## New env var workflow

Env vars are read at PM2 worker start. Order matters:

```bash
# 1. Put the var in the prod .env first
echo 'NEW_FEATURE_TOKEN="xxx"' >> .env

# 2. Then deploy the code that uses it
npm run deploy
```

`pm2 reload --update-env` (built into `./deploy.sh`) re-reads `.env` on every deploy, so step 1 only needs to happen once.

---

## Cloudflare CDN Worker

Lives in [cloudflare/cdn-worker/](cloudflare/cdn-worker/) — separate deploy lifecycle from the Next.js app.

```bash
cd cloudflare/cdn-worker
CLOUDFLARE_API_TOKEN=xxx wrangler deploy
```

Keep the URL contract (`cdn.contradigital.agency/b/{bucket}/{key}`) stable. If you need to change it, deploy the Worker **first** with both old and new paths supported, then deploy the app, then remove the old path from the Worker.

**Worker secret gotcha:** never `echo "value" | wrangler secret put NAME` from PowerShell — it prepends a UTF-8 BOM that silently breaks the secret. Use a BOM-less file:

```powershell
$tmp = [System.IO.Path]::GetTempFileName()
[System.IO.File]::WriteAllText($tmp, "value", [System.Text.UTF8Encoding]::new($false))
cmd /c "type $tmp | wrangler secret put NAME"
Remove-Item $tmp
```

---

## Recovery — what to do when deploy fails

| Failure | What to do |
|---|---|
| `git pull` fails (non-FF) | Investigate manually — someone pushed during deploy or local has commits |
| `npm ci` fails | Lockfile drift — run `npm ci` locally to reproduce, fix and commit `package-lock.json` |
| Control migration fails | The control DB is in a known state (the failed migration was rolled back). Fix the migration SQL locally, commit, redeploy. |
| One tenant migration fails | Other tenants migrated. Check the per-tenant output for the failing tenant's error. Fix the SQL or the tenant's data, then re-run `npm run db:migrate-all -- --slug=that-tenant`. Then redeploy normally — completed migrations are skipped. |
| `next build` fails | Code-level error. Fix locally first. Old build is still serving. |
| `pm2 reload` fails | Check `pm2 logs cd-ecom` — usually a missing env var or port collision. Old workers may still be running on the old version. |
| Health check fails | New workers are live but broken. Check `pm2 logs cd-ecom --lines 200`. To roll back: `git revert <bad-sha> && npm run deploy`. |

---

## One-time setup checklist (before the first prod tenant)

- [ ] Neon point-in-time recovery enabled on control project + every tenant project
- [ ] `HEALTH_URL` env var set on the prod server (or default works)
- [ ] At least one staging tenant exists for smoke-testing migrations
- [ ] GlitchTip project created at `https://glitchtip.shoutify.me`, DSN copied into prod `.env` as `GLITCHTIP_DSN` + `NEXT_PUBLIC_SENTRY_DSN` (see [MONITORING.md](MONITORING.md))
- [ ] `npm run db:migrate-all-dry` succeeds against current prod — confirms every tenant is up to date before introducing new migrations
- [ ] Cloudflare Worker secrets set (`CF_ACCOUNT_ID`, `CF_API_TOKEN`)
- [ ] R2 buckets are KV-registered in the `BUCKET_MAP` namespace (auto-handled by `createTenantBucket`)

---

## Related docs

- [MIGRATIONS.md](MIGRATIONS.md) — schema-change workflow (read before touching `prisma/schema.prisma`)
- [MONITORING.md](MONITORING.md) — GlitchTip (errors) + Uptime Kuma (uptime) + Soketi (realtime) wiring
- [HOSTINGER_DEPLOY.md](HOSTINGER_DEPLOY.md) — first-time server setup (Node, PM2, env files)
- [README.md](README.md) — architecture overview
