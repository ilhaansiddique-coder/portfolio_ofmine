/**
 * Super-admin root layout. Completely separate from the storefront —
 * no Navbar, no Footer, no tenant providers, no storefront analytics.
 * Forces a light color scheme so the admin console is consistent regardless
 * of the visitor's OS preference.
 */
import type { Metadata } from "next";
import "../globals.css";
import ChunkReload from "@/components/ChunkReload";

export const metadata: Metadata = {
  title: "CD Ecom Admin",
  description: "CD Ecom super admin console",
  robots: { index: false, follow: false },
};

export default function SuperAdminRootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning style={{ colorScheme: "light" }}>
      <body
        className="min-h-screen bg-zinc-50 text-zinc-900 antialiased"
        style={{
          fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
          colorScheme: "light",
        }}
      >
        <ChunkReload />
        {children}
      </body>
    </html>
  );
}
