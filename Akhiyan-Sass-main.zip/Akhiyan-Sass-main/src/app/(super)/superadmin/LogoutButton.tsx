"use client";

export default function LogoutButton() {
  async function logout() {
    await fetch("/api/v1/superadmin/auth/logout", { method: "POST" });
    window.location.href = "/superadmin/login";
  }
  return (
    <button
      onClick={logout}
      className="rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-100"
    >
      Sign out
    </button>
  );
}
