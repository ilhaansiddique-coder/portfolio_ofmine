/**
 * Super-admin login. Server component: if a valid superadmin session
 * already exists, skip the form and go straight to the dashboard so
 * /superadmin/login never shows a redundant login screen to someone
 * who's already authenticated.
 */
import { redirect } from "next/navigation";
import { getSuperAdminSession } from "@/lib/super-admin-auth";
import LoginForm from "./LoginForm";

export const dynamic = "force-dynamic";

export default async function SuperAdminLoginPage() {
  const session = await getSuperAdminSession();
  if (session) redirect("/superadmin");
  return <LoginForm />;
}
