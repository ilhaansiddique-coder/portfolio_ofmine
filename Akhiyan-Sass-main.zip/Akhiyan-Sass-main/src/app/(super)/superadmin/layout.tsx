/**
 * Top-level super-admin layout — pass-through.
 * Auth gate lives in `(protected)/layout.tsx`. The unauthenticated `/login`
 * route gets rendered raw without sidebar/gate.
 */
export const dynamic = "force-dynamic";

export default function SuperAdminRootLayout({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-gray-50">{children}</div>;
}
