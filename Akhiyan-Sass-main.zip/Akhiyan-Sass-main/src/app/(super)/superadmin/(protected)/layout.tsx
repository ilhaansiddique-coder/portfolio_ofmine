/**
 * Super-admin authenticated shell — top header, full-width main.
 * Auth gate redirects unauth → /superadmin/login. Lives under the (super)
 * root group so storefront chrome never bleeds in.
 */
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSuperAdminSession } from "@/lib/super-admin-auth";
import LogoutButton from "../LogoutButton";
import SuperAdminRealtime from "@/components/SuperAdminRealtime";
import SuperNav from "./SuperNav";

export const dynamic = "force-dynamic";

export default async function ProtectedSuperAdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSuperAdminSession();
  if (!session) redirect("/superadmin/login");

  return (
    <div className="flex min-h-screen flex-col bg-zinc-50/80">
      <SuperAdminRealtime />
      <header className="sticky top-0 z-30 border-b border-zinc-200 bg-white/80 shadow-sm backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-3">
          <Link href="/superadmin" className="flex shrink-0 items-center gap-2.5 text-sm font-semibold tracking-tight">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logo.png" alt="CD Ecom" width={32} height={32} className="h-8 w-8 shrink-0 object-contain" />
            <span className="hidden sm:inline">CD Ecom<span className="font-normal text-[#16b1ec]"> · admin</span></span>
          </Link>
          <SuperNav />
          <div className="flex shrink-0 items-center gap-3">
            <span className="hidden items-center gap-1.5 rounded-full bg-zinc-100 px-3 py-1 font-mono text-xs text-zinc-500 lg:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              {session.email}
            </span>
            <LogoutButton />
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-7xl flex-1 px-6 py-8">{children}</main>
      <footer className="border-t border-zinc-200 py-4 text-center text-xs text-zinc-400">
        CD Ecom · Super admin console
      </footer>
    </div>
  );
}
