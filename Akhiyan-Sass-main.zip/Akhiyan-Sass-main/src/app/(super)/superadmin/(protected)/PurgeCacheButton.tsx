"use client";

import { useState } from "react";
import { FiZap } from "react-icons/fi";

/**
 * Super-admin button to flush the whole Cloudflare cache — handy after a deploy
 * (clears stale storefront HTML that references old JS chunk hashes) or anytime
 * the CDN needs busting. POSTs to /api/v1/superadmin/cache/purge.
 */
export default function PurgeCacheButton() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function purge() {
    if (busy) return;
    if (!confirm("Purge the entire Cloudflare cache? Storefronts will re-warm over the next minute.")) return;
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch("/api/v1/superadmin/cache/purge", { method: "POST" });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setMsg({ ok: true, text: "Cache purged ✓" });
    } catch (e) {
      setMsg({ ok: false, text: e instanceof Error ? e.message : "Failed" });
    } finally {
      setBusy(false);
      setTimeout(() => setMsg(null), 6000);
    }
  }

  return (
    <span className="inline-flex items-center gap-2">
      <button
        type="button"
        onClick={purge}
        disabled={busy}
        title="Flush Cloudflare cache (use after a deploy)"
        className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-50"
      >
        <FiZap className="h-3.5 w-3.5 text-amber-500" /> {busy ? "Purging…" : "Purge CDN cache"}
      </button>
      {msg && (
        <span className={`text-xs font-medium ${msg.ok ? "text-emerald-600" : "text-rose-600"}`}>{msg.text}</span>
      )}
    </span>
  );
}
