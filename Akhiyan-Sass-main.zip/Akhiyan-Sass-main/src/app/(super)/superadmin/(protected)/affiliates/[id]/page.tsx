import Link from "next/link";
import { notFound } from "next/navigation";
import {
  FiUsers, FiClock, FiCheckCircle, FiDollarSign,
  FiMousePointer, FiEye, FiTrendingUp, FiTarget,
  FiUser, FiMail, FiKey, FiCalendar, FiLink, FiLogIn, FiCreditCard,
} from "react-icons/fi";
import { controlPrisma } from "@/lib/prisma-control";
import { getAffiliateStats, getAffiliateMetrics } from "@/lib/affiliate";
import { AffiliateClicksChart } from "@/components/AffiliateClicksChart";
import { AffiliateActions } from "./actions";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const taka = (n: number) => `৳${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
const fmtDate = (d: Date) => d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });

export default async function AffiliateDetailPage({ params }: Ctx) {
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) notFound();

  const affiliate = await controlPrisma.affiliate.findUnique({
    where: { id: affiliateId },
    include: {
      referrals: { orderBy: { createdAt: "desc" }, take: 50 },
      commissions: { orderBy: { createdAt: "desc" }, take: 50 },
      payouts: { orderBy: { createdAt: "desc" }, take: 20 },
    },
  });
  if (!affiliate) notFound();

  const [stats, metrics] = await Promise.all([
    getAffiliateStats(affiliateId),
    getAffiliateMetrics(affiliateId),
  ]);
  const baseDomain = process.env.NEXT_PUBLIC_BASE_URL || `https://${process.env.BASE_DOMAIN || "example.com"}`;
  const loginUrl = `${baseDomain}/affiliate/login`;
  const refUrl = `${baseDomain}/ref/${affiliate.code}`;
  const hasPassword = !!affiliate.password;
  const available = Math.max(0, stats.approvedCommission);

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* ── Header ── */}
      <div>
        <Link href="/superadmin/affiliates" className="text-xs text-zinc-500 hover:text-zinc-700">
          ← Affiliates
        </Link>
        <div className="mt-2 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 text-lg font-bold text-white">
              {affiliate.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">{affiliate.name}</h1>
              <div className="mt-0.5 flex items-center gap-2 text-sm text-zinc-500">
                <span>{affiliate.email}</span>
                <StatusPill status={affiliate.status} />
              </div>
            </div>
          </div>
          <AffiliateActions affiliateId={affiliateId} currentStatus={affiliate.status} />
        </div>
      </div>

      {/* ── Earnings stat cards ── */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard icon={FiUsers} label="Referrals" value={String(stats.referrals)} color="bg-blue-500" />
        <StatCard icon={FiClock} label="Pending" value={taka(stats.pendingCommission)} color="bg-amber-500" />
        <StatCard icon={FiCheckCircle} label="Approved" value={taka(stats.approvedCommission)} color="bg-indigo-500" />
        <StatCard icon={FiDollarSign} label="Paid out" value={taka(stats.paidCommission)} color="bg-emerald-500" />
      </div>

      {/* ── Traffic stat cards ── */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard icon={FiMousePointer} label="Total clicks" value={metrics.totalClicks.toLocaleString()} color="bg-sky-500" />
        <StatCard icon={FiEye} label="Visitors (30d)" value={metrics.uniqueVisitors30d.toLocaleString()} color="bg-violet-500" />
        <StatCard icon={FiTrendingUp} label="Clicks (30d)" value={metrics.clicks30d.toLocaleString()} color="bg-teal-500" />
        <StatCard icon={FiTarget} label="Conversion" value={`${(metrics.conversionRate * 100).toFixed(1)}%`} color="bg-rose-500" />
      </div>

      {/* ── Two-column: account + clicks chart ── */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Account / user card */}
        <Card title="User account" icon={FiUser}>
          <dl className="space-y-3 text-sm">
            <InfoRow icon={FiMail} label="Email" value={affiliate.email} mono />
            <InfoRow icon={FiKey} label="Password" valueNode={
              hasPassword
                ? <span className="inline-flex items-center gap-1 text-emerald-600"><FiCheckCircle className="h-3.5 w-3.5" /> Set</span>
                : <span className="text-rose-600">Not set — reset to enable login</span>
            } />
            <InfoRow icon={FiLogIn} label="Login URL" valueNode={
              <a href={loginUrl} target="_blank" rel="noopener noreferrer" className="break-all font-mono text-xs text-orange-600 hover:underline">{loginUrl}</a>
            } />
            <InfoRow icon={FiCalendar} label="Member since" value={fmtDate(affiliate.createdAt)} />
            <InfoRow icon={FiTarget} label="Commission" value={`${(affiliate.commissionRate * 100).toFixed(0)}%`} />
          </dl>
        </Card>

        {/* Promo + payout card */}
        <Card title="Promo & payout" icon={FiLink}>
          <dl className="space-y-3 text-sm">
            <InfoRow icon={FiLink} label="Code" valueNode={
              <span className="rounded bg-zinc-100 px-2 py-0.5 font-mono text-xs">{affiliate.code}</span>
            } />
            <InfoRow icon={FiLink} label="Ref link" valueNode={
              <a href={refUrl} target="_blank" rel="noopener noreferrer" className="break-all font-mono text-xs text-orange-600 hover:underline">{refUrl}</a>
            } />
            <InfoRow icon={FiCreditCard} label="bKash" value={affiliate.bkashPhone ?? "—"} mono />
            <InfoRow icon={FiCreditCard} label="PayPal" value={affiliate.paypalEmail ?? "—"} mono />
            <InfoRow icon={FiDollarSign} label="Available" valueNode={<span className="font-semibold text-emerald-600">{taka(available)}</span>} />
          </dl>
        </Card>
      </div>

      {/* ── Clicks chart ── */}
      <Card title="Traffic — last 30 days" icon={FiTrendingUp} legend>
        <AffiliateClicksChart daily={metrics.daily} />
      </Card>

      {/* ── Referrals ── */}
      <Card title={`Referrals (${affiliate.referrals.length})`} icon={FiUsers}>
        {affiliate.referrals.length === 0 ? (
          <Empty text="No referrals yet." />
        ) : (
          <DataTable head={["Store", "Plan", "Date"]}>
            {affiliate.referrals.map((r) => (
              <tr key={r.id} className="hover:bg-zinc-50">
                <Td><Link href={`/superadmin/tenants/${r.tenantId}`} className="text-orange-600 hover:underline">Store #{r.tenantId}</Link></Td>
                <Td><span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs capitalize">{r.plan}</span></Td>
                <Td muted>{fmtDate(r.createdAt)}</Td>
              </tr>
            ))}
          </DataTable>
        )}
      </Card>

      {/* ── Commissions ── */}
      <Card title={`Commissions (${affiliate.commissions.length})`} icon={FiTrendingUp}>
        {affiliate.commissions.length === 0 ? (
          <Empty text="No commissions yet." />
        ) : (
          <DataTable head={["Event", "Amount", "Status", "Date"]}>
            {affiliate.commissions.map((c) => (
              <tr key={c.id} className="hover:bg-zinc-50">
                <Td><span className="capitalize">{c.event}</span></Td>
                <Td><span className="font-semibold">{taka(c.amount)}</span></Td>
                <Td><CommissionPill status={c.status} /></Td>
                <Td muted>{fmtDate(c.createdAt)}</Td>
              </tr>
            ))}
          </DataTable>
        )}
      </Card>

      {/* ── Payouts ── */}
      <Card title={`Payouts (${affiliate.payouts.length})`} icon={FiCreditCard}>
        {affiliate.payouts.length === 0 ? (
          <Empty text="No payouts yet." />
        ) : (
          <DataTable head={["Method", "Amount", "Destination", "Status", "Ref", "Date"]}>
            {affiliate.payouts.map((p) => (
              <tr key={p.id} className="hover:bg-zinc-50">
                <Td><span className="capitalize">{p.method}</span></Td>
                <Td><span className="font-semibold">{taka(p.amount)}</span></Td>
                <Td muted><span className="font-mono">{p.destination}</span></Td>
                <Td><CommissionPill status={p.status} /></Td>
                <Td muted><span className="font-mono">{p.txRef ?? "—"}</span></Td>
                <Td muted>{fmtDate(p.createdAt)}</Td>
              </tr>
            ))}
          </DataTable>
        )}
      </Card>
    </div>
  );
}

// ── Components ──────────────────────────────────────────────────────────────

function StatCard({
  icon: Icon, label, value, color,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string; color: string;
}) {
  return (
    <div className="rounded-2xl border border-zinc-100 bg-white p-4 shadow-sm">
      <div className={`mb-3 grid h-9 w-9 place-items-center rounded-xl text-white ${color}`}>
        <Icon className="h-4.5 w-4.5" />
      </div>
      <div className="truncate text-xl font-bold text-zinc-900">{value}</div>
      <div className="mt-0.5 truncate text-xs text-zinc-500">{label}</div>
    </div>
  );
}

function Card({
  title, icon: Icon, legend, children,
}: {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  legend?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-zinc-100 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-zinc-100 px-5 py-3.5">
        <h2 className="flex items-center gap-2 text-sm font-semibold text-zinc-800">
          <Icon className="h-4 w-4 text-zinc-400" /> {title}
        </h2>
        {legend && (
          <div className="flex items-center gap-4 text-xs text-zinc-500">
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-sky-500" /> Clicks</span>
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-orange-500" /> Sign-ups</span>
          </div>
        )}
      </div>
      <div className="px-5 py-4">{children}</div>
    </div>
  );
}

function InfoRow({
  icon: Icon, label, value, valueNode, mono,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value?: string; valueNode?: React.ReactNode; mono?: boolean;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-zinc-400" />
      <div className="min-w-0 flex-1">
        <div className="text-xs text-zinc-400">{label}</div>
        <div className={`text-zinc-800 ${mono ? "break-all font-mono text-xs" : "text-sm"}`}>
          {valueNode ?? value}
        </div>
      </div>
    </div>
  );
}

function DataTable({ head, children }: { head: string[]; children: React.ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-xs font-medium uppercase tracking-wide text-zinc-400">
          <tr>{head.map((h) => <th key={h} className="pb-3 pr-4">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-zinc-100">{children}</tbody>
      </table>
    </div>
  );
}

function Td({ children, muted }: { children: React.ReactNode; muted?: boolean }) {
  return <td className={`py-3 pr-4 ${muted ? "text-xs text-zinc-400" : "text-zinc-700"}`}>{children}</td>;
}

function Empty({ text }: { text: string }) {
  return <p className="py-4 text-center text-sm text-zinc-400">{text}</p>;
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    active: "bg-emerald-100 text-emerald-700",
    paused: "bg-yellow-100 text-yellow-700",
    banned: "bg-rose-100 text-rose-700",
  };
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${map[status] ?? "bg-zinc-100 text-zinc-600"}`}>
      {status}
    </span>
  );
}

function CommissionPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending:    "bg-yellow-100 text-yellow-700",
    approved:   "bg-blue-100 text-blue-700",
    paid:       "bg-emerald-100 text-emerald-700",
    rejected:   "bg-rose-100 text-rose-700",
    processing: "bg-purple-100 text-purple-700",
    completed:  "bg-emerald-100 text-emerald-700",
    failed:     "bg-rose-100 text-rose-700",
  };
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${map[status] ?? "bg-zinc-100 text-zinc-600"}`}>
      {status}
    </span>
  );
}
