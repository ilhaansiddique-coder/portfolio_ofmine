import { CreateAffiliateForm } from "./form";

export default function NewAffiliatePage() {
  return (
    <div className="mx-auto max-w-xl space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Add affiliate</h1>
        <p className="text-sm text-zinc-500">
          Creates an affiliate account and generates their promo code + dashboard link.
        </p>
      </header>
      <CreateAffiliateForm />
    </div>
  );
}
