"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

interface Created {
  id: number;
  name: string;
  email: string;
  code: string;
  commissionRate: number;
}

export function CreateAffiliateForm() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [created, setCreated] = useState<Created | null>(null);
  const [tempPassword, setTempPassword] = useState<string>("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/v1/superadmin/affiliates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: String(fd.get("name") || "").trim(),
          email: String(fd.get("email") || "").trim().toLowerCase(),
          code: String(fd.get("code") || "").trim().toUpperCase() || undefined,
          commissionRate: Number(fd.get("commissionRate")) / 100,
          password: String(fd.get("password") || "").trim() || undefined,
          bkashPhone: String(fd.get("bkashPhone") || "").trim() || null,
          paypalEmail: String(fd.get("paypalEmail") || "").trim().toLowerCase() || null,
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setCreated(j.affiliate);
      setTempPassword(j.tempPassword || "");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
    }
  }

  const baseDomain = typeof window !== "undefined" ? window.location.origin : "";

  if (created) {
    const loginUrl = `${baseDomain}/affiliate/login`;
    const refUrl = `${baseDomain}/ref/${created.code}`;
    return (
      <div className="space-y-4 rounded-lg border border-emerald-300 bg-emerald-50 p-6">
        <h2 className="text-lg font-semibold text-emerald-900">✓ Affiliate created</h2>
        <dl className="space-y-2 text-sm text-zinc-800">
          <Row label="Name" value={created.name} />
          <Row label="Email" value={created.email} mono />
          <Row label="Promo code" value={created.code} mono />
          <Row label="Commission" value={`${(created.commissionRate * 100).toFixed(0)}%`} />
          <hr className="border-emerald-200" />
          <Row label="Login at" value={loginUrl} mono />
          <Row label="Password" value={tempPassword || "(set by you)"} mono highlight />
          <Row label="Ref link" value={refUrl} mono />
        </dl>
        <p className="text-xs text-emerald-700">
          Share the login URL + password with the affiliate — the password won&apos;t be shown again.
        </p>
        <div className="flex gap-2 pt-2">
          <Link
            href={`/superadmin/affiliates/${created.id}`}
            className="rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700"
          >
            Open affiliate detail
          </Link>
          <button
            type="button"
            onClick={() => { setCreated(null); router.refresh(); }}
            className="rounded-md border border-zinc-300 px-3 py-2 text-sm hover:bg-zinc-100"
          >
            Add another
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-lg border border-zinc-200 bg-white p-6">
      {err && (
        <div className="rounded-md border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700">{err}</div>
      )}

      <Field label="Full name">
        <input name="name" required placeholder="John Doe"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Email">
        <input name="email" type="email" required placeholder="john@example.com"
          autoCapitalize="off" autoComplete="off"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Commission rate (%)" hint="e.g. 20 = 20% of the first month's plan price">
        <input name="commissionRate" type="number" required min="1" max="100" defaultValue="20" step="1"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Promo code" hint="Leave blank to auto-generate (8-char uppercase)">
        <input name="code" placeholder="ACME2030" autoCapitalize="characters" autoComplete="off"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 font-mono text-sm uppercase outline-none focus:border-orange-500" />
      </Field>

      <Field label="Login password" hint="Leave blank to auto-generate. Shown once after creation.">
        <input name="password" type="text" minLength={8} placeholder="(auto-generate)" autoComplete="off"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 font-mono text-sm outline-none focus:border-orange-500" />
      </Field>

      <hr className="border-zinc-200" />

      <Field label="bKash phone (optional)">
        <input name="bkashPhone" type="tel" placeholder="01XXXXXXXXX"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="PayPal email (optional)">
        <input name="paypalEmail" type="email" placeholder="paypal@example.com"
          autoCapitalize="off" autoComplete="off"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500" />
      </Field>

      <button
        type="submit" disabled={busy}
        className="w-full rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {busy ? "Creating…" : "Create affiliate"}
      </button>
    </form>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-medium">{label}</div>
      {children}
      {hint && <div className="mt-1 text-xs text-zinc-500">{hint}</div>}
    </label>
  );
}

function Row({ label, value, mono, highlight }: { label: string; value: string; mono?: boolean; highlight?: boolean }) {
  return (
    <div className="flex">
      <dt className="w-28 shrink-0 text-zinc-500">{label}</dt>
      <dd className={[mono ? "font-mono text-xs break-all" : "", highlight ? "rounded bg-emerald-100 px-2" : ""].filter(Boolean).join(" ")}>
        {value}
      </dd>
    </div>
  );
}
