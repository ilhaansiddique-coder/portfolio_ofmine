import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";

export const dynamic = "force-dynamic";

export default async function AffiliatesListPage() {
  const rows = await controlPrisma.affiliate.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      code: true,
      commissionRate: true,
      status: true,
      totalEarned: true,
      totalPaid: true,
      createdAt: true,
      _count: { select: { referrals: true } },
    },
  });

  // Surface pending applications at the top so they're easy to approve.
  const pendingCount = rows.filter((a) => a.status === "pending").length;
  const affiliates = [...rows].sort(
    (a, b) => (a.status === "pending" ? -1 : 0) - (b.status === "pending" ? -1 : 0),
  );

  return (
    <div className="space-y-6">
      <header className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Affiliates</h1>
          <p className="text-sm text-zinc-500">{affiliates.length} total</p>
        </div>
        <Link
          href="/superadmin/affiliates/new"
          className="rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700"
        >
          + Add affiliate
        </Link>
      </header>

      {pendingCount > 0 && (
        <div className="flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <span className="grid h-6 w-6 place-items-center rounded-full bg-amber-200 text-xs font-bold">{pendingCount}</span>
          <span>
            {pendingCount === 1 ? "application is" : "applications are"} awaiting review. Open the affiliate to approve.
          </span>
        </div>
      )}

      <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-zinc-50 text-left text-xs font-medium uppercase tracking-wide text-zinc-500">
            <tr>
              <Th>Name</Th>
              <Th>Code</Th>
              <Th>Rate</Th>
              <Th>Referrals</Th>
              <Th>Earned</Th>
              <Th>Paid</Th>
              <Th>Status</Th>
              <Th>Created</Th>
              <Th></Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100">
            {affiliates.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-6 text-center text-zinc-500">
                  No affiliates yet.{" "}
                  <Link href="/superadmin/affiliates/new" className="text-orange-600 hover:underline">
                    Add one →
                  </Link>
                </td>
              </tr>
            ) : (
              affiliates.map((a) => (
                <tr key={a.id} className="hover:bg-zinc-50">
                  <Td>
                    <div className="font-medium">{a.name}</div>
                    <div className="text-xs text-zinc-400">{a.email}</div>
                  </Td>
                  <Td>
                    <span className="rounded bg-zinc-100 px-2 py-0.5 font-mono text-xs">{a.code}</span>
                  </Td>
                  <Td>{(a.commissionRate * 100).toFixed(0)}%</Td>
                  <Td>{a._count.referrals}</Td>
                  <Td>৳{a.totalEarned.toLocaleString()}</Td>
                  <Td>৳{a.totalPaid.toLocaleString()}</Td>
                  <Td>
                    <StatusPill status={a.status} />
                  </Td>
                  <Td className="text-xs text-zinc-400">
                    {a.createdAt.toLocaleDateString()}
                  </Td>
                  <Td>
                    <Link
                      href={`/superadmin/affiliates/${a.id}`}
                      className="text-xs text-orange-600 hover:underline"
                    >
                      Detail →
                    </Link>
                  </Td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Th({ children }: { children?: React.ReactNode }) {
  return <th className="px-4 py-3">{children}</th>;
}
function Td({ children, className }: { children?: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-3 ${className ?? ""}`}>{children}</td>;
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    active: "bg-emerald-100 text-emerald-700",
    paused: "bg-yellow-100 text-yellow-700",
    banned: "bg-rose-100 text-rose-700",
  };
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${map[status] ?? "bg-zinc-100 text-zinc-600"}`}>
      {status}
    </span>
  );
}
