"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function AffiliateActions({
  affiliateId,
  currentStatus,
}: {
  affiliateId: number;
  currentStatus: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [tempPw, setTempPw] = useState("");

  async function setStatus(status: string) {
    setBusy(true);
    await fetch(`/api/v1/superadmin/affiliates/${affiliateId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    router.refresh();
    setBusy(false);
  }

  async function loginAs() {
    setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/affiliates/${affiliateId}/login-as`, { method: "POST" });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) { alert(j.message || "Login-as failed"); return; }
      // Opens the affiliate dashboard in a new tab; superadmin session stays in this tab.
      window.open(j.redirectTo || "/affiliate/dashboard", "_blank", "noopener");
    } finally {
      setBusy(false);
    }
  }

  async function resetPassword() {
    if (!confirm("Generate a new password for this affiliate? Their current password stops working.")) return;
    setBusy(true);
    const res = await fetch(`/api/v1/superadmin/affiliates/${affiliateId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resetPassword: true }),
    });
    const j = await res.json().catch(() => ({}));
    if (j.tempPassword) setTempPw(j.tempPassword);
    setBusy(false);
  }

  const isPending = currentStatus === "pending";

  if (tempPw) {
    return (
      <div className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs">
        <div className="font-medium text-emerald-800">New password (shown once):</div>
        <code className="mt-1 block break-all font-mono text-sm text-emerald-900">{tempPw}</code>
        <button onClick={() => setTempPw("")} className="mt-2 text-emerald-700 hover:underline">Done</button>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {currentStatus !== "banned" && (
        <button
          disabled={busy}
          onClick={loginAs}
          className="rounded-md bg-zinc-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-zinc-700 disabled:opacity-40"
        >
          Log in as affiliate ↗
        </button>
      )}
      {currentStatus !== "active" && (
        <button
          disabled={busy}
          onClick={() => setStatus("active")}
          className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-100 disabled:opacity-40"
        >
          {isPending ? "Approve" : "Activate"}
        </button>
      )}
      {currentStatus === "active" && (
        <button
          disabled={busy}
          onClick={() => setStatus("paused")}
          className="rounded-md border border-yellow-300 bg-yellow-50 px-3 py-1.5 text-xs font-medium text-yellow-700 hover:bg-yellow-100 disabled:opacity-40"
        >
          Pause
        </button>
      )}
      {currentStatus !== "banned" && (
        <button
          disabled={busy}
          onClick={() => { if (confirm(isPending ? "Reject this application?" : "Ban this affiliate?")) setStatus("banned"); }}
          className="rounded-md border border-rose-300 bg-rose-50 px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-100 disabled:opacity-40"
        >
          {isPending ? "Reject" : "Ban"}
        </button>
      )}
      <button
        disabled={busy}
        onClick={resetPassword}
        className="rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-40"
      >
        Reset password
      </button>
    </div>
  );
}
