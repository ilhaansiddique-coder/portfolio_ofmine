"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function SignupActions({
  orderId,
  status,
}: {
  orderId: number;
  status: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function setStatus(next: string) {
    setBusy(true);
    await fetch(`/api/v1/superadmin/signups/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next }),
    });
    router.refresh();
    setBusy(false);
  }

  // Provisioned orders are done — no actions.
  if (status === "provisioned") {
    return <span className="text-xs text-zinc-400">Done</span>;
  }

  return (
    <div className="flex flex-wrap justify-end gap-1.5">
      {status === "pending" && (
        <button
          disabled={busy}
          onClick={() => setStatus("paid")}
          className="rounded-md border border-emerald-300 bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700 hover:bg-emerald-100 disabled:opacity-40"
        >
          Mark paid
        </button>
      )}
      {status === "paid" && (
        <button
          disabled={busy}
          onClick={() => setStatus("pending")}
          className="rounded-md border border-zinc-300 bg-white px-2.5 py-1 text-xs font-medium text-zinc-600 hover:bg-zinc-100 disabled:opacity-40"
        >
          Unmark paid
        </button>
      )}
      {status !== "rejected" && (
        <Link
          href={`/superadmin/tenants/new?signup=${orderId}`}
          className="rounded-md bg-zinc-900 px-2.5 py-1 text-xs font-medium text-white hover:bg-zinc-700"
        >
          Provision →
        </Link>
      )}
      {status !== "rejected" && (
        <button
          disabled={busy}
          onClick={() => { if (confirm("Reject this signup request?")) setStatus("rejected"); }}
          className="rounded-md border border-rose-300 bg-rose-50 px-2.5 py-1 text-xs font-medium text-rose-700 hover:bg-rose-100 disabled:opacity-40"
        >
          Reject
        </button>
      )}
      {status === "rejected" && (
        <button
          disabled={busy}
          onClick={() => setStatus("pending")}
          className="rounded-md border border-zinc-300 bg-white px-2.5 py-1 text-xs font-medium text-zinc-600 hover:bg-zinc-100 disabled:opacity-40"
        >
          Reopen
        </button>
      )}
    </div>
  );
}
