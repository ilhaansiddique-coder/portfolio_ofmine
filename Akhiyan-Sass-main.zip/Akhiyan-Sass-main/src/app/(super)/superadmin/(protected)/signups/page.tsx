import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";
import { SignupActions } from "./actions";

export const dynamic = "force-dynamic";

const STATUS_RANK: Record<string, number> = { paid: 0, pending: 1, provisioned: 2, rejected: 3 };

export default async function SignupsPage() {
  const rows = await controlPrisma.signupOrder.findMany({
    orderBy: { createdAt: "desc" },
  });

  // Surface actionable orders (paid, then pending) at the top.
  const orders = [...rows].sort(
    (a, b) => (STATUS_RANK[a.status] ?? 9) - (STATUS_RANK[b.status] ?? 9),
  );
  const open = rows.filter((o) => o.status === "pending" || o.status === "paid").length;

  return (
    <div className="space-y-6">
      <header className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Signups</h1>
          <p className="text-sm text-zinc-500">{orders.length} total · {open} awaiting action</p>
        </div>
      </header>

      {open > 0 && (
        <div className="flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <span className="grid h-6 w-6 place-items-center rounded-full bg-amber-200 text-xs font-bold">{open}</span>
          <span>signup request{open === 1 ? "" : "s"} need review. Mark paid, then Provision to create the store.</span>
        </div>
      )}

      <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-zinc-50 text-left text-xs font-medium uppercase tracking-wide text-zinc-500">
            <tr>
              <Th>Store</Th>
              <Th>Address</Th>
              <Th>Plan</Th>
              <Th>Contact</Th>
              <Th>Affiliate</Th>
              <Th>Status</Th>
              <Th>Date</Th>
              <Th></Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100">
            {orders.length === 0 ? (
              <tr><td colSpan={8} className="p-6 text-center text-zinc-500">No signup requests yet.</td></tr>
            ) : (
              orders.map((o) => (
                <tr key={o.id} className="hover:bg-zinc-50">
                  <Td><div className="font-medium">{o.storeName}</div></Td>
                  <Td><span className="rounded bg-zinc-100 px-2 py-0.5 font-mono text-xs">{o.slug}</span></Td>
                  <Td><span className="capitalize">{o.plan}</span></Td>
                  <Td>
                    <div className="text-xs">{o.ownerEmail}</div>
                    {o.phone && <div className="text-xs text-zinc-400">{o.phone}</div>}
                  </Td>
                  <Td>
                    {o.affCode
                      ? <span className="rounded bg-orange-100 px-2 py-0.5 font-mono text-xs text-orange-700">{o.affCode}</span>
                      : <span className="text-xs text-zinc-300">—</span>}
                  </Td>
                  <Td><StatusPill status={o.status} /></Td>
                  <Td className="text-xs text-zinc-400">{o.createdAt.toLocaleDateString()}</Td>
                  <Td>
                    {o.tenantId ? (
                      <Link href={`/superadmin/tenants/${o.tenantId}`} className="text-xs text-orange-600 hover:underline">
                        Tenant #{o.tenantId} →
                      </Link>
                    ) : (
                      <SignupActions orderId={o.id} status={o.status} />
                    )}
                  </Td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Th({ children }: { children?: React.ReactNode }) {
  return <th className="px-4 py-3">{children}</th>;
}
function Td({ children, className }: { children?: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-3 ${className ?? ""}`}>{children}</td>;
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    paid: "bg-blue-100 text-blue-700",
    provisioned: "bg-emerald-100 text-emerald-700",
    rejected: "bg-rose-100 text-rose-700",
  };
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${map[status] ?? "bg-zinc-100 text-zinc-600"}`}>
      {status}
    </span>
  );
}
