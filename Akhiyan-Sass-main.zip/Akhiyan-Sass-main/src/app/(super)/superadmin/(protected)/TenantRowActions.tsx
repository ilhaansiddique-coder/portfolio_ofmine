"use client";

import { useState } from "react";
import { FiExternalLink, FiLogIn } from "react-icons/fi";

/**
 * Compact per-row actions for tenant tables: open the storefront, and
 * "Login as" (real tenant-admin session via the login-as-admin token flow).
 */
export default function TenantRowActions({
  tenantId,
  storeUrl,
}: {
  tenantId: number;
  storeUrl: string;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function loginAs() {
    setErr("");
    setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}/login-as-admin`, { method: "POST" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      window.location.href = j.redirectTo;
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
      setBusy(false);
    }
  }

  return (
    <div className="flex items-center justify-end gap-1.5">
      <a
        href={storeUrl}
        target="_blank"
        rel="noreferrer"
        className="inline-flex items-center gap-1 rounded-md border border-zinc-300 bg-white px-2.5 py-1.5 text-xs font-medium text-zinc-600 hover:bg-zinc-50"
        title="Open storefront"
      >
        <FiExternalLink className="h-3.5 w-3.5" /> View
      </a>
      <button
        type="button"
        onClick={loginAs}
        disabled={busy}
        title={err || "Log in as this tenant's admin"}
        className="inline-flex items-center gap-1 rounded-md bg-[#16b1ec] px-2.5 py-1.5 text-xs font-medium text-white hover:bg-[#0b87c4] disabled:opacity-50"
      >
        <FiLogIn className="h-3.5 w-3.5" /> {busy ? "…" : "Login as"}
      </button>
    </div>
  );
}
