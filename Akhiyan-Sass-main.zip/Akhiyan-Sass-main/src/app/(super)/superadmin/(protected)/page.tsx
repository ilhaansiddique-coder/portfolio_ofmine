/**
 * Super-admin dashboard.
 * Cross-tenant overview from the control plane: tenant counts, recent
 * provisioning, recent impersonations (derived from audit log).
 */
import Link from "next/link";
import {
  FiServer, FiCheckCircle, FiPauseCircle, FiInbox, FiPlus,
  FiArrowRight, FiUserCheck, FiClock,
} from "react-icons/fi";
import { controlPrisma } from "@/lib/prisma-control";
import TenantRowActions from "./TenantRowActions";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const [
    totalTenants, activeTenants, suspendedTenants, provisioningTenants,
    totalSignups, totalPlans, recentTenants, recentImpersonations,
  ] = await Promise.all([
    controlPrisma.tenant.count(),
    controlPrisma.tenant.count({ where: { status: "active" } }),
    controlPrisma.tenant.count({ where: { status: "suspended" } }),
    controlPrisma.tenant.count({ where: { status: "provisioning" } }),
    controlPrisma.signupOrder.count().catch(() => 0),
    controlPrisma.plan.count().catch(() => 0),
    controlPrisma.tenant.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
      select: { id: true, slug: true, name: true, status: true, plan: true, ownerEmail: true, createdAt: true, primaryDomain: true },
    }),
    controlPrisma.auditLog.findMany({
      where: { action: "tenant.impersonate.start" },
      orderBy: { createdAt: "desc" },
      take: 5,
      include: {
        superAdmin: { select: { email: true } },
        tenant: { select: { slug: true, name: true } },
      },
    }),
  ]);

  const activePct = totalTenants ? Math.round((activeTenants / totalTenants) * 100) : 0;
  const baseDomain = process.env.BASE_DOMAIN || "contradigital.agency";
  const devPort = process.env.NODE_ENV === "production" ? "" : `:${process.env.PORT || "3005"}`;
  const storeUrlOf = (t: { primaryDomain: string | null; slug: string }) =>
    t.primaryDomain ? `https://${t.primaryDomain}` : `http://${t.slug}.${baseDomain}${devPort}`;

  return (
    <div className="space-y-7">
      {/* Hero header */}
      <header className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#16b1ec] via-[#34c4a6] to-[#88d544] px-6 py-7 text-white shadow-lg">
        <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -bottom-12 right-24 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-white/70">Control plane</p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight">Super Admin Dashboard</h1>
            <p className="mt-1 text-sm text-white/80">
              {totalTenants} tenant{totalTenants === 1 ? "" : "s"} · {activePct}% active · click any tenant to manage it.
            </p>
          </div>
          <Link
            href="/superadmin/tenants/new"
            className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-[#0b87c4] shadow-sm transition hover:bg-white/90"
          >
            <FiPlus className="h-4 w-4" /> Create tenant
          </Link>
        </div>
      </header>

      {/* Stat cards */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Total tenants" value={totalTenants} icon={FiServer} tone="brand"
          sub={`${provisioningTenants} provisioning`} />
        <Stat label="Active" value={activeTenants} icon={FiCheckCircle} tone="emerald"
          sub={`${activePct}% of total`} />
        <Stat label="Suspended" value={suspendedTenants} icon={FiPauseCircle} tone="rose"
          sub="needs attention" />
        <Stat label="Signups" value={totalSignups} icon={FiInbox} tone="amber"
          sub={`${totalPlans} plan${totalPlans === 1 ? "" : "s"} configured`} />
      </section>

      {/* Recent tenants */}
      <Card
        title="Recent tenants"
        icon={FiServer}
        action={<Link href="/superadmin/tenants" className="inline-flex items-center gap-1 text-xs font-medium text-[#0b87c4] hover:underline">View all <FiArrowRight className="h-3 w-3" /></Link>}
      >
        {recentTenants.length === 0 ? (
          <Empty>No tenants yet. <Link href="/superadmin/tenants/new" className="font-medium text-[#0b87c4] hover:underline">Create one →</Link></Empty>
        ) : (
          <Table head={<tr><Th>Tenant</Th><Th>Plan</Th><Th>Status</Th><Th>Owner</Th><Th>Created</Th><Th className="text-right">Actions</Th></tr>}>
            {recentTenants.map((t) => (
              <tr key={t.id} className="group transition-colors hover:bg-[#16b1ec]/5">
                <Td>
                  <Link href={`/superadmin/tenants/${t.slug}`} className="flex items-center gap-2.5">
                    <Avatar name={t.name || t.slug} />
                    <span className="min-w-0">
                      <span className="block truncate font-medium text-zinc-800 group-hover:text-[#0b87c4]">{t.name || t.slug}</span>
                      <span className="block font-mono text-xs text-zinc-400">{t.slug}</span>
                    </span>
                  </Link>
                </Td>
                <Td><span className="rounded-md bg-zinc-100 px-2 py-0.5 text-xs font-medium capitalize text-zinc-600">{t.plan}</span></Td>
                <Td><StatusBadge status={t.status} /></Td>
                <Td className="font-mono text-xs text-zinc-500">{t.ownerEmail}</Td>
                <Td className="text-xs text-zinc-500">{t.createdAt.toISOString().slice(0, 10)}</Td>
                <Td className="text-right"><TenantRowActions tenantId={t.id} storeUrl={storeUrlOf(t)} /></Td>
              </tr>
            ))}
          </Table>
        )}
      </Card>

      {/* Recent impersonations */}
      <Card title="Recent impersonations" icon={FiUserCheck}>
        {recentImpersonations.length === 0 ? (
          <Empty>No impersonations recorded.</Empty>
        ) : (
          <Table head={<tr><Th>Super admin</Th><Th>Tenant</Th><Th>Started</Th></tr>}>
            {recentImpersonations.map((s) => (
              <tr key={s.id} className="transition-colors hover:bg-[#16b1ec]/5">
                <Td className="font-mono text-xs text-zinc-600">{s.superAdmin?.email}</Td>
                <Td>
                  {s.tenant?.slug ? (
                    <Link href={`/superadmin/tenants/${s.tenant.slug}`} className="font-mono text-xs font-medium text-[#0b87c4] hover:underline">
                      {s.tenant.slug}
                    </Link>
                  ) : <span className="text-zinc-400">—</span>}
                </Td>
                <Td className="inline-flex items-center gap-1.5 text-xs text-zinc-500">
                  <FiClock className="h-3 w-3 text-zinc-400" />
                  {s.createdAt.toISOString().slice(0, 16).replace("T", " ")}
                </Td>
              </tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}

// ── UI primitives ───────────────────────────────────────────────────────────

const TONES: Record<string, { ring: string; chip: string; text: string }> = {
  brand: { ring: "ring-[#16b1ec]/15", chip: "bg-[#16b1ec]/10 text-[#0b87c4]", text: "text-[#0b87c4]" },
  emerald: { ring: "ring-emerald-100", chip: "bg-emerald-50 text-emerald-600", text: "text-emerald-600" },
  rose: { ring: "ring-rose-100", chip: "bg-rose-50 text-rose-600", text: "text-rose-600" },
  amber: { ring: "ring-amber-100", chip: "bg-amber-50 text-amber-600", text: "text-amber-600" },
};

function Stat({
  label, value, icon: Icon, tone, sub,
}: {
  label: string; value: string | number;
  icon: React.ComponentType<{ className?: string }>; tone: keyof typeof TONES; sub?: string;
}) {
  const t = TONES[tone];
  return (
    <div className={`rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm ring-1 ring-inset ${t.ring} transition hover:shadow-md`}>
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wide text-zinc-500">{label}</p>
        <span className={`grid h-8 w-8 place-items-center rounded-lg ${t.chip}`}><Icon className="h-4 w-4" /></span>
      </div>
      <p className="mt-2 text-3xl font-bold tracking-tight text-zinc-900">{value}</p>
      {sub && <p className="mt-0.5 text-xs text-zinc-400">{sub}</p>}
    </div>
  );
}

function Card({
  title, icon: Icon, action, children,
}: {
  title: string; icon: React.ComponentType<{ className?: string }>;
  action?: React.ReactNode; children: React.ReactNode;
}) {
  return (
    <section className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-zinc-100 px-5 py-3.5">
        <h2 className="flex items-center gap-2 text-sm font-semibold text-zinc-800">
          <Icon className="h-4 w-4 text-zinc-400" /> {title}
        </h2>
        {action}
      </div>
      {children}
    </section>
  );
}

function Table({ head, children }: { head: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-zinc-50/70 text-left text-xs font-semibold uppercase tracking-wide text-zinc-400">{head}</thead>
        <tbody className="divide-y divide-zinc-100">{children}</tbody>
      </table>
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <p className="p-6 text-center text-sm text-zinc-500">{children}</p>;
}

function Avatar({ name }: { name: string }) {
  const initial = (name || "?").trim().charAt(0).toUpperCase();
  const palette = ["from-[#16b1ec] to-[#34c4a6]", "from-emerald-500 to-teal-500", "from-[#34c4a6] to-[#88d544]", "from-amber-500 to-orange-500", "from-sky-500 to-cyan-500"];
  const idx = (name.charCodeAt(0) || 0) % palette.length;
  return (
    <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-gradient-to-br ${palette[idx]} text-sm font-bold text-white shadow-sm`}>
      {initial}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { dot: string; cls: string }> = {
    active: { dot: "bg-emerald-500", cls: "bg-emerald-50 text-emerald-700" },
    provisioning: { dot: "bg-amber-500", cls: "bg-amber-50 text-amber-700" },
    suspended: { dot: "bg-rose-500", cls: "bg-rose-50 text-rose-700" },
  };
  const s = map[status] || { dot: "bg-zinc-400", cls: "bg-zinc-100 text-zinc-600" };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ${s.cls}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} /> {status}
    </span>
  );
}

function Th({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <th className={`px-5 py-2.5 font-semibold ${className}`}>{children}</th>;
}
function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-5 py-3 align-middle ${className}`}>{children}</td>;
}
