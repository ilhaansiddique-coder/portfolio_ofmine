"use client";

/**
 * Super-admin date-range picker — same UI/UX as the tenant DateRangePicker
 * (presets sidebar + dual calendar + range highlight), but English-only and
 * provider-free (the (super) layout has no LanguageProvider). Brand-blue accent
 * via a scoped --primary override. Props mirror the tenant one: { from, to,
 * onChange } with "YYYY-MM-DD" strings ("" = all time).
 */
import { useState, useRef, useEffect, useMemo } from "react";
import { FiCalendar, FiX, FiChevronLeft, FiChevronRight } from "react-icons/fi";

interface Props {
  from: string;
  to: string;
  onChange: (from: string, to: string) => void;
}

const PRESETS = [
  { label: "Today", days: 0 },
  { label: "Yesterday", days: -3 },
  { label: "Last 7 days", days: 7 },
  { label: "Last 30 days", days: 30 },
  { label: "Last 90 days", days: 90 },
  { label: "This month", days: -1 },
  { label: "Last month", days: -2 },
  { label: "All time", days: -99 },
];

const WEEKDAYS = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function toDateStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function getPresetRange(days: number): { from: string; to: string } {
  const today = new Date();
  const to = toDateStr(today);
  if (days === 0) return { from: to, to };
  if (days === -3) { const y = toDateStr(new Date(today.getTime() - 86400000)); return { from: y, to: y }; }
  if (days === -1) return { from: toDateStr(new Date(today.getFullYear(), today.getMonth(), 1)), to };
  if (days === -2) {
    const first = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const last = new Date(today.getFullYear(), today.getMonth(), 0);
    return { from: toDateStr(first), to: toDateStr(last) };
  }
  if (days === -99) return { from: "", to: "" };
  return { from: toDateStr(new Date(today.getTime() - days * 86400000)), to };
}
function fmt(dateStr: string): string {
  if (!dateStr) return "";
  return new Date(dateStr).toLocaleDateString("en-US", { day: "numeric", month: "short" });
}

function MiniCalendar({ month, year, rangeStart, rangeEnd, hoverDate, onDateClick, onDateHover }: {
  month: number; year: number; rangeStart: string; rangeEnd: string; hoverDate: string;
  onDateClick: (d: string) => void; onDateHover: (d: string) => void;
}) {
  const days = useMemo(() => {
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevDays = new Date(year, month, 0).getDate();
    const cells: { date: string; day: number; outside: boolean }[] = [];
    const startPad = firstDay === 0 ? 6 : firstDay - 1;
    for (let i = startPad - 1; i >= 0; i--) { const d = new Date(year, month - 1, prevDays - i); cells.push({ date: toDateStr(d), day: prevDays - i, outside: true }); }
    for (let i = 1; i <= daysInMonth; i++) cells.push({ date: toDateStr(new Date(year, month, i)), day: i, outside: false });
    const remaining = 42 - cells.length;
    for (let i = 1; i <= remaining; i++) { const d = new Date(year, month + 1, i); cells.push({ date: toDateStr(d), day: i, outside: true }); }
    return cells;
  }, [month, year]);
  const today = toDateStr(new Date());
  const effectiveEnd = rangeEnd || hoverDate;
  return (
    <div>
      <div className="grid grid-cols-7 mb-1">
        {WEEKDAYS.map((d) => <div key={d} className="h-8 flex items-center justify-center text-[10px] font-semibold text-gray-400 uppercase">{d}</div>)}
      </div>
      <div className="grid grid-cols-7">
        {days.map((cell) => {
          if (cell.outside) return <div key={cell.date + "-o-" + cell.day} className="h-8 flex items-center justify-center text-xs text-gray-200">{cell.day}</div>;
          const isToday = cell.date === today;
          const isStart = cell.date === rangeStart;
          const isEnd = cell.date === (rangeEnd || (hoverDate && rangeStart ? hoverDate : ""));
          const lo = rangeStart && effectiveEnd ? (rangeStart < effectiveEnd ? rangeStart : effectiveEnd) : "";
          const hi = rangeStart && effectiveEnd ? (rangeStart < effectiveEnd ? effectiveEnd : rangeStart) : "";
          const inRange = lo && hi && cell.date >= lo && cell.date <= hi;
          const isEndpoint = isStart || isEnd;
          return (
            <div key={cell.date} onClick={() => onDateClick(cell.date)} onMouseEnter={() => onDateHover(cell.date)}
              className={`relative h-8 flex items-center justify-center text-xs cursor-pointer transition-all
                ${inRange && !isEndpoint ? "bg-[var(--primary)]/10" : ""}
                ${isEndpoint ? "bg-[var(--primary)] text-white rounded-lg font-semibold shadow-sm" : ""}
                ${!isEndpoint && !inRange ? "hover:bg-gray-100 rounded-lg" : ""}
                ${isToday && !isEndpoint ? "font-bold text-[var(--primary)]" : ""}
                ${inRange && isStart && !isEnd ? "rounded-l-lg rounded-r-none" : ""}
                ${inRange && isEnd && !isStart ? "rounded-r-lg rounded-l-none" : ""}`}>
              <span className="relative z-10">{cell.day}</span>
              {isToday && !isEndpoint && <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[var(--primary)]" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function SuperDateRangePicker({ from, to, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const now = new Date();
  const [viewMonth, setViewMonth] = useState(now.getMonth());
  const [viewYear, setViewYear] = useState(now.getFullYear());
  const [selecting, setSelecting] = useState(false);
  const [tempStart, setTempStart] = useState(from);
  const [tempEnd, setTempEnd] = useState(to);
  const [hoverDate, setHoverDate] = useState("");

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  useEffect(() => { setTempStart(from); setTempEnd(to); }, [from, to]);

  const handleDateClick = (d: string) => {
    if (!selecting || !tempStart) { setTempStart(d); setTempEnd(""); setSelecting(true); }
    else {
      const start = d < tempStart ? d : tempStart;
      const end = d < tempStart ? tempStart : d;
      setTempStart(start); setTempEnd(end); setSelecting(false); onChange(start, end);
    }
  };
  const prevMonth = () => { if (viewMonth === 0) { setViewMonth(11); setViewYear(viewYear - 1); } else setViewMonth(viewMonth - 1); };
  const nextMonth = () => { if (viewMonth === 11) { setViewMonth(0); setViewYear(viewYear + 1); } else setViewMonth(viewMonth + 1); };

  const hasFilter = !!(from || to);
  const todayStr = toDateStr(new Date());
  const yStr = toDateStr(new Date(Date.now() - 86400000));
  let label: string;
  if (!hasFilter) label = "All time";
  else if (from && to && from === to) label = from === todayStr ? "Today" : from === yStr ? "Yesterday" : fmt(from);
  else label = `${fmt(from)} — ${fmt(to)}`;

  const month2 = viewMonth === 11 ? 0 : viewMonth + 1;
  const year2 = viewMonth === 11 ? viewYear + 1 : viewYear;

  return (
    <div ref={ref} className="relative w-full md:w-auto" style={{ ["--primary" as string]: "#16b1ec" }}>
      <button onClick={() => setOpen(!open)}
        className={`w-full md:w-auto flex items-center gap-2 px-3.5 py-2 border rounded-xl text-sm transition-all min-w-0 ${
          hasFilter ? "border-[var(--primary)] bg-[var(--primary)]/5 text-[var(--primary)] font-medium" : "border-zinc-200 text-zinc-500 hover:border-zinc-300"
        }`}>
        <FiCalendar className="w-4 h-4 shrink-0" />
        <span className="truncate min-w-0 flex-1 text-left">{label}</span>
        {hasFilter && (
          <span onClick={(e) => { e.stopPropagation(); onChange("", ""); setOpen(false); }}
            className="ml-0.5 p-0.5 hover:bg-red-100 rounded-full text-red-500 shrink-0"><FiX className="w-3 h-3" /></span>
        )}
      </button>

      {open && <div className="fixed inset-0 bg-black/30 z-40 md:hidden" onClick={() => setOpen(false)} />}

      {open && (
        <div className="z-50 bg-white border border-zinc-100 shadow-2xl shadow-black/10 overflow-hidden fixed inset-x-3 bottom-3 top-auto rounded-2xl max-h-[85vh] overflow-y-auto md:absolute md:inset-auto md:top-full md:right-0 md:mt-2 md:rounded-2xl md:max-h-none md:overflow-visible"
          style={{ animation: "fadeSlideIn 0.15s ease-out" }}>
          <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-100 md:hidden">
            <span className="text-sm font-semibold text-zinc-800">Select date</span>
            <button onClick={() => setOpen(false)} className="p-1 text-zinc-400 hover:text-zinc-600"><FiX className="w-5 h-5" /></button>
          </div>
          <div className="flex flex-col md:flex-row">
            <div className="md:w-32 md:bg-zinc-50/80 md:border-r md:border-zinc-100 p-3 md:space-y-1">
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-2 px-1 hidden md:block">Quick select</p>
              <div className="flex flex-wrap gap-1.5 md:flex-col md:gap-0 md:space-y-1">
                {PRESETS.map((p) => {
                  const range = getPresetRange(p.days);
                  const isActive = from === range.from && to === range.to;
                  return (
                    <button key={p.label}
                      onClick={() => { onChange(range.from, range.to); setTempStart(range.from); setTempEnd(range.to); setSelecting(false); setOpen(false); }}
                      className={`px-2.5 py-2 rounded-lg text-xs font-medium transition-all md:w-full md:text-left ${
                        isActive ? "bg-[var(--primary)] text-white shadow-sm" : "bg-zinc-100 md:bg-transparent text-zinc-600 hover:bg-white hover:shadow-sm"
                      }`}>{p.label}</button>
                  );
                })}
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-3 px-1">
                <button onClick={prevMonth} className="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-500 hover:text-zinc-800"><FiChevronLeft className="w-4 h-4" /></button>
                <div className="flex gap-4 md:gap-8 text-sm font-semibold text-zinc-800">
                  <span>{MONTHS[viewMonth]} {viewYear}</span>
                  <span className="hidden md:inline">{MONTHS[month2]} {year2}</span>
                </div>
                <button onClick={nextMonth} className="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-500 hover:text-zinc-800"><FiChevronRight className="w-4 h-4" /></button>
              </div>
              <div className="flex gap-4">
                <div className="w-full md:w-56">
                  <MiniCalendar month={viewMonth} year={viewYear} rangeStart={tempStart} rangeEnd={tempEnd} hoverDate={selecting ? hoverDate : ""} onDateClick={handleDateClick} onDateHover={setHoverDate} />
                </div>
                <div className="w-px bg-zinc-100 hidden md:block" />
                <div className="w-56 hidden md:block">
                  <MiniCalendar month={month2} year={year2} rangeStart={tempStart} rangeEnd={tempEnd} hoverDate={selecting ? hoverDate : ""} onDateClick={handleDateClick} onDateHover={setHoverDate} />
                </div>
              </div>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mt-3 pt-3 border-t border-zinc-100 gap-2">
                <div className="text-xs text-zinc-400">{tempStart && tempEnd ? `${fmt(tempStart)} — ${fmt(tempEnd)}` : tempStart ? "Select end date" : "Select date"}</div>
                <div className="flex gap-2 w-full sm:w-auto">
                  {hasFilter && (
                    <button onClick={() => { onChange("", ""); setTempStart(""); setTempEnd(""); setSelecting(false); setOpen(false); }}
                      className="flex-1 sm:flex-none px-3 py-2 sm:py-1.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg">Reset</button>
                  )}
                  <button onClick={() => setOpen(false)}
                    className="flex-1 sm:flex-none px-4 py-2 sm:py-1.5 text-xs font-medium text-white bg-[var(--primary)] hover:opacity-90 rounded-lg shadow-sm">Done</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      <style jsx>{`@keyframes fadeSlideIn { from { opacity: 0; transform: translateY(-4px) scale(0.98); } to { opacity: 1; transform: translateY(0) scale(1); } }`}</style>
    </div>
  );
}
