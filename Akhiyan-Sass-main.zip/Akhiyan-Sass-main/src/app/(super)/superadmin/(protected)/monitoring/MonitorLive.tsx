"use client";

/**
 * Realtime live-visitor wiring for the monitoring page.
 *
 * The "Live now" total and the per-tenant Live column update IN PLACE from
 * Soketi (event "presence" on the super-admin feed, broadcast by the storefront
 * heartbeat route). No polling, no DB, no router.refresh — so a visitor count
 * bump never triggers the heavy cross-tenant metrics query. The slower
 * server-field refresh (DB connections, orders, revenue) is handled separately
 * by SuperAdminRealtime's visibility-gated interval.
 *
 * SSR values seed the initial state, so numbers are correct on first paint and
 * also self-correct on the next full refresh (covers the "all visitors left,
 * no more heartbeats" edge where Soketi can't fire a drop-to-zero event).
 */
import { createContext, useContext, useState } from "react";
import type { PresenceSnapshot } from "@/lib/presence";
import { useSuperAdminRealtime } from "@/lib/useRealtime";

const LiveCtx = createContext<PresenceSnapshot | null>(null);

export function MonitorLiveProvider({
  initial,
  children,
}: {
  initial: PresenceSnapshot;
  children: React.ReactNode;
}) {
  const [snap, setSnap] = useState<PresenceSnapshot>(initial);
  useSuperAdminRealtime<PresenceSnapshot>("presence", (p) => {
    if (p && typeof p.totalLive === "number" && p.byTenant) setSnap(p);
  });
  return <LiveCtx.Provider value={snap}>{children}</LiveCtx.Provider>;
}

/** Total live visitors across all tenants. */
export function LiveNow({ initial }: { initial: number }) {
  const snap = useContext(LiveCtx);
  const n = snap ? snap.totalLive : initial;
  return <>{n.toLocaleString("en-US")}</>;
}

/** Per-tenant live cell for the table. */
export function TenantLiveCell({ id, initial }: { id: number; initial: number }) {
  const snap = useContext(LiveCtx);
  const live = snap ? (snap.byTenant[id] ?? 0) : initial;
  return live > 0 ? (
    <span className="inline-flex items-center gap-1 font-semibold text-emerald-600">
      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> {live.toLocaleString("en-US")}
    </span>
  ) : (
    <span className="text-zinc-300">0</span>
  );
}
