"use client";

import { useRouter, useSearchParams } from "next/navigation";
import SuperDateRangePicker from "../SuperDateRangePicker";

function toDateStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/**
 * Monitoring date filter — uses the tenant-style SuperDateRangePicker (calendar
 * + presets). Drives the page via URL searchParams that resolveRange() reads:
 *   - all time      → ?range=all
 *   - any date span → ?range=custom&from=YYYY-MM-DD&to=YYYY-MM-DD
 * The server still defaults to last-30-days when no params are present.
 */
export default function RangeFilter({ base = "/superadmin/monitoring" }: { base?: string }) {
  const router = useRouter();
  const sp = useSearchParams();

  // Current selection → picker's from/to. Map preset keys (and the no-param
  // default = 30d) onto concrete dates so the picker highlights/labels them.
  const range = sp.get("range");
  let from = sp.get("from") || "";
  let to = sp.get("to") || "";
  if (!from && !to && range !== "all") {
    const today = new Date();
    const back = (n: number) => toDateStr(new Date(today.getTime() - n * 86_400_000));
    if (range === "7d") { from = back(7); to = toDateStr(today); }
    else if (range === "30d") { from = back(30); to = toDateStr(today); }
    else if (range === "90d") { from = back(90); to = toDateStr(today); }
    else if (range === "custom") { /* no dates → leave empty */ }
    else { from = to = toDateStr(today); } // default = today (also handles "today")
  }

  function onChange(f: string, t: string) {
    const next = new URLSearchParams();
    if (!f && !t) next.set("range", "all");
    else { next.set("range", "custom"); next.set("from", f); next.set("to", t); }
    router.push(`${base}?${next.toString()}`);
  }

  return <SuperDateRangePicker from={from} to={to} onChange={onChange} />;
}
