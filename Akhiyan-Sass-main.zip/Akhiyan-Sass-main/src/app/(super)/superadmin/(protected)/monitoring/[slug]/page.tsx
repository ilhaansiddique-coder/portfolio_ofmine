/**
 * Per-tenant monitoring drill-down — daily revenue/orders trend, recent orders,
 * top products, over the selected date range.
 */
import Link from "next/link";
import { notFound } from "next/navigation";
import { FiArrowLeft, FiExternalLink, FiSettings } from "react-icons/fi";
import { resolveRange, tenantDetail } from "@/lib/superadmin-metrics";
import RangeFilter from "../RangeFilter";

export const dynamic = "force-dynamic";

const money = (n: number) => "৳" + Math.round(n).toLocaleString("en-US");
const num = (n: number) => n.toLocaleString("en-US");

export default async function TenantMonitorPage({
  params, searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ range?: string; from?: string; to?: string }>;
}) {
  const { slug } = await params;
  const range = resolveRange(await searchParams);
  const d = await tenantDetail(slug, range);
  if (!d.found) notFound();

  const maxRev = Math.max(1, ...d.daily.map((x) => x.revenue));

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link href={`/superadmin/monitoring?range=${range.key}`} className="inline-flex items-center gap-1 text-sm text-zinc-500 hover:underline">
            <FiArrowLeft className="h-3.5 w-3.5" /> Monitoring
          </Link>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">{d.name}</h1>
          <p className="font-mono text-sm text-zinc-500">{d.slug} · {range.label}</p>
        </div>
        <div className="flex items-center gap-2">
          <RangeFilter base={`/superadmin/monitoring/${d.slug}`} />
          <Link href={`/superadmin/tenants/${d.slug}`} className="inline-flex items-center gap-1 rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-600 hover:bg-zinc-50">
            <FiSettings className="h-3.5 w-3.5" /> Manage
          </Link>
        </div>
      </header>

      {!d.reachable ? (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-6 text-sm text-rose-700">
          This tenant&apos;s data is unavailable (status: {d.status}, DB unreachable).
        </div>
      ) : (
        <>
          <section className="grid grid-cols-2 gap-4 sm:max-w-md">
            <Stat label="Orders" value={num(d.totals.orders)} />
            <Stat label="Revenue" value={money(d.totals.revenue)} />
          </section>

          {/* Daily revenue trend (inline SVG bars) */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm">
            <h2 className="mb-4 text-sm font-semibold text-zinc-800">Daily revenue</h2>
            {d.daily.length === 0 ? (
              <p className="text-sm text-zinc-400">No orders in this range.</p>
            ) : (
              <div className="flex items-end gap-1 overflow-x-auto" style={{ height: 160 }}>
                {d.daily.map((x) => (
                  <div key={x.day} className="group flex min-w-[10px] flex-1 flex-col items-center justify-end" title={`${x.day}: ${money(x.revenue)} · ${num(x.orders)} orders`}>
                    <div
                      className="w-full rounded-t bg-gradient-to-t from-[#16b1ec] to-[#88d544] transition-opacity group-hover:opacity-80"
                      style={{ height: `${Math.max(2, Math.round((x.revenue / maxRev) * 140))}px` }}
                    />
                  </div>
                ))}
              </div>
            )}
            {d.daily.length > 0 && (
              <div className="mt-2 flex justify-between text-[10px] text-zinc-400">
                <span>{d.daily[0].day}</span>
                <span>{d.daily[d.daily.length - 1].day}</span>
              </div>
            )}
          </section>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Recent orders */}
            <section className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
              <div className="border-b border-zinc-100 px-5 py-3 text-sm font-semibold text-zinc-800">Recent orders</div>
              {d.recent.length === 0 ? <p className="p-5 text-sm text-zinc-400">None.</p> : (
                <ul className="divide-y divide-zinc-100 text-sm">
                  {d.recent.map((o) => (
                    <li key={o.id} className="flex items-center justify-between px-5 py-2.5">
                      <span className="font-mono text-xs text-zinc-500">#{o.id}</span>
                      <span className="capitalize text-xs text-zinc-500">{o.status}</span>
                      <span className="text-xs text-zinc-400">{o.at.slice(0, 10)}</span>
                      <span className="font-semibold text-zinc-800">{money(o.total)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* Top products */}
            <section className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
              <div className="border-b border-zinc-100 px-5 py-3 text-sm font-semibold text-zinc-800">Top products</div>
              {d.topProducts.length === 0 ? <p className="p-5 text-sm text-zinc-400">None.</p> : (
                <ul className="divide-y divide-zinc-100 text-sm">
                  {d.topProducts.map((p, i) => (
                    <li key={p.name + i} className="flex items-center justify-between gap-3 px-5 py-2.5">
                      <span className="min-w-0 truncate text-zinc-700">{p.name}</span>
                      <span className="shrink-0 text-xs text-zinc-400">{num(p.qty)} sold</span>
                      <span className="shrink-0 font-semibold text-zinc-800">{money(p.revenue)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-zinc-500">{label}</p>
      <p className="mt-1 text-2xl font-bold tracking-tight text-zinc-900">{value}</p>
    </div>
  );
}
