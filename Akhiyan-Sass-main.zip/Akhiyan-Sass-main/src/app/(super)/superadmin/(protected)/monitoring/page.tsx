/**
 * Super-admin Monitoring — cross-tenant business metrics with a date filter.
 * Shows selected-range figures next to all-time, per tenant + platform totals.
 * (Part 1: business metrics. Health/issues + live users land in later parts.)
 */
import Link from "next/link";
import { FiActivity, FiShoppingCart, FiDollarSign, FiUsers, FiServer, FiAlertTriangle, FiDatabase } from "react-icons/fi";
import { resolveRange, collectMetrics, type TenantMetric } from "@/lib/superadmin-metrics";
import { getLiveCounts, getTotalLive } from "@/lib/presence";
import RangeFilter from "./RangeFilter";
import PurgeCacheButton from "../PurgeCacheButton";
import { MonitorLiveProvider, LiveNow, TenantLiveCell } from "./MonitorLive";

export const dynamic = "force-dynamic";

function money(n: number) {
  return "৳" + Math.round(n).toLocaleString("en-US");
}
function num(n: number) {
  return n.toLocaleString("en-US");
}

export default async function MonitoringPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string; from?: string; to?: string }>;
}) {
  const sp = await searchParams;
  const range = resolveRange(sp);
  const { tenants, totals, dbHealth, issueTenants } = await collectMetrics(range);
  const live = getLiveCounts();
  const totalLive = getTotalLive();
  const byTenant: Record<number, number> = {};
  for (const [id, n] of live) byTenant[id] = n;

  return (
    <MonitorLiveProvider initial={{ totalLive, byTenant }}>
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
            <FiActivity className="text-[#16b1ec]" /> Monitoring
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            Cross-tenant business metrics · <span className="font-medium text-zinc-700">{range.label}</span>
            {totals.unreachable > 0 && (
              <span className="ml-2 rounded-full bg-rose-50 px-2 py-0.5 text-xs font-medium text-rose-600">
                {totals.unreachable} tenant DB unreachable
              </span>
            )}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PurgeCacheButton />
          <RangeFilter />
        </div>
      </header>

      {/* Platform totals — range value (big) + all-time (sub) */}
      <section className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-wide text-emerald-700">Live now</p>
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
            </span>
          </div>
          <p className="mt-2 text-2xl font-bold tracking-tight text-emerald-900"><LiveNow initial={totalLive} /></p>
          <p className="mt-0.5 text-xs text-emerald-600/70">visitors online now</p>
        </div>
        <Stat icon={FiShoppingCart} tone="brand" label="Orders" value={num(totals.rangeOrders)} sub={`${num(totals.allOrders)} all-time`} />
        <Stat icon={FiDollarSign} tone="emerald" label="Revenue" value={money(totals.rangeRevenue)} sub={`${money(totals.allRevenue)} all-time`} />
        <Stat icon={FiUsers} tone="violet" label="New customers" value={num(totals.rangeCustomers)} sub={`${num(totals.allCustomers)} all-time`} />
        <Stat icon={FiServer} tone="amber" label="Tenants online" value={`${totals.reachable}`} sub={`${totals.unreachable} unreachable`} />
      </section>

      {/* DB connection health */}
      {dbHealth && (
        <section className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-sm font-semibold text-zinc-800">
              <FiDatabase className="h-4 w-4 text-zinc-400" /> Database connections
            </span>
            <span className={`text-sm font-semibold ${dbHealth.ok ? "text-emerald-600" : "text-rose-600"}`}>
              {dbHealth.total} / {dbHealth.max}
            </span>
          </div>
          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-zinc-100">
            <div
              className={`h-full rounded-full ${dbHealth.ok ? "bg-emerald-500" : "bg-rose-500"}`}
              style={{ width: `${Math.min(100, Math.round((dbHealth.total / dbHealth.max) * 100))}%` }}
            />
          </div>
          <p className="mt-1.5 text-xs text-zinc-400">
            {dbHealth.active} active · {dbHealth.idle} idle · {dbHealth.ok ? "healthy" : "near limit — consider raising max_connections"}
          </p>
        </section>
      )}

      {/* Issues / health flags */}
      {issueTenants.length > 0 && (
        <section className="overflow-hidden rounded-2xl border border-amber-200 bg-amber-50/40 shadow-sm">
          <div className="flex items-center gap-2 border-b border-amber-200/70 px-5 py-3.5 text-sm font-semibold text-amber-800">
            <FiAlertTriangle className="h-4 w-4" /> Needs attention ({issueTenants.length})
          </div>
          <ul className="divide-y divide-amber-100">
            {issueTenants.map((t) => (
              <li key={t.id} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3">
                <Link href={`/superadmin/tenants/${t.slug}`} className="min-w-0">
                  <span className="font-medium text-zinc-800 hover:text-[#0b87c4]">{t.name || t.slug}</span>
                  <span className="ml-2 font-mono text-xs text-zinc-400">{t.slug}</span>
                </Link>
                <span className="flex flex-wrap gap-1.5">
                  {t.issues.map((iss) => (
                    <span key={iss} className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                      /unreachable|expired|failed|suspended|stuck/.test(iss)
                        ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700"
                    }`}>{iss}</span>
                  ))}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Per-tenant table */}
      <section className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
        <div className="border-b border-zinc-100 px-5 py-3.5 text-sm font-semibold text-zinc-800">
          Per-tenant — {range.label} <span className="font-normal text-zinc-400">(all-time in grey)</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-zinc-50/70 text-left text-xs font-semibold uppercase tracking-wide text-zinc-400">
              <tr>
                <th className="px-5 py-2.5">Tenant</th>
                <th className="px-5 py-2.5 text-right">Live</th>
                <th className="px-5 py-2.5 text-right">Orders</th>
                <th className="px-5 py-2.5 text-right">Revenue</th>
                <th className="px-5 py-2.5 text-right">New customers</th>
                <th className="px-5 py-2.5">Last order</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {tenants.length === 0 ? (
                <tr><td colSpan={6} className="p-6 text-center text-zinc-500">No tenants.</td></tr>
              ) : tenants.map((t) => <Row key={t.id} t={t} live={live.get(t.id) || 0} rangeKey={range.key} />)}
            </tbody>
          </table>
        </div>
      </section>
    </div>
    </MonitorLiveProvider>
  );
}

function Row({ t, live, rangeKey }: { t: TenantMetric; live: number; rangeKey: string }) {
  return (
    <tr className="transition-colors hover:bg-[#16b1ec]/5">
      <td className="px-5 py-3">
        <Link href={`/superadmin/monitoring/${t.slug}?range=${rangeKey}`} className="flex items-center gap-2">
          <span className={`h-2 w-2 shrink-0 rounded-full ${
            t.status !== "active" ? "bg-zinc-300" : t.reachable ? "bg-emerald-500" : "bg-rose-500"
          }`} title={t.status !== "active" ? t.status : t.reachable ? "online" : "DB unreachable"} />
          <span className="min-w-0">
            <span className="block truncate font-medium text-zinc-800">{t.name || t.slug}</span>
            <span className="block font-mono text-xs text-zinc-400">{t.slug}</span>
          </span>
        </Link>
      </td>
      <td className="px-5 py-3 text-right">
        <TenantLiveCell id={t.id} initial={live} />
      </td>
      <Cell range={num(t.rangeOrders)} all={`${num(t.allOrders)}`} />
      <Cell range={money(t.rangeRevenue)} all={money(t.allRevenue)} />
      <Cell range={num(t.rangeCustomers)} all={`${num(t.allCustomers)}`} />
      <td className="px-5 py-3 text-xs text-zinc-500">
        {t.lastOrderAt ? t.lastOrderAt.slice(0, 10) : (t.reachable ? "—" : <span className="text-rose-500">unreachable</span>)}
      </td>
    </tr>
  );
}

function Cell({ range, all }: { range: string; all: string }) {
  return (
    <td className="px-5 py-3 text-right">
      <span className="block font-semibold text-zinc-800">{range}</span>
      <span className="block text-xs text-zinc-400">{all}</span>
    </td>
  );
}

const TONES: Record<string, string> = {
  brand: "bg-[#16b1ec]/10 text-[#0b87c4]",
  emerald: "bg-emerald-50 text-emerald-600",
  violet: "bg-violet-50 text-violet-600",
  amber: "bg-amber-50 text-amber-600",
};

function Stat({
  icon: Icon, tone, label, value, sub,
}: {
  icon: React.ComponentType<{ className?: string }>; tone: string; label: string; value: string; sub: string;
}) {
  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wide text-zinc-500">{label}</p>
        <span className={`grid h-8 w-8 place-items-center rounded-lg ${TONES[tone]}`}><Icon className="h-4 w-4" /></span>
      </div>
      <p className="mt-2 text-2xl font-bold tracking-tight text-zinc-900">{value}</p>
      <p className="mt-0.5 text-xs text-zinc-400">{sub}</p>
    </div>
  );
}
