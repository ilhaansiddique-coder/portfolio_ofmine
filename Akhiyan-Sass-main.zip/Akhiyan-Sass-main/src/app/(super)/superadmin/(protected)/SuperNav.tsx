"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  FiGrid, FiServer, FiInbox, FiPackage, FiShare2, FiActivity, FiBarChart2,
} from "react-icons/fi";

const ITEMS = [
  { href: "/superadmin", label: "Dashboard", icon: FiGrid, exact: true },
  { href: "/superadmin/monitoring", label: "Monitoring", icon: FiBarChart2 },
  { href: "/superadmin/tenants", label: "Tenants", icon: FiServer },
  { href: "/superadmin/signups", label: "Signups", icon: FiInbox },
  { href: "/superadmin/plans", label: "Plans", icon: FiPackage },
  { href: "/superadmin/affiliates", label: "Affiliates", icon: FiShare2 },
  { href: "/superadmin/activity", label: "Activity", icon: FiActivity },
];

export default function SuperNav() {
  const pathname = usePathname() || "";
  return (
    <nav className="flex items-center gap-1 text-sm">
      {ITEMS.map(({ href, label, icon: Icon, exact }) => {
        const active = exact ? pathname === href : pathname.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            className={[
              "flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-medium transition-colors",
              active
                ? "bg-[#16b1ec]/10 text-[#0b87c4] ring-1 ring-inset ring-[#16b1ec]/20"
                : "text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900",
            ].join(" ")}
          >
            <Icon className="h-4 w-4" />
            <span className="hidden md:inline">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
