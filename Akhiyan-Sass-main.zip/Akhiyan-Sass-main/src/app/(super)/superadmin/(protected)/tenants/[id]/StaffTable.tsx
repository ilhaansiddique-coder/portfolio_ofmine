"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

interface Member {
  id: number;
  name: string;
  email: string | null;
  role: string;
  createdAt: string | null;
}

export default function StaffTable({
  tenantId,
  tenantSlug,
  members,
  initialAdminEmail,
  initialAdminPassword,
}: {
  tenantId: number;
  tenantSlug: string;
  members: Member[];
  initialAdminEmail: string | null;
  initialAdminPassword: string | null;
}) {
  const router = useRouter();
  const [reveal, setReveal] = useState<Record<number, boolean>>({});
  const [storedPw, setStoredPw] = useState(initialAdminPassword);
  const [storedEmail, setStoredEmail] = useState(initialAdminEmail);
  const [busy, setBusy] = useState(false);
  const [removing, setRemoving] = useState<number | null>(null);
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  function toggle(id: number) {
    setReveal((r) => ({ ...r, [id]: !r[id] }));
  }

  async function copy(text: string, key: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied((c) => (c === key ? null : c)), 1500);
    } catch {
      /* ignored */
    }
  }

  async function resetPassword() {
    if (!confirm(`Reset admin password for "${tenantSlug}"? The current admin will need to use the new password to log in.`)) return;
    setBusy(true);
    setErr("");
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}/reset-admin-password`, { method: "POST" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setStoredEmail(j.adminEmail);
      setStoredPw(j.adminPassword);
      const adminMember = members.find((m) => m.email === j.adminEmail);
      if (adminMember) setReveal((r) => ({ ...r, [adminMember.id]: true }));
      router.refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
    }
  }

  async function removeUser(m: Member) {
    if (!confirm(`Remove ${m.email || m.name} (${m.role}) from "${tenantSlug}"? This cannot be undone.`)) return;
    setRemoving(m.id);
    setErr("");
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}/staff/${m.id}`, { method: "DELETE" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      router.refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setRemoving(null);
    }
  }

  return (
    <div className="space-y-3">
      {err && (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{err}</div>
      )}

      <div className="flex items-center justify-end">
        <button
          onClick={() => setShowAdd((v) => !v)}
          className="inline-flex items-center gap-1.5 rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100"
        >
          <PlusIcon /> {showAdd ? "Cancel" : "Add user"}
        </button>
      </div>

      {showAdd && (
        <AddUserForm
          tenantId={tenantId}
          onCreated={() => {
            setShowAdd(false);
            router.refresh();
          }}
          onError={setErr}
        />
      )}

      {members.length === 0 ? (
        <div className="rounded-lg border border-zinc-200 bg-white p-6 text-sm text-zinc-500">
          No staff/admin users — owner has not created any yet.
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
          <table className="w-full text-sm">
            <thead className="bg-zinc-50 text-left text-xs font-medium uppercase tracking-wide text-zinc-500">
              <tr>
                <th className="px-4 py-2.5">Email</th>
                <th className="px-4 py-2.5">Name</th>
                <th className="px-4 py-2.5">Role</th>
                <th className="px-4 py-2.5">Password</th>
                <th className="px-4 py-2.5">Joined</th>
                <th className="px-4 py-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {members.map((m) => {
                const hasStored = m.email && m.email === storedEmail && storedPw;
                const isRevealed = reveal[m.id];
                const isInitialAdmin = !!(initialAdminEmail && m.email === initialAdminEmail);
                return (
                  <tr key={m.id}>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs">{m.email || "—"}</span>
                        {m.email && (
                          <button
                            onClick={() => copy(m.email!, `email-${m.id}`)}
                            title="Copy email"
                            className="rounded p-1 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700"
                          >
                            {copied === `email-${m.id}` ? <CheckIcon /> : <CopyIcon />}
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-2.5">{m.name}</td>
                    <td className="px-4 py-2.5">
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${m.role === "admin" ? "bg-orange-100 text-orange-700" : "bg-zinc-100 text-zinc-700"}`}>
                        {m.role}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      {hasStored ? (
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs">
                            {isRevealed ? storedPw : "••••••••••••"}
                          </span>
                          <button
                            onClick={() => toggle(m.id)}
                            title={isRevealed ? "Hide" : "Reveal"}
                            className="rounded p-1 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700"
                          >
                            {isRevealed ? <EyeOffIcon /> : <EyeIcon />}
                          </button>
                          <button
                            onClick={() => copy(storedPw!, `pw-${m.id}`)}
                            title="Copy password"
                            className="rounded p-1 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700"
                          >
                            {copied === `pw-${m.id}` ? <CheckIcon /> : <CopyIcon />}
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-zinc-400 italic">
                          not stored
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-xs text-zinc-500">
                      {m.createdAt ? m.createdAt.slice(0, 10) : "—"}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <button
                        onClick={() => removeUser(m)}
                        disabled={removing === m.id || isInitialAdmin}
                        title={isInitialAdmin ? "Initial admin — use Reset admin password" : "Remove user"}
                        className="inline-flex items-center gap-1 rounded-md border border-rose-200 bg-white px-2.5 py-1 text-xs font-medium text-rose-700 hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        <TrashIcon />
                        {removing === m.id ? "Removing…" : "Remove"}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="flex items-center justify-between rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
        <div>
          Initial admin password is regenerated and stored on the control plane. If the tenant changes their password, this entry goes stale — click Reset to issue a new one.
        </div>
        <button
          onClick={resetPassword}
          disabled={busy}
          className="rounded-md border border-amber-300 bg-white px-3 py-1.5 text-xs font-medium text-amber-800 hover:bg-amber-100 disabled:opacity-50"
        >
          {busy ? "Resetting…" : "Reset admin password"}
        </button>
      </div>
    </div>
  );
}

function AddUserForm({
  tenantId,
  onCreated,
  onError,
}: {
  tenantId: number;
  onCreated: () => void;
  onError: (msg: string) => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"admin" | "staff">("staff");
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  function suggestPassword() {
    // 12-char URL-safe random
    const bytes = new Uint8Array(9);
    crypto.getRandomValues(bytes);
    const s = btoa(String.fromCharCode(...bytes)).replace(/[+/=]/g, "");
    setPassword(s.slice(0, 12));
    setShowPw(true);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    onError("");
    setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}/staff`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, role }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      onCreated();
    } catch (e) {
      onError(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      onSubmit={submit}
      className="grid gap-3 rounded-lg border border-zinc-200 bg-white p-4 md:grid-cols-2"
    >
      <div>
        <label className="mb-1 block text-xs font-medium text-zinc-600">Name</label>
        <input
          required
          minLength={2}
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full rounded-md border border-zinc-300 px-3 py-1.5 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
        />
      </div>
      <div>
        <label className="mb-1 block text-xs font-medium text-zinc-600">Email</label>
        <input
          required
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded-md border border-zinc-300 px-3 py-1.5 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
        />
      </div>
      <div>
        <label className="mb-1 block text-xs font-medium text-zinc-600">Role</label>
        <select
          value={role}
          onChange={(e) => setRole(e.target.value as "admin" | "staff")}
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
        >
          <option value="staff">Staff</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div>
        <label className="mb-1 block text-xs font-medium text-zinc-600">Password (min 8)</label>
        <div className="flex gap-2">
          <input
            required
            minLength={8}
            type={showPw ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="flex-1 rounded-md border border-zinc-300 px-3 py-1.5 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
          />
          <button
            type="button"
            onClick={() => setShowPw((v) => !v)}
            className="rounded-md border border-zinc-300 bg-white px-2 py-1.5 text-xs text-zinc-600 hover:bg-zinc-50"
          >
            {showPw ? "Hide" : "Show"}
          </button>
          <button
            type="button"
            onClick={suggestPassword}
            className="rounded-md border border-zinc-300 bg-white px-2 py-1.5 text-xs text-zinc-600 hover:bg-zinc-50"
          >
            Generate
          </button>
        </div>
      </div>
      <div className="md:col-span-2 flex items-center justify-end gap-2">
        <button
          type="submit"
          disabled={busy}
          className="rounded-md bg-zinc-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:bg-zinc-300"
        >
          {busy ? "Creating…" : "Create user"}
        </button>
      </div>
    </form>
  );
}

function EyeIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}
function EyeOffIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" />
      <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
      <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61" />
      <line x1="2" y1="2" x2="22" y2="22" />
    </svg>
  );
}
function CopyIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <path d="M10 11v6M14 11v6" />
      <path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" />
    </svg>
  );
}
