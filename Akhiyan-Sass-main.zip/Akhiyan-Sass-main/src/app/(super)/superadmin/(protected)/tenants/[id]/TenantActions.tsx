"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function TenantActions({ tenantId, tenantSlug, status }: {
  tenantId: number; tenantSlug: string; status: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function call(path: string, body?: unknown) {
    setErr("");
    setBusy(true);
    try {
      const res = await fetch(path, {
        method: "POST",
        headers: body ? { "Content-Type": "application/json" } : {},
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.message || j.error || `HTTP ${res.status}`);
      }
      router.refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
    }
  }

  /**
   * Real login as the tenant admin user. Mints a short-lived token on the
   * superadmin side, then redirects to the tenant's host where the token
   * is exchanged for a normal tenant-admin session cookie. Cleanly
   * separated from the superadmin session — both can coexist.
   */
  async function loginAsAdmin() {
    setErr("");
    setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}/login-as-admin`, { method: "POST" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      window.location.href = j.redirectTo;
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
      setBusy(false);
    }
  }

  /**
   * Impersonate — overlays the superadmin's identity onto the tenant
   * dashboard via a parent-domain cookie. Audit log shows "[SuperAdmin] X
   * did Y" so every action is traceable back to the real super-admin.
   * Use for support / read-only inspection. Use "Login as admin" when
   * you want to act AS the tenant admin (audit logs show the actual user).
   */
  async function impersonate() {
    setErr("");
    setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}/impersonate`, { method: "POST" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      window.location.href = j.redirect || "/dashboard";
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
      setBusy(false);
    }
  }

  async function suspend() {
    if (!confirm(`Suspend "${tenantSlug}"? Visitors will get 404 until resumed.`)) return;
    await call(`/api/v1/superadmin/tenants/${tenantId}/suspend`);
  }
  async function resume() {
    await call(`/api/v1/superadmin/tenants/${tenantId}/resume`);
  }
  async function destroy() {
    const confirmed = prompt(`Permanently delete tenant + drop its DB.\nType the slug "${tenantSlug}" to confirm:`);
    if (confirmed !== tenantSlug) {
      if (confirmed != null) alert("Slug didn't match. Aborted.");
      return;
    }
    setErr("");
    setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirmSlug: tenantSlug }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.message || `HTTP ${res.status}`);
      }
      window.location.href = "/superadmin/tenants";
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3">
      {err && (
        <div className="rounded-md border border-rose-300 bg-rose-50 p-2 text-sm text-rose-700">
          {err}
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        {status === "active" && (
          <>
            <button
              onClick={loginAsAdmin}
              disabled={busy}
              title="Sign you in as the tenant's actual admin user. Separate from your super-admin session."
              className="rounded-md border border-orange-300 bg-orange-50 px-3 py-1.5 text-xs font-medium text-orange-700 hover:bg-orange-100 disabled:opacity-50"
            >
              🔑 Login as admin
            </button>
            <button
              onClick={impersonate}
              disabled={busy}
              title="View the dashboard AS the admin while keeping your super-admin identity (audit shows [SuperAdmin])."
              className="rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-50"
            >
              👁 Impersonate
            </button>
          </>
        )}
        {status !== "suspended" && (
          <button
            onClick={suspend}
            disabled={busy}
            className="rounded-md border border-amber-300 bg-amber-50 px-3 py-1.5 text-xs font-medium text-amber-700 hover:bg-amber-100 disabled:opacity-50"
          >
            Suspend
          </button>
        )}
        {status === "suspended" && (
          <button
            onClick={resume}
            disabled={busy}
            className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-100 disabled:opacity-50"
          >
            Resume
          </button>
        )}
        <button
          onClick={destroy}
          disabled={busy}
          className="rounded-md border border-rose-300 bg-rose-50 px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-100 disabled:opacity-50"
        >
          Delete tenant
        </button>
      </div>
    </div>
  );
}
