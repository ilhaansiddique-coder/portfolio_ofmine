"use client";

/**
 * Permissions card with horizontal tabs.
 *
 * Layout matches the reference: role selector top-right, Grant all /
 * Revoke all / Save bar above tabs, group tabs across the top, items
 * (label + key + switch) below.
 *
 * Changes are staged locally — Save commits to the server in one PATCH.
 * Realtime broadcast hits the tenant's dashboards on commit so disabled
 * features disappear from their nav within ms.
 */
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  FEATURE_GROUPS,
  hasFeature,
  type TenantFeatures,
} from "@/lib/tenant-features";

export default function PermissionsCard({
  tenantId,
  initialFeatures,
}: {
  tenantId: number;
  initialFeatures: TenantFeatures;
}) {
  const router = useRouter();
  const [active, setActive] = useState(FEATURE_GROUPS[0].id);

  const initial = useMemo(() => sanitize(initialFeatures), [initialFeatures]);
  const [saved, setSaved] = useState<Record<string, boolean>>(initial);
  const [pending, setPending] = useState<Record<string, boolean>>(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  const isDirty = JSON.stringify(saved) !== JSON.stringify(pending);

  function toggle(key: string, on: boolean) {
    setPending((p) => {
      const next = { ...p };
      if (on) delete next[key];
      else next[key] = false;
      return next;
    });
  }

  function grantAll() {
    setPending({});
  }

  function toggleGroup(groupId: string, on: boolean) {
    const group = FEATURE_GROUPS.find((g) => g.id === groupId);
    if (!group) return;
    setPending((p) => {
      const next = { ...p };
      for (const f of group.features) {
        if (on) delete next[f.key];
        else next[f.key] = false;
      }
      return next;
    });
  }

  function revokeAll() {
    const next: Record<string, boolean> = {};
    for (const g of FEATURE_GROUPS) for (const f of g.features) next[f.key] = false;
    setPending(next);
  }

  function discard() {
    setPending(saved);
    setErr("");
    setMsg("");
  }

  async function save() {
    setErr(""); setMsg(""); setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ features: pending }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setSaved(pending);
      setMsg("Saved.");
      router.refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
    }
  }

  const activeGroup = FEATURE_GROUPS.find((g) => g.id === active) ?? FEATURE_GROUPS[0];

  return (
    <div className="overflow-hidden rounded-xl border border-zinc-200 bg-white">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 border-b border-zinc-200 px-5 py-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldIcon />
            <h3 className="text-lg font-semibold">Permissions</h3>
          </div>
          <p className="mt-1 max-w-2xl text-sm text-zinc-500">
            Permissions apply to the tenant&apos;s admin AND all staff users. Disabling a
            feature here hides it from the sidebar and blocks direct URL access.
            Changes save with a single click and push live to the tenant in real time.
          </p>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap items-center justify-end gap-3 border-b border-zinc-200 bg-zinc-50/40 px-5 py-3">
        <div className="flex items-center gap-1.5">
          <button
            onClick={grantAll}
            disabled={busy}
            className="inline-flex items-center gap-1.5 rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-50"
          >
            <CheckIcon /> Grant all
          </button>
          <button
            onClick={revokeAll}
            disabled={busy}
            className="inline-flex items-center gap-1.5 rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-50"
          >
            <BanIcon /> Revoke all
          </button>
          {isDirty && (
            <button
              onClick={discard}
              disabled={busy}
              className="rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-50"
            >
              Discard
            </button>
          )}
          <button
            onClick={save}
            disabled={busy || !isDirty}
            className="inline-flex items-center gap-1.5 rounded-md bg-zinc-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:bg-zinc-300 disabled:text-zinc-500"
          >
            <SaveIcon /> {busy ? "Saving…" : "Save"}
          </button>
        </div>
      </div>

      {(err || msg) && (
        <div className={`px-5 py-2 text-xs ${err ? "bg-rose-50 text-rose-700" : "bg-emerald-50 text-emerald-700"}`}>
          {err || msg}
        </div>
      )}

      {/* Group tabs */}
      <div className="flex overflow-x-auto border-b border-zinc-200 bg-zinc-50/30 px-2">
        {FEATURE_GROUPS.map((g) => {
          const isActive = g.id === active;
          return (
            <button
              key={g.id}
              onClick={() => setActive(g.id)}
              className={[
                "whitespace-nowrap px-4 py-2.5 text-sm transition-colors",
                isActive
                  ? "rounded-md bg-white font-semibold text-zinc-900 shadow-sm my-1.5"
                  : "text-zinc-500 hover:text-zinc-900",
              ].join(" ")}
            >
              {g.label}
            </button>
          );
        })}
      </div>

      {/* Active tab feature list */}
      <ul className="divide-y divide-zinc-100">
        <li className="flex items-center justify-between gap-4 bg-zinc-50/60 px-5 py-3.5">
          <div className="min-w-0">
            <span className="text-sm font-semibold text-zinc-900">Toggle all</span>
            <p className="mt-0.5 text-xs text-zinc-500">
              Enable or disable every option in {activeGroup.label}.
            </p>
          </div>
          <Toggle
            on={activeGroup.features.every((f) => hasFeature(pending, f.key))}
            disabled={busy}
            onChange={(v) => toggleGroup(activeGroup.id, v)}
          />
        </li>
        {activeGroup.features.map((f) => {
          const on = hasFeature(pending, f.key);
          const wasOn = hasFeature(saved, f.key);
          const dirty = on !== wasOn;
          return (
            <li key={f.key} className="flex items-center justify-between gap-4 px-5 py-3.5">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{f.label}</span>
                  {dirty && (
                    <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-medium uppercase text-amber-700">
                      unsaved
                    </span>
                  )}
                </div>
                {f.description && (
                  <p className="mt-0.5 text-xs text-zinc-500">{f.description}</p>
                )}
              </div>
              <Toggle on={on} disabled={busy} onChange={(v) => toggle(f.key, v)} />
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Toggle({ on, disabled, onChange }: { on: boolean; disabled?: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      disabled={disabled}
      onClick={() => onChange(!on)}
      className={[
        "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors disabled:opacity-50",
        on ? "bg-emerald-500" : "bg-zinc-300",
      ].join(" ")}
    >
      <span
        className={[
          "inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform",
          on ? "translate-x-5" : "translate-x-0.5",
        ].join(" ")}
      />
    </button>
  );
}

function sanitize(input: TenantFeatures): Record<string, boolean> {
  if (!input || typeof input !== "object") return {};
  const out: Record<string, boolean> = {};
  for (const [k, v] of Object.entries(input)) {
    if (v === false) out[k] = false;
  }
  return out;
}

// ─── inline icons ──────────────────────────────────────────────────────
function ShieldIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-700">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function BanIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
    </svg>
  );
}
function SaveIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
      <polyline points="17 21 17 13 7 13 7 21" />
      <polyline points="7 3 7 8 15 8" />
    </svg>
  );
}
