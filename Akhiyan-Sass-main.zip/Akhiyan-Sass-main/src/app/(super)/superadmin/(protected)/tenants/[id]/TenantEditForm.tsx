"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

interface PlanOption { slug: string; name: string }

export default function TenantEditForm({ tenantId, name, plan, primaryDomain, plans, baseDomain = "example.com" }: {
  tenantId: number;
  name: string;
  plan: string;
  primaryDomain: string | null;
  plans: PlanOption[];
  baseDomain?: string;
}) {
  const router = useRouter();
  const [n, setN] = useState(name);
  const [p, setP] = useState(plan);
  const [d, setD] = useState(primaryDomain || "");
  const [applyPlanFeatures, setApplyPlanFeatures] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  const planChanged = p !== plan;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setMsg(""); setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: n,
          plan: p,
          primaryDomain: d || null,
          applyPlanFeatures: planChanged ? applyPlanFeatures : false,
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setMsg("Saved.");
      router.refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={save} className="space-y-3">
      {err && (
        <div className="rounded-md border border-rose-300 bg-rose-50 p-2 text-sm text-rose-700">{err}</div>
      )}
      {msg && (
        <div className="rounded-md border border-emerald-300 bg-emerald-50 p-2 text-sm text-emerald-700">{msg}</div>
      )}

      <Field label="Store name">
        <input
          value={n}
          onChange={(e) => setN(e.target.value)}
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        />
      </Field>
      <Field label="Plan">
        <select
          value={p}
          onChange={(e) => setP(e.target.value)}
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        >
          {plans.length === 0 && <option value={p}>{p || "(none)"}</option>}
          {plans.map((pl) => (
            <option key={pl.slug} value={pl.slug}>{pl.name}</option>
          ))}
        </select>
      </Field>
      {planChanged && (
        <label className="flex items-start gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
          <input
            type="checkbox"
            checked={applyPlanFeatures}
            onChange={(e) => setApplyPlanFeatures(e.target.checked)}
            className="mt-0.5 h-3.5 w-3.5"
          />
          <span>
            <strong>Apply this plan&apos;s permissions on save.</strong> Replaces any per-tenant
            feature overrides with the plan&apos;s default map. Uncheck to change the plan label
            without touching the current permissions.
          </span>
        </label>
      )}
      <Field label="Custom domain" hint={`Optional. CNAME → cname.${baseDomain}, then enter the domain here.`}>
        <input
          value={d}
          onChange={(e) => setD(e.target.value)}
          placeholder="shop.example.com"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm font-mono outline-none focus:border-orange-500"
        />
      </Field>

      <button
        type="submit"
        disabled={busy}
        className="rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:opacity-50"
      >
        {busy ? "Saving…" : "Save changes"}
      </button>
    </form>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-medium">{label}</div>
      {children}
      {hint && <div className="mt-1 text-xs text-zinc-500">{hint}</div>}
    </label>
  );
}
