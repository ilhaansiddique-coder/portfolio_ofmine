"use client";

import Link from "next/link";
import { useState, useEffect, useRef, useCallback } from "react";

interface CreatedResponse {
  tenant: { id: number; slug: string; name: string; status: string; primaryDomain: string | null };
  adminEmail: string;
  adminPassword: string;
  neonProjectId: string;
}

type SlugStatus =
  | { state: "idle" }
  | { state: "checking" }
  | { state: "available"; hostname: string }
  | { state: "taken"; reason: string }
  | { state: "invalid"; reason: string };

const SLUG_RE = /^[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?$/;

interface InitialValues {
  slug?: string;
  name?: string;
  ownerEmail?: string;
  ownerName?: string;
  plan?: string;
}

export function CreateTenantForm({
  baseDomain = "example.com",
  initial,
  affCode,
  signupId,
}: {
  baseDomain?: string;
  initial?: InitialValues;
  affCode?: string | null;
  signupId?: number | null;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [created, setCreated] = useState<CreatedResponse | null>(null);
  // Non-null while the background provisioning is running + we're polling.
  const [provisioningId, setProvisioningId] = useState<number | null>(null);
  const [slugStatus, setSlugStatus] = useState<SlugStatus>({ state: "idle" });
  // Subscription validity chosen at creation. Default to a 1-month trial so no
  // tenant is ever created without an expiry; super-admin can pick lifetime
  // explicitly. "custom" reveals a days input.
  const [validityPlan, setValidityPlan] = useState<string>("1m");
  const [customDays, setCustomDays] = useState<string>("30");

  // Debounce timer ref — cleared on each keystroke.
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // AbortController so an in-flight check is cancelled when the user keeps typing.
  const abortRef = useRef<AbortController | null>(null);

  const checkSlug = useCallback(async (raw: string) => {
    const slug = raw.trim().toLowerCase();

    if (!slug) {
      setSlugStatus({ state: "idle" });
      return;
    }
    if (!SLUG_RE.test(slug)) {
      setSlugStatus({ state: "invalid", reason: "Lowercase a-z, 0-9, hyphens. 2–32 chars." });
      return;
    }

    // Cancel previous in-flight request.
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    setSlugStatus({ state: "checking" });
    try {
      const res = await fetch(
        `/api/v1/superadmin/tenants/check-slug?slug=${encodeURIComponent(slug)}`,
        { signal: ctrl.signal },
      );
      const json = await res.json();
      if (json.available) {
        setSlugStatus({ state: "available", hostname: json.hostname ?? `${slug}.${baseDomain}` });
      } else {
        setSlugStatus({ state: "taken", reason: json.reason ?? "already in use" });
      }
    } catch (e) {
      if ((e as Error)?.name === "AbortError") return; // superseded by newer keystroke
      // Network error — don't block the form, just clear status.
      setSlugStatus({ state: "idle" });
    }
  }, [baseDomain]);

  function onSlugChange(e: React.ChangeEvent<HTMLInputElement>) {
    const val = e.target.value;
    // Cancel previous debounce timer.
    if (debounceRef.current) clearTimeout(debounceRef.current);
    // Fast-path: clear status immediately while the user is still typing.
    setSlugStatus(val.trim() ? { state: "checking" } : { state: "idle" });
    // Debounce the actual API call by 400 ms.
    debounceRef.current = setTimeout(() => checkSlug(val), 400);
  }

  // Cleanup on unmount.
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
      abortRef.current?.abort();
    };
  }, []);

  // Prefilled slug (provisioning from a signup order) → run an initial check.
  useEffect(() => {
    if (initial?.slug) checkSlug(initial.slug);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const canSubmit =
    !busy &&
    slugStatus.state !== "taken" &&
    slugStatus.state !== "invalid" &&
    slugStatus.state !== "checking";

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!canSubmit) return;
    setErr("");
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/v1/superadmin/tenants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slug: String(fd.get("slug") || "").trim().toLowerCase(),
          name: String(fd.get("name") || "").trim(),
          ownerEmail: String(fd.get("ownerEmail") || "").trim().toLowerCase(),
          ownerName: String(fd.get("ownerName") || "").trim(),
          plan: String(fd.get("plan") || "starter"),
          // Subscription validity → server computes expiresAt. "custom" carries days.
          validityPlan,
          ...(validityPlan === "custom" ? { customDays: Number(customDays) || 0 } : {}),
          dbProvider: String(fd.get("dbProvider") || "neon"),
          primaryDomain: String(fd.get("primaryDomain") || "").trim().toLowerCase() || null,
          skipDnsCheck: fd.get("skipDnsCheck") === "on",
          // Affiliate attribution + signup-order linkage (when provisioning from an order)
          ...(affCode ? { affCode } : {}),
          ...(signupId ? { signupId } : {}),
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);

      // Provisioning is now ASYNC: the POST returns 202 immediately with the
      // tenant id + status "provisioning", then the server creates the DB /
      // migrates / seeds in the background (avoids the proxy timeout that used
      // to surface as "Unexpected end of JSON input"). Poll the tenant detail
      // endpoint until status flips to active (read credentials) or failed.
      const tenantId: number = j.tenant.id;
      setProvisioningId(tenantId);
      const result = await pollUntilDone(tenantId);
      if (result.status === "failed") {
        throw new Error(result.error || "Provisioning failed — see tenant audit log.");
      }
      setCreated({
        tenant: { id: result.id, slug: result.slug, name: result.name, status: result.status, primaryDomain: result.primaryDomain },
        adminEmail: result.initialAdminEmail || "(see tenant detail)",
        adminPassword: result.initialAdminPassword || "(see tenant detail)",
        neonProjectId: "",
      });
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    } finally {
      setBusy(false);
      setProvisioningId(null);
    }
  }

  // Poll GET /tenants/<id> until status is no longer "provisioning".
  async function pollUntilDone(id: number): Promise<any> {
    const deadline = Date.now() + 5 * 60_000; // 5 min cap
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 2500));
      try {
        const r = await fetch(`/api/v1/superadmin/tenants/${id}`, { headers: { Accept: "application/json" } });
        if (!r.ok) continue;
        const d = await r.json();
        const t = d.tenant;
        if (t && t.status !== "provisioning") {
          if (t.status === "failed") {
            const failLog = (d.audit || []).find((a: any) => a.action === "tenant.create.failed");
            return { status: "failed", error: failLog?.details?.error };
          }
          return t; // active
        }
      } catch { /* transient — keep polling */ }
    }
    throw new Error("Provisioning timed out after 5 min. Check the tenant list.");
  }

  if (created) {
    return (
      <div className="space-y-4 rounded-lg border border-emerald-300 bg-emerald-50 p-6">
        <div>
          <h2 className="text-lg font-semibold text-emerald-900">✓ Tenant provisioned</h2>
          <p className="text-sm text-emerald-700">
            Save the admin password — it won&apos;t be shown again.
          </p>
        </div>
        <dl className="space-y-2 text-sm text-zinc-800">
          <Row label="Tenant ID" value={String(created.tenant.id)} />
          <Row label="Slug" value={created.tenant.slug} mono />
          <Row label="Name" value={created.tenant.name} />
          <Row label="Status" value={created.tenant.status} />
          {created.tenant.primaryDomain && (
            <Row label="Custom domain" value={created.tenant.primaryDomain} mono />
          )}
          {created.neonProjectId && <Row label="Neon project" value={created.neonProjectId} mono />}
          <hr className="border-emerald-200" />
          <Row label="Admin email" value={created.adminEmail} mono />
          <Row label="Admin password" value={created.adminPassword} mono highlight />
        </dl>
        <div className="flex gap-2 pt-2">
          <Link
            href={`/superadmin/tenants/${created.tenant.slug}`}
            className="rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700"
          >
            Open tenant detail
          </Link>
          <button
            type="button"
            onClick={() => setCreated(null)}
            className="rounded-md border border-zinc-300 px-3 py-2 text-sm hover:bg-zinc-100"
          >
            Create another
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-lg border border-zinc-200 bg-white p-6">
      {err && (
        <div className="rounded-md border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700">
          {err}
        </div>
      )}

      {/* ── Slug field with live availability badge ── */}
      <div>
        <label className="block">
          <div className="mb-1 text-sm font-medium">Slug (subdomain)</div>
          <div className="relative">
            <input
              name="slug"
              required
              defaultValue={initial?.slug}
              // Char class has `-` at the end so it's treated literally
              // (not as a range). Earlier form had `-` mid-class which Chrome
              // rejects under the unicode-sets parser used for HTML `pattern`.
              pattern="[a-z0-9](?:[-a-z0-9]{0,30}[a-z0-9])?"
              placeholder="acme"
              autoCapitalize="off"
              autoComplete="off"
              onChange={onSlugChange}
              className={[
                "w-full rounded-md border bg-white px-3 py-2 pr-10 text-sm font-mono lowercase outline-none",
                slugStatus.state === "taken" || slugStatus.state === "invalid"
                  ? "border-rose-400 focus:border-rose-500"
                  : slugStatus.state === "available"
                    ? "border-emerald-400 focus:border-emerald-500"
                    : "border-zinc-300 focus:border-orange-500",
              ].join(" ")}
            />
            {/* Status icon — right-aligned inside the input */}
            <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-base">
              {slugStatus.state === "checking" && (
                <SpinnerIcon />
              )}
              {slugStatus.state === "available" && (
                <span className="text-emerald-500" title="Available">✓</span>
              )}
              {(slugStatus.state === "taken" || slugStatus.state === "invalid") && (
                <span className="text-rose-500" title="Not available">✗</span>
              )}
            </span>
          </div>

          {/* Status line below the input */}
          <div className="mt-1 min-h-[1.25rem] text-xs">
            {slugStatus.state === "idle" && (
              <span className="text-zinc-500">
                Becomes <span className="font-mono">{"<slug>"}. {baseDomain}</span>. Lowercase a-z, 0-9, hyphens.
              </span>
            )}
            {slugStatus.state === "checking" && (
              <span className="text-zinc-400">Checking availability…</span>
            )}
            {slugStatus.state === "available" && (
              <span className="font-medium text-emerald-600">
                ✓ Available — <span className="font-mono">{slugStatus.hostname}</span>
              </span>
            )}
            {slugStatus.state === "taken" && (
              <span className="font-medium text-rose-600">
                ✗ {slugStatus.reason}
              </span>
            )}
            {slugStatus.state === "invalid" && (
              <span className="font-medium text-rose-600">
                ✗ {slugStatus.reason}
              </span>
            )}
          </div>
        </label>

        {/* Hard block banner — only when slug is explicitly taken */}
        {slugStatus.state === "taken" && (
          <div className="mt-2 rounded-md border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700">
            This subdomain is already in use. Choose a different slug to continue.
          </div>
        )}
      </div>

      <Field label="Store name">
        <input
          name="name"
          required
          defaultValue={initial?.name}
          placeholder="Acme Store"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        />
      </Field>

      <Field label="Plan">
        <select
          name="plan"
          defaultValue={initial?.plan ?? "starter"}
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        >
          <option value="starter">Starter</option>
          <option value="pro">Pro</option>
          <option value="enterprise">Enterprise</option>
        </select>
      </Field>

      {/* Subscription validity — sets expiresAt at creation. The store
        * auto-shows an expired/renew page once this lapses; the owner gets a
        * 7-day warning banner + email before then. "Lifetime" = no expiry. */}
      <Field label="Subscription validity" hint="When the subscription expires. The store goes offline (renew/contact-support page) after this date; the owner is warned 7 days ahead. Pick Lifetime for no expiry.">
        <select
          name="validityPlan"
          value={validityPlan}
          onChange={(e) => setValidityPlan(e.target.value)}
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        >
          <option value="7d">7 days</option>
          <option value="1m">1 month</option>
          <option value="3m">3 months</option>
          <option value="6m">6 months</option>
          <option value="1y">1 year</option>
          <option value="lifetime">Lifetime (no expiry)</option>
          <option value="custom">Custom…</option>
        </select>
      </Field>

      {validityPlan === "custom" && (
        <Field label="Custom validity (days)">
          <input
            type="number"
            min={1}
            value={customDays}
            onChange={(e) => setCustomDays(e.target.value)}
            placeholder="30"
            className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
          />
        </Field>
      )}

      {/* DB provider — choose where this tenant's data lives.
        * Coolify (self-hosted) = no per-tenant cold-start, no Neon quota,
        *   single shared cluster. Best for small/medium tenants.
        * Neon (serverless cloud) = isolated project per tenant, auto-scale,
        *   pay-as-go. Best for larger/spiky tenants. */}
      <Field label="Database host" hint="Where this tenant's database lives. Pick Coolify for self-hosted Postgres on our server, Neon for an isolated serverless project.">
        <select
          name="dbProvider"
          defaultValue="coolify"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        >
          <option value="coolify">Coolify Postgres (self-hosted, default)</option>
          <option value="neon">Neon (serverless cloud)</option>
        </select>
      </Field>

      <hr className="border-zinc-200" />

      <Field label="Owner full name">
        <input
          name="ownerName"
          defaultValue={initial?.ownerName}
          placeholder="John Doe"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        />
      </Field>

      <Field label="Owner email" hint="Becomes the admin login for the new tenant.">
        <input
          name="ownerEmail"
          type="email"
          required
          defaultValue={initial?.ownerEmail}
          placeholder="owner@acme.com"
          autoCapitalize="off"
          autoComplete="off"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
        />
      </Field>

      <hr className="border-zinc-200" />

      <Field
        label="Custom domain (optional)"
        hint={
          <>
            Add now or later. Customer must CNAME their domain to{" "}
            <code className="rounded bg-zinc-100 px-1 font-mono">cname.{baseDomain}</code>{" "}
            (or an A record for apex domains).
            Leave blank to use <code className="rounded bg-zinc-100 px-1 font-mono">{`<slug>.${baseDomain}`}</code>.
          </>
        }
      >
        <input
          name="primaryDomain"
          type="text"
          placeholder="shop.acme.com"
          autoCapitalize="off"
          autoComplete="off"
          className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm font-mono outline-none focus:border-orange-500"
        />
      </Field>

      <label className="flex items-start gap-2 text-xs text-zinc-600">
        <input type="checkbox" name="skipDnsCheck" className="mt-0.5" />
        <span>
          <strong>Skip DNS verification</strong> on creation — saves the domain even if
          the CNAME isn&apos;t live yet. Use when pre-staging ahead of DNS propagation.
        </span>
      </label>

      <div className="rounded-md border border-zinc-200 bg-zinc-50 p-3 text-xs text-zinc-600">
        Provisioning will: create a fresh Neon project, run schema migrations,
        seed defaults, generate a random admin password, and return it. Takes ~30–60s.
      </div>

      {provisioningId && (
        <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-sm text-blue-800">
          <span className="inline-block animate-pulse">●</span>{" "}
          Provisioning tenant #{provisioningId} in the background — creating database, running migrations, seeding admin user. This can take up to a minute; the credentials will appear here when it&apos;s ready.
        </div>
      )}
      <button
        type="submit"
        disabled={!canSubmit}
        title={
          slugStatus.state === "taken"
            ? "Change the slug to a unique value before creating"
            : slugStatus.state === "checking"
              ? "Waiting for availability check…"
              : undefined
        }
        className="w-full rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {busy
          ? "Provisioning… (waiting for completion)"
          : slugStatus.state === "taken"
            ? "Choose a unique slug to continue"
            : slugStatus.state === "checking"
              ? "Checking availability…"
              : "Create tenant"}
      </button>
    </form>
  );
}

// ── Tiny inline spinner ──────────────────────────────────────────────────────

function SpinnerIcon() {
  return (
    <svg
      className="h-4 w-4 animate-spin text-zinc-400"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
    >
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
      />
    </svg>
  );
}

// ── Shared field wrapper ─────────────────────────────────────────────────────

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-medium">{label}</div>
      {children}
      {hint && <div className="mt-1 text-xs text-zinc-500">{hint}</div>}
    </label>
  );
}

// ── Success card row ─────────────────────────────────────────────────────────

function Row({
  label,
  value,
  mono,
  highlight,
}: {
  label: string;
  value: string;
  mono?: boolean;
  highlight?: boolean;
}) {
  return (
    <div className="flex">
      <dt className="w-32 shrink-0 text-zinc-500">{label}</dt>
      <dd
        className={[
          mono ? "font-mono text-xs break-all" : "",
          highlight ? "rounded bg-emerald-100 px-2" : "",
        ]
          .filter(Boolean)
          .join(" ")}
      >
        {value}
      </dd>
    </div>
  );
}
