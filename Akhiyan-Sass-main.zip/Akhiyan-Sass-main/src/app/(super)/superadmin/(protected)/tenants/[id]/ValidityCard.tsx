"use client";

/**
 * Super-admin validity controls for a single tenant.
 *
 * Three independent sub-forms, each PATCHes the same /tenants/:id endpoint:
 *   1. Plan picker  — sets validityPlan + recomputes expiresAt from `now`.
 *   2. Direct override — caller types an exact expiresAt (datetime-local).
 *   3. Quick extend — adds N days on top of current expiresAt (or `now` if
 *      already expired).
 *
 * All three clear `warningSentAt` server-side so the next 7-day window
 * triggers a fresh email.
 */

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { VALIDITY_PLAN_LABELS, type ValidityPlan } from "@/lib/tenant-validity";

type Props = {
  tenantId: number;
  initialPlan: ValidityPlan | null;
  initialExpiresAt: string | null; // ISO
  warningSentAt: string | null;
};

const PLAN_ORDER: ValidityPlan[] = ["7d", "1m", "3m", "6m", "1y", "lifetime", "custom"];

export default function ValidityCard({ tenantId, initialPlan, initialExpiresAt, warningSentAt }: Props) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [plan, setPlan] = useState<ValidityPlan>(initialPlan ?? "1m");
  const [customDays, setCustomDays] = useState<number>(30);
  const [overrideAt, setOverrideAt] = useState<string>(
    initialExpiresAt ? new Date(initialExpiresAt).toISOString().slice(0, 16) : "",
  );
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  const expiry = initialExpiresAt ? new Date(initialExpiresAt) : null;
  const now = new Date();
  const daysLeft = expiry ? Math.ceil((expiry.getTime() - now.getTime()) / 86_400_000) : null;
  const isLapsed = expiry !== null && expiry <= now;
  const isLifetime = initialPlan === "lifetime" || (initialPlan !== null && expiry === null);

  async function patch(body: Record<string, unknown>, label: string) {
    setErr(""); setMsg("");
    try {
      const res = await fetch(`/api/v1/superadmin/tenants/${tenantId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setMsg(`${label} ✓`);
      startTransition(() => router.refresh());
    } catch (e) {
      setErr(e instanceof Error ? e.message : "failed");
    }
  }

  function applyPlan() {
    if (plan === "custom" && (!Number.isFinite(customDays) || customDays <= 0)) {
      setErr("Enter a positive number of days");
      return;
    }
    void patch({ validityPlan: plan, customDays: plan === "custom" ? customDays : undefined }, "Plan applied");
  }
  function applyOverride() {
    if (!overrideAt) { setErr("Pick a date/time"); return; }
    // datetime-local is naive; treat as local then convert to ISO.
    const iso = new Date(overrideAt).toISOString();
    void patch({ expiresAt: iso }, "Expiry overridden");
  }
  function extend(days: number) { void patch({ extendDays: days }, `Extended +${days}d`); }
  function clearWarn()         { void patch({ clearWarning: true }, "Warning flag reset"); }

  return (
    <div className="space-y-5 rounded-lg border border-zinc-200 bg-white p-5">
      <div className="flex items-baseline justify-between">
        <h3 className="text-sm font-semibold uppercase tracking-wide text-zinc-500">Subscription validity</h3>
        <SummaryBadge isLifetime={isLifetime} daysLeft={daysLeft} isLapsed={isLapsed} />
      </div>

      <dl className="grid grid-cols-2 gap-3 text-sm">
        <Row label="Current plan" value={initialPlan ? VALIDITY_PLAN_LABELS[initialPlan] : "—"} />
        <Row label="Expires at" value={isLifetime ? "Never (lifetime)" : expiry ? expiry.toLocaleString() : "—"} />
        <Row label="Days left" value={isLifetime ? "∞" : daysLeft !== null ? `${daysLeft}d` : "—"} />
        <Row label="Warning sent" value={warningSentAt ? new Date(warningSentAt).toLocaleString() : "—"} />
      </dl>

      {(err || msg) && (
        <div className={`rounded-md border p-2 text-xs ${err ? "border-rose-300 bg-rose-50 text-rose-700" : "border-emerald-300 bg-emerald-50 text-emerald-700"}`}>
          {err || msg}
        </div>
      )}

      {/* 1. Plan picker */}
      <fieldset className="space-y-2 border-t border-zinc-100 pt-4">
        <legend className="text-xs font-medium uppercase tracking-wide text-zinc-500">Set plan</legend>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={plan}
            onChange={(e) => setPlan(e.target.value as ValidityPlan)}
            disabled={pending}
            className="rounded-md border border-zinc-300 px-2 py-1.5 text-sm"
          >
            {PLAN_ORDER.map((p) => (
              <option key={p} value={p}>{VALIDITY_PLAN_LABELS[p]}</option>
            ))}
          </select>
          {plan === "custom" && (
            <input
              type="number"
              min={1}
              value={customDays}
              onChange={(e) => setCustomDays(Number(e.target.value))}
              disabled={pending}
              className="w-24 rounded-md border border-zinc-300 px-2 py-1.5 text-sm"
              placeholder="Days"
            />
          )}
          <button
            onClick={applyPlan}
            disabled={pending}
            className="rounded-md bg-zinc-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-zinc-800 disabled:opacity-50"
          >
            Apply plan
          </button>
        </div>
        <p className="text-xs text-zinc-500">Resets the clock from now. Lifetime = never expires.</p>
      </fieldset>

      {/* 2. Direct override */}
      <fieldset className="space-y-2 border-t border-zinc-100 pt-4">
        <legend className="text-xs font-medium uppercase tracking-wide text-zinc-500">Direct override</legend>
        <div className="flex flex-wrap items-center gap-2">
          <input
            type="datetime-local"
            value={overrideAt}
            onChange={(e) => setOverrideAt(e.target.value)}
            disabled={pending}
            className="rounded-md border border-zinc-300 px-2 py-1.5 text-sm"
          />
          <button
            onClick={applyOverride}
            disabled={pending}
            className="rounded-md border border-zinc-300 px-3 py-1.5 text-xs font-medium hover:bg-zinc-50 disabled:opacity-50"
          >
            Save expiry
          </button>
          <button
            onClick={() => patch({ expiresAt: null, validityPlan: "lifetime" }, "Set to lifetime")}
            disabled={pending}
            className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-100 disabled:opacity-50"
          >
            Set lifetime
          </button>
        </div>
      </fieldset>

      {/* 3. Quick extend */}
      <fieldset className="space-y-2 border-t border-zinc-100 pt-4">
        <legend className="text-xs font-medium uppercase tracking-wide text-zinc-500">Quick extend</legend>
        <div className="flex flex-wrap gap-2">
          {[7, 30, 90, 180, 365].map((d) => (
            <button
              key={d}
              onClick={() => extend(d)}
              disabled={pending || isLifetime}
              className="rounded-md border border-zinc-300 px-3 py-1.5 text-xs font-medium hover:bg-zinc-50 disabled:opacity-50"
            >
              +{d}d
            </button>
          ))}
        </div>
        {isLifetime && <p className="text-xs text-zinc-500">Lifetime tenants don't need extending.</p>}
      </fieldset>

      {warningSentAt && (
        <div className="border-t border-zinc-100 pt-4">
          <button
            onClick={clearWarn}
            disabled={pending}
            className="text-xs text-zinc-500 underline hover:text-zinc-700 disabled:opacity-50"
          >
            Reset warning flag (re-arm 7-day email)
          </button>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <>
      <dt className="text-zinc-500">{label}</dt>
      <dd className="font-medium text-zinc-900">{value}</dd>
    </>
  );
}

function SummaryBadge({ isLifetime, daysLeft, isLapsed }: { isLifetime: boolean; daysLeft: number | null; isLapsed: boolean }) {
  if (isLifetime) {
    return <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-medium text-emerald-700">Lifetime</span>;
  }
  if (isLapsed) {
    return <span className="rounded-full bg-rose-100 px-2.5 py-1 text-xs font-medium text-rose-700">Expired</span>;
  }
  if (daysLeft !== null && daysLeft <= 7) {
    return <span className="rounded-full bg-amber-100 px-2.5 py-1 text-xs font-medium text-amber-700">{daysLeft}d left</span>;
  }
  if (daysLeft !== null) {
    return <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-medium text-zinc-700">{daysLeft}d left</span>;
  }
  return <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-medium text-zinc-600">No expiry set</span>;
}
