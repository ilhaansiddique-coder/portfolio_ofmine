/**
 * Tenants list — clickable table with status pill + quick "open store" link.
 */
import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";
import { validityState } from "@/lib/tenant-validity";

export const dynamic = "force-dynamic";

export default async function TenantsListPage() {
  const tenants = await controlPrisma.tenant.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      slug: true,
      name: true,
      status: true,
      plan: true,
      primaryDomain: true,
      ownerEmail: true,
      createdAt: true,
      expiresAt: true,
    },
  });

  const baseDomain = process.env.BASE_DOMAIN || "contradigital.agency";
  const devPort = process.env.NODE_ENV === "production" ? "" : `:${process.env.PORT || "3005"}`;

  return (
    <div className="space-y-6">
      <header className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Tenants</h1>
          <p className="text-sm text-zinc-500">{tenants.length} total</p>
        </div>
        <Link
          href="/superadmin/tenants/new"
          className="rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700"
        >
          + Create tenant
        </Link>
      </header>

      <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-zinc-50 text-left text-xs font-medium uppercase tracking-wide text-zinc-500">
            <tr>
              <Th>Slug</Th>
              <Th>Name</Th>
              <Th>Plan</Th>
              <Th>Status</Th>
              <Th>Expiry</Th>
              <Th>Domain</Th>
              <Th>Owner</Th>
              <Th>Created</Th>
              <Th></Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100">
            {tenants.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-6 text-center text-zinc-500">
                  No tenants yet. <Link href="/superadmin/tenants/new" className="text-orange-600 hover:underline">Create one →</Link>
                </td>
              </tr>
            ) : (
              tenants.map((t) => {
                const storeUrl = t.primaryDomain
                  ? `https://${t.primaryDomain}`
                  : `http://${t.slug}.${baseDomain}${devPort}`;
                return (
                  <tr key={t.id}>
                    <Td>
                      <Link href={`/superadmin/tenants/${t.slug}`} className="font-mono text-orange-600 hover:underline">
                        {t.slug}
                      </Link>
                    </Td>
                    <Td>{t.name}</Td>
                    <Td className="capitalize">{t.plan}</Td>
                    <Td><StatusBadge status={t.status} /></Td>
                    <Td><ExpiryBadge expiresAt={t.expiresAt} /></Td>
                    <Td className="font-mono text-xs">{t.primaryDomain || `${t.slug}.${baseDomain}`}</Td>
                    <Td className="font-mono text-xs">{t.ownerEmail}</Td>
                    <Td className="text-zinc-500">{t.createdAt.toISOString().slice(0, 10)}</Td>
                    <Td>
                      <a href={storeUrl} target="_blank" rel="noreferrer" className="text-xs text-zinc-500 hover:underline">
                        open ↗
                      </a>
                    </Td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const color =
    status === "active" ? "bg-emerald-100 text-emerald-700"
    : status === "provisioning" ? "bg-amber-100 text-amber-700"
    : status === "suspended" ? "bg-rose-100 text-rose-700"
    : "bg-zinc-100 text-zinc-600";
  return <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${color}`}>{status}</span>;
}

function ExpiryBadge({ expiresAt }: { expiresAt: Date | null }) {
  const v = validityState(expiresAt);
  if (v.state === "ok" && v.daysLeft === null) {
    return <span className="text-xs text-zinc-400">Lifetime</span>;
  }
  const dateStr = expiresAt ? expiresAt.toISOString().slice(0, 10) : "";
  if (v.state === "expired") {
    return <span className="rounded-full bg-rose-100 px-2 py-0.5 text-xs font-medium text-rose-700" title={dateStr}>Expired</span>;
  }
  if (v.state === "expiring") {
    return <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700" title={dateStr}>{v.daysLeft}d left</span>;
  }
  return <span className="text-xs text-zinc-500" title={dateStr}>{v.daysLeft}d</span>;
}

function Th({ children }: { children?: React.ReactNode }) {
  return <th className="px-4 py-2.5 whitespace-nowrap">{children}</th>;
}
function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-2.5 whitespace-nowrap ${className}`}>{children}</td>;
}
