/**
 * Tenant detail — full info, live counts, members, DB, audit log + actions.
 */
import Link from "next/link";
import { notFound } from "next/navigation";
import { controlPrisma } from "@/lib/prisma-control";
import { getPrismaForDbUrl } from "@/lib/prisma-tenant";
import TenantActions from "./TenantActions";
import TenantEditForm from "./TenantEditForm";
import StaffTable from "./StaffTable";
import PermissionsCard from "./PermissionsCard";
import ValidityCard from "./ValidityCard";
import type { TenantFeatures } from "@/lib/tenant-features";
import type { ValidityPlan } from "@/lib/tenant-validity";

export const dynamic = "force-dynamic";

export default async function TenantDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  // The URL segment can be a numeric id (legacy links) OR a tenant slug
  // (/superadmin/tenants/<slug>). Resolve either — slug is the canonical link
  // now, but old numeric bookmarks keep working.
  const tenant = /^\d+$/.test(id)
    ? await controlPrisma.tenant.findUnique({ where: { id: Number(id) } })
    : await controlPrisma.tenant.findUnique({ where: { slug: id.toLowerCase() } });
  if (!tenant) notFound();

  const audit = await controlPrisma.auditLog.findMany({
    where: { tenantId: tenant.id },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  const planRows = await controlPrisma.plan.findMany({
    where: { isActive: true },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
    select: { slug: true, name: true },
  });

  // Live counts from the tenant DB. Best-effort — render nulls if unreachable.
  let liveCounts: { products: number; orders: number; users: number; customers: number } | null = null;
  let members: Array<{ id: number; name: string; email: string | null; role: string; createdAt: Date | null }> = [];
  if (tenant.status === "active" && tenant.dbUrl) {
    try {
      const tdb = getPrismaForDbUrl(tenant.dbUrl);
      const [products, orders, users, customers, staff] = await Promise.all([
        tdb.product.count(),
        tdb.order.count({ where: { status: { not: "trashed" } } }),
        tdb.user.count(),
        tdb.user.count({ where: { role: "customer" } }),
        tdb.user.findMany({
          where: { role: { in: ["admin", "staff"] } },
          select: { id: true, name: true, email: true, role: true, createdAt: true },
          orderBy: { id: "asc" },
        }),
      ]);
      liveCounts = { products, orders, users, customers };
      members = staff;
    } catch {
      liveCounts = null;
    }
  }

  const baseDomain = process.env.BASE_DOMAIN || "contradigital.agency";
  const devPort = process.env.NODE_ENV === "production" ? "" : `:${process.env.PORT || "3005"}`;
  const storeUrl = tenant.primaryDomain
    ? `https://${tenant.primaryDomain}`
    : `http://${tenant.slug}.${baseDomain}${devPort}`;

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <header>
        <Link href="/superadmin/tenants" className="text-sm text-zinc-500 hover:underline">← Tenants</Link>
        <div className="mt-1 flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="truncate text-2xl font-semibold tracking-tight">{tenant.name}</h1>
              <StatusBadge status={tenant.status} />
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-sm text-zinc-500">
              <span className="font-mono">{tenant.slug}</span>
              <span className="capitalize">· {tenant.plan}</span>
              {tenant.primaryDomain && <span>· {tenant.primaryDomain}</span>}
            </div>
          </div>
          <a
            href={storeUrl}
            target="_blank"
            rel="noreferrer"
            className="shrink-0 rounded-md border border-zinc-300 px-3 py-2 text-sm hover:bg-zinc-100"
          >
            Visit ↗
          </a>
        </div>
      </header>

      {/* ── Stats + live data ── */}
      <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat label="Status" value={tenant.status} />
        <Stat label="Plan" value={tenant.plan} />
        <Stat label="DB" value={tenant.dbName} mono />
        <Stat label="Created" value={tenant.createdAt.toISOString().slice(0, 10)} />
        {liveCounts && <>
          <Stat label="Products" value={liveCounts.products} />
          <Stat label="Orders" value={liveCounts.orders} />
          <Stat label="Users" value={liveCounts.users} />
          <Stat label="Customers" value={liveCounts.customers} />
        </>}
      </section>

      {/* ── Permissions ── */}
      <section>
        <SectionTitle>Permissions</SectionTitle>
        <PermissionsCard
          tenantId={tenant.id}
          initialFeatures={tenant.features as TenantFeatures}
        />
      </section>

      {/* ── Management ── */}
      <section className="grid gap-6 md:grid-cols-2">
        <Card title="Edit">
          <TenantEditForm
            tenantId={tenant.id}
            name={tenant.name}
            plan={tenant.plan}
            primaryDomain={tenant.primaryDomain}
            plans={planRows}
            baseDomain={baseDomain}
          />
        </Card>
        <div className="space-y-6">
          <ValidityCard
            tenantId={tenant.id}
            initialPlan={(tenant.validityPlan ?? null) as ValidityPlan | null}
            initialExpiresAt={tenant.expiresAt ? tenant.expiresAt.toISOString() : null}
            warningSentAt={tenant.warningSentAt ? tenant.warningSentAt.toISOString() : null}
          />
          <Card title="Actions">
            <TenantActions tenantId={tenant.id} tenantSlug={tenant.slug} status={tenant.status} />
          </Card>
        </div>
      </section>

      {/* ── Staff ── */}
      <section>
        <SectionTitle count={members.length}>Staff &amp; admins</SectionTitle>
        <StaffTable
          tenantId={tenant.id}
          tenantSlug={tenant.slug}
          members={members.map((m) => ({
            ...m,
            createdAt: m.createdAt?.toISOString() ?? null,
          }))}
          initialAdminEmail={tenant.initialAdminEmail}
          initialAdminPassword={tenant.initialAdminPassword}
        />
      </section>

      {/* ── Audit log ── */}
      <section>
        <details className="group rounded-lg border border-zinc-200 bg-white">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-5 py-3 text-sm font-semibold uppercase tracking-wide text-zinc-500 hover:bg-zinc-50">
            <span className="flex items-center gap-2">
              Audit log
              <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium normal-case tracking-normal text-zinc-600">{audit.length}</span>
            </span>
            <svg
              className="h-4 w-4 text-zinc-400 transition-transform group-open:rotate-180"
              viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
            >
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </summary>
          <div className="border-t border-zinc-200">
            {audit.length === 0 ? (
              <p className="p-6 text-sm text-zinc-500">No entries.</p>
            ) : (
              <ul className="divide-y divide-zinc-100 text-xs">
                {audit.map((row) => (
                  <li key={row.id} className="px-4 py-2.5">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-zinc-700">{row.action}</span>
                      <span className="text-zinc-400">{row.createdAt.toISOString().slice(0, 16).replace("T", " ")}</span>
                    </div>
                    {row.details && (
                      <pre className="mt-1 whitespace-pre-wrap text-[11px] text-zinc-500">
                        {JSON.stringify(row.details, null, 2)}
                      </pre>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </details>
      </section>
    </div>
  );
}

function Stat({ label, value, mono }: { label: string; value: string | number; mono?: boolean }) {
  return (
    <div className="rounded-lg border border-zinc-200 bg-white p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-zinc-500">{label}</p>
      <p className={`mt-1 text-xl font-semibold ${mono ? "font-mono text-sm break-all" : "capitalize"}`}>{value}</p>
    </div>
  );
}

function SectionTitle({ children, count }: { children: React.ReactNode; count?: number }) {
  return (
    <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wide text-zinc-500">
      {children}
      {typeof count === "number" && (
        <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium normal-case tracking-normal text-zinc-600">{count}</span>
      )}
    </h2>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-zinc-200 bg-white p-5">
      <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-zinc-500">{title}</h3>
      {children}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const color =
    status === "active" ? "bg-emerald-100 text-emerald-700"
    : status === "provisioning" ? "bg-amber-100 text-amber-700"
    : status === "suspended" ? "bg-rose-100 text-rose-700"
    : "bg-zinc-100 text-zinc-600";
  return <span className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${color}`}>{status}</span>;
}
