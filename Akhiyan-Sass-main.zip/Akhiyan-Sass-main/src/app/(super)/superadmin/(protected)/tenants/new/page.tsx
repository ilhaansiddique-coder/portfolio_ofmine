import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";
import { CreateTenantForm } from "./form";

export const dynamic = "force-dynamic";

type Ctx = { searchParams: Promise<{ signup?: string }> };

export default async function NewTenantPage({ searchParams }: Ctx) {
  const baseDomain = process.env.BASE_DOMAIN || "example.com";
  const { signup } = await searchParams;

  // When provisioning from a public signup order, prefill the form + carry
  // the affiliate code and order id through so the commission is credited and
  // the order is marked provisioned on success.
  let order = null;
  if (signup) {
    const id = Number(signup);
    if (id) {
      order = await controlPrisma.signupOrder.findUnique({ where: { id } });
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Create tenant</h1>
        <p className="text-sm text-zinc-500">
          Provisions a new isolated Neon database, runs schema, seeds defaults, and returns the owner&apos;s admin password.
        </p>
      </header>

      {order && (
        <div className="rounded-lg border border-orange-300 bg-orange-50 px-4 py-3 text-sm text-orange-800">
          Provisioning from signup order <strong>#{order.id}</strong>
          {order.affCode && <> · affiliate <span className="font-mono">{order.affCode}</span></>}.
          Fields are prefilled below. <Link href="/superadmin/signups" className="underline">Back to signups</Link>
        </div>
      )}

      <CreateTenantForm
        baseDomain={baseDomain}
        initial={order ? {
          slug: order.slug,
          name: order.storeName,
          ownerEmail: order.ownerEmail,
          ownerName: order.ownerName ?? undefined,
          plan: order.plan,
        } : undefined}
        affCode={order?.affCode ?? undefined}
        signupId={order?.id ?? undefined}
      />
    </div>
  );
}
