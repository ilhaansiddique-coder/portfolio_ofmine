/**
 * Plans index — lists every Plan row with quick stats and actions.
 *
 * "New plan" button routes to /superadmin/plans/new. Each row is a link
 * to /superadmin/plans/[id] for editing. Tenant counts are computed on
 * the fly so super admins can see plan adoption at a glance.
 */
import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";
import { FEATURE_GROUPS, hasFeature, type TenantFeatures } from "@/lib/tenant-features";

export const dynamic = "force-dynamic";

const ALL_KEYS = FEATURE_GROUPS.flatMap((g) => g.features.map((f) => f.key));

export default async function PlansIndexPage() {
  const plans = await controlPrisma.plan.findMany({
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });

  // Bulk-count tenants per plan so we don't N+1 the DB.
  const counts = await controlPrisma.tenant.groupBy({
    by: ["plan"],
    _count: { _all: true },
  });
  const countBySlug = new Map(counts.map((c) => [c.plan, c._count._all]));

  return (
    <div className="space-y-6">
      <header className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Plans</h1>
          <p className="mt-1 text-sm text-zinc-500">
            Bundle features and assign them to tenants. A tenant&apos;s plan determines
            its default permission map; per-tenant overrides still work afterward.
          </p>
        </div>
        <Link
          href="/superadmin/plans/new"
          className="rounded-md bg-zinc-900 px-3 py-2 text-sm font-medium text-white hover:bg-zinc-700"
        >
          + New plan
        </Link>
      </header>

      {plans.length === 0 ? (
        <div className="rounded-lg border border-zinc-200 bg-white p-10 text-center">
          <p className="text-sm text-zinc-500">No plans yet.</p>
          <Link
            href="/superadmin/plans/new"
            className="mt-3 inline-block rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-sm font-medium text-zinc-700 hover:bg-zinc-100"
          >
            Create your first plan
          </Link>
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
          <table className="w-full text-sm">
            <thead className="bg-zinc-50 text-left text-xs font-medium uppercase tracking-wide text-zinc-500">
              <tr>
                <th className="px-4 py-2.5">Plan</th>
                <th className="px-4 py-2.5">Slug</th>
                <th className="px-4 py-2.5 text-right">Enabled features</th>
                <th className="px-4 py-2.5 text-right">Monthly</th>
                <th className="px-4 py-2.5 text-right">Tenants</th>
                <th className="px-4 py-2.5 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {plans.map((p) => {
                const features = p.features as TenantFeatures;
                const enabledCount = ALL_KEYS.filter((k) => hasFeature(features, k)).length;
                const tenants = countBySlug.get(p.slug) ?? 0;
                return (
                  <tr key={p.id} className="hover:bg-zinc-50">
                    <td className="px-4 py-3">
                      <Link href={`/superadmin/plans/${p.id}`} className="font-medium text-zinc-900 hover:underline">
                        {p.name}
                      </Link>
                      {p.description && (
                        <p className="mt-0.5 text-xs text-zinc-500 line-clamp-1">{p.description}</p>
                      )}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-zinc-500">{p.slug}</td>
                    <td className="px-4 py-3 text-right text-xs text-zinc-600">
                      {enabledCount} / {ALL_KEYS.length}
                    </td>
                    <td className="px-4 py-3 text-right text-xs">
                      {p.priceMonthly != null ? `৳${p.priceMonthly.toLocaleString()}` : <span className="text-zinc-400">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-zinc-600">{tenants}</td>
                    <td className="px-4 py-3 text-right">
                      <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium ${p.isActive ? "bg-emerald-100 text-emerald-700" : "bg-zinc-200 text-zinc-600"}`}>
                        {p.isActive ? "active" : "inactive"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
