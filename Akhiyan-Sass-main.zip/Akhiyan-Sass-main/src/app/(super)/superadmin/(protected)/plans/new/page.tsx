import Link from "next/link";
import PlanEditor from "../PlanEditor";

export const dynamic = "force-dynamic";

export default function NewPlanPage() {
  return (
    <div className="space-y-6">
      <header>
        <Link href="/superadmin/plans" className="text-sm text-zinc-500 hover:underline">
          ← Plans
        </Link>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">New plan</h1>
        <p className="mt-1 text-sm text-zinc-500">
          Pick a slug, name, price, and toggle the features you want this plan to include.
        </p>
      </header>
      <PlanEditor mode="create" />
    </div>
  );
}
