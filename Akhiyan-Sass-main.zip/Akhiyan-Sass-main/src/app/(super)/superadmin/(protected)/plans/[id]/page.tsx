import Link from "next/link";
import { notFound } from "next/navigation";
import { controlPrisma } from "@/lib/prisma-control";
import PlanEditor from "../PlanEditor";

export const dynamic = "force-dynamic";

export default async function EditPlanPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const plan = await controlPrisma.plan.findUnique({ where: { id: Number(id) } });
  if (!plan) notFound();

  const tenantCount = await controlPrisma.tenant.count({ where: { plan: plan.slug } });

  return (
    <div className="space-y-6">
      <header>
        <Link href="/superadmin/plans" className="text-sm text-zinc-500 hover:underline">
          ← Plans
        </Link>
        <div className="mt-1 flex items-baseline gap-3">
          <h1 className="text-2xl font-semibold tracking-tight">{plan.name}</h1>
          <code className="text-sm text-zinc-500">{plan.slug}</code>
        </div>
      </header>
      <PlanEditor
        mode="edit"
        tenantCount={tenantCount}
        initial={{
          id: plan.id,
          slug: plan.slug,
          name: plan.name,
          description: plan.description ?? "",
          features: (plan.features as Record<string, boolean>) ?? {},
          priceMonthly: plan.priceMonthly?.toString() ?? "",
          priceYearly: plan.priceYearly?.toString() ?? "",
          isActive: plan.isActive,
          sortOrder: plan.sortOrder,
        }}
      />
    </div>
  );
}
