"use client";

/**
 * Shared editor used by /plans/new and /plans/[id]. Exposes the same
 * tabs-per-feature-group toggle UI as the per-tenant PermissionsCard so
 * super admins build plans in the same visual vocabulary they manage
 * tenants in.
 */
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { FEATURE_GROUPS, hasFeature, type TenantFeatures } from "@/lib/tenant-features";

interface PlanFormData {
  id?: number;
  slug: string;
  name: string;
  description: string;
  features: Record<string, boolean>;
  priceMonthly: string; // string in input, converted on save
  priceYearly: string;
  isActive: boolean;
  sortOrder: number;
}

export default function PlanEditor({
  initial,
  mode,
  tenantCount,
}: {
  initial?: Partial<PlanFormData>;
  mode: "create" | "edit";
  tenantCount?: number;
}) {
  const router = useRouter();
  const [form, setForm] = useState<PlanFormData>({
    id: initial?.id,
    slug: initial?.slug ?? "",
    name: initial?.name ?? "",
    description: initial?.description ?? "",
    features: initial?.features ?? {},
    priceMonthly: initial?.priceMonthly ?? "",
    priceYearly: initial?.priceYearly ?? "",
    isActive: initial?.isActive ?? true,
    sortOrder: initial?.sortOrder ?? 0,
  });
  const [active, setActive] = useState(FEATURE_GROUPS[0].id);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const featuresAsTenant: TenantFeatures = form.features;

  function patch<K extends keyof PlanFormData>(key: K, value: PlanFormData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function toggleFeature(key: string, on: boolean) {
    setForm((f) => {
      const next = { ...f.features };
      if (on) delete next[key];
      else next[key] = false;
      return { ...f, features: next };
    });
  }

  function toggleGroup(groupId: string, on: boolean) {
    const group = FEATURE_GROUPS.find((g) => g.id === groupId);
    if (!group) return;
    setForm((f) => {
      const next = { ...f.features };
      for (const fea of group.features) {
        if (on) delete next[fea.key];
        else next[fea.key] = false;
      }
      return { ...f, features: next };
    });
  }

  function grantAll() {
    patch("features", {});
  }
  function revokeAll() {
    const next: Record<string, boolean> = {};
    for (const g of FEATURE_GROUPS) for (const f of g.features) next[f.key] = false;
    patch("features", next);
  }

  async function save() {
    setErr(""); setBusy(true);
    try {
      const payload = {
        slug: form.slug.trim(),
        name: form.name.trim(),
        description: form.description.trim() || null,
        features: form.features,
        priceMonthly: form.priceMonthly === "" ? null : Number(form.priceMonthly),
        priceYearly: form.priceYearly === "" ? null : Number(form.priceYearly),
        isActive: form.isActive,
        sortOrder: Number(form.sortOrder) || 0,
      };
      const url = mode === "create"
        ? "/api/v1/superadmin/plans"
        : `/api/v1/superadmin/plans/${form.id}`;
      const method = mode === "create" ? "POST" : "PATCH";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      if (mode === "create") {
        router.push(`/superadmin/plans/${j.plan.id}`);
      } else {
        router.refresh();
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Save failed.");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!form.id) return;
    if (!confirm(`Delete plan "${form.name}"? This cannot be undone.`)) return;
    setErr(""); setBusy(true);
    try {
      const res = await fetch(`/api/v1/superadmin/plans/${form.id}`, { method: "DELETE" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      router.push("/superadmin/plans");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Delete failed.");
    } finally {
      setBusy(false);
    }
  }

  const activeGroup = useMemo(
    () => FEATURE_GROUPS.find((g) => g.id === active) ?? FEATURE_GROUPS[0],
    [active],
  );

  return (
    <div className="space-y-6">
      {err && (
        <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{err}</div>
      )}

      {/* Plan metadata */}
      <div className="grid gap-4 rounded-lg border border-zinc-200 bg-white p-5 md:grid-cols-2">
        <Field label="Name" required>
          <input
            value={form.name}
            onChange={(e) => patch("name", e.target.value)}
            className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
            placeholder="Advanced"
          />
        </Field>
        <Field label="Slug" required hint="Lowercase, dashes only. Used to assign this plan to tenants.">
          <input
            value={form.slug}
            disabled={mode === "edit"}
            onChange={(e) => patch("slug", e.target.value.toLowerCase())}
            className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm font-mono focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500 disabled:bg-zinc-100 disabled:text-zinc-500"
            placeholder="advanced"
          />
        </Field>
        <div className="md:col-span-2">
          <Field label="Description" hint="Shown to super admins as a tooltip when picking a plan.">
            <textarea
              value={form.description}
              onChange={(e) => patch("description", e.target.value)}
              rows={2}
              className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
              placeholder="What's included and who's it for?"
            />
          </Field>
        </div>
        <Field label="Monthly price (৳)" hint="Leave blank for custom-quote plans.">
          <input
            type="number"
            min={0}
            value={form.priceMonthly}
            onChange={(e) => patch("priceMonthly", e.target.value)}
            className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
            placeholder="2499"
          />
        </Field>
        <Field label="Yearly price (৳)">
          <input
            type="number"
            min={0}
            value={form.priceYearly}
            onChange={(e) => patch("priceYearly", e.target.value)}
            className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
          />
        </Field>
        <Field label="Sort order" hint="Lower numbers appear first.">
          <input
            type="number"
            value={form.sortOrder}
            onChange={(e) => patch("sortOrder", Number(e.target.value))}
            className="w-full rounded-md border border-zinc-300 px-3 py-2 text-sm focus:border-zinc-500 focus:outline-none focus:ring-1 focus:ring-zinc-500"
          />
        </Field>
        <div className="flex items-center">
          <label className="inline-flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) => patch("isActive", e.target.checked)}
              className="h-4 w-4"
            />
            Active (available to assign)
          </label>
        </div>
      </div>

      {/* Permissions */}
      <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        <div className="flex items-center justify-between border-b border-zinc-200 bg-zinc-50/40 px-5 py-3">
          <div>
            <p className="text-sm font-semibold">Permissions</p>
            <p className="text-xs text-zinc-500">
              Toggle features included in this plan. Tenants assigned to this plan inherit this exact map.
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={grantAll}
              disabled={busy}
              className="rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-50"
            >
              Grant all
            </button>
            <button
              onClick={revokeAll}
              disabled={busy}
              className="rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-100 disabled:opacity-50"
            >
              Revoke all
            </button>
          </div>
        </div>

        {/* Group tabs */}
        <div className="flex overflow-x-auto border-b border-zinc-200 bg-zinc-50/30 px-2">
          {FEATURE_GROUPS.map((g) => {
            const isActive = g.id === active;
            return (
              <button
                key={g.id}
                onClick={() => setActive(g.id)}
                className={[
                  "whitespace-nowrap px-4 py-2.5 text-sm transition-colors",
                  isActive
                    ? "rounded-md bg-white font-semibold text-zinc-900 shadow-sm my-1.5"
                    : "text-zinc-500 hover:text-zinc-900",
                ].join(" ")}
              >
                {g.label}
              </button>
            );
          })}
        </div>

        {/* Active tab feature list */}
        <ul className="divide-y divide-zinc-100">
          <li className="flex items-center justify-between gap-4 bg-zinc-50/60 px-5 py-3.5">
            <div>
              <span className="text-sm font-semibold text-zinc-900">Toggle all</span>
              <p className="mt-0.5 text-xs text-zinc-500">
                Enable or disable every option in {activeGroup.label}.
              </p>
            </div>
            <Toggle
              on={activeGroup.features.every((f) => hasFeature(featuresAsTenant, f.key))}
              disabled={busy}
              onChange={(v) => toggleGroup(activeGroup.id, v)}
            />
          </li>
          {activeGroup.features.map((f) => {
            const on = hasFeature(featuresAsTenant, f.key);
            return (
              <li key={f.key} className="flex items-center justify-between gap-4 px-5 py-3.5">
                <div className="min-w-0">
                  <span className="text-sm font-medium">{f.label}</span>
                  {f.description && (
                    <p className="mt-0.5 text-xs text-zinc-500">{f.description}</p>
                  )}
                </div>
                <Toggle on={on} disabled={busy} onChange={(v) => toggleFeature(f.key, v)} />
              </li>
            );
          })}
        </ul>
      </div>

      {/* Footer actions */}
      <div className="flex items-center justify-between">
        <div className="text-xs text-zinc-500">
          {mode === "edit" && tenantCount !== undefined && (
            <span>
              {tenantCount} tenant{tenantCount === 1 ? "" : "s"} on this plan.
              {tenantCount > 0 && " Saving updates the plan, but does NOT auto-apply to existing tenants — re-assign each tenant to push changes."}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {mode === "edit" && (
            <button
              onClick={remove}
              disabled={busy || (tenantCount ?? 0) > 0}
              title={tenantCount ? "Move tenants off this plan first" : "Delete plan"}
              className="rounded-md border border-rose-200 bg-white px-3 py-1.5 text-sm font-medium text-rose-700 hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Delete
            </button>
          )}
          <button
            onClick={save}
            disabled={busy}
            className="rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:bg-zinc-300"
          >
            {busy ? "Saving…" : mode === "create" ? "Create plan" : "Save changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  required,
  hint,
  children,
}: {
  label: string;
  required?: boolean;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-zinc-700">
        {label}
        {required && <span className="ml-0.5 text-rose-500">*</span>}
      </label>
      {children}
      {hint && <p className="mt-1 text-xs text-zinc-500">{hint}</p>}
    </div>
  );
}

function Toggle({ on, disabled, onChange }: { on: boolean; disabled?: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      disabled={disabled}
      onClick={() => onChange(!on)}
      className={[
        "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors disabled:opacity-50",
        on ? "bg-emerald-500" : "bg-zinc-300",
      ].join(" ")}
    >
      <span
        className={[
          "inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform",
          on ? "translate-x-5" : "translate-x-0.5",
        ].join(" ")}
      />
    </button>
  );
}
