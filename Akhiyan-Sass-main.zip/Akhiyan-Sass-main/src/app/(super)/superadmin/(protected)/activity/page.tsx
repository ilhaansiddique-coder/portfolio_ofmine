/**
 * Cross-tenant activity log — last 200 audit entries from the control plane.
 */
import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";

export const dynamic = "force-dynamic";

export default async function ActivityPage() {
  const rows = await controlPrisma.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      tenant: { select: { slug: true } },
      superAdmin: { select: { email: true } },
    },
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Activity</h1>
        <p className="text-sm text-zinc-500">Last 200 actions across all tenants.</p>
      </header>

      <div className="overflow-hidden rounded-lg border border-zinc-200 bg-white">
        {rows.length === 0 ? (
          <p className="p-6 text-sm text-zinc-500">No entries yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-zinc-50 text-left text-xs font-medium uppercase tracking-wide text-zinc-500">
              <tr>
                <Th>When</Th>
                <Th>Action</Th>
                <Th>Tenant</Th>
                <Th>Super admin</Th>
                <Th>Details</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {rows.map((r) => (
                <tr key={r.id}>
                  <Td className="text-xs text-zinc-500 whitespace-nowrap">
                    {r.createdAt.toISOString().slice(0, 16).replace("T", " ")}
                  </Td>
                  <Td className="font-mono text-xs">{r.action}</Td>
                  <Td>
                    {r.tenant?.slug ? (
                      <Link
                        href={`/superadmin/tenants/${r.tenantId}`}
                        className="font-mono text-xs text-orange-600 hover:underline"
                      >
                        {r.tenant.slug}
                      </Link>
                    ) : (
                      <span className="text-xs text-zinc-400">—</span>
                    )}
                  </Td>
                  <Td className="font-mono text-xs text-zinc-600">
                    {r.superAdmin?.email || "—"}
                  </Td>
                  <Td>
                    {r.details ? (
                      <pre className="max-w-md truncate text-[11px] text-zinc-500">
                        {JSON.stringify(r.details)}
                      </pre>
                    ) : (
                      <span className="text-xs text-zinc-400">—</span>
                    )}
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="px-4 py-2.5">{children}</th>;
}
function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <td className={`px-4 py-2.5 ${className}`}>{children}</td>;
}
