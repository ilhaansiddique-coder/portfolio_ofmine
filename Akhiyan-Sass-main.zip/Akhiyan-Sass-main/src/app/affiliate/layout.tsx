/**
 * Affiliate root layout — standalone, no storefront/admin chrome.
 * Provides <html>/<body> for /affiliate and /affiliate/dashboard.
 *
 * Fonts mirror the (site) layout so /affiliate/dashboard renders the shared
 * ReferAndEarnClient with the exact same typography as the in-tenant
 * /dashboard/refer-and-earn page — body = Hind Siliguri, headings = Bricolage
 * (CSS vars wired through, picked up by Tailwind utilities in globals.css).
 */
import type { Metadata } from "next";
import { Hind_Siliguri, Bricolage_Grotesque } from "next/font/google";
import "../globals.css";

const hindSiliguri = Hind_Siliguri({
  variable: "--font-hind-siliguri",
  subsets: ["bengali", "latin"],
  weight: ["400", "500", "700"],
  display: "swap",
  preload: true,
  adjustFontFallback: true,
});

const bricolage = Bricolage_Grotesque({
  variable: "--font-bricolage",
  subsets: ["latin"],
  weight: ["500", "700"],
  display: "swap",
  preload: false,
  adjustFontFallback: true,
});

export const metadata: Metadata = {
  title: "CD Ecom Affiliate Program",
  description: "Earn commission referring merchants to CD Ecom.",
};

export default function AffiliateRootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      style={{ colorScheme: "light" }}
      className={`${hindSiliguri.variable} ${bricolage.variable} antialiased lang-en`}
    >
      <body className="min-h-screen bg-white text-zinc-900" style={{ colorScheme: "light" }}>
        {children}
      </body>
    </html>
  );
}
