/**
 * /affiliate — public landing page for the affiliate program.
 * Explains the program and invites interested parties to apply via email.
 */

export default function AffiliateLandingPage() {
  const commissionRate = "20%";
  const cookieDays = 30;

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-2xl space-y-12 px-4 py-16">
        {/* Hero */}
        <header className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-orange-600">
            CD Ecom Affiliate Program
          </p>
          <h1 className="mt-3 text-4xl font-bold tracking-tight text-zinc-900">
            Earn {commissionRate} for every store you refer
          </h1>
          <p className="mt-4 text-lg text-zinc-600">
            Recommend CD Ecom to business owners. Get {commissionRate} commission on their first month — paid to your bKash or PayPal.
          </p>
          <div className="mt-8 flex items-center justify-center gap-3">
            <a
              href="/affiliate/apply"
              className="inline-block rounded-lg bg-zinc-900 px-6 py-3 text-sm font-semibold text-white hover:bg-zinc-700"
            >
              Apply to join →
            </a>
            <a
              href="/affiliate/login"
              className="inline-block rounded-lg border border-zinc-300 px-6 py-3 text-sm font-semibold text-zinc-700 hover:bg-zinc-100"
            >
              Log in
            </a>
          </div>
        </header>

        {/* How it works */}
        <section>
          <h2 className="mb-6 text-center text-sm font-semibold uppercase tracking-widest text-zinc-500">
            How it works
          </h2>
          <div className="grid gap-6 sm:grid-cols-3">
            <Step n={1} title="Get your link" body="We email you a unique referral link after you're approved." />
            <Step n={2} title="Share it" body="Post it on social media, your blog, or send it directly to business owners." />
            <Step n={3} title="Get paid" body={`Earn ${commissionRate} when they sign up. Cookie lasts ${cookieDays} days.`} />
          </div>
        </section>

        {/* Benefits */}
        <section className="rounded-2xl bg-zinc-50 p-8">
          <h2 className="mb-4 text-lg font-semibold">Why join?</h2>
          <ul className="space-y-3 text-sm text-zinc-700">
            <li className="flex gap-3">
              <span className="text-orange-500">✓</span>
              <span><strong>{commissionRate} commission</strong> on every referred merchant's first paid month.</span>
            </li>
            <li className="flex gap-3">
              <span className="text-orange-500">✓</span>
              <span><strong>{cookieDays}-day cookie</strong> — you get credit even if they don't sign up on day one.</span>
            </li>
            <li className="flex gap-3">
              <span className="text-orange-500">✓</span>
              <span><strong>Real-time dashboard</strong> — track referrals and commissions without creating an account.</span>
            </li>
            <li className="flex gap-3">
              <span className="text-orange-500">✓</span>
              <span><strong>bKash, PayPal, or bank transfer</strong> — we pay you the way you prefer.</span>
            </li>
          </ul>
        </section>

        {/* FAQ */}
        <section>
          <h2 className="mb-4 text-lg font-semibold">FAQ</h2>
          <dl className="space-y-4 text-sm">
            <Faq q="Who can apply?">
              Anyone — freelancers, agencies, bloggers, or existing CD Ecom merchants.
            </Faq>
            <Faq q="When do I get paid?">
              Commissions are approved within 14 days of the merchant's first payment and paid out on request.
            </Faq>
            <Faq q="Is there a minimum payout?">
              Yes — ৳500 minimum per payout via bKash; $10 via PayPal.
            </Faq>
            <Faq q="How do I apply?">
              Fill out the <a href="/affiliate/apply" className="text-orange-600 hover:underline">application form</a> with your name and payout details. We&apos;ll review and approve within 48 hours.
            </Faq>
          </dl>
        </section>

        <footer className="text-center text-xs text-zinc-400">
          © {new Date().getFullYear()} Contra Digital. All rights reserved.
        </footer>
      </div>
    </div>
  );
}

function Step({ n, title, body }: { n: number; title: string; body: string }) {
  return (
    <div className="text-center">
      <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-orange-100 text-sm font-bold text-orange-600">
        {n}
      </div>
      <h3 className="mt-3 font-semibold">{title}</h3>
      <p className="mt-1 text-sm text-zinc-500">{body}</p>
    </div>
  );
}

function Faq({ q, children }: { q: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="font-medium text-zinc-800">{q}</dt>
      <dd className="mt-1 text-zinc-500">{children}</dd>
    </div>
  );
}
