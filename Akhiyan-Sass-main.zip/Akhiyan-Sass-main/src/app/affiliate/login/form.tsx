"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { FiArrowRight } from "react-icons/fi";

export function LoginForm() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/v1/affiliate/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: String(fd.get("email") || "").trim().toLowerCase(),
          password: String(fd.get("password") || ""),
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      router.push("/affiliate/dashboard");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Login failed.");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      {err && (
        <div className="rounded-xl border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700">{err}</div>
      )}

      <label className="block">
        <div className="mb-1 text-sm font-medium">Email</div>
        <input name="email" type="email" required placeholder="you@example.com"
          autoCapitalize="off" autoComplete="email"
          className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </label>

      <label className="block">
        <div className="mb-1 text-sm font-medium">Password</div>
        <input name="password" type="password" required placeholder="••••••••"
          autoComplete="current-password"
          className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </label>

      <button
        type="submit" disabled={busy}
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-zinc-900 px-5 py-3 text-sm font-semibold text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {busy ? "Logging in…" : "Log in"}
        {!busy && <FiArrowRight className="h-4 w-4" />}
      </button>
    </form>
  );
}
