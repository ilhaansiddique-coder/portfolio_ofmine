import Link from "next/link";
import { redirect } from "next/navigation";
import { getAffiliateSession } from "@/lib/affiliate-auth";
import { LoginForm } from "./form";

export const dynamic = "force-dynamic";
export const metadata = { title: "Log in — CD Ecom Affiliate" };

export default async function AffiliateLoginPage() {
  // Already logged in → straight to dashboard.
  const session = await getAffiliateSession();
  if (session) redirect("/affiliate/dashboard");

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-12">
      <header className="mb-6 text-center">
        <p className="text-xs font-medium uppercase tracking-widest text-orange-600">CD Ecom Affiliate</p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-zinc-900">Welcome back</h1>
        <p className="mt-2 text-sm text-zinc-500">Log in to track your referrals and earnings.</p>
      </header>
      <LoginForm />
      <p className="mt-6 text-center text-sm text-zinc-500">
        New here?{" "}
        <Link href="/affiliate/apply" className="font-medium text-orange-600 hover:underline">
          Apply to join
        </Link>
      </p>
    </div>
  );
}
