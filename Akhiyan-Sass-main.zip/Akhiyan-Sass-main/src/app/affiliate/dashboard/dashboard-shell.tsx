"use client";

/**
 * Minimal page chrome for the standalone affiliate dashboard. Shows the
 * affiliate's name + logout in a topbar; the page body is whatever the
 * server component renders inside (currently the shared ReferAndEarnClient
 * so the affiliate sees the same Refer & earn / My earnings UI tenants get).
 *
 * Intentionally light-themed only — the dark-mode toggle lives in the
 * tenant ProfileMenu and doesn't apply to this standalone surface.
 */

import { useState } from "react";
import { useRouter } from "next/navigation";
import { FiLogOut, FiUser } from "react-icons/fi";
import { PiSealPercentFill } from "react-icons/pi";

export function AffiliateDashboardShell({
  name,
  email,
  children,
}: {
  name: string;
  email: string;
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [loggingOut, setLoggingOut] = useState(false);

  async function logout() {
    setLoggingOut(true);
    try {
      await fetch("/api/v1/affiliate/logout", { method: "POST" });
    } catch {
      /* fall through — still redirect even if the cookie clear failed */
    }
    router.replace("/affiliate/login");
  }

  return (
    <div className="dashboard-shell min-h-screen bg-gray-50">
      {/* Topbar */}
      <header className="sticky top-0 z-30 border-b border-gray-200 bg-white">
        <div
          className="mx-auto flex h-16 items-center justify-between gap-4 px-6 md:px-10 lg:px-[60px]"
          style={{ maxWidth: 1450 }}
        >
          <div className="flex items-center gap-2">
            <PiSealPercentFill className="h-6 w-6 text-emerald-500" />
            <span className="text-base font-semibold text-gray-900">Affiliate</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <div className="text-sm font-semibold text-gray-900 leading-tight">{name}</div>
              <div className="text-xs text-gray-500 leading-tight">{email}</div>
            </div>
            <div className="grid h-9 w-9 place-items-center rounded-full bg-gray-100 text-gray-700">
              <FiUser className="h-4 w-4" />
            </div>
            <button
              type="button"
              onClick={logout}
              disabled={loggingOut}
              className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              <FiLogOut className="h-4 w-4" />
              <span className="hidden sm:inline">{loggingOut ? "Logging out…" : "Log out"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Page content — extra horizontal gutters (px-6/10/16) so the cards
       * breathe on the standalone affiliate surface where there's no sidebar
       * eating left space. Vertical padding stays modest. */}
      <main
        className="mx-auto p-6 md:p-10 lg:p-[60px]"
        style={{ maxWidth: 1450 }}
      >
        {children}
      </main>
    </div>
  );
}
