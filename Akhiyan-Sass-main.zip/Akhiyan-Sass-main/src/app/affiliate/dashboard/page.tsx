/**
 * /affiliate/dashboard — login-gated standalone affiliate dashboard.
 *
 * Cookie-session-gated. Shares its UI with the in-tenant Refer & earn page
 * (src/app/(site)/dashboard/refer-and-earn) — the two tabs (Refer & earn /
 * My earnings) come from the same `ReferAndEarnClient` component so a fix on
 * one surface automatically ships to the other.
 *
 * The only difference vs the tenant dashboard route: this one has no
 * sidebar/topbar chrome — it's wrapped in a small standalone shell with
 * the affiliate's name + logout button.
 */

import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { controlPrisma } from "@/lib/prisma-control";
import { getAffiliateSession } from "@/lib/affiliate-auth";
import { getAffiliateStats, getAffiliateMetrics } from "@/lib/affiliate";
import { ReferAndEarnClient } from "@/app/(site)/dashboard/refer-and-earn/refer-and-earn-client";
import { AffiliateDashboardShell } from "./dashboard-shell";

export const dynamic = "force-dynamic";

export default async function AffiliateDashboardPage() {
  const session = await getAffiliateSession();
  if (!session) redirect("/affiliate/login");

  const affiliate = await controlPrisma.affiliate.findUnique({
    where: { id: session.id },
    include: {
      referrals: { orderBy: { createdAt: "desc" }, take: 50 },
      commissions: { orderBy: { createdAt: "desc" }, take: 50 },
      payouts: { orderBy: { createdAt: "desc" }, take: 50 },
    },
  });

  // Session valid but row gone, or banned → bounce to login.
  if (!affiliate || affiliate.status === "banned") redirect("/affiliate/login");

  const [stats, metrics] = await Promise.all([
    getAffiliateStats(affiliate.id),
    getAffiliateMetrics(affiliate.id),
  ]);

  // Join each referral with its first signup commission so the Referrals
  // table can show status + earnings inline — same logic as the tenant
  // dashboard. Without this the table would N+1 lookup per row.
  const commByRef = new Map<number, typeof affiliate.commissions[number]>();
  for (const c of affiliate.commissions) {
    if (c.event === "signup") commByRef.set(c.referralId, c);
  }

  // Look up the referred tenant's email/name (these are the "Invites" column).
  const tenantIds = affiliate.referrals.map((r) => r.tenantId);
  const referredTenants = tenantIds.length
    ? await controlPrisma.tenant.findMany({
        where: { id: { in: tenantIds } },
        select: { id: true, name: true, ownerEmail: true },
      })
    : [];
  const tenantById = new Map(referredTenants.map((t) => [t.id, t]));

  // Build the ref URL from the CURRENT request host so the link works in
  // dev (cdeadmin.localtest.me:3005) and in production (real domain) with
  // no env-var juggling.
  const h = await headers();
  const proto = h.get("x-forwarded-proto") || (process.env.NODE_ENV === "production" ? "https" : "http");
  const hostHeader = h.get("host");
  const baseDomain = hostHeader
    ? `${proto}://${hostHeader}`
    : (process.env.NEXT_PUBLIC_BASE_URL || `https://${process.env.BASE_DOMAIN || "example.com"}`);
  const refUrl = `${baseDomain}/ref/${affiliate.code}`;
  const available = Math.max(0, stats.approvedCommission);

  return (
    <AffiliateDashboardShell name={affiliate.name} email={affiliate.email}>
      <ReferAndEarnClient
        code={affiliate.code}
        refUrl={refUrl}
        commissionRate={affiliate.commissionRate}
        bkashPhone={affiliate.bkashPhone}
        paypalEmail={affiliate.paypalEmail}
        totalEarned={affiliate.totalEarned}
        totalPaid={affiliate.totalPaid}
        available={available}
        stats={stats}
        metrics={{
          totalClicks: metrics.totalClicks,
          clicks30d: metrics.clicks30d,
          uniqueVisitors30d: metrics.uniqueVisitors30d,
          conversionRate: metrics.conversionRate,
        }}
        commissions={affiliate.commissions.map((c) => ({
          id: c.id,
          amount: c.amount,
          status: c.status,
          event: c.event,
          createdAt: c.createdAt.toISOString(),
        }))}
        referrals={affiliate.referrals.map((r) => {
          const t = tenantById.get(r.tenantId);
          const c = commByRef.get(r.id);
          return {
            id: r.id,
            invite: t?.ownerEmail || `Store #${r.tenantId}`,
            plan: r.plan,
            status: c?.status ?? "pending",
            earnings: c?.amount ?? 0,
            createdAt: r.createdAt.toISOString(),
          };
        })}
        payouts={affiliate.payouts.map((po) => ({
          id: po.id,
          method: po.method,
          destination: po.destination,
          amount: po.amount,
          status: po.status,
          txRef: po.txRef,
          createdAt: po.createdAt.toISOString(),
        }))}
        payoutThresholds={{ bkash: 500, paypal: 10 }}
      />
    </AffiliateDashboardShell>
  );
}
