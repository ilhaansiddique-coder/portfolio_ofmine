"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { FiArrowRight } from "react-icons/fi";

export function ApplyForm() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/v1/affiliate/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: String(fd.get("name") || "").trim(),
          email: String(fd.get("email") || "").trim().toLowerCase(),
          password: String(fd.get("password") || ""),
          bkashPhone: String(fd.get("bkashPhone") || "").trim(),
          paypalEmail: String(fd.get("paypalEmail") || "").trim().toLowerCase(),
          promo: String(fd.get("promo") || "").trim(),
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      // Auto-logged-in by the API — go straight to the dashboard.
      router.push("/affiliate/dashboard");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Something went wrong. Try again.");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      {err && (
        <div className="rounded-xl border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700">{err}</div>
      )}

      <Field label="Full name" required>
        <input name="name" required placeholder="John Doe"
          className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Email" required>
        <input name="email" type="email" required placeholder="you@example.com"
          autoCapitalize="off" autoComplete="email"
          className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Password" required hint="At least 8 characters — you'll use this to log in.">
        <input name="password" type="password" required minLength={8} placeholder="••••••••"
          autoComplete="new-password"
          className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <div className="rounded-xl bg-zinc-50 p-4 ring-1 ring-inset ring-zinc-100">
        <p className="mb-3 text-xs font-medium text-zinc-600">How should we pay you? (at least one)</p>
        <div className="space-y-3">
          <Field label="bKash number" small>
            <input name="bkashPhone" type="tel" inputMode="numeric" placeholder="01XXXXXXXXX"
              className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-2.5 text-sm outline-none focus:border-orange-500" />
          </Field>
          <Field label="PayPal email" small>
            <input name="paypalEmail" type="email" placeholder="paypal@example.com"
              autoCapitalize="off" autoComplete="off"
              className="w-full rounded-xl border border-zinc-300 bg-white px-4 py-2.5 text-sm outline-none focus:border-orange-500" />
          </Field>
        </div>
      </div>

      <Field label="How will you promote CD Ecom?" hint="Optional — helps us approve faster.">
        <textarea name="promo" rows={3} placeholder="e.g. I run a Facebook group for small business owners…"
          className="w-full resize-none rounded-xl border border-zinc-300 bg-white px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <button
        type="submit" disabled={busy}
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-zinc-900 px-5 py-3 text-sm font-semibold text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {busy ? "Submitting…" : "Submit application"}
        {!busy && <FiArrowRight className="h-4 w-4" />}
      </button>

      <p className="text-center text-xs text-zinc-400">
        By applying you agree to our affiliate terms. Commission is paid on referred stores&apos; first paid month.
      </p>
    </form>
  );
}

function Field({
  label, hint, required, small, children,
}: {
  label: string; hint?: string; required?: boolean; small?: boolean; children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className={`mb-1 font-medium ${small ? "text-xs text-zinc-500" : "text-sm"}`}>
        {label}{required && <span className="text-rose-500"> *</span>}
      </div>
      {children}
      {hint && <div className="mt-1 text-xs text-zinc-400">{hint}</div>}
    </label>
  );
}
