import Link from "next/link";
import { ApplyForm } from "./form";

export const metadata = {
  title: "Apply — CD Ecom Affiliate Program",
};

export default function AffiliateApplyPage() {
  return (
    <div className="mx-auto max-w-lg space-y-6 px-4 py-12">
      <header className="text-center">
        <Link href="/affiliate" className="text-xs text-zinc-400 hover:text-zinc-600">
          ← Back to program
        </Link>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-zinc-900">Join the affiliate program</h1>
        <p className="mt-2 text-sm text-zinc-500">
          Apply below. Once approved, you&apos;ll get your referral link and start earning commission.
        </p>
      </header>
      <ApplyForm />
      <p className="text-center text-sm text-zinc-500">
        Already have an account?{" "}
        <Link href="/affiliate/login" className="font-medium text-orange-600 hover:underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
