"use client";

import { useEffect, useState, use } from "react";
import { motion } from "framer-motion";
import { FiSearch, FiFrown } from "react-icons/fi";
import { api } from "@/lib/api";
import { mapApiProduct, type Product } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { useLang } from "@/lib/LanguageContext";
import { trackViewItemList } from "@/lib/analytics";
import { Editable } from "@/storefront-engine/editor/Editable";
import { useEditable } from "@/storefront-engine/editor/EditModeContext";

export default function SearchClient({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const params = use(searchParams);
  const q = params.q || "";
  const { lang } = useLang();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!q) {
      setLoading(false);
      return;
    }

    setLoading(true);
    api.searchProducts(q)
      .then((res) => {
        const data = res.data || res;
        if (Array.isArray(data)) {
          setProducts(data.map(mapApiProduct));
        }
      })
      .finally(() => setLoading(false));
  }, [q]);

  // GA4 view_item_list for search results — keyed on the query so each new
  // search fires once (not on unrelated re-renders).
  useEffect(() => {
    if (!q || products.length === 0) return;
    trackViewItemList({
      item_list_id: "search",
      item_list_name: `Search: ${q}`,
      items: products.slice(0, 50).map((p) => ({
        id: p.id, name: p.name, category: p.category, price: p.price,
      })),
    });
    // fire once per (query, result-set) — products identity changes only
    // when the search resolves, so [q, products] is the right key.
  }, [q, products]);

  const en = lang === "en";
  const e = useEditable("search");

  const fallbackHeading = en ? "Search Results" : "অনুসন্ধানের ফলাফল";
  const fallbackEmptyTitle = en ? "No products found" : "কোনো পণ্য পাওয়া যায়নি";
  const fallbackEmptyDesc = en
    ? "Try checking your spelling or use more general terms."
    : "অনুগ্রহ করে বানান চেক করুন অথবা সাধারণ শব্দ ব্যবহার করে পুনরায় চেষ্টা করুন।";

  return (
    <section className="py-12 bg-background-alt min-h-[70vh]">
      <div className="container mx-auto px-4">
        <div className="mb-10">
          <Editable
            section="search"
            field="heading"
            defaultValue={fallbackHeading}
            label="Search heading"
          >
            {(v, ep) => (
              <h1 {...ep} className={`text-2xl md:text-3xl font-bold text-foreground ${ep.className ?? ""}`}>
                {v || fallbackHeading}
              </h1>
            )}
          </Editable>
          <p className="text-text-muted mt-2">
            {en ? (
              <>
                <Editable section="search" field="resultsPrefix" defaultValue="Showing results for" label="Results prefix">
                  {(v, ep) => <span {...ep}>{v || "Showing results for"}</span>}
                </Editable>
                {" "}&ldquo;{q}&rdquo;
              </>
            ) : (
              `"${q}" এর জন্য ফলাফল দেখানো হচ্ছে`
            )}
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-[3/4] bg-white rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-3xl border border-border">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <FiFrown className="w-10 h-10 text-text-muted" />
            </div>
            <Editable
              section="search"
              field="emptyTitle"
              defaultValue={fallbackEmptyTitle}
              label="Empty results title"
            >
              {(v, ep) => (
                <h2 {...ep} className={`text-2xl font-bold text-foreground mb-3 ${ep.className ?? ""}`}>
                  {v || fallbackEmptyTitle}
                </h2>
              )}
            </Editable>
            <Editable
              section="search"
              field="emptyDescription"
              defaultValue={fallbackEmptyDesc}
              label="Empty results description"
            >
              {(v, ep) => (
                <p {...ep} className={`text-text-muted max-w-md mx-auto mb-8 ${ep.className ?? ""}`}>
                  {v || fallbackEmptyDesc}
                </p>
              )}
            </Editable>
            <div className="relative max-w-md mx-auto">
              <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted" />
              <form action="/search" method="GET">
                <input
                  name="q"
                  defaultValue={q}
                  type="text"
                  placeholder={e("searchAgainPlaceholder", en ? "Search again..." : "আবার খুঁজুন...")}
                  className="w-full pl-12 pr-4 py-4 bg-background-alt border border-border rounded-2xl focus:outline-none focus:border-primary transition-colors"
                />
              </form>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
