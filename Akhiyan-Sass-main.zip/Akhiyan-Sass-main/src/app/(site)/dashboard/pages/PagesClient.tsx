"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { FiPlus, FiEdit2, FiExternalLink, FiTrash2 } from "react-icons/fi";

interface Row {
  id: number; title: string; slug: string; status: string;
  type: string; version: number; updated_at?: string;
}

export default function PagesClient() {
  const router = useRouter();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await api.admin.getCmsPages();
      setRows(Array.isArray(d) ? d : d.data || []);
    } catch { setMsg("Failed to load pages"); }
    setLoading(false);
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function create() {
    setBusy(true); setMsg("");
    try {
      const title = prompt("Page title?", "New Page");
      if (!title) { setBusy(false); return; }
      const r = await api.admin.createCmsPage({ title });
      const id = (r as { id?: number }).id ?? (r as { data?: { id: number } }).data?.id;
      if (id) router.push(`/dashboard/page-builder/${id}/edit`);
    } catch { setMsg("Create failed"); }
    setBusy(false);
  }

  async function del(id: number) {
    if (!confirm("Delete this page? This cannot be undone.")) return;
    setBusy(true);
    try { await api.admin.deleteCmsPage(id); await load(); }
    catch { setMsg("Delete failed"); }
    setBusy(false);
  }

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Pages</h1>
          <p className="text-sm text-text-muted">Custom pages built with the page builder, served at clean URLs like <code>/&lt;slug&gt;</code>.</p>
        </div>
        <button onClick={create} disabled={busy}
          className="px-4 py-2 rounded-lg bg-[var(--primary)] text-white text-sm font-semibold disabled:opacity-50 flex items-center gap-2">
          <FiPlus size={16} /> New page
        </button>
      </div>

      {msg && <div className="p-3 rounded-lg bg-red-50 text-red-700 text-sm">{msg}</div>}
      {loading && <p className="text-sm text-text-muted">Loading…</p>}

      {!loading && rows.length === 0 && (
        <div className="border-2 border-dashed border-gray-200 rounded-xl p-10 text-center text-sm text-text-muted">
          No pages yet. Click <strong>New page</strong> to build one.
        </div>
      )}

      {rows.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-xl divide-y divide-gray-100">
          {rows.map((p) => (
            <div key={p.id} className="flex items-center gap-3 p-3">
              <div className="flex-1 min-w-0">
                <div className="font-medium text-foreground truncate">{p.title}</div>
                <div className="text-xs text-text-muted">/{p.slug} · v{p.version}</div>
              </div>
              <span className={`text-[11px] px-2 py-0.5 rounded-full ${p.status === "published" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                {p.status}
              </span>
              <button onClick={() => router.push(`/dashboard/page-builder/${p.id}/edit`)} className="p-2 text-text-muted hover:text-[var(--primary)]" title="Edit"><FiEdit2 size={15} /></button>
              {p.status === "published" && (
                <a href={`/${p.slug}`} target="_blank" rel="noreferrer" className="p-2 text-text-muted hover:text-[var(--primary)]" title="Open"><FiExternalLink size={15} /></a>
              )}
              <button onClick={() => del(p.id)} disabled={busy} className="p-2 text-text-muted hover:text-red-600" title="Delete"><FiTrash2 size={15} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
