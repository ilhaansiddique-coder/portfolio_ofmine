import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import PagesClient from "./PagesClient";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function PagesRoute() {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");
  return <PagesClient />;
}
