/**
 * Stub page shown when every dashboard feature is disabled for this tenant.
 * Reachable via the layout's fallback redirect — never linked from the nav.
 *
 * Has no `feature` requirement so it won't redirect-loop.
 */
export default function NoAccessPage() {
  return (
    <div className="mx-auto max-w-md py-16 text-center">
      <h1 className="text-2xl font-semibold text-zinc-900">No dashboard access</h1>
      <p className="mt-3 text-sm text-zinc-500">
        Your account doesn&apos;t currently have permission to view any dashboard
        pages. Ask your account owner to enable at least one feature.
      </p>
    </div>
  );
}
