/**
 * AI Usage dashboard — month-to-date spend, breakdown by surface,
 * recent calls table. Helps tenants see what AI is costing them.
 */
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import UsageClient from "./UsageClient";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function UsagePage() {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");
  return <UsageClient />;
}
