"use client";

import { useEffect, useState } from "react";
import { FiBarChart2, FiAlertTriangle, FiCheckCircle, FiXCircle, FiLoader } from "react-icons/fi";
import DashboardLayout from "@/components/DashboardLayout";

interface BySurface { surface: string; calls: number; tokens: number; costUsd: number }
interface RecentRow {
  id: number;
  surface: string;
  field: string | null;
  provider: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  costUsd: number;
  durationMs: number;
  success: boolean;
  errorMessage: string | null;
  createdAt: string;
}
interface UsageData {
  summary: {
    totalCalls: number;
    successfulCalls: number;
    failedCalls: number;
    inputTokens: number;
    outputTokens: number;
    totalCostUsd: number;
    bySurface: BySurface[];
  };
  budgetUsd: number | null;
  spentThisMonth: number;
  recent: RecentRow[];
}

const surfaceColor: Record<string, string> = {
  rewrite:       "bg-orange-100 text-orange-700",
  generate_site: "bg-indigo-100 text-indigo-700",
  generate_lp:   "bg-violet-100 text-violet-700",
  image_tag:     "bg-emerald-100 text-emerald-700",
  test:          "bg-zinc-100 text-zinc-700",
};
const surfaceLabel: Record<string, string> = {
  rewrite:       "Field rewrite",
  generate_site: "Whole site",
  generate_lp:   "Landing page",
  image_tag:     "Image tag",
  test:          "Test ping",
};

function fmtUsd(n: number) {
  if (n === 0) return "$0";
  if (n < 0.01) return `$${n.toFixed(6)}`;
  return `$${n.toFixed(4)}`;
}
function fmtTime(iso: string) {
  return new Date(iso).toLocaleString();
}

export default function UsageClient() {
  const [data, setData] = useState<UsageData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/v1/admin/ai/usage");
        const j = await res.json();
        if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);
        if (!cancelled) setData(j);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "Failed to load usage");
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (error) {
    return (
      <DashboardLayout title="AI Usage">
        <div className="mx-auto max-w-3xl py-8">
          <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">
            <FiAlertTriangle className="mb-0.5 inline" /> {error}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (!data) {
    return (
      <DashboardLayout title="AI Usage">
        <div className="mx-auto max-w-3xl py-8 text-center text-sm text-zinc-500">
          <FiLoader className="mx-auto animate-spin" /> Loading…
        </div>
      </DashboardLayout>
    );
  }

  const budgetPct = data.budgetUsd && data.budgetUsd > 0
    ? Math.min(100, Math.round((data.spentThisMonth / data.budgetUsd) * 100))
    : 0;
  const budgetWarn = data.budgetUsd && budgetPct >= 80;

  return (
    <DashboardLayout title="AI Usage">
      <div className="mx-auto max-w-5xl space-y-6 py-8">
        <header>
          <h1 className="flex items-center gap-2 text-2xl font-bold text-zinc-900">
            <FiBarChart2 className="text-orange-500" /> AI Usage
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            Month-to-date spend, breakdown by feature, and the last {data.recent.length} calls.
          </p>
        </header>

        {/* Top-line tiles */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Tile label="This month" value={fmtUsd(data.spentThisMonth)} />
          <Tile label="Calls" value={data.summary.totalCalls.toLocaleString()} sub={`${data.summary.failedCalls} failed`} />
          <Tile label="Input tokens" value={(data.summary.inputTokens / 1000).toFixed(1) + "k"} />
          <Tile label="Output tokens" value={(data.summary.outputTokens / 1000).toFixed(1) + "k"} />
        </div>

        {/* Budget bar */}
        {data.budgetUsd && data.budgetUsd > 0 && (
          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-zinc-900">Monthly budget</span>
              <span className={budgetWarn ? "text-amber-700" : "text-zinc-600"}>
                {fmtUsd(data.spentThisMonth)} of {fmtUsd(data.budgetUsd)} ({budgetPct}%)
              </span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-zinc-100">
              <div
                className={[
                  "h-full transition-all",
                  budgetPct >= 100 ? "bg-rose-500" : budgetWarn ? "bg-amber-500" : "bg-emerald-500",
                ].join(" ")}
                style={{ width: `${budgetPct}%` }}
              />
            </div>
            {budgetWarn && budgetPct < 100 && (
              <p className="mt-2 text-xs text-amber-700">
                <FiAlertTriangle className="mb-0.5 inline" /> Over 80% of budget used this month.
              </p>
            )}
            {budgetPct >= 100 && (
              <p className="mt-2 text-xs text-rose-700">
                <FiAlertTriangle className="mb-0.5 inline" /> Budget reached — new AI calls will be refused.
              </p>
            )}
          </section>
        )}

        {/* Breakdown by surface */}
        {data.summary.bySurface.length > 0 && (
          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-semibold text-zinc-900">By feature</h2>
            <div className="mt-3 space-y-2">
              {data.summary.bySurface
                .sort((a, b) => b.costUsd - a.costUsd)
                .map((s) => (
                  <div key={s.surface} className="flex items-center justify-between rounded-lg border border-zinc-100 px-3 py-2 text-sm">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${surfaceColor[s.surface] || "bg-zinc-100 text-zinc-700"}`}>
                      {surfaceLabel[s.surface] || s.surface}
                    </span>
                    <div className="flex gap-4 text-zinc-600">
                      <span>{s.calls.toLocaleString()} calls</span>
                      <span>{(s.tokens / 1000).toFixed(1)}k tokens</span>
                      <span className="font-mono font-medium text-zinc-900">{fmtUsd(s.costUsd)}</span>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}

        {/* Recent calls */}
        <section className="rounded-xl border border-zinc-200 bg-white">
          <h2 className="border-b border-zinc-100 px-5 py-3 text-sm font-semibold text-zinc-900">Recent calls</h2>
          {data.recent.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-zinc-400">No AI calls yet. Try the &quot;AI&quot; button on any field.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-xs">
                <thead className="border-b border-zinc-100 bg-zinc-50 text-left text-[10px] font-semibold uppercase text-zinc-500">
                  <tr>
                    <th className="px-3 py-2">When</th>
                    <th className="px-3 py-2">Feature</th>
                    <th className="px-3 py-2">Field</th>
                    <th className="px-3 py-2">Model</th>
                    <th className="px-3 py-2 text-right">In</th>
                    <th className="px-3 py-2 text-right">Out</th>
                    <th className="px-3 py-2 text-right">Cost</th>
                    <th className="px-3 py-2 text-right">ms</th>
                    <th className="px-3 py-2"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  {data.recent.map((r) => (
                    <tr key={r.id} className={r.success ? "" : "bg-rose-50"}>
                      <td className="px-3 py-1.5 whitespace-nowrap text-zinc-600">{fmtTime(r.createdAt)}</td>
                      <td className="px-3 py-1.5">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${surfaceColor[r.surface] || "bg-zinc-100 text-zinc-700"}`}>
                          {surfaceLabel[r.surface] || r.surface}
                        </span>
                      </td>
                      <td className="px-3 py-1.5 font-mono text-[10px] text-zinc-500">{r.field || "—"}</td>
                      <td className="px-3 py-1.5 font-mono text-[10px] text-zinc-700">{r.model}</td>
                      <td className="px-3 py-1.5 text-right font-mono text-zinc-600">{r.inputTokens}</td>
                      <td className="px-3 py-1.5 text-right font-mono text-zinc-600">{r.outputTokens}</td>
                      <td className="px-3 py-1.5 text-right font-mono font-medium text-zinc-900">{fmtUsd(r.costUsd)}</td>
                      <td className="px-3 py-1.5 text-right font-mono text-zinc-500">{r.durationMs}</td>
                      <td className="px-3 py-1.5">
                        {r.success ? (
                          <FiCheckCircle className="text-emerald-500" title="OK" />
                        ) : (
                          <FiXCircle className="text-rose-500" title={r.errorMessage || "Failed"} />
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </DashboardLayout>
  );
}

function Tile({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl border border-zinc-200 bg-white p-4">
      <div className="text-xs font-medium uppercase tracking-wider text-zinc-500">{label}</div>
      <div className="mt-1 font-mono text-2xl font-bold text-zinc-900">{value}</div>
      {sub && <div className="text-[10px] text-zinc-500">{sub}</div>}
    </div>
  );
}
