/**
 * AI Site Setup — generate, review/edit, and publish a tenant's whole-site
 * draft content (branding + policy/about pages) from the Site Brief.
 * Generation/staging/publish happen via /api/v1/admin/ai/site-setup.
 */
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { getBrief } from "@/lib/ai/brief";
import SiteSetupClient from "./SiteSetupClient";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function SiteSetupRoute() {
  const { prisma } = await getPrismaForRequest();
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");
  const brief = await getBrief(prisma);
  return <SiteSetupClient initialBrief={brief} />;
}
