"use client";

/**
 * AI Site Setup — single page, TABBED.
 *   Brief · Branding · Home · About · Terms · Privacy · Refund
 * Generate auto-saves the brief first. Each artifact has its own tab +
 * Approve toggle. "Publish all" pushes every staged key live regardless of
 * the per-tab checkboxes. Nothing is live until you publish.
 */
import { useEffect, useState, useCallback } from "react";
import type { SiteBriefData } from "@/lib/ai/brief";

type Bi = { en: string; bn: string };
type Section = { title: Bi; content: Bi };
type PolicyContent = { title: Bi; lastUpdated: Bi; intro: Bi; sections: Section[] };
type Hero = {
  badge: string; title: string; subtitle: string; description: string;
  cta_primary: string; cta_secondary: string; trust_1: string; trust_2: string; trust_3: string;
};

// The staged homepage is the FULL shape ({ hero, products_section, features,
// reviews }). The wizard edits the hero fields; the other sections ride along
// untouched so publish keeps them.
type HomepageDraft = { hero?: Partial<Hero> } & Record<string, unknown>;

interface Manifest {
  status: "draft" | "published" | "discarded";
  generatedAt: string;
  warnings: string[];
  settingKeys: string[];
  pageKeys: string[];
  homepageKeys?: string[];
}
interface DraftState {
  manifest: Manifest | null;
  settings: Record<string, string>;
  pages: Record<string, PolicyContent>;
  homepage: HomepageDraft | null;
}

const PAGE_LABEL: Record<string, string> = {
  page_about: "About", page_contact: "Contact", page_terms: "Terms", page_privacy: "Privacy", page_refund: "Refund",
};
const HERO_FIELDS: Array<[keyof Hero, string, boolean]> = [
  ["badge", "Badge", false], ["title", "Title", false], ["subtitle", "Subtitle", false],
  ["description", "Description", true], ["cta_primary", "Primary button", false],
  ["cta_secondary", "Secondary button", false], ["trust_1", "Trust point 1", false],
  ["trust_2", "Trust point 2", false], ["trust_3", "Trust point 3", false],
];
const joinCsv = (a: string[]) => a.join(", ");
const splitCsv = (s: string) => s.split(",").map((v) => v.trim()).filter(Boolean);

export default function SiteSetupClient({ initialBrief }: { initialBrief: SiteBriefData }) {
  const [brief, setBrief] = useState<SiteBriefData>(initialBrief);
  const [briefDirty, setBriefDirty] = useState(false);
  const setB = <K extends keyof SiteBriefData>(k: K, v: SiteBriefData[K]) => {
    setBrief((p) => ({ ...p, [k]: v })); setBriefDirty(true);
  };

  const [draft, setDraft] = useState<DraftState>({ manifest: null, settings: {}, pages: {}, homepage: null });
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [approved, setApproved] = useState<Record<string, boolean>>({});
  const [tab, setTab] = useState<string>("brief");

  const load = useCallback(async () => {
    setBusy("load");
    try {
      const r = await fetch("/api/v1/admin/ai/site-setup", { headers: { Accept: "application/json" } });
      const d = await r.json();
      setDraft({
        manifest: d.manifest ?? null, settings: d.settings ?? {},
        pages: d.pages ?? {}, homepage: d.homepage ?? null,
      });
    } catch { /* ignore */ } finally { setBusy(null); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const m = draft.manifest;
  const hasHome = !!m?.homepageKeys?.includes("homepage_content") && !!draft.homepage;
  const hasBranding = !!m && m.settingKeys.length > 0;
  const pageKeys = m?.pageKeys ?? [];
  const allKeys = m ? [...m.settingKeys, ...m.pageKeys, ...(m.homepageKeys ?? [])] : [];
  const hasDraft = m?.status === "draft" && allKeys.length > 0;

  const tabs: Array<{ id: string; label: string }> = [
    { id: "brief", label: "Brief" },
    ...(hasBranding ? [{ id: "branding", label: "Branding" }] : []),
    ...(hasHome ? [{ id: "home", label: "Home" }] : []),
    ...pageKeys.map((k) => ({ id: k, label: PAGE_LABEL[k] || k })),
  ];

  async function saveBrief(): Promise<void> {
    const r = await fetch("/api/v1/admin/ai/brief", {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(brief),
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.message || j.error || "Brief save failed");
    setBrief(j); setBriefDirty(false);
  }
  async function onSaveBrief() {
    setBusy("brief"); setMsg(null);
    try { await saveBrief(); setMsg({ kind: "ok", text: "Brief saved." }); }
    catch (e) { setMsg({ kind: "err", text: e instanceof Error ? e.message : "Brief save failed" }); }
    finally { setBusy(null); }
  }

  async function generate() {
    if (!brief.businessName.trim()) { setMsg({ kind: "err", text: "Add a Business name first." }); return; }
    if (!confirm("Save the brief and generate the whole site (home, branding, about, policies)? Stages a DRAFT — nothing goes live until you publish.")) return;
    setBusy("gen"); setMsg(null);
    try {
      await saveBrief();
      const r = await fetch("/api/v1/admin/ai/site-setup", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || d.error || "Generation failed");
      await load();
      setMsg({ kind: "ok", text: `Draft generated (~$${(d.costUsd ?? 0).toFixed(4)}). Review each tab, then Publish all.` });
      setTab("home");
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Generation failed" });
    } finally { setBusy(null); }
  }

  function patchBody() {
    return JSON.stringify({
      settings: draft.settings, pages: draft.pages,
      ...(draft.homepage ? { homepage: draft.homepage } : {}),
    });
  }
  async function saveEdits() {
    setBusy("save"); setMsg(null);
    try {
      const r = await fetch("/api/v1/admin/ai/site-setup", {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: patchBody(),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || d.error || "Save failed");
      setMsg({ kind: "ok", text: `Saved ${d.updated?.length ?? 0} field(s).` });
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Save failed" });
    } finally { setBusy(null); }
  }
  async function publish(keys?: string[]) {
    const list = keys ?? allKeys.filter((k) => approved[k]);
    if (list.length === 0) { setMsg({ kind: "err", text: "Approve at least one item, or use Publish all." }); return; }
    if (!confirm(`Publish ${list.length} item(s) LIVE? Replaces current site content.`)) return;
    setBusy("publish"); setMsg(null);
    try {
      await fetch("/api/v1/admin/ai/site-setup", {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: patchBody(),
      });
      const r = await fetch("/api/v1/admin/ai/site-setup", {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ keys: list }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.message || d.error || "Publish failed");
      await load();
      setMsg({ kind: "ok", text: `Published: ${(d.published || []).join(", ")}. Live in ~60s (hard-refresh to see now).` });
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Publish failed" });
    } finally { setBusy(null); }
  }
  async function discard() {
    if (!confirm("Discard the entire staged draft?")) return;
    setBusy("discard");
    try { await fetch("/api/v1/admin/ai/site-setup", { method: "DELETE" }); await load(); setMsg({ kind: "ok", text: "Draft discarded." }); }
    finally { setBusy(null); }
  }

  const setSetting = (k: string, v: string) => setDraft((d) => ({ ...d, settings: { ...d.settings, [k]: v } }));
  // Edit a hero field inside the nested homepage shape (keeping the other
  // sections — products_section/features/reviews — intact).
  const setHero = (k: keyof Hero, v: string) =>
    setDraft((d) => ({ ...d, homepage: { ...(d.homepage ?? {}), hero: { ...(d.homepage?.hero ?? {}), [k]: v } } }));
  const setPageField = (key: string, mut: (p: PolicyContent) => void) =>
    setDraft((d) => { const next = structuredClone(d.pages[key]); mut(next); return { ...d, pages: { ...d.pages, [key]: next } }; });

  const inp = "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/30";
  const fld = "mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500";

  const Approve = ({ k }: { k: string }) => (
    <label className="text-xs flex items-center gap-1 text-text-muted">
      <input type="checkbox" checked={!!approved[k]} onChange={(e) => setApproved((a) => ({ ...a, [k]: e.target.checked }))} />
      Approve
    </label>
  );

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-4">
      <div>
        <h1 className="text-xl font-bold text-foreground">AI Site Setup</h1>
        <p className="text-sm text-text-muted">Describe the business, generate the whole site, review each tab, publish. AI drafts only — contacts/socials stay as you set them.</p>
      </div>

      {msg && (
        <div className={`p-3 rounded-lg text-sm ${msg.kind === "ok" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>{msg.text}</div>
      )}
      {m?.warnings?.length ? (
        <div className="p-3 rounded-lg bg-amber-50 text-amber-800 text-sm space-y-1">
          {m.warnings.map((w, i) => <div key={i}>⚠️ {w}</div>)}
        </div>
      ) : null}

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 border-b border-gray-200">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-3 py-2 text-sm font-medium rounded-t-lg -mb-px border-b-2 ${
              tab === t.id ? "border-[var(--primary)] text-[var(--primary)]" : "border-transparent text-text-muted hover:text-foreground"
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      {busy === "load" && <p className="text-sm text-text-muted">Loading…</p>}

      {/* Brief tab */}
      {tab === "brief" && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-foreground">Business Brief</h2>
            {briefDirty && <span className="text-xs text-amber-600">unsaved</span>}
          </div>
          {([
            ["businessName", "Business name *", false], ["oneLiner", "One-liner", false],
            ["longDescription", "Long description", true], ["targetAudience", "Target audience", false],
          ] as const).map(([k, label, ta]) => (
            <div key={k}>
              <label className="block text-sm font-medium text-zinc-700">{label}</label>
              {ta ? (
                <textarea rows={4} value={brief[k] as string} onChange={(e) => setB(k, e.target.value)} className={fld} />
              ) : (
                <input value={brief[k] as string} onChange={(e) => setB(k, e.target.value)} className={fld} />
              )}
            </div>
          ))}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-zinc-700">Tone</label>
              <select value={brief.tone} onChange={(e) => setB("tone", e.target.value)} className={fld}>
                {["friendly", "professional", "playful", "luxury", "bold", "warm"].map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-700">Primary language</label>
              <select value={brief.primaryLanguage} onChange={(e) => setB("primaryLanguage", e.target.value)} className={fld}>
                <option value="en">English</option><option value="bn">Bangla</option>
              </select>
            </div>
          </div>
          {([
            ["productCategories", "Product categories"], ["locations", "Locations / markets"],
            ["uniqueSelling", "Unique selling points"], ["doNotUse", "Words to avoid"],
          ] as const).map(([k, label]) => (
            <div key={k}>
              <label className="block text-sm font-medium text-zinc-700">{label}</label>
              <input value={joinCsv(brief[k] as string[])} onChange={(e) => setB(k, splitCsv(e.target.value))} placeholder="comma, separated" className={fld} />
            </div>
          ))}
          <div>
            <label className="block text-sm font-medium text-zinc-700">Voice sample</label>
            <textarea rows={3} value={brief.exampleParagraph} onChange={(e) => setB("exampleParagraph", e.target.value)} className={fld} />
          </div>
          <div className="flex gap-2">
            <button onClick={onSaveBrief} disabled={!!busy || !brief.businessName.trim()} className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium disabled:opacity-50">
              {busy === "brief" ? "Saving…" : "Save brief"}
            </button>
            <button onClick={generate} disabled={!!busy || !brief.businessName.trim()} className="px-4 py-2 rounded-lg bg-[var(--primary)] text-white text-sm font-semibold disabled:opacity-50">
              {busy === "gen" ? "Generating…" : hasDraft ? "Save & regenerate" : "Save brief & generate site"}
            </button>
          </div>
        </section>
      )}

      {/* Branding tab */}
      {tab === "branding" && hasBranding && (
        <section className="space-y-3">
          {m!.settingKeys.map((k) => (
            <label key={k} className="block">
              <span className="text-xs font-medium text-text-muted flex items-center justify-between">
                {k} <Approve k={k} />
              </span>
              {k === "site_description" || k === "address" ? (
                <textarea rows={2} className={inp} value={draft.settings[k] ?? ""} onChange={(e) => setSetting(k, e.target.value)} />
              ) : (
                <input className={inp} value={draft.settings[k] ?? ""} onChange={(e) => setSetting(k, e.target.value)} />
              )}
            </label>
          ))}
        </section>
      )}

      {/* Home tab */}
      {tab === "home" && hasHome && draft.homepage && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-foreground">Homepage hero</h2>
            <Approve k="homepage_content" />
          </div>
          {HERO_FIELDS.map(([k, label, ta]) => (
            <label key={k} className="block">
              <span className="text-xs font-medium text-text-muted">{label}</span>
              {ta ? (
                <textarea rows={3} className={inp} value={draft.homepage?.hero?.[k] ?? ""} onChange={(e) => setHero(k, e.target.value)} />
              ) : (
                <input className={inp} value={draft.homepage?.hero?.[k] ?? ""} onChange={(e) => setHero(k, e.target.value)} />
              )}
            </label>
          ))}
          <p className="text-xs text-text-muted">The AI also generates the products, features &amp; reviews section headings — those publish along with the hero.</p>
        </section>
      )}

      {/* Page tabs */}
      {/* Contact uses a flat, single-language shape (heroTitle, formTitle…),
          not the bilingual PolicyContent the other pages use. Render a simple
          field editor for it and bail before the PolicyContent block. */}
      {tab === "page_contact" && draft.pages["page_contact"] && (() => {
        const c = draft.pages["page_contact"] as unknown as Record<string, string>;
        const CONTACT_FIELDS: Array<[string, string, boolean]> = [
          ["heroTitle", "Hero title", false],
          ["heroSubtitle", "Hero subtitle", true],
          ["formTitle", "Form heading", false],
          ["infoTitle", "Info heading", false],
          ["responseNote", "Response note", true],
        ];
        const setC = (k: string, v: string) =>
          setDraft((d) => ({ ...d, pages: { ...d.pages, page_contact: { ...(d.pages.page_contact as unknown as Record<string, string>), [k]: v } as unknown as PolicyContent } }));
        return (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-foreground">Contact</h2>
              <Approve k="page_contact" />
            </div>
            {CONTACT_FIELDS.map(([k, label, ta]) => (
              <label key={k} className="block">
                <span className="text-xs font-medium text-text-muted">{label}</span>
                {ta
                  ? <textarea rows={2} className={inp} value={c[k] ?? ""} onChange={(e) => setC(k, e.target.value)} />
                  : <input className={inp} value={c[k] ?? ""} onChange={(e) => setC(k, e.target.value)} />}
              </label>
            ))}
          </section>
        );
      })()}

      {pageKeys.includes(tab) && tab !== "page_contact" && draft.pages[tab] && (() => {
        const p = draft.pages[tab];
        return (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-foreground">{PAGE_LABEL[tab] || tab}</h2>
              <Approve k={tab} />
            </div>
            <BiField label="Title" v={p.title} onChange={(en, bn) => setPageField(tab, (np) => { np.title = { en, bn }; })} />
            <BiField label="Intro" textarea v={p.intro} onChange={(en, bn) => setPageField(tab, (np) => { np.intro = { en, bn }; })} />
            {p.sections.map((s, idx) => (
              <div key={idx} className="border border-gray-100 rounded-lg p-3 space-y-2">
                <span className="text-[11px] text-text-muted">Section {idx + 1}</span>
                <BiField label="Heading" v={s.title} onChange={(en, bn) => setPageField(tab, (np) => { np.sections[idx].title = { en, bn }; })} />
                <BiField label="Content" textarea v={s.content} onChange={(en, bn) => setPageField(tab, (np) => { np.sections[idx].content = { en, bn }; })} />
              </div>
            ))}
          </section>
        );
      })()}

      {/* Sticky actions */}
      {hasDraft && (
        <div className="flex flex-wrap gap-2 sticky bottom-2 bg-white/90 backdrop-blur border border-gray-100 rounded-xl p-3">
          <button onClick={saveEdits} disabled={!!busy} className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium disabled:opacity-50">
            {busy === "save" ? "Saving…" : "Save edits"}
          </button>
          <button onClick={() => publish()} disabled={!!busy} className="px-4 py-2 rounded-lg bg-[var(--primary)] text-white text-sm font-semibold disabled:opacity-50">
            Publish approved
          </button>
          <button onClick={() => publish(allKeys)} disabled={!!busy} className="px-4 py-2 rounded-lg bg-[var(--primary)]/10 text-[var(--primary)] text-sm font-semibold disabled:opacity-50">
            {busy === "publish" ? "Publishing…" : "Publish all"}
          </button>
          <button onClick={discard} disabled={!!busy} className="px-4 py-2 rounded-lg text-red-600 text-sm font-medium ml-auto disabled:opacity-50">
            Discard
          </button>
        </div>
      )}
    </div>
  );
}

function BiField({ label, v, onChange, textarea }: {
  label: string; v: { en: string; bn: string };
  onChange: (en: string, bn: string) => void; textarea?: boolean;
}) {
  const cls = "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/30";
  return (
    <div>
      <span className="text-xs font-medium text-text-muted">{label}</span>
      <div className="grid md:grid-cols-2 gap-2 mt-1">
        {textarea ? (
          <textarea className={cls} rows={2} placeholder="English" value={v.en} onChange={(e) => onChange(e.target.value, v.bn)} />
        ) : (
          <input className={cls} placeholder="English" value={v.en} onChange={(e) => onChange(e.target.value, v.bn)} />
        )}
        {textarea ? (
          <textarea className={cls} rows={2} placeholder="বাংলা" value={v.bn} onChange={(e) => onChange(v.en, e.target.value)} />
        ) : (
          <input className={cls} placeholder="বাংলা" value={v.bn} onChange={(e) => onChange(v.en, e.target.value)} />
        )}
      </div>
    </div>
  );
}
