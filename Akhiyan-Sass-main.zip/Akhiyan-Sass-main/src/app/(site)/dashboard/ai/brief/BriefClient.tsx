"use client";

import { useState } from "react";
import { FiBookOpen, FiSave, FiCheckCircle, FiAlertTriangle } from "react-icons/fi";
import DashboardLayout from "@/components/DashboardLayout";
import type { SiteBriefData } from "@/lib/ai/brief";

interface Props {
  initial: SiteBriefData;
}

/** Convert string[] ↔ comma-separated string for textarea-style editing. */
const joinCsv = (arr: string[]) => arr.join(", ");
const splitCsv = (s: string): string[] =>
  s.split(",").map((v) => v.trim()).filter(Boolean);

export default function BriefClient({ initial }: Props) {
  const [form, setForm] = useState<SiteBriefData>(initial);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  function set<K extends keyof SiteBriefData>(key: K, value: SiteBriefData[K]) {
    setForm((p) => ({ ...p, [key]: value }));
  }

  async function save() {
    setMsg(null);
    setSaving(true);
    try {
      const res = await fetch("/api/v1/admin/ai/brief", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);
      setForm(j);
      setMsg({ kind: "ok", text: "Brief saved. Every AI call will use this as context." });
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Save failed" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <DashboardLayout title="Site Brief">
      <div className="mx-auto max-w-3xl space-y-6 py-8">
        <header>
          <h1 className="flex items-center gap-2 text-2xl font-bold text-zinc-900">
            <FiBookOpen className="text-orange-500" /> Site Brief
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            Tell the AI about your business once. Every AI feature in this dashboard —
            rewrites, page generation, landing-page builder — will use this as
            context so generated copy stays consistent with your brand.
          </p>
        </header>

        {msg && (
          <div
            className={[
              "rounded-lg border px-4 py-3 text-sm flex items-start gap-2",
              msg.kind === "ok"
                ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                : "border-rose-200 bg-rose-50 text-rose-800",
            ].join(" ")}
          >
            {msg.kind === "ok" ? <FiCheckCircle className="mt-0.5" /> : <FiAlertTriangle className="mt-0.5" />}
            <span>{msg.text}</span>
          </div>
        )}

        <section className="space-y-4 rounded-xl border border-zinc-200 bg-white p-5">
          <div>
            <label className="block text-sm font-medium text-zinc-700">Business name <span className="text-rose-500">*</span></label>
            <input
              value={form.businessName}
              onChange={(e) => set("businessName", e.target.value)}
              placeholder="e.g. CD Ecom Herbals"
              required
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700">One-liner</label>
            <input
              value={form.oneLiner}
              onChange={(e) => set("oneLiner", e.target.value)}
              placeholder="Handmade herbal soap from Sylhet"
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
            <p className="mt-1 text-xs text-zinc-500">One sentence: what you do.</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700">Long description (2–3 paragraphs)</label>
            <textarea
              value={form.longDescription}
              onChange={(e) => set("longDescription", e.target.value)}
              placeholder="Tell your story. Why does the business exist? What's special about it?"
              rows={5}
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700">Target audience</label>
            <input
              value={form.targetAudience}
              onChange={(e) => set("targetAudience", e.target.value)}
              placeholder="Eco-conscious women 25-45 in Bangladesh"
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-zinc-700">Tone</label>
              <select
                value={form.tone}
                onChange={(e) => set("tone", e.target.value)}
                className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
              >
                <option value="friendly">Friendly</option>
                <option value="professional">Professional</option>
                <option value="playful">Playful</option>
                <option value="luxury">Luxury</option>
                <option value="bold">Bold</option>
                <option value="warm">Warm</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-700">Primary language</label>
              <select
                value={form.primaryLanguage}
                onChange={(e) => set("primaryLanguage", e.target.value)}
                className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
              >
                <option value="en">English</option>
                <option value="bn">Bangla</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-zinc-700">Product categories</label>
              <input
                value={joinCsv(form.productCategories)}
                onChange={(e) => set("productCategories", splitCsv(e.target.value))}
                placeholder="soap, skincare, shampoo"
                className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
              />
              <p className="mt-1 text-xs text-zinc-500">Comma-separated.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-700">Locations / markets</label>
              <input
                value={joinCsv(form.locations)}
                onChange={(e) => set("locations", splitCsv(e.target.value))}
                placeholder="Bangladesh, Sylhet, Dhaka"
                className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
              />
              <p className="mt-1 text-xs text-zinc-500">Comma-separated.</p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700">Unique selling points (up to 5)</label>
            <input
              value={joinCsv(form.uniqueSelling)}
              onChange={(e) => set("uniqueSelling", splitCsv(e.target.value))}
              placeholder="Locally sourced ingredients, plastic-free packaging, family business since 1998"
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700">Words/phrases to avoid</label>
            <input
              value={joinCsv(form.doNotUse)}
              onChange={(e) => set("doNotUse", splitCsv(e.target.value))}
              placeholder="cheap, discount, world-class"
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
            <p className="mt-1 text-xs text-zinc-500">The AI will be told to never use these.</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700">
              Voice sample <span className="text-xs font-normal text-zinc-500">(a paragraph you&apos;ve already written that sounds like you)</span>
            </label>
            <textarea
              value={form.exampleParagraph}
              onChange={(e) => set("exampleParagraph", e.target.value)}
              placeholder="Paste a paragraph you're proud of. The AI will match this writing style."
              rows={4}
              className="mt-1 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
            />
          </div>
        </section>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={save}
            disabled={saving || !form.businessName.trim()}
            className="inline-flex items-center gap-2 rounded-md bg-zinc-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-zinc-700 disabled:opacity-50"
          >
            <FiSave /> {saving ? "Saving…" : "Save brief"}
          </button>
        </div>
      </div>
    </DashboardLayout>
  );
}
