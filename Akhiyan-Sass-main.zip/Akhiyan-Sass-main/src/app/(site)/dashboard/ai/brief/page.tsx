/**
 * Site Brief was merged into AI Site Setup (single page). Keep this route as
 * a permanent redirect so old links / nav / bookmarks still work.
 */
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default function BriefRedirect() {
  redirect("/dashboard/ai/site-setup");
}
