/**
 * Dashboard → AI → History.
 * Read-only viewer for AI page-builder conversation sessions: list every
 * session, open one to replay the full back-and-forth + what was built.
 */
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import AiHistoryClient from "./AiHistoryClient";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function AiHistoryPage() {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");
  return <AiHistoryClient />;
}
