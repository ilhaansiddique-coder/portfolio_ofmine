"use client";

import * as React from "react";
import { api } from "@/lib/api";

type Session = { id: number; title: string; pageId: number | null; createdAt: string; updatedAt: string; messageCount: number };
type Message = { id: number; role: string; content: string; mode: string | null; appliedData: unknown; inputTokens: number; outputTokens: number; createdAt: string };
type Detail = { id: number; title: string; pageId: number | null; createdAt: string; updatedAt: string; messages: Message[] };

export default function AiHistoryClient() {
  const [sessions, setSessions] = React.useState<Session[] | null>(null);
  const [active, setActive] = React.useState<Detail | null>(null);
  const [loadingDetail, setLoadingDetail] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setError(null);
    try { setSessions(await api.admin.aiConversations()); }
    catch (e) { setError(e instanceof Error ? e.message : "Failed to load"); setSessions([]); }
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const open = async (id: number) => {
    setLoadingDetail(true); setError(null);
    try { setActive(await api.admin.aiConversation(id)); }
    catch (e) { setError(e instanceof Error ? e.message : "Failed to open"); }
    finally { setLoadingDetail(false); }
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this conversation? This can't be undone.")) return;
    try {
      await api.admin.deleteAiConversation(id);
      if (active?.id === id) setActive(null);
      load();
    } catch (e) { setError(e instanceof Error ? e.message : "Failed to delete"); }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight text-zinc-900">AI History</h1>
        <p className="mt-1 text-sm text-zinc-500">Every page-builder conversation, with what the AI built.</p>
      </header>

      {error && <div className="rounded-lg bg-rose-50 px-4 py-2.5 text-sm text-rose-700">{error}</div>}

      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        {/* Sessions list */}
        <div className="rounded-xl border border-zinc-200 bg-white">
          <div className="border-b border-zinc-100 px-4 py-3 text-sm font-semibold text-zinc-700">
            Conversations
            {sessions && <span className="ml-2 rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium text-zinc-600">{sessions.length}</span>}
          </div>
          <div className="max-h-[70vh] overflow-y-auto">
            {sessions === null && <div className="p-6 text-sm text-zinc-400">Loading…</div>}
            {sessions?.length === 0 && <div className="p-6 text-sm text-zinc-400">No conversations yet. Use the AI assistant in the page builder.</div>}
            <ul className="divide-y divide-zinc-50">
              {sessions?.map((s) => (
                <li key={s.id} className={`group flex items-start gap-2 px-4 py-3 ${active?.id === s.id ? "bg-zinc-50" : "hover:bg-zinc-50/60"}`}>
                  <button type="button" className="min-w-0 flex-1 text-left" onClick={() => open(s.id)}>
                    <p className="truncate text-sm font-medium text-zinc-800">{s.title}</p>
                    <p className="mt-0.5 text-xs text-zinc-400">
                      {s.messageCount} msg · {new Date(s.updatedAt).toLocaleString()}
                      {s.pageId ? ` · page #${s.pageId}` : ""}
                    </p>
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(s.id)}
                    className="rounded p-1 text-zinc-300 opacity-0 transition-opacity hover:bg-rose-50 hover:text-rose-600 group-hover:opacity-100"
                    title="Delete"
                  >
                    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Thread */}
        <div className="rounded-xl border border-zinc-200 bg-white">
          {!active ? (
            <div className="flex h-full min-h-[300px] items-center justify-center p-8 text-sm text-zinc-400">
              {loadingDetail ? "Loading…" : "Select a conversation to view its history."}
            </div>
          ) : (
            <div className="flex flex-col">
              <div className="border-b border-zinc-100 px-5 py-4">
                <h2 className="text-base font-semibold text-zinc-900">{active.title}</h2>
                <p className="mt-0.5 text-xs text-zinc-400">
                  Started {new Date(active.createdAt).toLocaleString()} · {active.messages.length} messages
                </p>
              </div>
              <div className="space-y-4 p-5">
                {active.messages.map((m) => (
                  <div key={m.id} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
                    <div className="max-w-[80%]">
                      <div className={`rounded-2xl px-4 py-2.5 text-sm ${m.role === "user" ? "rounded-br-md bg-violet-600 text-white" : "rounded-bl-md bg-zinc-100 text-zinc-800"}`}>
                        {m.content}
                      </div>
                      <div className={`mt-1 flex items-center gap-2 text-[11px] text-zinc-400 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                        {m.mode && <span className="rounded-full bg-zinc-100 px-1.5 py-0.5 capitalize">{m.mode}</span>}
                        <span>{new Date(m.createdAt).toLocaleTimeString()}</span>
                        {(m.inputTokens > 0 || m.outputTokens > 0) && <span>· {m.inputTokens + m.outputTokens} tok</span>}
                      </div>
                      {m.appliedData != null && (
                        <details className="mt-2">
                          <summary className="cursor-pointer text-[11px] font-medium text-zinc-400 hover:text-zinc-600">View what was built</summary>
                          <pre className="mt-1 max-h-64 overflow-auto rounded-lg bg-zinc-50 p-3 text-[11px] leading-relaxed text-zinc-500">
                            {JSON.stringify(m.appliedData, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
