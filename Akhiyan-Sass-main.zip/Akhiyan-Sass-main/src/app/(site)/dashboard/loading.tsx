/**
 * Generic dashboard loading fallback — used for every dashboard subroute that
 * doesn't ship its own loading.tsx. The persistent shell (sidebar + topbar
 * from dashboard/layout.tsx) stays mounted; only this skeleton swaps in for
 * the inner main content during nav. Gives instant visual feedback so nav
 * never feels like a stall.
 */
export default function DashboardSubrouteLoading() {
  return (
    <div className="space-y-4 animate-pulse">
      {/* Page title + actions bar */}
      <div className="flex items-center justify-between gap-4">
        <div className="h-7 w-48 rounded bg-gray-200" />
        <div className="flex items-center gap-2">
          <div className="h-9 w-24 rounded-lg bg-gray-200" />
          <div className="h-9 w-32 rounded-lg bg-gray-200" />
        </div>
      </div>

      {/* Filter / toolbar row */}
      <div className="flex items-center gap-3">
        <div className="h-10 flex-1 rounded-lg bg-gray-100" />
        <div className="h-10 w-28 rounded-lg bg-gray-100" />
        <div className="h-10 w-28 rounded-lg bg-gray-100" />
      </div>

      {/* Content card with table rows */}
      <div className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
        <div className="space-y-3">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 py-2">
              <div className="h-10 w-10 rounded-lg bg-gray-200 shrink-0" />
              <div className="flex-1 space-y-1.5">
                <div className="h-3.5 w-2/5 rounded bg-gray-200" />
                <div className="h-3 w-1/4 rounded bg-gray-100" />
              </div>
              <div className="h-3.5 w-20 rounded bg-gray-200" />
              <div className="h-7 w-7 rounded-full bg-gray-100" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
