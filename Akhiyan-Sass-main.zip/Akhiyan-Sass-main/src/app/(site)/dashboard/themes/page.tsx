/**
 * /dashboard/themes — tenant-side storefront theme picker.
 *
 * Lists the storefront UI design themes registered in
 * `src/lib/storefront-themes/`. Picking one writes `storefront_theme`
 * to this tenant's site_setting rows; the storefront reads that value
 * on render and swaps in the matching component set on the next page
 * load (existing products, content, and settings stay untouched).
 *
 * To add a new theme: create a file in `src/lib/storefront-themes/`,
 * register it in that folder's `index.ts`, and rebuild. The card grid
 * here picks it up automatically — no edits to this file needed.
 */

import { redirect } from "next/navigation";
import DashboardLayout from "@/components/DashboardLayout";
import { getSessionUser } from "@/lib/auth";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { STOREFRONT_THEMES, DEFAULT_STOREFRONT_THEME_ID } from "@/lib/storefront-themes";
import ThemesClient from "./ThemesClient";

export const dynamic = "force-dynamic";

export default async function ThemesPage() {
  const user = await getSessionUser();
  if (!user) redirect("/cdlogin?next=/dashboard/themes");
  if (user.role !== "admin") redirect("/dashboard");

  // Read the tenant's saved storefront-theme key so the picker can
  // highlight the active card. Default = the "default" theme.
  const { prisma } = await getPrismaForRequest();
  const row = await prisma.siteSetting.findUnique({ where: { key: "storefront_theme" } });
  const activeId = row?.value || DEFAULT_STOREFRONT_THEME_ID;

  // Strip non-serializable fields (React component refs in `.components`)
  // before crossing the server→client boundary — Next.js rejects the
  // whole render otherwise. The client only needs JSON-safe metadata to
  // draw the picker; preview components are looked up by id in the
  // client-side registry (`previews/registry.ts`).
  const safeThemes = STOREFRONT_THEMES.map(({ id, label, description, preview, isDefault, tags }) => ({
    id, label, description, preview, isDefault, tags,
  }));

  return (
    <DashboardLayout title="Storefront themes">
      <ThemesClient themes={safeThemes} activeId={activeId} />
    </DashboardLayout>
  );
}
