"use client";

/**
 * Storefront theme picker. Grid of cards from `src/lib/storefront-themes/`.
 * Click Apply → persists `storefront_theme = <id>` to this tenant's
 * site_setting via the same API the customizer uses. Storefront switches
 * to the new component set on the next page load — existing data
 * (products, content, branding, settings) is preserved.
 */

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { FiCheck, FiLoader, FiLayout, FiArrowRight } from "react-icons/fi";
import { api } from "@/lib/api";
import type { StorefrontTheme } from "@/lib/storefront-themes";
import { getPreviewMockup } from "@/lib/storefront-themes/previews/registry";

export default function ThemesClient({
  themes,
  activeId,
}: {
  themes?: StorefrontTheme[];
  activeId: string;
}) {
  // Defensive — if the prop is missing (e.g. server module hot-reloaded with
  // a partial state) treat it as empty instead of crashing the page.
  const themeList = Array.isArray(themes) ? themes : [];
  const router = useRouter();
  const [applyingId, setApplyingId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; kind: "ok" | "err" } | null>(null);

  async function apply(t: StorefrontTheme) {
    if (applyingId || t.id === activeId) return;
    setApplyingId(t.id);
    try {
      await api.admin.updateSettings({ storefront_theme: t.id });
      setToast({ msg: `Applied "${t.label}". Storefront uses the new theme on the next page load.`, kind: "ok" });
      router.refresh();
    } catch (err) {
      setToast({ msg: err instanceof Error ? err.message : "Apply failed", kind: "err" });
    } finally {
      setApplyingId(null);
      setTimeout(() => setToast(null), 4000);
    }
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1">
        <h2 className="text-xl font-bold text-gray-900">Storefront themes</h2>
        <p className="text-sm text-gray-500 max-w-2xl">
          Pick a UI design for your store. The theme changes how products, sections, and pages are <em>presented</em> — your products, prices, content, and brand settings stay exactly as they are.
        </p>
      </header>

      {toast && (
        <div className={`rounded-xl px-4 py-3 text-sm ${
          toast.kind === "ok"
            ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
            : "bg-red-50 text-red-700 border border-red-200"
        }`}>
          {toast.msg}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {themeList.length === 0 && (
          <div className="col-span-full text-center text-sm text-gray-400 py-12">
            No themes registered yet.
          </div>
        )}
        {themeList.map((t) => {
          const active = t.id === activeId;
          const busy = applyingId === t.id;
          // Preview-mockup lookup happens client-side so the theme object
          // stays JSON-safe across the server→client boundary.
          const PreviewMockup = getPreviewMockup(t.id);
          return (
            <article
              key={t.id}
              className={`group relative flex flex-col bg-white border rounded-2xl overflow-hidden shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-lg ${
                active ? "border-[var(--primary)] ring-2 ring-[var(--primary)]/30" : "border-gray-200 hover:border-gray-300"
              }`}
            >
              {/* Preview area — real screenshot if available, otherwise a
                * branded gradient placeholder so the card never looks empty
                * while a developer is still preparing the asset. */}
              <div className="relative aspect-[16/10] bg-gradient-to-br from-emerald-50 via-white to-emerald-50/30 overflow-hidden">
                {t.preview ? (
                  // Priority 1: real screenshot asset. `object-contain` so
                  // the whole storefront is visible — no edge-cropping —
                  // and a subtle gradient backdrop fills any letterboxed
                  // space behind it.
                  <Image
                    src={t.preview}
                    alt={`${t.label} preview`}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className="object-contain"
                    onError={(e) => {
                      // Hide the broken image so the fallback shows through.
                      (e.currentTarget as HTMLImageElement).style.display = "none";
                    }}
                  />
                ) : PreviewMockup ? (
                  // Priority 2: inline CSS mockup registered for this
                  // theme id — small storefront sketch (browser chrome,
                  // hero, product grid, footer) that gives the user a
                  // faithful preview before any screenshot is captured.
                  <PreviewMockup />
                ) : (
                  // Priority 3: bare icon fallback when neither is provided.
                  <div className="absolute inset-0 grid place-items-center">
                    <FiLayout className="h-14 w-14 text-[var(--primary)]/30" />
                  </div>
                )}

                {/* Active badge */}
                {active && (
                  <span className="absolute top-3 right-3 inline-flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide bg-white/95 text-[var(--primary)] px-2.5 py-1 rounded-full shadow">
                    <FiCheck className="w-3 h-3" /> Active
                  </span>
                )}
                {t.isDefault && !active && (
                  <span className="absolute top-3 left-3 inline-flex items-center text-[10px] font-semibold uppercase tracking-wider bg-white/95 text-gray-600 px-2 py-0.5 rounded-full shadow-sm">
                    Default
                  </span>
                )}
              </div>

              <div className="p-5 space-y-3 flex-1 flex flex-col">
                <div>
                  <h3 className="text-base font-bold text-gray-900">{t.label}</h3>
                  <p className="mt-1 text-xs text-gray-500 leading-relaxed">{t.description}</p>
                </div>

                {t.tags && t.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {t.tags.map((tag) => (
                      <span key={tag} className="text-[10px] font-medium uppercase tracking-wide bg-gray-100 text-gray-600 px-2 py-0.5 rounded-md">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                <div className="mt-auto pt-2">
                  <button
                    type="button"
                    onClick={() => apply(t)}
                    disabled={busy || active}
                    className={`w-full inline-flex items-center justify-center gap-2 h-10 rounded-xl text-sm font-semibold transition-colors ${
                      active
                        ? "bg-gray-100 text-gray-500 cursor-default"
                        : "bg-[var(--primary)] text-white hover:bg-[var(--primary-light)]"
                    } disabled:opacity-60`}
                  >
                    {busy
                      ? (<><FiLoader className="w-4 h-4 animate-spin" /> Applying…</>)
                      : active
                        ? "Currently active"
                        : <>Apply {t.label} <FiArrowRight className="w-4 h-4" /></>}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      <div className="rounded-xl border border-dashed border-gray-200 bg-gray-50/50 p-5 text-sm text-gray-600">
        <p className="font-semibold text-gray-800">Want a new theme?</p>
        <p className="mt-1 text-xs leading-relaxed">
          Themes live in <code className="px-1 py-0.5 bg-white border border-gray-200 rounded text-[11px] font-mono">src/lib/storefront-themes/</code> —
          one file per theme. Adding a new file + registering it in <code className="px-1 py-0.5 bg-white border border-gray-200 rounded text-[11px] font-mono">index.ts</code>
          makes it appear here automatically. See the README in that folder for the full guide.
        </p>
      </div>
    </div>
  );
}
