import type { Metadata } from "next";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { UI_PREF_COOKIE } from "@/lib/ui-prefs";
import { DashboardLayoutShell } from "@/components/DashboardLayout";
import PwaRegister from "@/components/dashboard/PwaRegister";
import NewOrderToast from "@/components/NewOrderToast";
import DashboardRealtime from "@/components/DashboardRealtime";
import TenantFeaturesProvider from "@/components/TenantFeaturesProvider";
import TenantExpiryBanner from "@/components/dashboard/TenantExpiryBanner";
import { validityState } from "@/lib/tenant-validity";
import { getSessionUser } from "@/lib/auth";
import { isStaffOrAdmin } from "@/lib/auth-helpers";
import { maybeGetPrismaForRequest } from "@/lib/prisma-tenant";
import { featureKeyForPath, firstAllowedDashboardPath } from "@/lib/dashboard-route-features";
import { hasFeature, type TenantFeatures } from "@/lib/tenant-features";

/**
 * Server-render the <link rel="manifest"> only for staff/admin sessions.
 * Chrome's PWA install heuristic looks for the manifest link at initial
 * HTML parse time — injecting it client-side via useEffect (as the old
 * approach did) was unreliable: by the time React hydrated, Chrome had
 * often already decided the page was not installable and never fired
 * beforeinstallprompt. Putting it in metadata guarantees it ships in
 * the first response.
 *
 * Customers and logged-out visitors get NO manifest link → no install
 * prompt, no leakage that an admin PWA exists. The /api/dashboard/manifest
 * endpoint also 404s for non-staff as defense-in-depth.
 */
// generateMetadata reads cookies() via getSessionUser → layout must be dynamic.
// Without this, Next may try to prerender at build time and fail on cookies().
export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  try {
    const user = await getSessionUser();
    if (user && isStaffOrAdmin(user.role)) {
      return { manifest: "/api/dashboard/manifest" };
    }
  } catch {
    // Session lookup failed — treat as unauthenticated, no manifest
  }
  return {};
}

/**
 * Persistent dashboard shell — sidebar + header mount ONCE and stay mounted
 * across navigations between dashboard pages. Only the inner main content
 * unmounts/remounts (and shows loading.tsx as a fallback).
 *
 * Per-page <DashboardLayout title="..."> calls now act as no-op title-setters
 * via DashboardShellContext, so existing pages don't need to be refactored.
 */
export default async function DashboardRootLayout({ children }: { children: React.ReactNode }) {
  // Pull the current tenant's feature flags so the dashboard nav can hide
  // disabled modules without requiring a separate API call.
  const ctx = await maybeGetPrismaForRequest();
  const features: TenantFeatures = (ctx?.tenant.features as Record<string, boolean> | null) ?? null;

  // Subscription expiry warning. Shown only inside the 7-day window — an
  // already-expired tenant is blocked upstream by the (site) layout's renew
  // page, so here we only ever surface the "expiring soon" heads-up.
  const expiry = validityState((ctx?.tenant as { expiresAt?: Date | null } | undefined)?.expiresAt ?? null);

  // Server-side gate: if the current path requires a feature that's disabled
  // for this tenant, kick the user back to the dashboard root. Hiding the
  // sidebar item alone isn't enough — anyone could type the URL or follow
  // a stale bookmark. This redirect applies to admin AND staff equally
  // because there's only one feature map per tenant.
  const h = await headers();
  const path = h.get("x-pathname") || "";
  const required = featureKeyForPath(path);
  if (required && !hasFeature(features, required)) {
    // Pick the first allowed dashboard page as the fallback. If even that's
    // gone (every feature disabled), show /dashboard/no-access — a static
    // "ask your admin" stub that doesn't require any feature.
    const target = firstAllowedDashboardPath(features);
    if (path !== target) redirect(target);
  }

  // Read saved chrome prefs from cookies so SSR renders the sidebar at its
  // saved width — no post-mount snap from expanded→collapsed on refresh.
  const cookieStore = await cookies();
  const initialCollapsed = cookieStore.get(UI_PREF_COOKIE.sidebarCollapsed)?.value === "1";

  return (
    <TenantFeaturesProvider value={features}>
      <DashboardLayoutShell
        initialCollapsed={initialCollapsed}
        topBanner={
          expiry.state === "expiring" && expiry.daysLeft !== null ? (
            <TenantExpiryBanner daysLeft={expiry.daysLeft} expiresAt={expiry.expiresAt} />
          ) : null
        }
      >
        <PwaRegister />
        <NewOrderToast />
        <DashboardRealtime />
        {children}
      </DashboardLayoutShell>
    </TenantFeaturesProvider>
  );
}
