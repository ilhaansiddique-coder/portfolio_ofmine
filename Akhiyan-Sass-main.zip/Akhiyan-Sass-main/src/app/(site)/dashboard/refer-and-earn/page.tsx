/**
 * /dashboard/refer-and-earn — tenant admin "refer & earn" inside the dashboard.
 *
 * Two tabs:
 *   • Refer & earn — hero with ref link, how-it-works, FAQ
 *   • My earnings — payout progress, stats, commission history, payout method
 *
 * Server component does the auth + auto-enrollment + initial data fetch.
 * Renders a client component with the tab UI.
 */

import { redirect } from "next/navigation";
import DashboardLayout from "@/components/DashboardLayout";
import { getSessionUser } from "@/lib/auth";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { controlPrisma } from "@/lib/prisma-control";
import {
  generateUniqueCode,
  generateDashboardToken,
  getAffiliateStats,
  getAffiliateMetrics,
} from "@/lib/affiliate";
import { ReferAndEarnClient } from "./refer-and-earn-client";
import { headers } from "next/headers";
import { hasFeature } from "@/lib/tenant-features";

export const dynamic = "force-dynamic";

async function getOrCreateTenantAffiliate(tenant: { id: number; name: string; ownerEmail: string }) {
  // 1) Already linked to this tenant — done.
  const byTenant = await controlPrisma.affiliate.findUnique({ where: { tenantId: tenant.id } });
  if (byTenant) return byTenant;

  // 2) An Affiliate row already exists for the owner's email (signed up
  //    earlier as a standalone affiliate). Link it to this tenant instead of
  //    creating a duplicate — the email column is UNIQUE.
  const byEmail = await controlPrisma.affiliate.findUnique({ where: { email: tenant.ownerEmail } });
  if (byEmail) {
    return controlPrisma.affiliate.update({
      where: { id: byEmail.id },
      data: { tenantId: tenant.id },
    });
  }

  // 3) Fresh enrollment.
  return controlPrisma.affiliate.create({
    data: {
      tenantId: tenant.id,
      email: tenant.ownerEmail,
      name: tenant.name,
      code: await generateUniqueCode(tenant.name),
      status: "active",
      commissionRate: 0.20,
      dashboardToken: generateDashboardToken(),
    },
  });
}

export default async function ReferAndEarnPage() {
  // Soft auth check: bounce non-admin users via redirect (server component
  // can't throw a NextResponse, the dashboard layout's client-side guard
  // catches the rest). Refer-and-earn is admin-only.
  const user = await getSessionUser();
  if (!user) redirect("/cdlogin?next=/dashboard/refer-and-earn");
  if (user.role !== "admin") redirect("/dashboard");

  // Build a minimal Request shape so getPrismaForRequest can read the host.
  const h = await headers();
  const fakeReq = new Request(`http://${h.get("host")}/`, { headers: h });
  const { tenant } = await getPrismaForRequest(fakeReq);
  const ctrlTenant = await controlPrisma.tenant.findUnique({
    where: { id: tenant.id },
    select: { id: true, name: true, ownerEmail: true, features: true },
  });
  // Hard gate: superadmin can disable the refer-and-earn feature per tenant.
  // The dashboard layout's client-side TenantFeaturesProvider also catches
  // URL jumps, but this is the durable server-side fallback — if a tenant
  // hits the route via direct URL with the feature disabled they're sent to
  // the dashboard root instead of seeing referral data they shouldn't.
  if (ctrlTenant && !hasFeature((ctrlTenant.features as Record<string, boolean> | null) ?? null, "marketing.refer_earn")) {
    redirect("/dashboard");
  }
  if (!ctrlTenant) {
    return (
      <DashboardLayout title="Refer & earn">
        <div className="p-6 text-center text-gray-500">Tenant not found.</div>
      </DashboardLayout>
    );
  }

  const affiliate = await getOrCreateTenantAffiliate(ctrlTenant);
  const [stats, metrics, commissions, referrals, payouts] = await Promise.all([
    getAffiliateStats(affiliate.id),
    getAffiliateMetrics(affiliate.id),
    controlPrisma.affiliateCommission.findMany({
      where: { affiliateId: affiliate.id },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
    controlPrisma.affiliateReferral.findMany({
      where: { affiliateId: affiliate.id },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
    controlPrisma.affiliatePayout.findMany({
      where: { affiliateId: affiliate.id },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
  ]);

  // Join each referral with its first signup commission so we can show the
  // earnings + status on the Referrals table without an N+1 lookup.
  const commByRef = new Map<number, typeof commissions[number]>();
  for (const c of commissions) if (c.event === "signup") commByRef.set(c.referralId, c);
  // Look up the referred tenant's email/name (these are the "Invites").
  const tenantIds = referrals.map((r) => r.tenantId);
  const referredTenants = tenantIds.length
    ? await controlPrisma.tenant.findMany({
        where: { id: { in: tenantIds } },
        select: { id: true, name: true, ownerEmail: true },
      })
    : [];
  const tenantById = new Map(referredTenants.map((t) => [t.id, t]));

  // Build the ref URL from the CURRENT request host (works in dev on
  // demo.localtest.me:3005 AND in production on the real domain — no env
  // variable needed). Falls back to NEXT_PUBLIC_BASE_URL / BASE_DOMAIN only
  // when headers aren't available (shouldn't happen in a route handler but
  // guards against future refactors).
  const reqHeaders = h;
  const proto = reqHeaders.get("x-forwarded-proto") || (process.env.NODE_ENV === "production" ? "https" : "http");
  const hostHeader = reqHeaders.get("host");
  const baseDomain = hostHeader
    ? `${proto}://${hostHeader}`
    : (process.env.NEXT_PUBLIC_BASE_URL || `https://${process.env.BASE_DOMAIN || "example.com"}`);
  const refUrl = `${baseDomain}/ref/${affiliate.code}`;
  const available = Math.max(0, stats.approvedCommission);

  return (
    <DashboardLayout title="Refer & earn">
      <ReferAndEarnClient
        code={affiliate.code}
        refUrl={refUrl}
        commissionRate={affiliate.commissionRate}
        bkashPhone={affiliate.bkashPhone}
        paypalEmail={affiliate.paypalEmail}
        totalEarned={affiliate.totalEarned}
        totalPaid={affiliate.totalPaid}
        available={available}
        stats={stats}
        metrics={{
          totalClicks: metrics.totalClicks,
          clicks30d: metrics.clicks30d,
          uniqueVisitors30d: metrics.uniqueVisitors30d,
          conversionRate: metrics.conversionRate,
        }}
        commissions={commissions.map((c) => ({
          id: c.id,
          amount: c.amount,
          status: c.status,
          event: c.event,
          createdAt: c.createdAt.toISOString(),
        }))}
        referrals={referrals.map((r) => {
          const t = tenantById.get(r.tenantId);
          const c = commByRef.get(r.id);
          return {
            id: r.id,
            invite: t?.ownerEmail || `Store #${r.tenantId}`,
            plan: r.plan,
            status: c?.status ?? "pending",
            earnings: c?.amount ?? 0,
            createdAt: r.createdAt.toISOString(),
          };
        })}
        payouts={payouts.map((po) => ({
          id: po.id,
          method: po.method,
          destination: po.destination,
          amount: po.amount,
          status: po.status,
          txRef: po.txRef,
          createdAt: po.createdAt.toISOString(),
        }))}
        payoutThresholds={{ bkash: 500, paypal: 10 }}
      />
    </DashboardLayout>
  );
}
