"use client";

import { useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useSiteSettings } from "@/lib/SiteSettingsContext";
import {
  FiCopy, FiCheck, FiGift, FiUsers, FiTrendingUp,
  FiCreditCard, FiChevronDown, FiChevronLeft, FiChevronRight, FiCheckCircle, FiHelpCircle, FiInfo, FiArrowDown,
} from "react-icons/fi";

interface Stats { referrals: number; pendingCommission: number; approvedCommission: number; paidCommission: number; pendingPayout: number; processingPayout: number; }
interface Metrics { totalClicks: number; clicks30d: number; uniqueVisitors30d: number; conversionRate: number; }
interface Commission { id: number; amount: number; status: string; event: string; createdAt: string; }
interface ReferralRow { id: number; invite: string; plan: string; status: string; earnings: number; createdAt: string; }
interface PayoutRow { id: number; method: string; destination: string; amount: number; status: string; txRef: string | null; createdAt: string; }
interface Thresholds { bkash: number; paypal: number; }

interface Props {
  code: string;
  refUrl: string;
  commissionRate: number;
  bkashPhone: string | null;
  paypalEmail: string | null;
  totalEarned: number;
  totalPaid: number;
  available: number;
  stats: Stats;
  metrics: Metrics;
  commissions: Commission[];
  referrals: ReferralRow[];
  payouts: PayoutRow[];
  payoutThresholds: Thresholds;
}

const taka = (n: number) => `৳${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
const takaFixed = (n: number) => `৳${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const fmtDate = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
// ISO date format (YYYY-MM-DD) for table cells — matches the design reference.
const fmtIsoDate = (iso: string) => new Date(iso).toISOString().slice(0, 10);

type Tab = "refer" | "earnings";

export function ReferAndEarnClient(p: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const settings = useSiteSettings();
  const tabParam = searchParams.get("tab");
  const tab: Tab = tabParam === "earnings" || tabParam === "my-earnings" ? "earnings" : "refer";
  const brandName =
    settings.site_name ||
    settings.store_name ||
    settings.business_name ||
    settings.company_name ||
    "CD Ecom";

  function setTab(next: Tab) {
    const params = new URLSearchParams(searchParams.toString());
    if (next === "earnings") params.set("tab", "earnings");
    else params.delete("tab");
    const query = params.toString();
    router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
  }

  return (
    <div className="space-y-6">
      {/* Tab nav */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <TabBtn active={tab === "refer"} onClick={() => setTab("refer")}>Refer & earn</TabBtn>
          <TabBtn active={tab === "earnings"} onClick={() => setTab("earnings")}>My earnings</TabBtn>
        </div>
        <div className="hidden sm:flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm text-gray-900 shadow-sm">
          <FiCreditCard className="h-4 w-4 text-[var(--primary)]" />
          <span>{brandName} balance:</span>
          <strong>{takaFixed(p.available)}</strong>
          <FiHelpCircle className="h-4 w-4 text-[var(--primary)]" />
        </div>
      </div>

      {tab === "refer" ? <ReferTab p={p} /> : <EarningsTab p={p} />}
    </div>
  );
}

// ─── Tab 1: Refer & earn ─────────────────────────────────────────────────────

function ReferTab({ p }: { p: Props }) {
  const rate = Math.round(p.commissionRate * 100);

  return (
    <div className="space-y-6">
      {/* Hero banner with ref link */}
      <div
        className="refer-hero relative overflow-hidden rounded-2xl p-6 md:p-8 text-white shadow-lg"
        style={{
          // Hard-coded to the LIGHT-mode brand greens so the hero keeps its
          // gradient identity in dark mode (dark mode flattens --primary-*
          // CSS vars to a single bright #00bc7d which kills the gradient).
          background:
            "linear-gradient(135deg, #072b18 0%, #0a3d22 50%, #072b18 100%)",
        }}
      >
        <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full bg-white/5" />
        <div className="absolute -bottom-16 -left-8 h-48 w-48 rounded-full bg-white/5" />
        <div className="relative">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-emerald-300">
            <FiGift className="w-4 h-4" /> Limited time offer
          </div>
          <h2 className="mt-2 text-2xl md:text-3xl font-bold leading-tight">
            Earn {rate}% commission when you refer friends to <span className="italic">CD Ecom</span>
          </h2>
          <p className="mt-2 text-sm text-white/80 max-w-xl">
            Share your link. They get a discount, you get paid when they sign up and pay.
          </p>
          <CopyLinkRow refUrl={p.refUrl} />
        </div>
      </div>

      {/* What you earn / what they get */}
      <div className="rounded-2xl border border-gray-200 bg-white p-6">
        <h3 className="text-lg font-bold text-gray-900">Know what your friend needs?</h3>
        <p className="mt-1 text-sm text-gray-500">Refer them the exact plan. You earn on every paid signup.</p>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          <PerkCard icon={FiTrendingUp} title={`${rate}% per referral`} body="Of their first month's plan price — paid out to bKash, PayPal, or bank." />
          <PerkCard icon={FiGift} title="Friend gets a discount" body="They pay less to sign up — easier for you to convert them." />
          <PerkCard icon={FiCheckCircle} title="Confirmed after 14 days" body="Once their payment clears, the commission becomes available to withdraw." />
        </div>
      </div>

      {/* How it works */}
      <div className="rounded-2xl border border-gray-200 bg-white p-6">
        <h3 className="text-lg font-bold text-gray-900">How do referrals work?</h3>
        <div className="mt-5 grid gap-4 md:grid-cols-3">
          <Step n={1} title="You send an invite" body="Share your referral link with shop owners who need an ecommerce platform." />
          <Step n={2} title="They start a store" body="Your friend signs up via your link and picks a plan." />
          <Step n={3} title="You get paid" body="Choose bKash, PayPal or wire transfer. Cash out when you hit the minimum." />
        </div>
      </div>

      {/* FAQ */}
      <div className="rounded-2xl border border-gray-200 bg-white p-6">
        <h3 className="text-lg font-bold text-gray-900 text-center">Refer & Earn FAQ</h3>
        <div className="mt-5 space-y-2">
          <Faq q="Which signups count?">
            Any new store that signs up through your link, pays their first plan invoice, and stays active for 14 days.
          </Faq>
          <Faq q="Can I refer an existing customer?">
            Only brand-new tenants count. Existing CD Ecom merchants signing up a second store don&apos;t generate commission.
          </Faq>
          <Faq q="How is this different from the public affiliate program?">
            This is the same program — your tenant account is automatically enrolled as an affiliate. You can also log in at <code>/affiliate</code> if you ever want a separate dashboard view.
          </Faq>
          <Faq q="Why does it take 14 days to confirm a commission?">
            We hold confirmation until the new tenant&apos;s first invoice clears refund risk. After that the amount becomes available to withdraw.
          </Faq>
          <Faq q="How do I get paid?">
            Add a payout method (bKash or PayPal) under <strong>My earnings</strong>. When your approved balance hits the minimum, request a payout — we send within 3 business days.
          </Faq>
        </div>
      </div>
    </div>
  );
}

// ─── Tab 2: My earnings ──────────────────────────────────────────────────────

function EarningsTab({ p }: { p: Props }) {
  // Three fixed milestones on the progress bar (visually equidistant —
  // matches the branded milestone ladder. Bar fill is computed
  // against the highest milestone so the indicator advances smoothly.)
  const M1_BKASH = p.payoutThresholds.bkash;             // bKash minimum (৳500)
  const M2_PAYPAL = p.payoutThresholds.paypal * 110;     // PayPal minimum (~৳1,100)
  const M3_WIRE = 22000;                                 // Wire transfer minimum
  const pct = Math.min(100, Math.round((p.available / M3_WIRE) * 100));

  // Dynamic CTA panel — pick the highest payout method the affiliate qualifies
  // for right now (needs both: enough balance AND payout details on file).
  const hasAnyMethod = !!(p.bkashPhone || p.paypalEmail);
  const eligibleMethod: "Wire Transfer" | "PayPal" | "bKash" | null =
    p.available >= M3_WIRE && hasAnyMethod ? "Wire Transfer" :
    p.available >= M2_PAYPAL && p.paypalEmail ? "PayPal" :
    p.available >= M1_BKASH && p.bkashPhone   ? "bKash" :
    null;

  return (
    <div className="space-y-6">
      {/* ── Top row: payout card (left) + 2 stacked stat tiles (right) ── */}
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_280px]">
        {/* Left: payout card — inner 2-col split (progress on left, CTA panel
         * on right). Breakpoint is xl (1280px) because at lg the left column
         * becomes too narrow for the 3-marker progress bar; below xl the CTA
         * panel drops below the progress section. */}
        <section className="rounded-2xl border border-gray-200 bg-white p-8 shadow-sm">
          <div className="grid gap-10 xl:grid-cols-[minmax(0,1fr)_280px]">
            {/* Left side: title, balance, progress bar */}
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-semibold text-gray-900">Referrals commission payout</h2>
                <FiInfo className="h-4 w-4 text-gray-400" />
              </div>
              <div className="mt-4 text-4xl font-bold text-[var(--primary)]">{taka(p.available)}</div>
              <p className="mt-1 text-xs text-gray-500">Available to withdraw</p>

              {/* Progress bar with 3 milestone markers. Bottom margin reserves
               * space for the absolute-positioned labels below the bar so they
               * don't overlap the next element (CTA panel on mobile). */}
              <div className="relative mt-10 mb-16">
                <div className="relative h-1.5 w-full rounded-full bg-gray-200">
                  <div
                    className="absolute inset-y-0 left-0 rounded-full bg-[var(--primary)] transition-[width] duration-300"
                    style={{ width: `${pct}%` }}
                  />
                  <Dot x={0} />
                  <Dot x={50} />
                  <Dot x={100} />
                </div>
                <Label x={0}   value={taka(M1_BKASH)}  caption="bKash" align="left" />
                <Label x={50}  value={taka(M2_PAYPAL)} caption="PayPal" align="center" />
                <Label x={100} value={taka(M3_WIRE)}   caption="Wire Transfer" align="right" />
              </div>
            </div>

            {/* Right side: dynamic payout CTA panel */}
            <PayoutCtaPanel
              eligibleMethod={eligibleMethod}
              hasAnyMethod={hasAnyMethod}
              available={p.available}
            />
          </div>
        </section>

        {/* Right column: 2 stacked stat tiles */}
        <aside className="grid grid-rows-2 gap-4">
          <StatTile icon={FiGift}  label="Total paid out"  value={taka(p.totalPaid)} />
          <StatTile icon={FiUsers} label="Total referrals" value={String(p.stats.referrals)} />
        </aside>
      </div>

      {/* Traffic stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <SmallStat label="Clicks (30d)"   value={p.metrics.clicks30d.toLocaleString()} />
        <SmallStat label="Unique visitors" value={p.metrics.uniqueVisitors30d.toLocaleString()} />
        <SmallStat label="Total clicks"    value={p.metrics.totalClicks.toLocaleString()} />
        <SmallStat label="Conversion"      value={`${(p.metrics.conversionRate * 100).toFixed(1)}%`} />
      </div>

      {/* Referrals + Payouts (sub-tabbed) */}
      <ReferralsPayoutsCard referrals={p.referrals} payouts={p.payouts} thresholds={p.payoutThresholds} />

      {/* Payout method editor */}
      <PayoutMethodEditor bkashPhone={p.bkashPhone} paypalEmail={p.paypalEmail} />
    </div>
  );
}

// ─── Bits ────────────────────────────────────────────────────────────────────

function TabBtn({ children, active, onClick }: { children: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "px-4 py-2.5 text-sm font-medium transition-colors",
        // Bottom underline: theme color when active, transparent otherwise
        // (transparent keeps height stable so the row doesn't jump on switch).
        "border-b-2",
        active
          ? "border-[var(--primary)] text-[var(--primary)] bg-gray-50"
          : "border-transparent text-gray-600 hover:bg-gray-100 hover:text-gray-900",
      ].join(" ")}
    >
      {children}
    </button>
  );
}

function CopyLinkRow({ refUrl }: { refUrl: string }) {
  const [copied, setCopied] = useState(false);
  function copy() {
    const flag = () => { setCopied(true); setTimeout(() => setCopied(false), 2000); };
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(refUrl).then(flag).catch(legacy);
    else legacy();
    function legacy() {
      try {
        const ta = document.createElement("textarea");
        ta.value = refUrl; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select(); document.execCommand("copy"); document.body.removeChild(ta);
        flag();
      } catch {}
    }
  }
  return (
    <div className="mt-5 flex flex-col items-stretch gap-2 rounded-2xl border border-white/20 bg-white p-2 shadow-lg sm:flex-row">
      <code className="flex-1 overflow-x-auto whitespace-nowrap rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 font-mono text-xs text-gray-900 sm:text-sm">
        {refUrl}
      </code>
      <button
        onClick={copy}
        className={`inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold transition-colors ${
          copied ? "bg-emerald-500 text-white" : "bg-[var(--primary)] text-white hover:bg-[var(--primary-dark)]"
        }`}
      >
        {copied ? <FiCheck className="w-4 h-4" /> : <FiCopy className="w-4 h-4" />}
        {copied ? "Copied!" : "Copy link"}
      </button>
    </div>
  );
}

function PerkCard({ icon: Icon, title, body }: { icon: React.ComponentType<{ className?: string }>; title: string; body: string }) {
  return (
    <div className="rounded-xl border border-gray-100 bg-gray-50 p-4">
      <div className="grid h-9 w-9 place-items-center rounded-lg bg-[var(--primary)] text-white">
        <Icon className="w-4 h-4" />
      </div>
      <div className="mt-3 text-sm font-semibold text-gray-900">{title}</div>
      <p className="mt-1 text-xs text-gray-500">{body}</p>
    </div>
  );
}

function Step({ n, title, body }: { n: number; title: string; body: string }) {
  return (
    <div className="rounded-xl border border-gray-100 bg-white p-5">
      <div className="grid h-8 w-8 place-items-center rounded-full bg-[var(--primary)]/15 text-[var(--primary-dark)] text-sm font-bold">{n}</div>
      <div className="mt-3 text-sm font-semibold text-gray-900">{title}</div>
      <p className="mt-1 text-xs text-gray-500">{body}</p>
    </div>
  );
}

function Faq({ q, children }: { q: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-gray-200 bg-white">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-4 px-4 py-3 text-left"
      >
        <span className="text-sm font-medium text-gray-800">{q}</span>
        <FiChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="px-4 pb-4 text-sm text-gray-600">{children}</div>}
    </div>
  );
}

// ── Referrals + Payouts (sub-tabbed table card) ─────────────────────────────

function ReferralsPayoutsCard({ referrals = [], payouts = [], thresholds }: { referrals?: ReferralRow[]; payouts?: PayoutRow[]; thresholds: Thresholds }) {
  const [tab, setTab] = useState<"referrals" | "payouts">("referrals");
  const [pageSize, setPageSize] = useState<number>(10);
  const [page, setPage] = useState<number>(1);

  const total = tab === "referrals" ? referrals.length : payouts.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const start = (page - 1) * pageSize;
  const end = Math.min(total, start + pageSize);
  const referralSlice = tab === "referrals" ? referrals.slice(start, end) : [];
  const payoutSlice = tab === "payouts" ? payouts.slice(start, end) : [];

  // Reset to page 1 when tab or page size changes
  function switchTab(t: "referrals" | "payouts") { setTab(t); setPage(1); }
  function changeSize(n: number) { setPageSize(n); setPage(1); }

  return (
    <div className="rounded-2xl border border-gray-200 bg-white overflow-hidden">
      {/* Sub-tab nav — flush to top-left of the card */}
      <div className="flex items-center gap-2">
        <SubTab active={tab === "referrals"} onClick={() => switchTab("referrals")}>Referrals</SubTab>
        <SubTab active={tab === "payouts"} onClick={() => switchTab("payouts")}>Payouts</SubTab>
      </div>

      {/* Both tables render their own themed empty state (SVG + caption)
       * when rows are empty — keeps the two tabs visually consistent. */}
      {tab === "referrals" ? (
        <ReferralsTable rows={referralSlice} />
      ) : (
        <PayoutsTable rows={payoutSlice} thresholds={thresholds} />
      )}

      {/* Pagination */}
      {total > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-gray-100 px-6 py-3 text-sm text-gray-600">
          <div className="flex items-center gap-3">
            <span>Page size:</span>
            <select
              value={pageSize}
              onChange={(e) => changeSize(Number(e.target.value))}
              className="rounded-md border border-gray-300 bg-white px-2 py-1 text-sm outline-none focus:border-[var(--primary)]"
            >
              {[5, 10, 20, 50].map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
            <span>{start + 1} to {end} of {total}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="grid h-7 w-7 place-items-center rounded-md text-gray-500 hover:bg-gray-100 disabled:opacity-30 disabled:hover:bg-transparent"
              aria-label="Previous page"
            >
              <FiChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-sm">
              Page <strong>{page}</strong> of <strong>{totalPages}</strong>
            </span>
            <button
              type="button"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="grid h-7 w-7 place-items-center rounded-md text-gray-500 hover:bg-gray-100 disabled:opacity-30 disabled:hover:bg-transparent"
              aria-label="Next page"
            >
              <FiChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function SubTab({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "px-4 py-4 text-sm font-medium transition-colors border-b-2",
        active
          ? "border-[var(--primary)] text-[var(--primary)]"
          : "border-transparent text-gray-600 hover:text-gray-900",
      ].join(" ")}
    >
      {children}
    </button>
  );
}

function ReferralsTable({ rows }: { rows: ReferralRow[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-sm font-semibold text-gray-900 border-b border-gray-100">
          <tr>
            <SortHeader>Invites</SortHeader>
            <SortHeader align="center">Status</SortHeader>
            <SortHeader align="right">Date purchased</SortHeader>
            <SortHeader align="right">Earnings</SortHeader>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {rows.length === 0 ? (
            <tr>
              <td colSpan={4} className="px-6 py-12">
                <EmptyReferralsState />
              </td>
            </tr>
          ) : (
            rows.map((r) => (
              <tr key={r.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-gray-800">{r.invite}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-center gap-2">
                    <StatusIndicator status={r.status} />
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-gray-700">{fmtIsoDate(r.createdAt)}</td>
                <td className="px-6 py-4 text-right text-gray-900 font-semibold">{takaFixed(r.earnings)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Empty state for the Referrals tab. Mirrors EmptyPayoutsState's visual
 * language (themed SVG card + heading + caption) so the two tabs feel like
 * siblings. Imagery is people / connection focused since referrals are
 * about getting friends to sign up.
 */
function EmptyReferralsState() {
  return (
    <div className="flex flex-col items-center justify-center text-center">
      <svg
        viewBox="0 0 240 160"
        className="h-40 w-60 text-[var(--primary)]"
        aria-hidden
      >
        {/* outer rounded card outline */}
        <rect x="34" y="22" width="172" height="116" rx="10" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="1.5" />
        {/* link / share icon (top-left) */}
        <g transform="translate(48,40)" fill="none" stroke="currentColor" strokeOpacity=".4" strokeWidth="1.5">
          <path d="M3 11 L9 5 a4 4 0 0 1 6 6 L13 13" strokeLinecap="round" />
          <path d="M19 11 L13 17 a4 4 0 0 1 -6 -6 L9 9" strokeLinecap="round" />
        </g>
        {/* small primary square accent */}
        <rect x="118" y="20" width="6" height="6" fill="currentColor" />
        {/* center group: 3 people silhouettes (one larger middle + two side) */}
        <circle cx="120" cy="80" r="34" fill="currentColor" fillOpacity=".1" />
        <circle cx="120" cy="80" r="34" fill="none" stroke="currentColor" strokeOpacity=".6" strokeWidth="1.5" strokeDasharray="3 4" />
        {/* middle person */}
        <circle cx="120" cy="70" r="7" fill="currentColor" />
        <path d="M108 92 Q120 80 132 92 L132 96 L108 96 Z" fill="currentColor" />
        {/* left person (smaller, faded) */}
        <circle cx="103" cy="76" r="5" fill="currentColor" fillOpacity=".55" />
        <path d="M94 92 Q103 84 112 92 L112 95 L94 95 Z" fill="currentColor" fillOpacity=".55" />
        {/* right person */}
        <circle cx="137" cy="76" r="5" fill="currentColor" fillOpacity=".55" />
        <path d="M128 92 Q137 84 146 92 L146 95 L128 95 Z" fill="currentColor" fillOpacity=".55" />
        {/* + badge top right of the cluster (signals new invite coming in) */}
        <circle cx="152" cy="58" r="8" fill="currentColor" />
        <line x1="148" y1="58" x2="156" y2="58" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
        <line x1="152" y1="54" x2="152" y2="62" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
        {/* check (bottom-right) */}
        <g transform="translate(180,100)" fill="none" stroke="currentColor" strokeOpacity=".4" strokeWidth="1.5">
          <rect width="22" height="22" rx="11" />
          <polyline points="6,11 10,15 16,8" />
        </g>
        {/* corner dot accent */}
        <circle cx="160" cy="130" r="3" fill="currentColor" />
      </svg>

      <h3 className="mt-6 text-lg font-bold text-gray-900">No referrals yet</h3>
      <p className="mt-2 max-w-xl text-sm text-gray-500 leading-6">
        Share your referral link to start earning. Every friend who signs up and pays through your link shows up here with their plan and your commission.
      </p>
    </div>
  );
}

// Table-header label with a sort indicator arrow. (Visual cue only — wire to
// real sort state later if needed.)
function SortHeader({ children, align = "left" }: { children: React.ReactNode; align?: "left" | "center" | "right" }) {
  const alignCls = align === "center" ? "justify-center" : align === "right" ? "justify-end" : "justify-start";
  const cellAlign = align === "center" ? "text-center" : align === "right" ? "text-right" : "text-left";
  return (
    <th className={`px-6 py-3 ${cellAlign}`}>
      <span className={`inline-flex items-center gap-1.5 ${alignCls}`}>
        {children}
        <FiArrowDown className="h-3 w-3 text-gray-400" />
      </span>
    </th>
  );
}

// Status pill — green check + colored text. Color reacts to the commission
// status so different rows show different states (approved=primary, pending=
// amber, paid=emerald, rejected=rose).
function StatusIndicator({ status }: { status: string }) {
  const cls: Record<string, string> = {
    approved: "text-[var(--primary)]",
    paid:     "text-emerald-600",
    pending:  "text-amber-600",
    rejected: "text-rose-600",
  };
  const color = cls[status] ?? "text-gray-500";
  return (
    <span className={`flex items-center gap-2 font-semibold ${color}`}>
      <FiCheckCircle className="h-4 w-4" />
      <span className="capitalize">{status}</span>
    </span>
  );
}

function PayoutsTable({ rows, thresholds }: { rows: PayoutRow[]; thresholds: Thresholds }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-sm font-semibold text-gray-900 border-b border-gray-100">
          <tr>
            <SortHeader>Payout method</SortHeader>
            <SortHeader align="center">Status</SortHeader>
            <SortHeader align="right">Payout date</SortHeader>
            <SortHeader align="right">Earnings</SortHeader>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {rows.length === 0 ? (
            <tr>
              <td colSpan={4} className="px-6 py-12">
                <EmptyPayoutsState thresholds={thresholds} />
              </td>
            </tr>
          ) : (
            rows.map((po) => (
              <tr key={po.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 capitalize text-gray-800">{po.method}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-center gap-2">
                    <StatusIndicator status={po.status} />
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-gray-700">{fmtIsoDate(po.createdAt)}</td>
                <td className="px-6 py-4 text-right text-gray-900 font-semibold">{takaFixed(po.amount)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Empty state for the Payouts tab. The threshold text is interpolated from
 * the same payoutThresholds the rest of the page uses, so when the admin
 * changes thresholds (or we add more methods) the copy stays in sync.
 */
function EmptyPayoutsState({ thresholds }: { thresholds: Thresholds }) {
  const M1 = thresholds.bkash;
  const M2 = thresholds.paypal * 110;
  const M3 = 22000;
  return (
    <div className="flex flex-col items-center justify-center text-center">
      {/* Stylized illustration — dashed circle with $ + side accent shapes,
          theme-tinted so it follows the brand. */}
      <svg
        viewBox="0 0 240 160"
        className="h-40 w-60 text-[var(--primary)]"
        aria-hidden
      >
        {/* outer rounded card outline */}
        <rect x="34" y="22" width="172" height="116" rx="10" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="1.5" />
        {/* share icon (top-left) */}
        <g transform="translate(48,40)" fill="none" stroke="currentColor" strokeOpacity=".4" strokeWidth="1.5">
          <rect width="22" height="22" rx="4" />
          <circle cx="7" cy="7" r="2" />
          <circle cx="15" cy="11" r="2" />
          <circle cx="7" cy="15" r="2" />
          <line x1="8.6" y1="8.4" x2="13.4" y2="9.6" />
          <line x1="8.6" y1="13.6" x2="13.4" y2="12.4" />
        </g>
        {/* check (bottom-right) */}
        <g transform="translate(180,100)" fill="none" stroke="currentColor" strokeOpacity=".4" strokeWidth="1.5">
          <rect width="22" height="22" rx="11" />
          <polyline points="6,11 10,15 16,8" />
        </g>
        {/* small primary square dot */}
        <rect x="118" y="20" width="6" height="6" fill="currentColor" />
        {/* big dashed coin */}
        <circle cx="120" cy="80" r="32" fill="currentColor" fillOpacity=".1" />
        <circle cx="120" cy="80" r="32" fill="none" stroke="currentColor" strokeOpacity=".6" strokeWidth="1.5" strokeDasharray="3 4" />
        <text x="120" y="92" textAnchor="middle" fontSize="36" fontWeight="700" fill="currentColor">$</text>
        {/* corner dot accent */}
        <circle cx="160" cy="130" r="3" fill="currentColor" />
      </svg>

      <h3 className="mt-6 text-lg font-bold text-gray-900">You don&apos;t have any payouts yet</h3>
      <p className="mt-2 max-w-xl text-sm text-gray-500 leading-6">
        Payouts are transferred when you reach the threshold:{" "}
        <strong className="text-gray-800">{taka(M1)}</strong> for bKash,{" "}
        <strong className="text-gray-800">{taka(M2)}</strong> for PayPal and{" "}
        <strong className="text-gray-800">{taka(M3)}</strong> for Wire Transfer.
      </p>
    </div>
  );
}

// ── Dynamic payout CTA panel (right side of payout card) ───────────────────

/**
 * Renders one of four states based on the affiliate's balance + payout setup:
 *   • Eligible (balance ≥ threshold AND matching method set) → Congrats + Get paid now
 *   • Has method, not yet eligible → Get paid automatically when min hit
 *   • No method, has some balance → Add a method to start receiving
 *   • No method, ৳0 balance → Default "Get paid automatically" intro
 */
function PayoutCtaPanel({
  eligibleMethod,
  hasAnyMethod,
  available,
}: {
  eligibleMethod: "Wire Transfer" | "PayPal" | "bKash" | null;
  hasAnyMethod: boolean;
  available: number;
}) {
  // ── Eligible: ready to be paid ──
  if (eligibleMethod) {
    return (
      <aside className="flex flex-col rounded-2xl bg-[var(--primary)]/8 p-5 text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[var(--primary)]/15 text-[var(--primary)]">
          <FiCheckCircle className="h-6 w-6" />
        </div>
        <p className="mt-4 text-sm text-gray-800 leading-6 flex-1">
          <strong className="text-gray-900">Congrats!</strong>{" "}
          You&apos;ve earned enough to get paid to your{" "}
          <strong className="text-[var(--primary)]">{eligibleMethod}</strong> now.
        </p>
        <a
          href="#payout-method"
          className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--primary)] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[var(--primary-dark)] transition-colors"
        >
          Get paid now
        </a>
        <a href="#payout-method" className="mt-3 text-xs font-semibold text-[var(--primary)] hover:underline">
          Update payout method
        </a>
      </aside>
    );
  }

  // ── Has method, waiting to qualify ──
  if (hasAnyMethod) {
    return (
      <aside className="flex flex-col rounded-2xl bg-[var(--primary)]/8 p-5">
        <FiCreditCard className="h-6 w-6 text-[var(--primary)]" />
        <p className="mt-4 text-sm text-gray-800 leading-6 flex-1">
          <strong className="text-gray-900">Get paid automatically</strong>{" "}
          when you earn the minimum amount for your chosen payout method.
        </p>
        <a
          href="#payout-method"
          className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--primary)] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[var(--primary-dark)] transition-colors"
        >
          Update payout method
        </a>
      </aside>
    );
  }

  // ── No method, has some balance — nudge to add details ──
  if (available > 0) {
    return (
      <aside className="flex flex-col rounded-2xl bg-amber-50 ring-1 ring-amber-200 p-5">
        <FiCreditCard className="h-6 w-6 text-amber-600" />
        <p className="mt-4 text-sm text-gray-800 leading-6 flex-1">
          <strong className="text-gray-900">Add a payout method</strong>{" "}
          to receive your earnings — bKash or PayPal.
        </p>
        <a
          href="#payout-method"
          className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg bg-amber-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-amber-700 transition-colors"
        >
          Add payout method
        </a>
      </aside>
    );
  }

  // ── No method, ৳0 balance — generic intro ──
  return (
    <aside className="flex flex-col rounded-2xl bg-[var(--primary)]/8 p-5">
      <FiCreditCard className="h-6 w-6 text-[var(--primary)]" />
      <p className="mt-4 text-sm text-gray-800 leading-6 flex-1">
        <strong className="text-gray-900">Get paid automatically</strong>{" "}
        when you earn the minimum amount for your chosen payout method.
      </p>
      <a
        href="#payout-method"
        className="mt-5 inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--primary)] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[var(--primary-dark)] transition-colors"
      >
        Add payout method
      </a>
    </aside>
  );
}

// ── Progress bar helpers ────────────────────────────────────────────────────

/** A small solid milestone marker on the progress bar (all 3 look identical). */
function Dot({ x }: { x: number; reached?: boolean }) {
  return (
    <span
      className="absolute top-1/2 h-2.5 w-2.5 rounded-full bg-[var(--primary)]"
      style={{ left: `${x}%`, transform: `translate(${x === 100 ? "-100%" : x === 0 ? "0%" : "-50%"}, -50%)` }}
      aria-hidden
    />
  );
}

/** Label stack below a milestone (value + caption). */
function Label({ x, value, caption, align }: { x: number; value: string; caption: string; align: "left" | "center" | "right" }) {
  const transform =
    align === "left" ? "translateX(0)" :
    align === "right" ? "translateX(-100%)" :
    "translateX(-50%)";
  const textAlign = align === "left" ? "text-left" : align === "right" ? "text-right" : "text-center";
  return (
    <div
      className={`absolute top-5 ${textAlign}`}
      style={{ left: `${x}%`, transform }}
    >
      <div className="text-sm font-semibold text-gray-900 whitespace-nowrap">{value}</div>
      <div className="mt-0.5 text-xs text-gray-500 whitespace-nowrap">{caption}</div>
    </div>
  );
}

function StatTile({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex min-h-[120px] items-center gap-4 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gray-100 text-gray-700">
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0">
        <div className="truncate text-2xl font-semibold text-gray-900">{value}</div>
        <div className="mt-1 truncate text-sm text-gray-900">{label}</div>
      </div>
    </div>
  );
}

function SmallStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-4">
      <div className="text-xs uppercase tracking-wide text-gray-500">{label}</div>
      <div className="mt-1 text-xl font-bold text-gray-900">{value}</div>
    </div>
  );
}

function Pill({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-700",
    approved: "bg-blue-100 text-blue-700",
    paid: "bg-emerald-100 text-emerald-700",
    rejected: "bg-rose-100 text-rose-700",
  };
  return <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${map[status] ?? "bg-gray-100 text-gray-600"}`}>{status}</span>;
}

function PayoutMethodEditor({ bkashPhone, paypalEmail }: { bkashPhone: string | null; paypalEmail: string | null }) {
  const [bkash, setBkash] = useState(bkashPhone ?? "");
  const [paypal, setPaypal] = useState(paypalEmail ?? "");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErr(""); setMsg(""); setBusy(true);
    try {
      const res = await fetch("/api/v1/dashboard/refer-and-earn", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bkashPhone: bkash, paypalEmail: paypal }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || "Save failed");
      setMsg("Saved. Payouts will route to the methods above.");
    } catch (e) { setErr(e instanceof Error ? e.message : "Save failed"); }
    finally { setBusy(false); }
  }

  return (
    <form id="payout-method" onSubmit={save} className="rounded-2xl border border-gray-200 bg-white p-6">
      <h3 className="text-sm font-semibold text-gray-900">Payout details</h3>
      <p className="mt-1 text-xs text-gray-500">Add at least one method so we can send your earnings.</p>
      {err && <div className="mt-3 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">{err}</div>}
      {msg && <div className="mt-3 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{msg}</div>}
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <div className="mb-1 text-xs font-medium text-gray-600">bKash number</div>
          <input value={bkash} onChange={(e) => setBkash(e.target.value)} type="tel" inputMode="numeric" placeholder="01XXXXXXXXX"
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-[var(--primary)] outline-none" />
        </label>
        <label className="block">
          <div className="mb-1 text-xs font-medium text-gray-600">PayPal email</div>
          <input value={paypal} onChange={(e) => setPaypal(e.target.value)} type="email" placeholder="you@example.com"
            autoCapitalize="off" autoComplete="off"
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-[var(--primary)] outline-none" />
        </label>
      </div>
      <button type="submit" disabled={busy}
        className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[var(--primary)] px-4 py-2 text-sm font-semibold text-white hover:bg-[var(--primary-dark)] disabled:opacity-50">
        {busy ? "Saving…" : "Save payout details"}
      </button>
    </form>
  );
}
