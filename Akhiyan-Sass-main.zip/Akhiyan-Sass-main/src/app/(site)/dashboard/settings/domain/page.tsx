/**
 * Tenant dashboard — Custom Domain settings page.
 *
 * Lets the tenant admin point their own domain (e.g. shop.acme.com) at the
 * storefront. We render the page server-side with the current tenant's
 * primaryDomain and live DNS-check result so the customer sees the state
 * without an extra round-trip; the client component handles add / remove /
 * re-verify actions.
 */
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { verifyDomainDNS, cnameTarget, type VerifyResult } from "@/lib/domain-verify";
import { ensureCustomHostname } from "@/lib/cloudflare-custom-hostnames";
import DomainSettingsClient from "./DomainSettingsClient";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function DomainSettingsPage() {
  const { tenant } = await getPrismaForRequest();
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");

  let verification: VerifyResult | null = null;
  let cfHostname: { status: string; ssl: string } | null = null;
  if (tenant.primaryDomain) {
    try {
      verification = await verifyDomainDNS(tenant.primaryDomain);
    } catch {
      verification = null;
    }
    // SELF-HEAL: idempotently ensure the domain is a Cloudflare-for-SaaS custom
    // hostname so it always has a valid cert + routing (fixes Error 1014 and
    // cert mismatches). Registered for EVERY custom domain — any domain routed
    // through our Cloudflare needs it, and a domain pointed straight at our
    // server just leaves a harmless pending entry (it works via Traefik). 100
    // custom hostnames are free; correctness over saving slots. Idempotent +
    // automatic just by the admin viewing this page.
    try {
      const ch = await ensureCustomHostname(tenant.primaryDomain);
      if (ch) cfHostname = { status: ch.status, ssl: ch.ssl?.status || "unknown" };
    } catch { /* CF down / not configured — UI shows not-yet-registered */ }
  }

  const baseDomain = (process.env.BASE_DOMAIN || "example.com").toLowerCase();
  const apexA = process.env.APP_PUBLIC_IP || null;

  return (
    <DomainSettingsClient
      currentDomain={tenant.primaryDomain}
      verification={verification}
      cfHostname={cfHostname}
      slug={tenant.slug}
      cnameTarget={cnameTarget()}
      apexA={apexA}
      baseDomain={baseDomain}
    />
  );
}
