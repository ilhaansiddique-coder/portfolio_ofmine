"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { FiGlobe, FiCheckCircle, FiAlertTriangle, FiCopy, FiTrash2, FiRefreshCw } from "react-icons/fi";
import DashboardLayout from "@/components/DashboardLayout";
import type { VerifyResult } from "@/lib/domain-verify";

interface Props {
  currentDomain: string | null;
  verification: VerifyResult | null;
  cfHostname: { status: string; ssl: string } | null;
  slug: string;
  cnameTarget: string;
  apexA: string | null;
  baseDomain: string;
}

export default function DomainSettingsClient({
  currentDomain,
  verification,
  cfHostname,
  slug,
  cnameTarget,
  apexA,
  baseDomain,
}: Props) {
  const router = useRouter();
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [, startTransition] = useTransition();

  const subdomainUrl = `${slug}.${baseDomain}`;

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);
    setBusy(true);
    try {
      const res = await fetch("/api/v1/admin/domain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: input.trim() }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);
      setMsg({ kind: "ok", text: j.message || "Domain saved." });
      setInput("");
      startTransition(() => router.refresh());
    } catch (err) {
      setMsg({ kind: "err", text: err instanceof Error ? err.message : "Failed." });
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!confirm(`Remove the custom domain "${currentDomain}"? Your store will only be reachable at ${subdomainUrl} after this.`)) return;
    setMsg(null);
    setBusy(true);
    try {
      const res = await fetch("/api/v1/admin/domain", { method: "DELETE" });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);
      setMsg({ kind: "ok", text: j.message || "Domain removed." });
      startTransition(() => router.refresh());
    } catch (err) {
      setMsg({ kind: "err", text: err instanceof Error ? err.message : "Failed." });
    } finally {
      setBusy(false);
    }
  }

  function copy(text: string) {
    navigator.clipboard.writeText(text).then(() => {
      setMsg({ kind: "ok", text: `Copied: ${text}` });
      setTimeout(() => setMsg(null), 2000);
    });
  }

  return (
    <DashboardLayout title="Custom Domain">
    <div className="mx-auto max-w-3xl space-y-6 py-8">
      <header>
        <h1 className="flex items-center gap-2 text-2xl font-bold text-zinc-900">
          <FiGlobe className="text-orange-500" /> Custom Domain
        </h1>
        <p className="mt-1 text-sm text-zinc-500">
          Point your own domain at your store. Your store is always reachable at{" "}
          <code className="rounded bg-zinc-100 px-1.5 py-0.5 font-mono text-xs">{subdomainUrl}</code>
          {currentDomain && " plus the custom domain below"}.
        </p>
      </header>

      {msg && (
        <div
          className={[
            "rounded-lg border px-4 py-3 text-sm",
            msg.kind === "ok"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-rose-200 bg-rose-50 text-rose-800",
          ].join(" ")}
        >
          {msg.text}
        </div>
      )}

      {/* Current state */}
      {currentDomain ? (
        <section className="rounded-xl border border-zinc-200 bg-white p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium uppercase tracking-wider text-zinc-500">Current domain</span>
                {verification?.ok ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700">
                    <FiCheckCircle className="h-3 w-3" /> verified
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700">
                    <FiAlertTriangle className="h-3 w-3" /> Pending verification
                  </span>
                )}
                {cfHostname && (
                  <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                    cfHostname.ssl === "active"
                      ? "bg-emerald-100 text-emerald-700"
                      : "bg-sky-100 text-sky-700"
                  }`} title={`Cloudflare custom hostname: ${cfHostname.status}`}>
                    SSL {cfHostname.ssl === "active" ? "active" : "provisioning…"}
                  </span>
                )}
              </div>
              <div className="mt-1 font-mono text-lg text-zinc-900">{currentDomain}</div>
              {verification?.ok === false && (
                <div className="mt-2 text-xs text-amber-700">
                  {verification.reason}. Add the DNS record below, then click Re-verify.
                </div>
              )}
              {!verification && (
                <div className="mt-2 text-xs text-amber-700">
                  DNS not checked yet — add the record below, then click Re-verify.
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => startTransition(() => router.refresh())}
                disabled={busy}
                className="inline-flex items-center gap-1 rounded-md border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-50"
                title="Re-check DNS"
              >
                <FiRefreshCw className="h-3 w-3" /> Re-verify
              </button>
              <button
                type="button"
                onClick={remove}
                disabled={busy}
                className="inline-flex items-center gap-1 rounded-md border border-rose-300 bg-white px-3 py-1.5 text-xs font-medium text-rose-700 hover:bg-rose-50 disabled:opacity-50"
              >
                <FiTrash2 className="h-3 w-3" /> Remove
              </button>
            </div>
          </div>
        </section>
      ) : (
        <section className="rounded-xl border border-dashed border-zinc-300 bg-zinc-50 p-5 text-sm text-zinc-600">
          No custom domain assigned yet. Your store is only reachable at{" "}
          <code className="rounded bg-white px-1.5 py-0.5 font-mono text-xs">{subdomainUrl}</code>.
        </section>
      )}

      {/* DNS setup instructions */}
      <section className="rounded-xl border border-zinc-200 bg-white p-5">
        <h2 className="text-sm font-semibold text-zinc-900">Step 1: Configure DNS</h2>
        <p className="mt-1 text-xs text-zinc-500">
          Add ONE of these records at your DNS provider (Cloudflare, Namecheap, GoDaddy, etc.).
        </p>

        <div className="mt-3 space-y-2">
          <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="text-xs font-medium text-zinc-700">
                  CNAME — for subdomains (e.g. <span className="font-mono">shop.example.com</span>)
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                  <code className="rounded bg-white px-2 py-1 font-mono text-zinc-800">your-subdomain</code>
                  <span className="text-zinc-400">CNAME</span>
                  <code className="rounded bg-white px-2 py-1 font-mono text-zinc-800">{cnameTarget}</code>
                </div>
              </div>
              <button
                type="button"
                onClick={() => copy(cnameTarget)}
                className="rounded-md border border-zinc-300 bg-white p-1.5 text-zinc-600 hover:bg-zinc-100"
                title="Copy CNAME target"
              >
                <FiCopy className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {apexA && (
            <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs font-medium text-zinc-700">
                    A record — for apex domains (e.g. <span className="font-mono">example.com</span>)
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                    <code className="rounded bg-white px-2 py-1 font-mono text-zinc-800">@</code>
                    <span className="text-zinc-400">A</span>
                    <code className="rounded bg-white px-2 py-1 font-mono text-zinc-800">{apexA}</code>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => copy(apexA)}
                  className="rounded-md border border-zinc-300 bg-white p-1.5 text-zinc-600 hover:bg-zinc-100"
                  title="Copy A record IP"
                >
                  <FiCopy className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
        <p className="mt-3 text-xs text-zinc-500">
          DNS changes can take a few minutes (sometimes up to 1 hour) to propagate worldwide.
        </p>
      </section>

      {/* Add domain form */}
      <section className="rounded-xl border border-zinc-200 bg-white p-5">
        <h2 className="text-sm font-semibold text-zinc-900">
          Step 2: {currentDomain ? "Replace current domain" : "Add your domain"}
        </h2>
        <p className="mt-1 text-xs text-zinc-500">
          Enter your domain — we save it right away and show it above. You can add the DNS record
          before or after; then click <span className="font-medium">Re-verify</span> to confirm.
        </p>

        <form onSubmit={submit} className="mt-4 space-y-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="shop.example.com"
            autoCapitalize="off"
            autoComplete="off"
            spellCheck={false}
            required
            disabled={busy}
            className="w-full rounded-md border border-zinc-300 bg-white px-3 py-2.5 text-sm font-mono outline-none focus:border-orange-500 disabled:bg-zinc-100"
          />
          <button
            type="submit"
            disabled={busy || !input.trim()}
            className="inline-flex items-center gap-2 rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:opacity-50"
          >
            {busy ? "Saving…" : currentDomain ? "Replace domain" : "Add domain"}
          </button>
        </form>
      </section>
    </div>
    </DashboardLayout>
  );
}
