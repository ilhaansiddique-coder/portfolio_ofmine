"use client";

import { useState, useEffect, useTransition, useCallback } from "react";
import { useRouter } from "next/navigation";
import { FiCpu, FiCheckCircle, FiAlertTriangle, FiEye, FiEyeOff, FiZap, FiSave, FiRefreshCw } from "react-icons/fi";
import DashboardLayout from "@/components/DashboardLayout";
import type { AiConfigPublic, AiProvider } from "@/lib/ai/config";

interface ModelOption { id: string; label: string; vision: boolean }
interface Props {
  initial: AiConfigPublic;
  modelOptions: Record<Exclude<AiProvider, "platform">, ModelOption[]>;
  encryptionReady: boolean;
  platformAvailable: boolean;
}

export default function AiSettingsClient({ initial, modelOptions: fallbackOptions, encryptionReady, platformAvailable }: Props) {
  const router = useRouter();
  const [, startTransition] = useTransition();

  const [provider, setProvider] = useState<AiProvider>(initial.provider);
  const [apiKey, setApiKey] = useState(""); // empty = "don't change"
  const [model, setModel] = useState(initial.model);
  const [budget, setBudget] = useState<string>(initial.monthlyBudgetUsd?.toString() ?? "");
  const [showKey, setShowKey] = useState(false);

  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  // Dynamic model list
  const [dynamicModels, setDynamicModels] = useState<ModelOption[] | null>(null);
  const [loadingModels, setLoadingModels] = useState(false);

  const providerModels = provider === "platform"
    ? []
    : dynamicModels ?? (fallbackOptions[provider] ?? []);

  // Fetch models dynamically when provider or apiKey changes
  const fetchModels = useCallback(async (p: AiProvider, key?: string) => {
    if (p === "platform") { setDynamicModels(null); return; }
    setLoadingModels(true);
    try {
      const params = new URLSearchParams({ provider: p });
      if (key) params.set("apiKey", key);
      const res = await fetch(`/api/v1/admin/ai/models?${params}`);
      const j = await res.json();
      if (j.models && Array.isArray(j.models) && j.models.length > 0) {
        setDynamicModels(j.models);
      } else {
        setDynamicModels(null); // use fallback
      }
    } catch {
      setDynamicModels(null);
    } finally {
      setLoadingModels(false);
    }
  }, []);

  // Fetch on mount and when provider changes
  useEffect(() => {
    fetchModels(provider);
  }, [provider, fetchModels]);

  async function save() {
    setMsg(null);
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        provider,
        model,
        monthlyBudgetUsd: budget === "" ? null : Number(budget),
      };
      if (apiKey.length > 0) body.apiKey = apiKey;
      const res = await fetch("/api/v1/admin/ai/config", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);
      setMsg({ kind: "ok", text: "AI settings saved." });
      // After saving with a new key, re-fetch models with the saved key
      if (apiKey.length > 0) {
        fetchModels(provider, apiKey);
      }
      setApiKey(""); // wipe input
      startTransition(() => router.refresh());
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Save failed" });
    } finally {
      setSaving(false);
    }
  }

  async function test() {
    setMsg(null);
    setTesting(true);
    try {
      const body: Record<string, unknown> = { provider, model };
      if (apiKey.length > 0) body.apiKey = apiKey;
      const res = await fetch("/api/v1/admin/ai/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const j = await res.json();
      if (!j.ok) {
        throw new Error(j.error || `HTTP ${res.status}`);
      }
      setMsg({
        kind: "ok",
        text: `✓ Connected — ${j.provider}/${j.model} replied "${j.output?.trim()}" in ${j.durationMs}ms (cost: $${j.costUsd?.toFixed(6) ?? "0"})`,
      });
    } catch (e) {
      setMsg({ kind: "err", text: `Test failed: ${e instanceof Error ? e.message : "unknown error"}` });
    } finally {
      setTesting(false);
    }
  }

  function handleProviderChange(p: AiProvider) {
    setProvider(p);
    setDynamicModels(null); // clear while loading
    if (p !== "platform") {
      const fallback = fallbackOptions[p];
      if (fallback?.[0]) setModel(fallback[0].id);
    }
  }

  return (
    <DashboardLayout title="AI Settings">
      <div className="mx-auto max-w-3xl space-y-6 py-8">
        <header>
          <h1 className="flex items-center gap-2 text-2xl font-bold text-zinc-900">
            <FiCpu className="text-orange-500" /> AI Provider Settings
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            Connect your own AI API key, or use the platform default. All AI features
            (rewrite, generate-site, landing-page builder, image tagging) route through this config.
          </p>
        </header>

        {!encryptionReady && (
          <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
            <FiAlertTriangle className="mb-1 inline" /> The server is missing
            <code className="mx-1 rounded bg-rose-100 px-1 font-mono text-xs">AI_KEY_ENCRYPTION_SECRET</code>.
            API keys can&apos;t be saved until the platform owner sets it.
          </div>
        )}

        {msg && (
          <div
            className={[
              "rounded-lg border px-4 py-3 text-sm",
              msg.kind === "ok"
                ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                : "border-rose-200 bg-rose-50 text-rose-800",
            ].join(" ")}
          >
            {msg.text}
          </div>
        )}

        {/* Provider */}
        <section className="rounded-xl border border-zinc-200 bg-white p-5">
          <h2 className="text-sm font-semibold text-zinc-900">Provider</h2>
          <p className="mt-1 text-xs text-zinc-500">
            Choose where AI requests are sent. Pick &quot;Platform&quot; to use the SaaS-provided key
            (subject to your plan&apos;s quota), or bring your own.
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {(["platform", "openai", "anthropic", "google", "groq", "openrouter"] as AiProvider[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => handleProviderChange(p)}
                className={[
                  "rounded-lg border px-3 py-2 text-sm font-medium capitalize transition-colors",
                  provider === p
                    ? "border-orange-500 bg-orange-50 text-orange-700"
                    : "border-zinc-200 bg-white text-zinc-600 hover:border-zinc-300 hover:bg-zinc-50",
                ].join(" ")}
              >
                {p === "platform" ? "Platform" : p === "openrouter" ? "OpenRouter" : p}
              </button>
            ))}
          </div>
          {provider === "platform" && !platformAvailable && (
            <p className="mt-2 text-xs text-amber-700">
              <FiAlertTriangle className="mb-0.5 inline" /> No platform-level AI key is configured on the server.
              Pick a specific provider above and add your own key.
            </p>
          )}
        </section>

        {/* API Key (only when not platform) */}
        {provider !== "platform" && (
          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <h2 className="text-sm font-semibold text-zinc-900">API Key</h2>
            <p className="mt-1 text-xs text-zinc-500">
              Your API key is encrypted at rest with AES-256-GCM and decrypted only at request time.
              {initial.hasApiKey && (
                <>
                  {" "}Current: <code className="rounded bg-zinc-100 px-1 font-mono text-xs">{initial.apiKeyPreview}</code>
                </>
              )}
            </p>
            <div className="mt-3 flex gap-2">
              <input
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={initial.hasApiKey ? "Leave blank to keep current key" : "sk-..."}
                autoCapitalize="off"
                autoComplete="off"
                spellCheck={false}
                className="flex-1 rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm font-mono outline-none focus:border-orange-500"
              />
              <button
                type="button"
                onClick={() => setShowKey((v) => !v)}
                className="rounded-md border border-zinc-300 bg-white px-3 text-zinc-600 hover:bg-zinc-50"
                title={showKey ? "Hide" : "Show"}
              >
                {showKey ? <FiEyeOff /> : <FiEye />}
              </button>
            </div>
            {/* Reload models with this key */}
            {apiKey.length > 3 && (
              <button
                type="button"
                onClick={() => fetchModels(provider, apiKey)}
                disabled={loadingModels}
                className="mt-2 inline-flex items-center gap-1 text-xs text-orange-600 hover:underline disabled:opacity-50"
              >
                <FiRefreshCw className={loadingModels ? "animate-spin" : ""} />
                {loadingModels ? "Loading models…" : "Load available models with this key"}
              </button>
            )}
          </section>
        )}

        {/* Model */}
        {provider !== "platform" && (
          <section className="rounded-xl border border-zinc-200 bg-white p-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-zinc-900">Model</h2>
                <p className="mt-1 text-xs text-zinc-500">
                  {dynamicModels
                    ? `${providerModels.length} models loaded from ${provider} API`
                    : "Showing suggested models. Enter your API key to load all available models."}
                </p>
              </div>
              {!loadingModels && (provider as string) !== "platform" && (
                <button
                  type="button"
                  onClick={() => fetchModels(provider, apiKey || undefined)}
                  className="text-xs text-zinc-500 hover:text-zinc-700"
                  title="Refresh model list"
                >
                  <FiRefreshCw className="h-3.5 w-3.5" />
                </button>
              )}
              {loadingModels && (
                <FiRefreshCw className="h-3.5 w-3.5 animate-spin text-orange-500" />
              )}
            </div>

            {providerModels.length > 0 && (
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="mt-3 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
              >
                {providerModels.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label} {m.vision ? "  • vision" : ""}
                  </option>
                ))}
                {/* Show current model if it's not in the list */}
                {model && !providerModels.find((m) => m.id === model) && (
                  <option value={model}>{model} (custom)</option>
                )}
              </select>
            )}

            <div className="mt-2 flex items-center gap-2">
              <input
                type="text"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="or type a custom model id"
                className="w-full rounded-md border border-zinc-200 bg-zinc-50 px-3 py-1.5 text-xs font-mono outline-none focus:border-orange-500"
              />
            </div>
          </section>
        )}

        {/* Budget */}
        <section className="rounded-xl border border-zinc-200 bg-white p-5">
          <h2 className="text-sm font-semibold text-zinc-900">Monthly budget (USD)</h2>
          <p className="mt-1 text-xs text-zinc-500">
            Soft cap. AI requests refuse once spend exceeds this. Leave blank for unlimited.
          </p>
          <input
            type="number"
            step="0.01"
            min="0"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
            placeholder="e.g. 20"
            className="mt-3 w-40 rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"
          />
        </section>

        {/* Actions */}
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={save}
            disabled={saving || !encryptionReady}
            className="inline-flex items-center gap-2 rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:opacity-50"
          >
            <FiSave /> {saving ? "Saving…" : "Save settings"}
          </button>
          <button
            type="button"
            onClick={test}
            disabled={testing || (provider !== "platform" && !initial.hasApiKey && apiKey.length === 0)}
            className="inline-flex items-center gap-2 rounded-md border border-orange-300 bg-white px-4 py-2 text-sm font-medium text-orange-700 hover:bg-orange-50 disabled:opacity-50"
          >
            <FiZap /> {testing ? "Testing…" : "Test connection"}
          </button>
          {initial.hasApiKey && (
            <span className="ml-auto inline-flex items-center gap-1 text-xs text-emerald-700">
              <FiCheckCircle /> Key on file
            </span>
          )}
        </div>

        {/* Help text */}
        {provider !== "platform" && !initial.hasApiKey && apiKey.length === 0 && (
          <p className="text-xs text-zinc-400">
            Enter your API key and click &quot;Save settings&quot; first, then test the connection.
          </p>
        )}
      </div>
    </DashboardLayout>
  );
}
