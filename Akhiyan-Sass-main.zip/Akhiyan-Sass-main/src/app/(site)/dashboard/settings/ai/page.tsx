/**
 * Tenant dashboard — AI provider settings.
 * Server component: fetches current config (key masked) for initial render
 * so the form shows the user's existing settings without a client round-trip.
 */
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { getAiConfigPublic } from "@/lib/ai/config";
import { isEncryptionConfigured } from "@/lib/encryption";
import { MODEL_OPTIONS } from "@/lib/ai/provider";
import AiSettingsClient from "./AiSettingsClient";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function AiSettingsPage() {
  const { prisma } = await getPrismaForRequest();
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");

  const config = await getAiConfigPublic(prisma);
  // Surface platform-key availability so the UI can hint the user
  const platformOpenAi = !!process.env.OPENAI_API_KEY;
  const platformAnthropic = !!process.env.ANTHROPIC_API_KEY;
  const platformGoogle = !!process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  const platformGroq = !!process.env.GROQ_API_KEY;
  const anyPlatform = platformOpenAi || platformAnthropic || platformGoogle || platformGroq;

  return (
    <AiSettingsClient
      initial={config}
      modelOptions={MODEL_OPTIONS}
      encryptionReady={isEncryptionConfigured()}
      platformAvailable={anyPlatform}
    />
  );
}
