import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import TrackingSettingsClient from "./TrackingSettingsClient";

export const dynamic = "force-dynamic";

export default async function TrackingSettingsPage() {
  const { prisma } = await getPrismaForRequest();
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");

  try {
    const rows = await prisma.siteSetting.findMany();
    const settings = Object.fromEntries(rows.map((r) => [r.key, r.value ?? ""]));
    return <TrackingSettingsClient initialData={settings as Record<string, string>} />;
  } catch {
    return <TrackingSettingsClient />;
  }
}
