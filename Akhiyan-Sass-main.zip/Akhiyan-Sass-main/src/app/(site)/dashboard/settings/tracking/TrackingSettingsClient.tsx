"use client";

import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { api } from "@/lib/api";
import DashboardLayout from "@/components/DashboardLayout";
import Toast from "@/components/Toast";
import { FiSave } from "react-icons/fi";
import { FormSkeleton } from "@/components/DashboardSkeleton";
import { theme } from "@/lib/theme";
import { useLang } from "@/lib/LanguageContext";

interface TrackingSettings {
  fb_pixel_id?: string;
  fb_capi_access_token?: string;
  fb_test_event_code?: string;
  fb_domain_verification?: string;
  fb_deferred_purchase?: string;
  clarity_project_id?: string;
  gtm_id?: string;
}

const emptySettings: TrackingSettings = {};

export default function TrackingSettingsClient({ initialData }: { initialData?: Record<string, string> }) {
  const { t } = useLang();
  const [form, setForm] = useState<TrackingSettings>(
    initialData ? { ...emptySettings, ...(initialData as TrackingSettings) } : emptySettings,
  );
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState({ message: "", type: "success" as "success" | "error" });

  const showToast = (message: string, type: "success" | "error" = "success") =>
    setToast({ message, type });

  const fetchSettings = useCallback((background = false) => {
    if (!background) setLoading(true);
    api.admin.getSettings()
      .then((res: { data?: Record<string, string> } | Record<string, string>) => {
        const data = (res as { data?: Record<string, string> }).data || (res as Record<string, string>) || {};
        setForm({ ...emptySettings, ...(data as TrackingSettings) });
      })
      .catch(() => { if (!background) showToast(t("toast.loadError"), "error"); })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Refresh from server only when we weren't given server-rendered initialData.
  useEffect(() => {
    if (!initialData) fetchSettings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.admin.updateSettings(form as Record<string, unknown>);
      showToast(t("toast.updated"));
    } catch {
      showToast(t("toast.error"), "error");
    } finally {
      setSaving(false);
    }
  };

  const set = (key: keyof TrackingSettings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((prev) => ({ ...prev, [key]: e.target.value }));

  const inputCls = theme.input;
  const labelCls = theme.label;

  return (
    <DashboardLayout title="Tracking">
      <Toast message={toast.message} type={toast.type} onClose={() => setToast({ ...toast, message: "" })} />

      {loading ? (
        <FormSkeleton />
      ) : (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <form onSubmit={handleSubmit} className="space-y-6">

            {/* Tracking (Facebook Pixel / CAPI) */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-sm font-bold text-gray-700 mb-4">{t("settings.tracking")}</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>{t("settings.fbPixelId")}</label>
                  <input value={form.fb_pixel_id || ""} onChange={set("fb_pixel_id")} className={inputCls} placeholder="123456789012345" />
                </div>
                <div>
                  <label className={labelCls}>{t("settings.fbCapiToken")}</label>
                  <input type="password" value={form.fb_capi_access_token || ""} onChange={set("fb_capi_access_token")} className={inputCls} placeholder="EAABsbCS..." />
                </div>
                <div>
                  <label className={labelCls}>{t("settings.fbTestCode")}</label>
                  <input value={form.fb_test_event_code || ""} onChange={set("fb_test_event_code")} className={inputCls} placeholder="TEST12345" />
                </div>
                <div>
                  <label className={labelCls}>{t("settings.fbDomainVerification")}</label>
                  <input value={form.fb_domain_verification || ""} onChange={set("fb_domain_verification")} className={inputCls} placeholder="abcdef1234567890..." />
                </div>
                <div className="sm:col-span-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.fb_deferred_purchase === "true"}
                      onChange={(e) => setForm((prev) => ({ ...prev, fb_deferred_purchase: e.target.checked ? "true" : "false" }))}
                      className="w-5 h-5 rounded border-gray-300 text-[var(--primary)] focus:ring-[var(--primary)]"
                    />
                    <div>
                      <span className="text-sm font-semibold text-gray-700">{t("settings.deferredPurchase")}</span>
                      <p className="text-xs text-gray-400 mt-0.5">{t("settings.deferredPurchaseDesc")}</p>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Microsoft Clarity */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-sm font-bold text-gray-700 mb-1">Microsoft Clarity</h3>
              <p className="text-xs text-gray-400 mb-4">Free session recordings &amp; heatmaps. Loads on the storefront only when an ID is set — leave blank to keep it off.</p>
              <div className="max-w-sm">
                <label className={labelCls}>Clarity Project ID</label>
                <input
                  value={form.clarity_project_id || ""}
                  onChange={set("clarity_project_id")}
                  className={inputCls}
                  placeholder="abcde12345"
                />
                <p className="text-xs text-gray-400 mt-1.5">
                  Clarity → Settings → Overview → &quot;Project ID&quot; (the code in
                  <span className="font-mono"> clarity.ms/tag/&lt;ID&gt;</span>). Tracking
                  starts automatically once saved.
                </p>
              </div>
            </div>

            {/* Google Tag Manager */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <h3 className="text-sm font-bold text-gray-700 mb-1">{t("settings.gtmSection")}</h3>
              <p className="text-xs text-gray-400 mb-4">{t("settings.gtmSectionDesc")}</p>
              <div className="max-w-sm">
                <label className={labelCls}>{t("settings.gtmId")}</label>
                <input value={form.gtm_id || ""} onChange={set("gtm_id")} className={inputCls} placeholder="GTM-XXXXXXX" />
                <p className="text-xs text-gray-400 mt-1.5">{t("settings.gtmIdHint")}</p>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[var(--primary)] text-white text-sm font-semibold shadow-sm hover:opacity-90 disabled:opacity-50 transition"
              >
                <FiSave className="w-4 h-4" />
                {saving ? t("btn.saving") : t("settings.saveBtn")}
              </button>
            </div>
          </form>
        </motion.div>
      )}
    </DashboardLayout>
  );
}
