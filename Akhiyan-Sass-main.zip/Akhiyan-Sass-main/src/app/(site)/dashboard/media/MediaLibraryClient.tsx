"use client";

/**
 * Dashboard Media Library — gallery of every file this tenant has uploaded,
 * organised by type (images / videos / audio / other files). Fetches the full
 * library via /api/v1/admin/media?scope=library. Supports search, type filter,
 * preview (lightbox / inline player), copy-URL, download, multi-file upload and
 * delete. Storefront picker (MediaGallery) is untouched — it still calls the
 * same endpoint without scope and gets image/video only.
 */
import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  FiUploadCloud, FiImage, FiVideo, FiMusic, FiFile, FiTrash2, FiSearch,
  FiX, FiCopy, FiDownload, FiRefreshCw, FiCheck, FiGrid,
} from "react-icons/fi";
import { SafeImg } from "@/components/SafeImage";

type MediaType = "image" | "video" | "audio" | "file";
interface MediaItem {
  filename: string;
  url: string;
  size: number;
  type: MediaType;
  modified: string;
}

type FilterKey = "all" | MediaType;

const TABS: { key: FilterKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "all", label: "All", icon: FiGrid },
  { key: "image", label: "Images", icon: FiImage },
  { key: "video", label: "Videos", icon: FiVideo },
  { key: "audio", label: "Audio", icon: FiMusic },
  { key: "file", label: "Files", icon: FiFile },
];

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${(bytes / 1073741824).toFixed(2)} GB`;
}
function baseName(key: string): string {
  return key.split("/").pop() || key;
}
function extLabel(key: string): string {
  const e = baseName(key).split(".").pop();
  return e && e !== baseName(key) ? e.toUpperCase() : "FILE";
}

export default function MediaLibraryClient() {
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterKey>("all");
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState<{ done: number; total: number } | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [preview, setPreview] = useState<MediaItem | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/v1/admin/media?scope=library", { credentials: "include", headers: { Accept: "application/json" } })
      .then((r) => r.json())
      .then((d) => setMedia(Array.isArray(d) ? d : []))
      .catch(() => setMedia([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const counts = useMemo(() => {
    const c: Record<FilterKey, number> = { all: media.length, image: 0, video: 0, audio: 0, file: 0 };
    for (const m of media) c[m.type]++;
    return c;
  }, [media]);

  const totalSize = useMemo(() => media.reduce((s, m) => s + (m.size || 0), 0), [media]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return media
      .filter((m) => filter === "all" || m.type === filter)
      .filter((m) => !q || baseName(m.filename).toLowerCase().includes(q));
  }, [media, filter, search]);

  const handleUpload = async (files: FileList) => {
    const list = Array.from(files);
    if (list.length === 0) return;
    setUploading({ done: 0, total: list.length });
    let failed = 0;
    for (let i = 0; i < list.length; i++) {
      try {
        const fd = new FormData();
        fd.append("file", list[i]);
        const res = await fetch("/api/v1/admin/upload", { method: "POST", credentials: "include", body: fd });
        if (!res.ok) failed++;
      } catch { failed++; }
      setUploading({ done: i + 1, total: list.length });
    }
    setUploading(null);
    if (failed > 0) alert(`${failed} of ${list.length} file(s) failed to upload (type/size not allowed?).`);
    load();
  };

  const handleDelete = async (item: MediaItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!confirm(`Delete "${baseName(item.filename)}"? This cannot be undone.`)) return;
    setDeleting(item.filename);
    try {
      const res = await fetch("/api/v1/admin/media", {
        method: "DELETE",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: item.filename }),
      });
      if (!res.ok) throw new Error();
      setMedia((prev) => prev.filter((m) => m.filename !== item.filename));
      setPreview((p) => (p?.filename === item.filename ? null : p));
    } catch {
      alert("Failed to delete file.");
    } finally {
      setDeleting(null);
    }
  };

  const copyUrl = async (url: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const abs = url.startsWith("http") ? url : `${window.location.origin}${url}`;
    try { await navigator.clipboard.writeText(abs); setCopied(url); setTimeout(() => setCopied(null), 1500); } catch { /* ignore */ }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-bold tracking-tight text-gray-900">
            <FiImage className="text-[var(--primary)]" /> Media Library
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            {media.length.toLocaleString()} file{media.length === 1 ? "" : "s"} · {formatSize(totalSize)} used
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={load}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 disabled:opacity-50"
          >
            <FiRefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /> Refresh
          </button>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={!!uploading}
            className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--primary)] px-3.5 py-2 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-50"
          >
            <FiUploadCloud className="h-4 w-4" />
            {uploading ? `Uploading ${uploading.done}/${uploading.total}…` : "Upload"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*,audio/*,.pdf"
            className="hidden"
            onChange={(e) => { if (e.target.files) handleUpload(e.target.files); e.target.value = ""; }}
          />
        </div>
      </div>

      {/* Tabs + search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {TABS.map((t) => {
            const active = filter === t.key;
            return (
              <button
                key={t.key}
                type="button"
                onClick={() => setFilter(t.key)}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                  active ? "bg-[var(--primary)] text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                <t.icon className="h-3.5 w-3.5" /> {t.label}
                <span className={`ml-0.5 rounded-full px-1.5 text-[10px] ${active ? "bg-white/20" : "bg-gray-200/80"}`}>
                  {counts[t.key]}
                </span>
              </button>
            );
          })}
        </div>
        <div className="relative w-full sm:w-64">
          <FiSearch className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by filename"
            className="h-10 w-full rounded-xl border border-gray-200 pl-9 pr-9 text-sm focus:border-[var(--primary)] focus:outline-none"
          />
          {search && (
            <button type="button" onClick={() => setSearch("")} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-700">
              <FiX className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="aspect-square animate-pulse rounded-xl bg-gray-100" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gray-200 py-16 text-center">
          <FiImage className="mx-auto mb-3 h-10 w-10 text-gray-300" />
          <p className="text-sm text-gray-500">{search ? "No matching files." : "No media yet — upload your first file."}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {filtered.map((item) => (
            <div
              key={item.filename}
              onClick={() => setPreview(item)}
              className="group relative aspect-square cursor-pointer overflow-hidden rounded-xl border border-gray-200 bg-gray-50"
            >
              <Thumb item={item} />
              {/* Hover actions */}
              <div className="absolute right-1.5 top-1.5 flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                <button
                  type="button"
                  onClick={(e) => copyUrl(item.url, e)}
                  title="Copy URL"
                  className="rounded-lg bg-white/90 p-1.5 text-gray-700 shadow hover:bg-white"
                >
                  {copied === item.url ? <FiCheck className="h-3.5 w-3.5 text-emerald-600" /> : <FiCopy className="h-3.5 w-3.5" />}
                </button>
                <button
                  type="button"
                  onClick={(e) => handleDelete(item, e)}
                  disabled={deleting === item.filename}
                  title="Delete"
                  className="rounded-lg bg-red-500 p-1.5 text-white shadow hover:bg-red-600 disabled:opacity-50"
                >
                  <FiTrash2 className="h-3.5 w-3.5" />
                </button>
              </div>
              {/* Caption */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-2 py-1.5">
                <p className="truncate text-[10px] font-medium text-white">{baseName(item.filename)}</p>
                <p className="text-[9px] text-white/70">{formatSize(item.size)}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Lightbox preview */}
      {preview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={() => setPreview(null)}>
          <div className="relative max-h-[90vh] w-full max-w-3xl overflow-hidden rounded-2xl bg-white" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between gap-3 border-b border-gray-100 px-4 py-3">
              <p className="min-w-0 truncate text-sm font-semibold text-gray-800">{baseName(preview.filename)}</p>
              <div className="flex shrink-0 items-center gap-1.5">
                <button type="button" onClick={(e) => copyUrl(preview.url, e)} title="Copy URL" className="rounded-lg p-2 text-gray-500 hover:bg-gray-100">
                  {copied === preview.url ? <FiCheck className="h-4 w-4 text-emerald-600" /> : <FiCopy className="h-4 w-4" />}
                </button>
                <a href={preview.url} download target="_blank" rel="noopener noreferrer" title="Download" className="rounded-lg p-2 text-gray-500 hover:bg-gray-100">
                  <FiDownload className="h-4 w-4" />
                </a>
                <button type="button" onClick={() => handleDelete(preview)} title="Delete" className="rounded-lg p-2 text-red-500 hover:bg-red-50">
                  <FiTrash2 className="h-4 w-4" />
                </button>
                <button type="button" onClick={() => setPreview(null)} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100">
                  <FiX className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="flex max-h-[70vh] items-center justify-center overflow-auto bg-gray-50 p-4">
              <PreviewBody item={preview} />
            </div>
            <div className="flex items-center justify-between gap-2 border-t border-gray-100 px-4 py-2.5 text-xs text-gray-500">
              <span className="uppercase">{extLabel(preview.filename)} · {preview.type}</span>
              <span>{formatSize(preview.size)} · {new Date(preview.modified).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Thumb({ item }: { item: MediaItem }) {
  if (item.type === "image") {
    return <SafeImg src={item.url} alt={baseName(item.filename)} className="h-full w-full object-cover" />;
  }
  if (item.type === "video") {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gray-800 text-white">
        <FiVideo className="h-7 w-7" />
        <span className="px-2 text-[9px] uppercase text-white/60">{extLabel(item.filename)}</span>
      </div>
    );
  }
  if (item.type === "audio") {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-violet-100 text-violet-600">
        <FiMusic className="h-7 w-7" />
        <span className="text-[9px] uppercase">{extLabel(item.filename)}</span>
      </div>
    );
  }
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-amber-50 text-amber-600">
      <FiFile className="h-7 w-7" />
      <span className="text-[9px] uppercase">{extLabel(item.filename)}</span>
    </div>
  );
}

function PreviewBody({ item }: { item: MediaItem }) {
  if (item.type === "image") {
    return <SafeImg src={item.url} alt={baseName(item.filename)} className="max-h-[65vh] w-auto rounded-lg object-contain" />;
  }
  if (item.type === "video") {
    return <video src={item.url} controls className="max-h-[65vh] w-full rounded-lg" />;
  }
  if (item.type === "audio") {
    return (
      <div className="flex w-full max-w-md flex-col items-center gap-4 py-8">
        <FiMusic className="h-14 w-14 text-violet-500" />
        <audio src={item.url} controls className="w-full" />
      </div>
    );
  }
  // Generic file (e.g. PDF) — embed if PDF, else download prompt.
  if (item.filename.toLowerCase().endsWith(".pdf")) {
    return <iframe src={item.url} className="h-[65vh] w-full rounded-lg" title={baseName(item.filename)} />;
  }
  return (
    <div className="flex flex-col items-center gap-3 py-10 text-center">
      <FiFile className="h-14 w-14 text-amber-500" />
      <a href={item.url} download target="_blank" rel="noopener noreferrer" className="rounded-xl bg-[var(--primary)] px-4 py-2 text-sm font-semibold text-white hover:opacity-90">
        Download {baseName(item.filename)}
      </a>
    </div>
  );
}
