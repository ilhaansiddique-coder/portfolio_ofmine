import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import MediaLibraryClient from "./MediaLibraryClient";

export const dynamic = "force-dynamic";

export default async function MediaPage() {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");
  return <MediaLibraryClient />;
}
