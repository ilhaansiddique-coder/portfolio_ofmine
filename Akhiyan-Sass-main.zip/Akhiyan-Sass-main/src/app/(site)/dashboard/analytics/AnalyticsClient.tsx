"use client";

/**
 * Tenant Analytics dashboard — Shopify-style card grid driven by the store's
 * own orders/products for a chosen date range. Real cards: sales totals +
 * breakdown, orders, fulfilled, returning-customer rate, AOV, sales over time,
 * sales by product, sell-through, customer cohort. Session/referrer/POS cards
 * have no first-party data source yet, so they render an honest "No data"
 * state (same as the reference UI). Date range uses the shared DateRangePicker
 * so the dropdown UI matches the rest of the dashboard.
 */
import { useState, useEffect, useCallback, useMemo } from "react";
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { FiBarChart2, FiRepeat, FiChevronDown, FiArrowUp, FiArrowDown } from "react-icons/fi";
import DateRangePicker from "@/components/DateRangePicker";
import type { AnalyticsResult, TimeSeries } from "@/lib/store-analytics";

type Comparison = "none" | "previous" | "year";

function bdToday(): string {
  return new Date(Date.now() + 6 * 3600 * 1000).toISOString().slice(0, 10);
}
// % change vs previous; null when there's no meaningful baseline.
function deltaPct(cur: number, prev: number): number | null {
  if (!prev) return cur > 0 ? 100 : null;
  return ((cur - prev) / prev) * 100;
}
function money(n: number): string {
  return "৳" + (n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function pct(n: number): string {
  return `${(n || 0).toFixed(n && n < 10 ? 1 : 0)}%`;
}
function shortDate(d: string): string {
  // d = YYYY-MM-DD
  const [, m, day] = d.split("-");
  const M = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${M[Number(m) - 1] || ""} ${Number(day)}`;
}
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function shortMonth(ym: string): string {
  const [y, m] = ym.split("-");
  const M = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${M[Number(m) - 1] || ""} ${y.slice(2)}`;
}

export default function AnalyticsClient() {
  const [from, setFrom] = useState(bdToday());
  const [to, setTo] = useState(bdToday());
  const [data, setData] = useState<AnalyticsResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);
  const [comparison, setComparison] = useState<Comparison>("previous");

  useEffect(() => setMounted(true), []);

  const load = useCallback((f: string, t: string, cmp: string) => {
    setLoading(true);
    const qs = new URLSearchParams();
    if (f) qs.set("from", f);
    if (t) qs.set("to", t);
    qs.set("compare", cmp);
    fetch(`/api/v1/admin/analytics?${qs.toString()}`, { credentials: "include", headers: { Accept: "application/json" } })
      .then((r) => r.json())
      .then((d) => setData(d && d.kpis ? d : null))
      .catch(() => setData(null))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(from, to, comparison); }, [from, to, comparison, load]);

  const rangeLabel = useMemo(() => {
    if (from && to && from === to) return from === bdToday() ? "Today" : shortDate(from);
    return `${shortDate(from)} – ${shortDate(to)}`;
  }, [from, to]);

  const k = data?.kpis;
  const kp = data?.kpisPrev;
  const b = data?.breakdown;
  const sales = data?.salesOverTime;
  const showCompare = comparison !== "none";

  return (
    <div className="space-y-4">
      {/* Kill the SVG focus outline recharts shows on click (ugly black box). */}
      <style jsx global>{`
        .recharts-wrapper:focus,
        .recharts-wrapper:focus-visible,
        .recharts-surface:focus,
        .recharts-surface:focus-visible,
        .recharts-wrapper *:focus { outline: none !important; }
      `}</style>

      {/* Header — title + date range + comparison + currency pills */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-bold tracking-tight text-gray-900">
            <FiBarChart2 className="text-[var(--primary)]" /> Analytics
          </h1>
          <p className="text-xs text-gray-400">
            {loading ? "Loading…" : rangeLabel}{comparison === "previous" ? " · vs previous period" : comparison === "year" ? " · vs previous year" : ""}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <DateRangePicker
            from={from}
            to={to}
            onChange={(f, t) => { setFrom(f || bdToday()); setTo(t || f || bdToday()); }}
            align="right"
            clearable={false}
          />
          <div className="relative">
            <FiRepeat className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-gray-400" />
            <select
              value={comparison}
              onChange={(e) => setComparison(e.target.value as Comparison)}
              className="h-[42px] appearance-none rounded-xl border border-gray-200 bg-white pl-8 pr-8 text-sm text-gray-700 focus:border-[var(--primary)] focus:outline-none"
              aria-label="Comparison"
            >
              <option value="none">No comparison</option>
              <option value="previous">Previous period</option>
              <option value="year">Previous year</option>
            </select>
            <FiChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          </div>
          <span className="inline-flex h-[42px] items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-3.5 text-sm font-medium text-gray-600">
            ৳ BDT
          </span>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi label="Gross sales" value={k ? money(k.grossSales) : "—"} delta={showCompare && k && kp ? deltaPct(k.grossSales, kp.grossSales) : null} />
        <Kpi label="Returning customer rate" value={k ? pct(k.returningCustomerRate) : "—"} />
        <Kpi label="Orders fulfilled" value={k ? k.ordersFulfilled.toLocaleString() : "—"} delta={showCompare && k && kp ? deltaPct(k.ordersFulfilled, kp.ordersFulfilled) : null} />
        <Kpi label="Orders" value={k ? k.orders.toLocaleString() : "—"} delta={showCompare && k && kp ? deltaPct(k.orders, kp.orders) : null} />
      </div>

      {/* Sales over time + breakdown */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Total sales over time" value={b ? money(b.total) : undefined} className="lg:col-span-2 flex flex-col">
          {mounted && sales && sales.points.length > 0
            ? <TimeSeriesChart series={sales} gradId="sales" title="Total sales" valueFmt={money} showCompare={showCompare} />
            : <NoData />}
        </Card>

        <Card title="Total sales breakdown">
          {b ? (
            <div className="text-sm">
              {[
                { label: "Gross sales", value: money(b.gross) },
                { label: "Discounts", value: `-${money(b.discounts)}` },
                { label: "Returns", value: money(b.returns) },
                { label: "Net sales", value: money(b.net), strong: true },
                { label: "Shipping charges", value: money(b.shipping) },
                { label: "Return fees", value: money(b.returnFees) },
                { label: "Taxes", value: money(b.taxes) },
                { label: "Total sales", value: money(b.total), strong: true },
              ].map((r, i) => (
                <BreakRow key={r.label} label={r.label} value={r.value} strong={r.strong} zebra={i % 2 === 1} />
              ))}
            </div>
          ) : <NoData />}
        </Card>
      </div>

      {/* Channel / AOV / by product */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Total sales by sales channel">
          {data && data.salesByChannel.length > 0 ? (
            <BarList items={data.salesByChannel.map((c) => ({ label: c.channel, value: c.total }))} format={money} />
          ) : <NoData />}
        </Card>

        <Card title="Average order value over time" value={data ? money(data.avgOrderValue) : undefined} className="flex flex-col">
          {mounted && data && data.aovOverTime.points.length > 0
            ? <TimeSeriesChart series={data.aovOverTime} gradId="aov" title="Average order value" valueFmt={money} showCompare={showCompare} />
            : <NoData />}
        </Card>

        <Card title="Total sales by product">
          {data && data.salesByProduct.length > 0 ? (
            <BarList items={data.salesByProduct.map((p) => ({ label: p.name, value: p.total }))} format={money} />
          ) : <NoData />}
        </Card>
      </div>

      {/* Sessions / conversion — no first-party source yet */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Sessions over time"><NoData hint="Session analytics not tracked yet" /></Card>
        <Card title="Conversion rate over time"><NoData hint="Session analytics not tracked yet" /></Card>
        <Card title="Conversion rate breakdown"><NoData hint="Session analytics not tracked yet" /></Card>
      </div>

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Sessions by device type"><NoData /></Card>
        <Card title="Sessions by location"><NoData /></Card>
        <Card title="Total sales by social referrer"><NoData /></Card>
      </div>

      {/* Cohort + landing pages */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Customer cohort analysis" sub="% of each month's new customers who ordered again" className="lg:col-span-2">
          {data && data.cohort.rows.some((r) => r.size > 0) ? (
            <Cohort cohort={data.cohort} />
          ) : <NoData hint="Not enough order history" />}
        </Card>
        <Card title="Sessions by landing page"><NoData /></Card>
      </div>

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Sessions by social referrer"><NoData /></Card>
        <Card title="Total sales by referrer"><NoData /></Card>
        <Card title="Performance by referring channel"><NoData /></Card>
      </div>

      {/* Referrer / POS / sell-through */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="Sessions by referrer"><NoData /></Card>
        <Card title="Total sales by POS location"><NoData hint="No POS" /></Card>
        <Card title="Products by sell-through rate" sub="Lifetime sold ÷ (sold + stock)">
          {data && data.sellThrough.length > 0 ? (
            <BarList items={data.sellThrough.map((p) => ({ label: p.name, value: p.rate }))} format={(v) => `${v.toFixed(0)}%`} max={100} />
          ) : <NoData />}
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <Card title="POS staff sales total"><NoData hint="No POS" /></Card>
      </div>
    </div>
  );
}

// ─── Building blocks ───
function Kpi({ label, value, delta }: { label: string; value: string; delta?: number | null }) {
  const up = (delta ?? 0) >= 0;
  return (
    <div className="rounded-2xl border border-border bg-white p-4 shadow-sm">
      <p className="text-xs font-medium text-gray-500">{label}</p>
      <div className="mt-1.5 flex items-end justify-between gap-2">
        <p className="text-lg font-bold tracking-tight text-gray-900">{value}</p>
        {delta != null && (
          <span className={`inline-flex items-center gap-0.5 text-xs font-medium ${up ? "text-emerald-600" : "text-rose-600"}`}>
            {up ? <FiArrowUp className="h-3 w-3" /> : <FiArrowDown className="h-3 w-3" />}
            {Math.abs(delta).toFixed(0)}%
          </span>
        )}
      </div>
    </div>
  );
}

function Card({ title, sub, value, children, className = "" }: { title: string; sub?: string; value?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-border bg-white p-4 shadow-sm ${className}`}>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-semibold text-gray-800">{title}</h3>
          {sub && <p className="mt-0.5 text-[11px] text-gray-400">{sub}</p>}
        </div>
        {value && <span className="text-sm font-bold text-gray-900">{value}</span>}
      </div>
      {children}
    </div>
  );
}

// Shared time-series chart: solid (elapsed) + dashed (future) current line over
// an area fill, optional dashed previous-period comparison line, dynamic
// date/time x-axis + custom tooltip + legend. Used by every time chart so they
// share one look + behaviour.
function TimeSeriesChart({ series, gradId, title, valueFmt, showCompare }: {
  series: TimeSeries; gradId: string; title: string; valueFmt: (n: number) => string; showCompare: boolean;
}) {
  const data = series.points.map((p) => ({
    t: p.t,
    past: p.i <= series.nowIndex ? p.current : null,
    future: p.i >= series.nowIndex ? p.current : null,
    previous: p.previous,
  }));
  const hour = series.granularity === "hour";
  const xfmt = (v: string | number) => {
    const d = new Date(Number(v) + 6 * 3600 * 1000);
    const mo = MON[d.getUTCMonth()]; const day = d.getUTCDate(); const h = d.getUTCHours();
    if (hour) {
      if (h === 0) return `${mo} ${day}`;
      const ap = h < 12 ? "AM" : "PM"; const hr = h % 12 === 0 ? 12 : h % 12;
      return `${hr} ${ap}`;
    }
    return `${mo} ${day}`;
  };
  const fmtDT = (ms: number) => {
    const d = new Date(ms + 6 * 3600 * 1000);
    const base = `${MON[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
    if (!hour) return base;
    const h = d.getUTCHours(); const ap = h < 12 ? "AM" : "PM"; const hr = h % 12 === 0 ? 12 : h % 12;
    return `${base}, ${hr}:00 ${ap}`;
  };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const tip = (props: any) => {
    if (!props?.active || !props.payload?.length) return null;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const val = (key: string) => { const e = props.payload.find((p: any) => p.dataKey === key); return typeof e?.value === "number" ? e.value : null; };
    const cur = val("past") ?? val("future") ?? 0;
    const prev = val("previous") ?? 0;
    return (
      <div className="min-w-[230px] rounded-[5px] border border-gray-200 bg-white p-3 shadow-lg">
        <p className="mb-2 text-xs font-semibold text-gray-800">{title}</p>
        <TipRow color="var(--primary)" label={fmtDT(Number(props.label))} value={valueFmt(cur)} />
        {showCompare && <TipRow color="#93c5fd" label={series.previousLabel} value={valueFmt(prev)} />}
      </div>
    );
  };
  return (
    <>
      <div className="min-h-[14rem] flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
            <defs>
              <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.25} />
                <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="t" tickFormatter={xfmt} tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} interval="preserveStartEnd" minTickGap={48} />
            <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} width={48} allowDecimals={false} tickCount={3} domain={[0, (max: number) => (max && max > 0 ? Math.ceil(max) : 10)]} />
            <Tooltip content={tip} cursor={{ stroke: "#cbd5e1", strokeWidth: 1 }} />
            {showCompare && <Line type="monotone" dataKey="previous" stroke="#93c5fd" strokeWidth={2} strokeDasharray="5 4" dot={false} connectNulls />}
            <Area type="monotone" dataKey="past" stroke="var(--primary)" strokeWidth={2} fill={`url(#${gradId})`} baseValue={0} connectNulls={false} />
            <Line type="monotone" dataKey="future" stroke="var(--primary)" strokeWidth={2} strokeDasharray="5 4" dot={false} connectNulls={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-1 flex flex-wrap items-center justify-center gap-x-5 gap-y-1 text-xs text-gray-500">
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: "var(--primary)" }} />{series.currentLabel}</span>
        {showCompare && <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-sky-300" />{series.previousLabel}</span>}
      </div>
    </>
  );
}

function TipRow({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <div className="mb-2 last:mb-0">
      <div className="flex items-center gap-1.5 text-[11px] text-gray-600">
        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: color }} />
        {label}
      </div>
      <div className="mt-1 inline-block rounded bg-gray-100 px-1.5 py-0.5 text-[11px] font-medium text-gray-700">{value}</div>
    </div>
  );
}

function NoData({ hint }: { hint?: string }) {
  return (
    <div className="flex h-32 flex-col items-center justify-center gap-1 text-center">
      <span className="text-sm text-gray-400">No data for this date range</span>
      {hint && <span className="text-[11px] text-gray-300">{hint}</span>}
    </div>
  );
}

function BreakRow({ label, value, strong, zebra }: { label: string; value: string; strong?: boolean; zebra?: boolean }) {
  return (
    <div className={`flex items-center justify-between rounded-lg px-3 py-2.5 ${zebra ? "bg-gray-50" : ""}`}>
      <span className={strong ? "font-semibold text-gray-800" : "text-gray-600"}>{label}</span>
      <span className={strong ? "font-semibold text-gray-900" : "text-gray-700"}>{value}</span>
    </div>
  );
}

function BarList({ items, format, max }: { items: { label: string; value: number }[]; format: (v: number) => string; max?: number }) {
  const peak = max ?? Math.max(1, ...items.map((i) => i.value));
  return (
    <div className="space-y-2.5">
      {items.map((it) => (
        <div key={it.label}>
          <div className="mb-1 flex items-center justify-between gap-2 text-xs">
            <span className="truncate text-gray-600">{it.label}</span>
            <span className="shrink-0 font-medium text-gray-800">{format(it.value)}</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-gray-100">
            <div className="h-full rounded-full bg-[var(--primary)]" style={{ width: `${Math.min(100, (it.value / peak) * 100)}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function Cohort({ cohort }: { cohort: AnalyticsResult["cohort"] }) {
  const n = cohort.months.length;
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-separate" style={{ borderSpacing: "3px 6px" }}>
        <thead>
          <tr className="text-xs font-medium text-gray-400">
            <th className="pb-1 pr-3 text-left">Cohort</th>
            <th colSpan={n} className="pb-1 text-left">Months</th>
          </tr>
        </thead>
        <tbody>
          {cohort.rows.map((row, ci) => {
            // Relative months: drop the leading nulls so each cohort's cells are
            // left-aligned (month 0 = signup month) → the descending staircase.
            const cells = row.values.slice(ci);
            return (
              <tr key={row.cohort}>
                <td className="whitespace-nowrap pr-3 text-sm text-gray-500">{shortMonth(row.cohort)}</td>
                {cells.map((v, k) => (
                  <td
                    key={k}
                    className={`bg-[#f3f4fb] px-2 py-2.5 text-center text-xs text-gray-600 ${k === 0 ? "rounded-l-lg" : ""} ${k === cells.length - 1 ? "rounded-r-lg" : ""}`}
                  >
                    {v == null ? "" : `${Math.round(v)}%`}
                  </td>
                ))}
                {/* keep column count stable so headers line up */}
                {Array.from({ length: ci }).map((_, j) => <td key={`pad-${j}`} />)}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
