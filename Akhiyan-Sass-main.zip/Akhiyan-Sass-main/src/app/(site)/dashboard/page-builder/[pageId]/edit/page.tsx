"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Puck, createUsePuck, type Data } from "@puckeditor/core";
import "@puckeditor/core/puck.css";
import { FiArrowLeft, FiCheckCircle, FiEye, FiLayers, FiMaximize2, FiMonitor, FiPlus, FiSave, FiSearch, FiSettings, FiSmartphone, FiTablet, FiZap } from "react-icons/fi";
import { puckConfig, migrateLegacyData } from "@/lib/puck/config";
import { TabbedFieldsPanel, CleanFieldLabel } from "@/components/page-builder/TabbedFieldsPanel";
import { ParentContainerToolbar } from "@/components/page-builder/ParentContainerToolbar";
import { setViewport as setBuilderViewport } from "@/components/page-builder/fields/useViewport";
import { AkhLayersPanel } from "@/components/page-builder/AkhLayers";
import { AkhContextMenuProvider } from "@/components/page-builder/AkhContextMenu";
import { AkhContainerResize } from "@/components/page-builder/AkhContainerResize";
import { AkhDragGhost } from "@/components/page-builder/AkhDragGhost";
import { AkhSectionAdder } from "@/components/page-builder/AkhSectionAdder";
import { AkhAiAssistant } from "@/components/page-builder/AkhAiAssistant";
import { AkhGlobals, AkhSeoForm } from "@/components/page-builder/AkhSidebarTabs";
import { AkhPageSettings } from "@/components/page-builder/AkhPageSettings";
import { api } from "@/lib/api";

/* Inline SVG glyphs per Element type — kept as data-URI-friendly small SVGs
 * so they share size + currentColor with the card label. */
function ElementIcon({ name }: { name: string }) {
  const common = { width: 26, height: 26, fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (name) {
    case "Container":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="4" y="6" width="16" height="12" rx="1" strokeDasharray="2 2" />
        </svg>
      );
    case "Columns":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="3" y="4" width="18" height="16" rx="1" />
          <path d="M9 4v16M15 4v16" />
        </svg>
      );
    case "Spacer":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <path d="M5 12h14M9 8l-4 4 4 4M15 8l4 4-4 4" />
        </svg>
      );
    case "Divider":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <path d="M4 12h16" strokeWidth="2" />
        </svg>
      );
    case "Heading":
      return (
        <svg viewBox="0 0 24 24" {...common} strokeWidth={1.8}>
          <path d="M7 5v14M17 5v14M7 12h10" />
        </svg>
      );
    case "Paragraph":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <path d="M5 7h14M5 12h14M5 17h9" />
        </svg>
      );
    case "RichText":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <path d="M5 6h10M5 12h14M5 18h7" />
        </svg>
      );
    case "Button":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="4" y="8" width="16" height="8" rx="4" />
        </svg>
      );
    case "Image":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="4" y="5" width="16" height="14" rx="1" />
          <path d="M8 10a1 1 0 100-2 1 1 0 000 2zM20 16l-4-5-3 4-2-2-3 4" />
        </svg>
      );
    case "EcommerceHero":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="3" y="5" width="18" height="14" rx="1" />
          <path d="M3 10h18M7 14h6M7 17h4" />
        </svg>
      );
    case "FeatureCards":
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="3" y="6" width="5" height="12" rx="1" />
          <rect x="10" y="6" width="5" height="12" rx="1" />
          <rect x="17" y="6" width="4" height="12" rx="1" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" {...common}>
          <rect x="4" y="4" width="16" height="16" rx="2" />
        </svg>
      );
  }
}

/* drawerItem override: render each Element-panel item as a card with an
 * icon on top and the component name below. Matches Elementor's widget
 * picker layout. Puck calls this with { name, children } — we ignore the
 * default children and render our own card. */
function DrawerItemCard({ name }: { name: string; children?: React.ReactNode }) {
  return (
    <div className="akh-drawer-card">
      <span className="akh-drawer-card__icon" aria-hidden><ElementIcon name={name} /></span>
      <span className="akh-drawer-card__label">{name.replace(/([a-z])([A-Z])/g, "$1 $2")}</span>
    </div>
  );
}

const puckOverrides = {
  fields: TabbedFieldsPanel,
  fieldLabel: CleanFieldLabel,
  drawerItem: DrawerItemCard,
};

/** PuckBridge — mounts inside <Puck> so it has access to usePuck's context;
 * pushes dispatch + lookup helpers up to the outer scope via refs so the
 * onAction callback (which runs outside the Puck context) can drive
 * follow-up actions (e.g. switching parent direction on smart-drop). */
function PuckBridge({
  dispatchRef,
  getItemByIdRef,
  getSelectorForIdRef,
}: {
  dispatchRef: React.MutableRefObject<((a: Record<string, unknown>) => void) | null>;
  getItemByIdRef: React.MutableRefObject<((id: string) => { props?: Record<string, unknown>; type?: string } | undefined) | null>;
  getSelectorForIdRef: React.MutableRefObject<((id: string) => { zone: string; index: number } | null | undefined) | null>;
}) {
  const dispatch = usePuck((s) => (s as unknown as { dispatch?: (a: Record<string, unknown>) => void }).dispatch);
  const getItemById = usePuck((s) => (s as unknown as { getItemById?: (id: string) => { props?: Record<string, unknown>; type?: string } | undefined }).getItemById);
  const getSelectorForId = usePuck((s) => (s as unknown as { getSelectorForId?: (id: string) => { zone: string; index: number } | null | undefined }).getSelectorForId);
  useEffect(() => {
    dispatchRef.current = dispatch ?? null;
    getItemByIdRef.current = getItemById ?? null;
    getSelectorForIdRef.current = getSelectorForId ?? null;
  }, [dispatch, getItemById, getSelectorForId, dispatchRef, getItemByIdRef, getSelectorForIdRef]);
  return null;
}

const usePuck = createUsePuck();

type Viewport = "desktop" | "tablet" | "mobile";

const VIEWPORT_STORAGE_KEY = "akh-builder-viewport";
const AUTOSAVE_DELAY_MS = 150;

const viewportWidth: Record<Viewport, string> = {
  desktop: "100%",
  tablet: "768px",
  mobile: "390px",
};

function isViewport(value: unknown): value is Viewport {
  return value === "desktop" || value === "tablet" || value === "mobile";
}

function readStoredViewport(): Viewport {
  if (typeof window === "undefined") return "desktop";
  try {
    const stored = window.localStorage.getItem(VIEWPORT_STORAGE_KEY);
    return isViewport(stored) ? stored : "desktop";
  } catch {
    return "desktop";
  }
}

interface CmsPageData {
  id: number;
  title: string;
  slug: string;
  status: string;
  version: number;
  draft_data: Data | null;
  published_data: Data | null;
  metaTitle?: string | null;
  metaDesc?: string | null;
  excerpt?: string | null;
  featuredImage?: string | null;
  noIndex?: boolean | null;
}

function BuilderShell({
  page,
  saving,
  publishing,
  autosave,
  statusText,
  viewport,
  fullscreen,
  onBack,
  onPreview,
  onSave,
  onPublish,
  setViewport,
  setFullscreen,
}: {
  page: CmsPageData;
  saving: boolean;
  publishing: boolean;
  autosave: boolean;
  statusText: string;
  viewport: Viewport;
  fullscreen: boolean;
  onBack: () => void;
  onPreview: () => void;
  onSave: () => void;
  onPublish: () => void;
  setViewport: (viewport: Viewport) => void;
  setFullscreen: (fullscreen: boolean) => void;
}) {
  const selectedItem = usePuck((state) => state.selectedItem);
  const puckDispatch = usePuck((s) => (s as unknown as { dispatch?: (a: Record<string, unknown>) => void }).dispatch);
  // Floating Structure popup (Elementor-style Navigator) toggled from topbar.
  const [structureOpen, setStructureOpen] = useState(false);
  // Sidebar sub-tab: Widgets / Globals / SEO / Page / AI.
  const [sideTab, setSideTab] = useState<"widgets" | "globals" | "seo" | "page" | "ai">("widgets");
  // Widget search query — filters Puck.Components drawer cards.
  const [widgetQuery, setWidgetQuery] = useState("");
  const canvasFrameRef = useRef<HTMLDivElement | null>(null);

  // Container's "+" button (rendered inside empty containers in edit mode)
  // dispatches `akh-builder:open-elements`. Force the sidebar back to the
  // Widgets sub-tab so the user can immediately drop a widget in.
  useEffect(() => {
    const handler = () => setSideTab("widgets");
    const aiHandler = () => setSideTab("ai");
    window.addEventListener("akh-builder:open-elements", handler);
    window.addEventListener("akh-builder:open-ai", aiHandler);
    return () => {
      window.removeEventListener("akh-builder:open-elements", handler);
      window.removeEventListener("akh-builder:open-ai", aiHandler);
    };
  }, []);

  // Widget search — hide drawer cards whose name doesn't include the query.
  useEffect(() => {
    if (sideTab !== "widgets") return;
    const root = document.querySelector(".akh-builder__left");
    if (!root) return;
    const q = widgetQuery.trim().toLowerCase();
    const items = root.querySelectorAll<HTMLElement>("[data-puck-drawer-item]");
    items.forEach((el) => {
      const testid = el.getAttribute("data-testid") || "";
      const name = testid.replace(/^drawer-item:/, "").toLowerCase();
      const pretty = name.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase();
      el.style.display = !q || name.includes(q) || pretty.includes(q) ? "" : "none";
    });
  }, [widgetQuery, sideTab]);

  // Click-to-insert: clicking a widget card inserts it into the selected
  // container (or page root) without needing to drag.
  useEffect(() => {
    const sidebar = document.querySelector(".akh-builder__left");
    if (!sidebar) return;
    const onClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement | null;
      if (!t) return;
      const drawerItem = t.closest<HTMLElement>("[data-puck-drawer-item]");
      if (!drawerItem) return;
      const testid = drawerItem.getAttribute("data-testid") || "";
      const componentType = testid.replace(/^drawer-item:/, "");
      if (!componentType) return;
      e.preventDefault();
      e.stopPropagation();
      if (!puckDispatch) return;
      let destinationZone = "root:default-zone";
      let destinationIndex = 9999;
      const sel = selectedItem as { type?: string; props?: { id?: string; content?: unknown[] } } | null;
      if (sel?.props?.id && sel.type === "Container") {
        destinationZone = `${sel.props.id}:content`;
        destinationIndex = Array.isArray(sel.props.content) ? sel.props.content.length : 0;
      }
      const newId = `${componentType}-${typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : Math.random().toString(36).slice(2)}`;
      puckDispatch({ type: "insert", componentType, destinationIndex, destinationZone, id: newId, recordHistory: true });
    };
    sidebar.addEventListener("click", onClick as EventListener, true);
    return () => sidebar.removeEventListener("click", onClick as EventListener, true);
  }, [puckDispatch, selectedItem]);

  // Mark the selected component's DOM element with `.akh-is-selected` so CSS
  // can apply the 2px dark-grey outline + persistent corner icon. Puck's own
  // selected class lives on a portaled overlay, not on the component DOM.
  const selectedId = (selectedItem?.props as { id?: string } | undefined)?.id;
  useEffect(() => {
    if (!selectedId) return;
    const el = document.querySelector<HTMLElement>(`[data-puck-component="${selectedId}"]`);
    if (!el) return;
    el.classList.add("akh-is-selected");
    return () => el.classList.remove("akh-is-selected");
  }, [selectedId]);

  return (
    <div className={`akh-builder ${fullscreen ? "akh-builder--fullscreen" : ""}${selectedItem?.type === "Container" ? " is-container-selected" : ""}`}>
      <header className="akh-builder__topbar">
        <div className="akh-builder__page">
          <button type="button" className="akh-builder__icon-btn" onClick={onBack} aria-label="Back to pages">
            <FiArrowLeft size={17} />
          </button>
          <div>
            <div className="akh-builder__eyebrow">Page Builder</div>
            <div className="akh-builder__title-row">
              <h1>{page.title || "Untitled page"}</h1>
              <span className="akh-builder__badge">{page.status}</span>
              <span className="akh-builder__version">v{page.version}</span>
            </div>
          </div>
        </div>

        <div className="akh-builder__viewport" aria-label="Preview viewport">
          {(["desktop", "tablet", "mobile"] as const).map((item) => {
            const Icon = item === "desktop" ? FiMonitor : item === "tablet" ? FiTablet : FiSmartphone;
            return (
              <button
                key={item}
                type="button"
                className={viewport === item ? "is-active" : ""}
                onClick={() => setViewport(item)}
                aria-label={`${item} preview`}
              >
                <Icon size={16} />
              </button>
            );
          })}
          <button
            type="button"
            className={structureOpen ? "is-active" : ""}
            onClick={() => setStructureOpen((v) => !v)}
            aria-label="Toggle Structure panel"
            title="Structure"
          >
            <FiLayers size={15} />
          </button>
          <button
            type="button"
            className={!selectedItem && sideTab === "ai" ? "is-active" : ""}
            onClick={() => {
              puckDispatch?.({ type: "setUi", ui: { itemSelector: null } });
              setSideTab("ai");
            }}
            aria-label="AI assistant"
            title="AI assistant"
          >
            <FiZap size={15} />
          </button>
          <button
            type="button"
            className={!selectedItem && sideTab === "page" ? "is-active" : ""}
            onClick={() => {
              // Deselect any element so the Elements sidebar (with its
              // sub-tabs) is shown, then switch it to the Page panel.
              puckDispatch?.({ type: "setUi", ui: { itemSelector: null } });
              setSideTab("page");
            }}
            aria-label="Page settings"
            title="Page settings"
          >
            <FiSettings size={15} />
          </button>
          <button
            type="button"
            className={fullscreen ? "is-active" : ""}
            onClick={() => setFullscreen(!fullscreen)}
            aria-label="Toggle fullscreen canvas"
          >
            <FiMaximize2 size={15} />
          </button>
        </div>

        <div className="akh-builder__actions">
          <span className={`akh-builder__status ${autosave ? "is-saving" : ""}`}>{statusText}</span>
          <button type="button" className="akh-builder__ghost" onClick={onPreview}>
            <FiEye size={15} />
            Preview
          </button>
          <button type="button" className="akh-builder__ghost" disabled={saving || publishing} onClick={onSave}>
            <FiSave size={15} className={saving ? "akh-btn-spin" : ""} />
            {saving ? "Saving" : "Save"}
          </button>
          <button type="button" className="akh-builder__primary" disabled={saving || publishing} onClick={onPublish}>
            <FiCheckCircle size={16} className={publishing ? "akh-btn-spin" : ""} />
            {publishing ? "Publishing" : "Publish"}
          </button>
        </div>
      </header>

      <div className={`akh-builder__body ${selectedItem ? "akh-builder__body--editing" : ""}`}>
        {!fullscreen && (
          <aside className="akh-builder__left">
            {selectedItem ? (
              <>
                <div className="akh-builder__edit-head">
                  <button
                    type="button"
                    className="akh-builder__edit-back"
                    aria-label="Back to Elements"
                    title="Back to Elements"
                    onClick={() => puckDispatch?.({ type: "setUi", ui: { itemSelector: null } })}
                  >
                    <FiPlus size={18} />
                  </button>
                  <span className="akh-builder__edit-head__title">{String(selectedItem.type)}</span>
                  <span style={{ width: 30 }} aria-hidden />
                </div>
                <div className="akh-builder__panel akh-builder__fields">
                  <Puck.Fields />
                </div>
              </>
            ) : sideTab === "page" ? (
              // Page Settings mode — gear in topbar opens this. Replaces
              // the whole Elements UI (title + Widgets/Globals/SEO tabs)
              // with a dedicated Page header + the Settings/Style/Advanced
              // panel, then a Back button to return to Elements.
              <>
                <div className="akh-builder__edit-head">
                  <button
                    type="button"
                    className="akh-builder__edit-back"
                    aria-label="Back to Elements"
                    title="Back to Elements"
                    onClick={() => setSideTab("widgets")}
                  >
                    <FiPlus size={18} />
                  </button>
                  <span className="akh-builder__edit-head__title">Page Settings</span>
                  <span style={{ width: 30 }} aria-hidden />
                </div>
                <div className="akh-builder__panel">
                  <AkhPageSettings
                    pageId={page.id}
                    initialTitle={page.title}
                    initialStatus={page.status}
                    initialExcerpt={page.excerpt ?? ""}
                    initialFeaturedImage={page.featuredImage ?? ""}
                  />
                </div>
              </>
            ) : sideTab === "ai" ? (
              // AI Assistant mode — sparkle in topbar opens this. Replaces
              // the Elements UI with the chat + history panel.
              <>
                <div className="akh-builder__edit-head">
                  <button
                    type="button"
                    className="akh-builder__edit-back"
                    aria-label="Back to Elements"
                    title="Back to Elements"
                    onClick={() => setSideTab("widgets")}
                  >
                    <FiPlus size={18} />
                  </button>
                  <span className="akh-builder__edit-head__title">AI Assistant</span>
                  <span style={{ width: 30 }} aria-hidden />
                </div>
                <div className="akh-builder__panel">
                  <AkhAiAssistant pageId={page.id} />
                </div>
              </>
            ) : (
              <>
                <div className="akh-builder__elements-title">Elements</div>
                <div className="akh-builder__side-tabs">
                  <button type="button" className={sideTab === "widgets" ? "is-active" : ""} onClick={() => setSideTab("widgets")}>Widgets</button>
                  <button type="button" className={sideTab === "globals" ? "is-active" : ""} onClick={() => setSideTab("globals")}>Globals</button>
                  <button type="button" className={sideTab === "seo" ? "is-active" : ""} onClick={() => setSideTab("seo")}>SEO</button>
                </div>
                {sideTab === "widgets" && (
                  <>
                    <div className="akh-builder__search">
                      <FiSearch size={15} />
                      <input placeholder="Search Widget..." aria-label="Search Widget" value={widgetQuery} onChange={(e) => setWidgetQuery(e.target.value)} />
                    </div>
                    <div className="akh-builder__panel">
                      <Puck.Components />
                    </div>
                  </>
                )}
                {sideTab === "globals" && (
                  <div className="akh-builder__panel"><AkhGlobals /></div>
                )}
                {sideTab === "seo" && (
                  <div className="akh-builder__panel">
                    <AkhSeoForm
                      pageId={page.id}
                      initialTitle={page.title}
                      initialSlug={page.slug}
                      initialMetaTitle={page.metaTitle ?? ""}
                      initialMetaDesc={page.metaDesc ?? ""}
                      initialExcerpt={page.excerpt ?? ""}
                      initialFeaturedImage={page.featuredImage ?? ""}
                      initialNoIndex={!!page.noIndex}
                    />
                  </div>
                )}
              </>
            )}
          </aside>
        )}
        <AkhLayersPanel open={structureOpen} onClose={() => setStructureOpen(false)} />

        <div className="akh-builder__canvas">
          <div
            ref={canvasFrameRef}
            className="akh-builder__frame"
            data-viewport={viewport}
            style={{ maxWidth: viewportWidth[viewport], position: "relative" }}
          >
            <Puck.Preview />
            <AkhSectionAdder />
            <ParentContainerToolbar canvasRef={canvasFrameRef} />
            <AkhContainerResize canvasRef={canvasFrameRef} />
            <AkhDragGhost />
          </div>
        </div>

      </div>
    </div>
  );
}

/* ── Column auto-balance (COUNT-CHANGE driven) ───────────────────
 * A row Container whose children are ALL Containers is a column layout.
 * When (and ONLY when) a column is ADDED / DUPLICATED / DELETED, redistribute:
 *   - desktop width → equal % (2→50/50, 3→33.33×3, 4→25×4 …)
 *   - tablet  width → equal % (tablet keeps the row)
 *   - mobile  width → 100% each + parent directionMobile = "column"
 *     (mobile stacks one-per-row; never inherits desktop's narrow %)
 * Between count changes NOTHING is touched, so every device's width /
 * direction / justify / height / style stays FREELY + independently editable.
 * Trigger = comparing per-row child counts against the previous tree. */
type WItem = { type: string; props?: Record<string, unknown> & { content?: WItem[]; id?: string } };

function equalPctStr(n: number): string {
  return `${parseFloat((100 / n).toFixed(2))}%`;
}

/** Per row-of-columns container: id → a signature of (column count + mobile
 * direction). A change in EITHER re-triggers rebalancing — so adding/removing
 * a column AND flipping the parent's mobile direction (stack ↔ row) both
 * re-distribute the children's widths. */
function rowSignature(props: Record<string, unknown>, count: number): string {
  return `${count}|${String(props.directionMobile ?? "")}`;
}
function rowSignatures(data: unknown): Map<string, string> {
  const map = new Map<string, string>();
  const walk = (items: WItem[]) => {
    for (const item of items) {
      const props = item.props;
      const children = props && Array.isArray(props.content) ? props.content : null;
      if (!children) continue;
      if (props!.direction === "row" && children.length > 0 && children.every((c) => c.type === "Container") && typeof props!.id === "string") {
        map.set(props!.id as string, rowSignature(props!, children.length));
      }
      walk(children);
    }
  };
  const content = (data as { content?: WItem[] })?.content;
  if (Array.isArray(content)) walk(content);
  return map;
}

/** Reconcile one row's columns — called ONLY when the row signature changed
 * (column count add/duplicate/delete, or mobile direction stack ↔ row). Sets
 * desktop + tablet to equal %, and mobile per direction: stack → BLANK (no
 * data-akh-mw marker, so the global mobile rule forces full-width 100%), row →
 * equal %. Between signature changes the balancer does NOT run, so every
 * device's manual edits PERSIST. */
function rebalanceRow(
  parentProps: Record<string, unknown>,
  cols: WItem[],
): { props: Record<string, unknown>; cols: WItem[]; changed: boolean } {
  const equal = equalPctStr(cols.length);
  const mobileIsRow = String(parentProps.directionMobile ?? "") === "row";
  const mobileWidth = mobileIsRow ? equal : "";
  let changed = false;
  const newCols = cols.map((c) => {
    const pr = c.props ?? {};
    if (String(pr.width ?? "") !== equal || String(pr.widthTablet ?? "") !== equal || String(pr.widthMobile ?? "") !== mobileWidth) {
      changed = true;
      return { ...c, props: { ...pr, width: equal, widthTablet: equal, widthMobile: mobileWidth } };
    }
    return c;
  });
  // Default a row's mobile direction to "column" (stack) when unset; never
  // override a manual "row".
  let newProps = parentProps;
  if (!mobileIsRow && String(parentProps.directionMobile ?? "") !== "column") {
    newProps = { ...parentProps, directionMobile: "column" };
    changed = true;
  }
  return { props: newProps, cols: newCols, changed };
}

function balanceColumnWidths<T>(data: T, previousData: unknown): { data: T; changed: boolean } {
  const prevSigs = rowSignatures(previousData);
  const balanceItem = (item: WItem): { item: WItem; changed: boolean } => {
    const props = item.props;
    if (!props || !Array.isArray(props.content)) return { item, changed: false };
    let changed = false;
    let children = props.content.map((ch) => {
      const r = balanceItem(ch);
      if (r.changed) changed = true;
      return r.item;
    });
    let newProps: Record<string, unknown> = props;
    const isRow = props.direction === "row";
    const allCols = children.length > 0 && children.every((c) => c.type === "Container");
    if (isRow && allCols && typeof props.id === "string") {
      // Rebalance ONLY when the row signature changed (column count or mobile
      // direction). Otherwise leave every device's widths untouched so manual
      // per-device edits PERSIST across saves/refreshes.
      if (prevSigs.get(props.id as string) !== rowSignature(props, children.length)) {
        const r = rebalanceRow(props, children);
        if (r.changed) { children = r.cols; newProps = r.props; changed = true; }
      }
    }
    if (changed) return { item: { ...item, props: { ...newProps, content: children } }, changed: true };
    return { item, changed: false };
  };
  const d = data as unknown as { content?: WItem[] };
  if (!Array.isArray(d.content)) return { data, changed: false };
  let changed = false;
  const content = d.content.map((item) => {
    const r = balanceItem(item);
    if (r.changed) changed = true;
    return r.item;
  });
  if (!changed) return { data, changed: false };
  return { data: { ...d, content } as unknown as T, changed: true };
}

export default function PageBuilderEditor() {
  const params = useParams();
  const router = useRouter();
  const pageId = Number(params.pageId as string);
  const [page, setPage] = useState<CmsPageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [autosave, setAutosave] = useState(false);
  const [statusText, setStatusText] = useState("Ready");
  const [error, setError] = useState("");
  const [viewport, setViewportState] = useState<Viewport>(() => {
    const initial = readStoredViewport();
    setBuilderViewport(initial);
    return initial;
  });
  const [fullscreen, setFullscreen] = useState(false);
  const [puckData, setPuckData] = useState<Data | null>(null);
  const dataRef = useRef<Data | null>(null);
  const autosaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // True while a save is queued or in-flight. Drives the beforeunload
  // guard so the user can't accidentally refresh-away an unsaved edit.
  const dirtyRef = useRef(false);

  // Ref-indirection so flushSave (declared before saveDraft) can call
  // the latest saveDraft without a circular dep. Reassigned each render.
  const saveDraftRef = useRef<((data: Data, quiet?: boolean) => Promise<void>) | null>(null);
  const saveInFlightRef = useRef(false);
  const queuedDraftSaveRef = useRef<{ data: Data; quiet: boolean } | null>(null);
  const saveWaitersRef = useRef<Array<() => void>>([]);

  /** Synchronously flush any queued autosave. Called on viewport switch
   * (so the user's last edit on desktop is persisted before mobile
   * preview reads it back) and on tab close / nav-away. */
  const flushSave = useCallback(() => {
    if (autosaveTimer.current) {
      clearTimeout(autosaveTimer.current);
      autosaveTimer.current = null;
    }
    if (dirtyRef.current && dataRef.current && saveDraftRef.current) {
      // Fire-and-forget. `quiet=true` keeps the topbar status indicator
      // showing "Autosaved" without flipping the full saving spinner.
      saveDraftRef.current(dataRef.current, true);
    }
  }, []);

  // Mirror viewport changes into the cross-cutting useViewport store so
  // responsive field renderers (read via useViewport hook) get the
  // current device without prop drilling. ALSO flush any pending
  // autosave first — switching devices is a "settled" moment, and we
  // never want the user's last desktop edit lost if they tap mobile.
  const setViewport = useCallback((v: Viewport) => {
    flushSave();
    setViewportState(v);
    setBuilderViewport(v);
    try {
      localStorage.setItem(VIEWPORT_STORAGE_KEY, v);
    } catch {
      // Ignore storage failures; viewport still changes for this session.
    }
  }, [flushSave]);
  // Refs that get filled by <PuckBridge> inside <Puck>. They expose dispatch
  // + the item lookup helpers to the outer scope so `onAction` (which lives
  // outside the Puck context) can drive further actions.
  const dispatchRef = useRef<((a: Record<string, unknown>) => void) | null>(null);
  const getItemByIdRef = useRef<((id: string) => { props?: Record<string, unknown>; type?: string } | undefined) | null>(null);
  const getSelectorForIdRef = useRef<((id: string) => { zone: string; index: number } | null | undefined) | null>(null);

  useEffect(() => {
    api.admin.getCmsPage(pageId)
      .then((response: CmsPageData) => {
        const migrated = migrateLegacyData(
          (response.draft_data as Data) || (response.published_data as Data) || { content: [], root: { props: {} } },
        );
        dataRef.current = migrated;
        setPuckData(migrated);
        setPage(response);
        setLoading(false);
      })
      .catch((err: Error) => {
        setError(err.message || "Failed to load page");
        setLoading(false);
      });
  }, [pageId]);

  useEffect(() => {
    document.body.classList.add("akh-builder-open");
    return () => {
      document.body.classList.remove("akh-builder-open");
      if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
    };
  }, []);

  const saveDraft = useCallback(async (data: Data, quiet = false) => {
    if (saveInFlightRef.current) {
      queuedDraftSaveRef.current = { data, quiet };
      return new Promise<void>((resolve) => {
        saveWaitersRef.current.push(resolve);
      });
    }

    saveInFlightRef.current = true;
    let currentData = data;
    let currentQuiet = quiet;

    try {
      for (;;) {
        if (!currentQuiet) setSaving(true);
        if (currentQuiet) setAutosave(true);

        try {
          await api.admin.updateCmsPage(pageId, { draftData: currentData });
          dataRef.current = currentData;
          setPuckData(currentData);
          setPage((current) => current ? { ...current, draft_data: currentData } : current);
          setStatusText(currentQuiet ? "Autosaved" : "Draft saved");
          if (!queuedDraftSaveRef.current) dirtyRef.current = false;
        } catch {
          dirtyRef.current = true;
          setStatusText("Save failed");
        } finally {
          if (!currentQuiet) setSaving(false);
          if (currentQuiet) setAutosave(false);
        }

        const queued = queuedDraftSaveRef.current;
        queuedDraftSaveRef.current = null;
        if (!queued) break;
        currentData = queued.data;
        currentQuiet = queued.quiet;
      }
    } finally {
      saveInFlightRef.current = false;
      const waiters = saveWaitersRef.current.splice(0);
      waiters.forEach((resolve) => resolve());
    }
  }, [pageId]);
  // Keep the ref in sync so flushSave can call the latest saveDraft.
  // Must be in an effect — assigning to .current during render trips
  // the react-hooks/refs lint rule (and is conceptually a side effect).
  useEffect(() => {
    saveDraftRef.current = saveDraft;
  }, [saveDraft]);

  // beforeunload: if the user tries to close the tab or navigate away
  // while we have an unflushed autosave, prompt them. The browser's
  // native dialog is the only thing that can reliably block nav before
  // the in-flight PUT completes. Modern browsers ignore custom strings
  // — returning a non-empty string is enough to trigger the prompt.
  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      // Force-flush in case the browser still allows our fetch to
      // complete (Chromium honors keepalive on small bodies).
      flushSave();
      if (dirtyRef.current) {
        e.preventDefault();
        e.returnValue = "";
        return "";
      }
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [flushSave]);

  const publish = useCallback(async (data: Data) => {
    setPublishing(true);
    setStatusText("Publishing...");
    try {
      if (autosaveTimer.current) {
        clearTimeout(autosaveTimer.current);
        autosaveTimer.current = null;
      }
      if (dataRef.current) {
        await saveDraft(dataRef.current, true);
      }
      const finalData = dataRef.current ?? data;
      const response = await api.admin.updateCmsPage(pageId, {
        draftData: finalData,
        status: "published",
      });

      setPage((current) => current
        ? {
            ...current,
            status: "published",
            version: (response as { version?: number }).version ?? current.version + 1,
            draft_data: finalData,
            published_data: finalData,
          }
        : current);
      dataRef.current = finalData;
      setPuckData(finalData);
      setStatusText("Published");
    } catch {
      setStatusText("Publish failed");
    } finally {
      setPublishing(false);
    }
  }, [pageId, saveDraft]);

  // True while we dispatch our own auto-wrap correction so the resulting
  // onChange doesn't trigger another wrap (infinite loop guard).
  const autoWrappingRef = useRef(false);

  function getRootContent(data: Data | null): Array<{ type: string; props?: Record<string, unknown> }> {
    const d = data as { content?: Array<{ type: string; props?: Record<string, unknown> }> } | null;
    return Array.isArray(d?.content) ? d.content : [];
  }

  function hasRootNonContainer(data: Data): boolean {
    return getRootContent(data).some((item) => item.type !== "Container");
  }

  /** Root canvas only accepts Container components. If the canvas is completely
   * empty, the first dropped widget may still auto-wrap into a fresh Container.
   * After that, widgets must be dropped inside an existing Container. */
  function autoWrapRootContent(data: Data, allowRootWrap: boolean): Data {
    if (!allowRootWrap) return data;
    const d = data as { content?: Array<{ type: string; props?: Record<string, unknown> }> };
    const content = d.content;
    if (!Array.isArray(content) || content.length === 0) return data;
    const containerDefaults =
      (puckConfig as { components?: { Container?: { defaultProps?: Record<string, unknown> } } })
        .components?.Container?.defaultProps;
    if (!containerDefaults) return data;
    let changed = false;
    const next = content.map((item) => {
      if (item.type === "Container") return item;
      changed = true;
      const newId = `Container-${typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : Math.random().toString(36).slice(2)}`;
      // Make sure the wrapped child keeps its existing id (Puck needs stable ids).
      return {
        type: "Container",
        props: {
          ...containerDefaults,
          id: newId,
          content: [item],
        },
      };
    });
    if (!changed) return data;
    return { ...data, content: next } as Data;
  }

  function handleChange(data: Data) {
    // If this onChange was triggered by our own setData dispatch, skip
    // re-wrapping and just save normally — breaks the infinite loop.
    if (autoWrappingRef.current) {
      autoWrappingRef.current = false;
      dataRef.current = data;
      setPuckData(data);
      dirtyRef.current = true;
      setStatusText("Unsaved changes");
      if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
      autosaveTimer.current = setTimeout(() => saveDraft(data, true), AUTOSAVE_DELAY_MS);
      return;
    }
    const previousData = dataRef.current;
    // Root-props-only change (Page Settings: layout/bg/css, etc.) — the
    // content tree is identical, so the auto-wrap guard below must NOT
    // run. Without this, a page whose root holds a bare (un-wrapped)
    // widget would have its root.props change rolled back every time,
    // so Page Settings never persisted. Detect "content unchanged" and
    // save straight through.
    const prevContent = JSON.stringify((previousData as { content?: unknown })?.content ?? null);
    const nextContent = JSON.stringify((data as { content?: unknown })?.content ?? null);
    const prevZones = JSON.stringify((previousData as { zones?: unknown })?.zones ?? null);
    const nextZones = JSON.stringify((data as { zones?: unknown })?.zones ?? null);
    if (previousData && prevContent === nextContent && prevZones === nextZones) {
      dataRef.current = data;
      setPuckData(data);
      dirtyRef.current = true;
      setStatusText("Unsaved changes");
      if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
      autosaveTimer.current = setTimeout(() => saveDraft(data, true), AUTOSAVE_DELAY_MS);
      return;
    }
    const previousRootWasEmpty = getRootContent(previousData).length === 0;
    if (!previousRootWasEmpty && hasRootNonContainer(data) && previousData && dispatchRef.current) {
      autoWrappingRef.current = true;
      dispatchRef.current({ type: "setData", data: previousData });
      setStatusText("Drop elements inside a container");
      return;
    }

    const wrapped = autoWrapRootContent(data, previousRootWasEmpty);
    if (wrapped !== data && dispatchRef.current) {
      // Root has a non-Container child → wrap it. Dispatch corrected data
      // through the bridge ref (PuckBridge populates this after mount).
      autoWrappingRef.current = true;
      dispatchRef.current({ type: "setData", data: wrapped });
      return;
    }
    // Auto-balance row columns ONLY when a column was added/duplicated/deleted
    // (detected by comparing child counts vs previousData). Desktop+tablet →
    // equal %, mobile → 100% stacked. Per-device edits between count changes
    // are left untouched. Idempotent → re-fired onChange (guard) finds nothing.
    const balanced = balanceColumnWidths(data, previousData);
    if (balanced.changed && dispatchRef.current) {
      dataRef.current = balanced.data;
      setPuckData(balanced.data);
      dirtyRef.current = true;
      setStatusText("Unsaved changes");
      if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
      autosaveTimer.current = setTimeout(() => saveDraft(balanced.data, true), AUTOSAVE_DELAY_MS);
      autoWrappingRef.current = true;
      dispatchRef.current({ type: "setData", data: balanced.data });
      return;
    }
    dataRef.current = data;
    setPuckData(data);
    dirtyRef.current = true;
    setStatusText("Unsaved changes");
    if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
    autosaveTimer.current = setTimeout(() => saveDraft(data, true), AUTOSAVE_DELAY_MS);
  }

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading builder...</div>;
  if (error || !page) return <div className="p-6 text-sm text-red-600">{error || "Page not found"}</div>;

  // Controlled Puck: data is driven by puckData (handleChange keeps it in sync).
  const initialData: Data = puckData ?? migrateLegacyData(
    (page.draft_data as Data) || (page.published_data as Data) || { content: [], root: { props: {} } },
  );

  return (
    <>
      <style>{BUILDER_CSS}</style>
      <Puck
        config={puckConfig}
        data={initialData}
        onPublish={publish}
        onChange={handleChange}
        iframe={{ enabled: false }}
        overrides={puckOverrides}
      >
        <PuckBridge
          dispatchRef={dispatchRef}
          getItemByIdRef={getItemByIdRef}
          getSelectorForIdRef={getSelectorForIdRef}
        />
        <AkhContextMenuProvider>
          <BuilderShell
            page={page}
            saving={saving}
            publishing={publishing}
            autosave={autosave}
            statusText={statusText}
            viewport={viewport}
            fullscreen={fullscreen}
            setViewport={setViewport}
            setFullscreen={setFullscreen}
            onBack={() => router.push("/dashboard/pages")}
            onPreview={() => window.open(`/p/${page.slug}`, "_blank", "noopener,noreferrer")}
            onSave={() => dataRef.current && saveDraft(dataRef.current)}
            onPublish={() => dataRef.current && publish(dataRef.current)}
          />
        </AkhContextMenuProvider>
      </Puck>
    </>
  );
}

const BUILDER_CSS = `
body.akh-builder-open {
  overflow: hidden !important;
  height: 100vh !important;
}
body.akh-builder-open #__next {
  height: 100vh !important;
}
.akh-builder {
  --akh-bg: #f4f6f8;
  --akh-panel: #ffffff;
  --akh-ink: #111827;
  --akh-muted: #6b7280;
  --akh-line: #e5e7eb;
  --akh-soft: #f1f5f9;
  --akh-primary: #0f172a;
  --akh-success: #00bc7d;
  --akh-canvas-min-height: calc(100vh - 96px);
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: var(--akh-bg);
  color: var(--akh-ink);
  font: 14px/1.45 ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}
.akh-builder button {
  font: inherit;
}
.akh-builder__topbar {
  height: 64px;
  min-height: 64px;
  display: grid;
  grid-template-columns: minmax(260px, 1fr) auto minmax(320px, 1fr);
  align-items: center;
  gap: 18px;
  padding: 0 18px;
  border-bottom: 1px solid var(--akh-line);
  background: rgba(255,255,255,.96);
  backdrop-filter: blur(10px);
  z-index: 20;
}
.akh-builder__page,
.akh-builder__title-row,
.akh-builder__actions,
.akh-builder__viewport,
.akh-builder__search {
  display: flex;
  align-items: center;
}
.akh-builder__page {
  gap: 12px;
  min-width: 0;
}
.akh-builder__eyebrow {
  color: var(--akh-muted);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
}
.akh-builder__title-row {
  gap: 8px;
  min-width: 0;
}
.akh-builder__title-row h1 {
  margin: 0;
  max-width: 260px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 16px;
  font-weight: 750;
}
.akh-builder__badge,
.akh-builder__version {
  border-radius: 999px;
  padding: 3px 8px;
  font-size: 11px;
  font-weight: 650;
}
.akh-builder__badge {
  background: rgba(0,188,125,.12);
  color: #047857;
  text-transform: capitalize;
}
.akh-builder__version {
  background: var(--akh-soft);
  color: var(--akh-muted);
}
.akh-builder__icon-btn,
.akh-builder__ghost,
.akh-builder__primary,
.akh-builder__viewport button {
  border: 1px solid var(--akh-line);
  background: #fff;
  color: var(--akh-ink);
  cursor: pointer;
  transition: background .15s ease, border-color .15s ease, color .15s ease, transform .15s ease;
}
.akh-builder__icon-btn {
  width: 38px;
  height: 38px;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
.akh-builder__icon-btn:hover,
.akh-builder__ghost:hover,
.akh-builder__viewport button:hover {
  background: var(--akh-soft);
  border-color: #d1d5db;
}
.akh-builder__viewport {
  gap: 4px;
  padding: 4px;
  border: 1px solid var(--akh-line);
  border-radius: 10px;
  background: var(--akh-soft);
}
.akh-builder__viewport button {
  width: 36px;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 7px;
  background: transparent;
}
.akh-builder__viewport button.is-active {
  background: var(--akh-primary);
  border-color: var(--akh-primary);
  color: #fff;
}
.akh-builder__actions {
  justify-content: flex-end;
  gap: 8px;
}
.akh-builder__status {
  color: var(--akh-muted);
  font-size: 12px;
  min-width: 104px;
  text-align: right;
}
.akh-builder__status.is-saving {
  color: #047857;
}
.akh-builder__ghost,
.akh-builder__primary {
  min-height: 38px;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  border-radius: 8px;
  padding: 0 13px;
  font-weight: 700;
  font-size: 13px;
}
.akh-builder__primary {
  background: var(--akh-success);
  border-color: var(--akh-success);
  color: #fff;
}
.akh-builder__primary:hover {
  background: #00a86f;
  border-color: #00a86f;
}
.akh-builder__ghost:disabled,
.akh-builder__primary:disabled {
  cursor: wait;
  opacity: .62;
}
/* Spinner on whichever action is actually running (Save vs Publish). */
.akh-btn-spin { animation: akh-btn-spin .7s linear infinite; }
@keyframes akh-btn-spin { to { transform: rotate(360deg); } }
.akh-builder__body {
  min-height: 0;
  flex: 1;
  height: calc(100dvh - 64px);
  display: grid;
  /* Single-sidebar layout (Elementor-style): one panel on the left
   * that switches between Elements and Edit modes. Canvas takes the
   * entire remaining width. */
  grid-template-columns: 304px minmax(0, 1fr);
  overflow: hidden;
  transition: grid-template-columns .25s ease;
}
.akh-builder--fullscreen .akh-builder__body {
  grid-template-columns: minmax(0, 1fr);
}
.akh-builder__left,
.akh-builder__right {
  min-height: 0;
  display: flex;
  flex-direction: column;
  background: var(--akh-panel);
  z-index: 10;
}
.akh-builder__left {
  border-right: 1px solid var(--akh-line);
}
.akh-builder__right {
  border-left: 1px solid var(--akh-line);
}
.akh-builder__search {
  gap: 8px;
  margin: 14px;
  padding: 0 12px;
  height: 40px;
  border: 1px solid var(--akh-line);
  border-radius: 8px;
  color: var(--akh-muted);
  background: var(--akh-soft);
}
.akh-builder__search input {
  width: 100%;
  border: 0;
  outline: 0;
  background: transparent;
  color: var(--akh-ink);
}
.akh-builder__tabs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
  padding: 0 14px 12px;
}
.akh-builder__tabs button {
  height: 34px;
  border: 1px solid var(--akh-line);
  border-radius: 8px;
  background: #fff;
  color: var(--akh-muted);
  cursor: pointer;
  font-weight: 700;
}
.akh-builder__tabs button.is-active {
  background: var(--akh-primary);
  border-color: var(--akh-primary);
  color: #fff;
}
.akh-builder__panel {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: 8px 10px 14px;
}
.akh-builder__panel[hidden] {
  display: none;
}

/* ─────────────────────────────────────────────────────────────────
 *  LAYERS / STRUCTURE PANEL — Elementor "Navigator" look
 *  Targets Puck's _LayerTree_* / _Layer_* class hashes.
 *  Reference: elementor/assets/css/editor.css lines 7574-7790
 * ───────────────────────────────────────────────────────────────── */

/* Compact title strip above the tree, sticky to panel top. */
.akh-builder__panel--outline {
  padding: 0 !important;
  display: flex;
  flex-direction: column;
}
.akh-builder__layers-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  border-bottom: 1px solid var(--akh-line, #e5e7eb);
  font: 600 13px/1 ui-sans-serif, system-ui, sans-serif;
  color: var(--akh-ink, #111827);
  letter-spacing: .01em;
  background: #fff;
  position: sticky;
  top: 0;
  z-index: 2;
}
.akh-builder__layers-head__title {
  flex: 1;
  text-align: center;
}
.akh-builder__layers-head__icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: 0;
  background: transparent;
  border-radius: 6px;
  color: #64748b;
  cursor: pointer;
}
.akh-builder__layers-head__icon:hover {
  background: #f1f5f9;
  color: #0f172a;
}
.akh-builder__layers-body {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: 6px 8px 16px;
}

/* Tree container — flatten Puck's chunky LayerTree padding/borders. */
.akh-builder__panel--outline [class*="_LayerTree_"] {
  font: 12px/1.4 ui-sans-serif, system-ui, sans-serif !important;
  color: #334155 !important;
  list-style: none !important;
  margin: 0 !important;
  padding: 0 !important;
}

/* Each Layer row — match Elementor's 30px height + clean borders. */
.akh-builder__panel--outline [class*="_Layer_"]:not([class*="_Layer-"]) {
  border: 0 !important;
  border-radius: 0 !important;
  position: relative;
}
.akh-builder__panel--outline [class*="_Layer-inner_"] {
  border: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  transition: background .12s ease, color .12s ease !important;
}
.akh-builder__panel--outline [class*="_Layer-clickable_"] {
  height: 30px !important;
  padding: 0 12px 0 10px !important;
  gap: 8px !important;
  font-size: 12px !important;
  color: #334155 !important;
  border-radius: 0 !important;
  cursor: pointer !important;
  transition: background .12s ease !important;
}
.akh-builder__panel--outline [class*="_Layer-clickable_"]:hover {
  background: #f1f5f9 !important;
  color: #0f172a !important;
  border-color: transparent !important;
}

/* Selected row — light-accent fill + accent text, mirroring
 * Elementor's --e-a-bg-active / color-txt-accent pattern. */
.akh-builder__panel--outline [class*="_Layer--isSelected_"] {
  border-color: transparent !important;
}
.akh-builder__panel--outline [class*="_Layer--isSelected_"] > [class*="_Layer-inner_"] {
  background: transparent !important;
}
.akh-builder__panel--outline [class*="_Layer--isSelected_"] > [class*="_Layer-inner_"] > [class*="_Layer-clickable_"] {
  background: #ecfdf5 !important;
  color: #065f46 !important;
  font-weight: 600 !important;
  box-shadow: inset 2px 0 0 #10b981 !important;
}

/* Child of selected — slight ancestor tint, like Elementor's parent
 * highlight when a descendant is being edited. */
.akh-builder__panel--outline [class*="_Layer--childIsSelected_"] > [class*="_Layer-inner_"] > [class*="_Layer-clickable_"] {
  color: #0f172a !important;
}

/* Chevron — single arrow, rotates when expanded (Puck handles rotation
 * via .Layer--isSelected/--childIsSelected). Make it subtle. */
.akh-builder__panel--outline [class*="_Layer-chevron_"] {
  flex-shrink: 0 !important;
  width: 14px !important;
  height: 14px !important;
  color: #94a3b8 !important;
  transition: transform .2s ease !important;
}
.akh-builder__panel--outline [class*="_Layer--isSelected_"] [class*="_Layer-chevron_"],
.akh-builder__panel--outline [class*="_Layer--childIsSelected_"] [class*="_Layer-chevron_"] {
  color: #065f46 !important;
}

/* Title row inside .Layer-clickable: icon | name | (right-side toggles) */
.akh-builder__panel--outline [class*="_Layer-title_"] {
  flex: 1 !important;
  min-width: 0 !important;
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  margin: 0 !important;
  overflow: hidden !important;
}
.akh-builder__panel--outline [class*="_Layer-icon_"] {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
  color: #94a3b8 !important;
}
.akh-builder__panel--outline [class*="_Layer--isSelected_"] [class*="_Layer-icon_"] {
  color: #10b981 !important;
}
.akh-builder__panel--outline [class*="_Layer-name_"] {
  flex: 1 !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  white-space: nowrap !important;
}

/* Nested zones — indent each level by 12px like Elementor. */
.akh-builder__panel--outline [class*="_Layer-zones_"] {
  margin-inline-start: 12px !important;
}
.akh-builder__panel--outline [class*="_Layer-zones_"] > [class*="_LayerTree_"] {
  margin-inline-start: 8px !important;
  border-inline-start: 1px solid #e2e8f0 !important;
  padding-inline-start: 2px !important;
}

/* Zone title (e.g. "content" sub-zones) — Elementor's all-caps small label */
.akh-builder__panel--outline [class*="_LayerTree-zoneTitle_"] {
  font: 600 10px/1 ui-sans-serif, system-ui, sans-serif !important;
  text-transform: uppercase !important;
  letter-spacing: .06em !important;
  color: #94a3b8 !important;
  padding: 10px 12px 4px !important;
  margin: 0 !important;
}

/* Empty-zone helper text — italic small grey, matches Elementor's
 * .elementor-empty-view__title at 10px italic. */
.akh-builder__panel--outline [class*="_LayerTree-helper_"] {
  font: italic 10px/1 ui-sans-serif, system-ui, sans-serif !important;
  color: #94a3b8 !important;
  margin: 8px 0 8px 34px !important;
  text-align: left !important;
}

/* ── Drawer-card (Elements panel item) — Elementor-style icon + label ──
 * Replaces Puck's default drawer item with a square card: SVG glyph on top,
 * component name below. Used in the left "Elements" panel for every widget
 * and also serves as the visual reference for the cursor's drag preview. */
.akh-builder__left :where([data-puck-drawer-item]) {
  background: transparent;
}
.akh-builder__left :where([data-puck-drawer-item]) [class*="_DrawerItem-draggableWrapper"],
.akh-builder__left :where([data-puck-drawer-item]) [class*="_DrawerItem-draggable"] {
  display: contents !important;
}
.akh-builder__left :where([data-puck-drawer-item]) [class*="_DrawerItem-name"],
.akh-builder__left :where([data-puck-drawer-item]) [class*="_DrawerItem-icon"] {
  display: none !important;
}
.akh-drawer-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 18px 12px;
  border: 1px solid var(--akh-line, #e5e7eb);
  border-radius: 8px;
  background: #fff;
  font: 500 12px/1.2 ui-sans-serif, system-ui, sans-serif;
  color: var(--akh-ink, #111827);
  text-align: center;
  cursor: all-scroll;
  transition: background .12s ease, border-color .12s ease, transform .12s ease;
  min-height: 92px;
  width: 100%;
}
.akh-drawer-card:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
}
.akh-drawer-card:active {
  cursor: all-scroll;
  transform: scale(0.98);
}
.akh-drawer-card__icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--akh-ink, #111827);
}
.akh-drawer-card__label {
  font-weight: 500;
  letter-spacing: .01em;
}
/* Drawer-origin drag preview — HIDDEN. The cursor-following white card is
 * AkhDragGhost now; we keep the dnd-kit drag clone in the DOM (so hit-testing
 * works) but make it invisible so only the white ghost shows. */
[data-dnd-dragging]:not([data-puck-component]):has(.akh-drawer-card) {
  opacity: 0 !important;
  pointer-events: none !important;
}
[data-dnd-dragging]:not([data-puck-component]):has(.akh-drawer-card) .akh-drawer-card {
  width: 132px !important;
  height: 96px !important;
  min-height: 96px !important;
  padding: 14px 10px !important;
  background: linear-gradient(180deg, #10b981 0%, #059669 100%) !important;
  border: 1px solid rgba(255, 255, 255, .42) !important;
  border-radius: 8px !important;
  box-shadow: none !important;
  transform: none !important;
  cursor: move !important;
  color: #ffffff !important;
}
[data-dnd-dragging]:not([data-puck-component]):has(.akh-drawer-card) .akh-drawer-card__icon,
[data-dnd-dragging]:not([data-puck-component]):has(.akh-drawer-card) .akh-drawer-card__label {
  color: #ffffff !important;
}
[data-dnd-dragging]:not([data-puck-component]):has(.akh-drawer-card) .akh-drawer-card__icon svg {
  width: 24px;
  height: 24px;
}

/* Lay drawer cards out in a 2-column grid so multiple cards fit per row,
 * matching Elementor's element-picker grid. */
.akh-builder__left [class*="_Drawer_"] {
  display: grid !important;
  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
  gap: 8px !important;
}
.akh-builder__canvas {
  position: relative;
  height: calc(100dvh - 64px);
  max-height: calc(100dvh - 64px);
  min-width: 0;
  overflow-x: auto;
  overflow-y: scroll;
  padding: 16px;
  box-sizing: border-box;
  overscroll-behavior: contain;
  background:
    linear-gradient(90deg, rgba(15,23,42,.04) 1px, transparent 1px),
    linear-gradient(rgba(15,23,42,.04) 1px, transparent 1px),
    #edf0f3;
  background-size: 24px 24px;
}
.akh-builder__frame {
  --akh-builder-section-min-height: var(--akh-canvas-min-height);
  width: 100%;
  margin: 0 auto;
  /* Always fill the visible canvas (≈100vh) so the white page never looks
   * short with little content. It's a MIN — taller content grows the frame
   * and the canvas (overflow-y: scroll) scrolls. The section adder flows in
   * normal order right after the last section; the remaining height is just
   * empty white below it. */
  min-height: var(--akh-canvas-min-height);
  background: #fff;
  box-sizing: border-box;
  box-shadow: 0 18px 45px rgba(15,23,42,.12);
  transition: max-width .18s ease;
}
/* Extra-tall ONLY while empty — gives a big initial drop target. */
.akh-builder__frame:not(:has([data-puck-component])) {
  min-height: calc(var(--akh-canvas-min-height) + 320px);
}
.akh-builder__frame[data-viewport="desktop"] {
  box-shadow: none;
  max-width: none !important;
}
.akh-builder__frame[data-viewport="tablet"],
.akh-builder__frame[data-viewport="mobile"] {
  box-shadow: 0 18px 45px rgba(15,23,42,.12);
}
.akh-builder__frame [data-puck-preview],
.akh-builder__frame [data-puck-entry],
.akh-builder__frame #puck-root {
  box-sizing: border-box;
}
/* Tall canvas ONLY while the page is empty (gives a big initial drop
 * target). Once the root has content, the dropzone hugs its content so
 * the section adder sits right after the last section instead of
 * floating at the bottom of a viewport-tall empty area. */
.akh-builder__frame [data-puck-preview]:not(:has([data-puck-component])),
.akh-builder__frame [data-puck-entry]:not(:has([data-puck-component])),
.akh-builder__frame #puck-root:not(:has([data-puck-component])),
.akh-builder__frame [data-puck-dropzone="root"]:not(:has([data-puck-component])) {
  min-height: calc(var(--akh-canvas-min-height) + 320px);
}
.akh-builder__frame [data-puck-preview] {
  width: 100%;
}
/* Only empty dropzones get the 120px drop-target minimum. Once a
 * container has children, its slot collapses to content height so the
 * outer container hugs its content (Elementor parity — no phantom
 * empty space below the last child). The :not(:has(...)) form is the
 * empty-state guard; supported by all modern browsers. */
.akh-builder__frame [data-puck-dropzone]:not(:has([data-puck-component])) {
  min-height: 120px;
}
.akh-builder__frame [data-puck-dropzone="root"] {
  padding-bottom: 0;
}

/* ── Section adder (Elementor-style + / templates) ──
 * Populated canvas: flows in normal document order (the component is
 * rendered right after <Puck.Preview/>), so it sits BELOW the last
 * section — never overlapping it. Empty canvas: floats centered near
 * the top of the big drop target instead. */
.akh-sadd {
  position: relative;
  z-index: 40;
  display: flex;
  justify-content: center;
  /* Extra breathing room above + below so the adder sits in clean space
   * between the last section and the empty canvas tail. */
  margin: 32px 0 96px;
  pointer-events: none;
}
/* Full-width dashed frame around the adder row (populated canvas only).
 * Buttons stay centered inside; the empty-state variant below opts out. */
.akh-sadd:not(.akh-sadd--empty) {
  align-items: center;
  padding: 32px 0;
  border: 1.5px dashed #cbd5e1;
  border-radius: 0;
  background: rgba(248, 250, 252, .5);
  transition: border-color .15s ease, background .15s ease;
}
.akh-sadd:not(.akh-sadd--empty):hover {
  border-color: #0f5931;
  background: #f0fdf4;
}
.akh-sadd--empty {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  top: 60px;
  margin: 0;
}
.akh-sadd__bar,
.akh-sadd__panel {
  pointer-events: auto;
}
/* Buttons + "Drag widget here" hint, stacked + centered. Inherits the
 * parent's pointer-events: none so empty box area still passes drops
 * through; only the button bar opts back into pointer events. */
.akh-sadd__stack {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}
.akh-sadd__bar {
  display: inline-flex;
  align-items: center;
  gap: 12px;
}
.akh-sadd__hint {
  font-size: 13px;
  font-style: italic;
  color: #94a3b8;
  pointer-events: none;
  user-select: none;
}
/* AI build button — pink sparkle, matches the topbar AI accent. */
.akh-sadd__btn--ai {
  background: #f5d0fe;
  color: #a21caf;
  box-shadow: 0 4px 12px rgba(217, 70, 239, .28);
}
.akh-sadd__btn--ai:hover { transform: translateY(-1px); background: #f0abfc; box-shadow: 0 12px 26px rgba(217, 70, 239, .38); }
.akh-sadd__btn {
  width: 46px;
  height: 46px;
  border-radius: 999px;
  border: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform .12s ease, box-shadow .12s ease, background .12s ease;
}
.akh-sadd__btn--add {
  background: #0f5931;
  color: #fff;
  box-shadow: 0 8px 20px rgba(15, 89, 49, .35);
}
.akh-sadd__btn--add:hover { transform: translateY(-1px); box-shadow: 0 12px 26px rgba(15, 89, 49, .42); }
.akh-sadd__btn--tpl {
  background: #fff;
  color: #0f5931;
  border: 1px solid #cbd5e1;
  box-shadow: 0 4px 12px rgba(15, 23, 42, .12);
}
.akh-sadd__btn--tpl:hover { transform: translateY(-1px); background: #f0fdf4; }
.akh-sadd__panel {
  width: 360px;
  max-width: 90vw;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  box-shadow: 0 18px 50px rgba(15, 23, 42, .22);
  padding: 16px;
}
.akh-sadd__panel-title {
  font-size: 13px;
  font-weight: 600;
  color: #334155;
  text-align: center;
  margin-bottom: 14px;
}
.akh-sadd__grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}
.akh-sadd__preset {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 12px 8px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  cursor: pointer;
  transition: border-color .12s ease, background .12s ease, transform .12s ease;
}
.akh-sadd__preset:hover {
  border-color: #0f5931;
  background: #f0fdf4;
  transform: translateY(-1px);
}
.akh-sadd__glyph {
  display: flex;
  gap: 3px;
  width: 100%;
  height: 34px;
}
.akh-sadd__glyph > span {
  background: #0f5931;
  border-radius: 2px;
  opacity: .85;
}
.akh-sadd__preset-label {
  font-size: 11px;
  color: #64748b;
  text-align: center;
  line-height: 1.2;
}
.akh-builder__frame:has([data-puck-entry][data-puck-dragging]) [data-puck-dropzone="root"]:not(:empty) {
  cursor: not-allowed !important;
}
/* Drop indicators — scoped to the ROOT canvas dropzone only.
 * Inside containers (nested dropzones) we let Puck's built-in subtle
 * blue tint do the work — no "+", no "Drag widget here" text, no
 * trailing slot, regardless of whether the container has children. */
.akh-builder__frame [data-puck-dropzone="root"]:empty {
  position: relative;
  min-height: 160px;
  background: #ffffff !important;
  outline: 1px dashed #cbd5e1 !important;
  outline-offset: -2px;
  border-radius: 8px;
  margin: 4px;
  box-sizing: border-box;
}
.akh-builder__frame [data-puck-dropzone="root"]:empty::before {
  content: "+";
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, calc(-50% - 14px));
  width: 44px;
  height: 44px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 999px;
  background: #f1f5f9;
  color: #475569;
  font: 400 22px/1 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  pointer-events: none;
}
.akh-builder__frame [data-puck-dropzone="root"]:empty::after {
  content: "Drag widget here";
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  transform: translateY(20px);
  text-align: center;
  font: italic 500 13px/1 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: #64748b;
  pointer-events: none;
}
/* Trailing visual indicator on the root dropzone removed — it was a non-
 * interactive ::after pseudo that visually claimed the area below content,
 * confusing dnd-kit's drop hit-detection during cross-zone drags (the user's
 * cursor hovered the "Drag widget here" tile and the actual underlying
 * dropzone target felt unresponsive). Empty drop area is still there: the
 * root dropzone has padding-bottom: 220px below for natural drop reception. */
.akh-builder__right-head {
  height: 54px;
  min-height: 54px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  border-bottom: 1px solid var(--akh-line);
  font-weight: 750;
}
.akh-builder__fields {
  padding: 0;
}

/* ─────────────────────────────────────────────────────────────────
 *  Elementor-style right panel — LIGHT THEME
 *  Scope: only inside .akh-builder__right so the rest of the editor
 *  inherits the dashboard palette.
 * ───────────────────────────────────────────────────────────────── */
.akh-builder__right,
.akh-builder__left {
  --rp-bg:           #ffffff;
  --rp-bg-2:         #f8fafc;
  --rp-bg-3:         #ffffff;
  --rp-line:         #e5e7eb;
  --rp-line-2:       #d1d5db;
  --rp-text:         #0f172a;
  --rp-text-dim:     #64748b;
  --rp-accent:       #0f172a;
  --rp-accent-hot:   #93003f;
  --rp-accent-blue:  #3b82f6;
}
.akh-builder__right {
  background: var(--rp-bg);
  color: var(--rp-text);
  border-left: 1px solid var(--rp-line);
}

/* ── Elements sidebar: title + Widgets/Globals/SEO underline tabs ── */
.akh-builder__elements-title {
  padding: 16px 14px 10px;
  text-align: center;
  font: 700 15px/1 ui-sans-serif, system-ui, -apple-system, sans-serif;
  color: #0f172a;
}
.akh-builder__side-tabs {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  border-bottom: 1px solid var(--akh-line, #e5e7eb);
  margin: 0 14px 4px;
}
.akh-builder__side-tabs button {
  position: relative;
  height: 38px;
  background: transparent;
  border: 0;
  color: #64748b;
  cursor: pointer;
  font: 500 13px/1 ui-sans-serif, system-ui, sans-serif;
  padding: 0;
  transition: color .12s ease;
}
.akh-builder__side-tabs button:hover { color: #0f172a; }
.akh-builder__side-tabs button.is-active {
  color: #0f172a;
  font-weight: 600;
}
.akh-builder__side-tabs button.is-active::after {
  content: "";
  position: absolute;
  left: 0; right: 0; bottom: -1px;
  height: 2px;
  background: #0f172a;
  border-radius: 2px;
}

/* ── Edit-mode header inside the left sidebar ── */
.akh-builder__edit-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 12px 14px;
  border-bottom: 1px solid var(--rp-line, #e5e7eb);
  background: var(--rp-bg-2, #f8fafc);
}
.akh-builder__edit-head__title {
  flex: 1;
  text-align: center;
  font: 600 14px/1 ui-sans-serif, system-ui, sans-serif;
  color: #0f172a;
  text-transform: capitalize;
}
.akh-builder__edit-back {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border: 1px solid #e2e8f0;
  background: #fff;
  border-radius: 8px;
  color: #0f172a;
  cursor: pointer;
  transition: background .12s ease, border-color .12s ease, transform .25s ease;
  transform: rotate(45deg);
  padding: 0;
}
.akh-builder__edit-back:hover { background: #f1f5f9; border-color: #cbd5e1; }
.akh-builder__edit-back:active { transform: rotate(45deg) scale(0.94); }
.akh-builder__right-head {
  background: var(--rp-bg-2);
  border-bottom-color: var(--rp-line);
  color: var(--rp-text);
}

.akh-rp {
  display: flex;
  flex-direction: column;
  min-height: 0;
  height: 100%;
  background: var(--rp-bg);
  color: var(--rp-text);
}
.akh-rp__tabs {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  position: sticky;
  top: 0;
  z-index: 2;
  background: var(--rp-bg-2);
  border-bottom: 1px solid var(--rp-line);
  padding: 0;
  gap: 0;
}
.akh-rp__tab {
  appearance: none;
  background: transparent;
  border: 0;
  padding: 10px 4px 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  font: 600 11px/1 ui-sans-serif, system-ui, sans-serif;
  letter-spacing: .02em;
  color: var(--rp-text-dim);
  cursor: pointer;
  border-bottom: 2px solid transparent;
  transition: color .12s ease, border-color .12s ease;
}
.akh-rp__tab:hover { color: var(--rp-text); }
.akh-rp__tab.is-active {
  color: var(--rp-text);
  border-bottom-color: var(--rp-text);
}
.akh-rp__tab-icon { display: inline-flex; }
.akh-rp__tab-label { font-size: 12px; }

.akh-rp__body {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: 0;
  background: var(--rp-bg);
}
.akh-rp__loading,
.akh-rp__empty {
  padding: 18px;
  color: var(--rp-text-dim);
  font-size: 13px;
}
.akh-rp__section { border: 0; }
.akh-rp__section-head {
  appearance: none;
  width: 100%;
  background: var(--rp-bg-2);
  border: 0;
  border-bottom: 1px solid var(--rp-line);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  cursor: pointer;
  font: 700 12px/1 ui-sans-serif, system-ui, sans-serif;
  color: var(--rp-text);
  letter-spacing: .02em;
  text-transform: uppercase;
}
.akh-rp__section-head:hover { background: #eef2f6; }
.akh-rp__section-chevron {
  color: var(--rp-text-dim);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.18s ease, color 0.12s ease;
}
.akh-rp__section-chevron svg { display: block; }
.akh-rp__section:not(.is-open) .akh-rp__section-chevron { transform: rotate(-90deg); }
.akh-rp__section-head:hover .akh-rp__section-chevron { color: var(--rp-text); }
.akh-rp__section-body {
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0;
  background: var(--rp-bg);
}
/* CleanFieldLabel — strips "L · Section · Foo" prefix, shows just "Foo".
 * Default layout: HORIZONTAL (label left, input right) — matches Elementor.
 * Switches to VERTICAL only when the child is a wide widget
 * (dimensions, slider) via :has(). */
.akh-fl {
  display: grid;
  /* Title : control = 70 : 30, inline on one row. */
  grid-template-columns: minmax(0, 7fr) minmax(0, 3fr);
  align-items: center;
  gap: 10px;
  padding: 16px !important;
  margin-top: 0 !important;
  border-top: 0 !important;
  border-bottom: 1px solid var(--rp-line) !important;
}
.akh-builder :where([class*="PuckFields--wrapFields"]) :where([class*="PuckFields-field"]) + :where([class*="PuckFields-field"]) {
  border-top: 0 !important;
  margin-top: 0 !important;
}
.akh-builder :where([class*="PuckFields-field"]):has(.akh-slider) {
  border-bottom: 1px solid var(--rp-line) !important;
}
.akh-fl__text {
  max-width: none;
  font-size: 12px;
  font-weight: 500;
  color: var(--rp-text);
  letter-spacing: .01em;
  /* Keep multi-word labels on a single line (e.g. "Grid Outline",
   * "Justify content") — wrap was making the panel look cramped. */
  white-space: nowrap;
}
.akh-fl__device {
  display: inline-flex;
  align-items: center;
  margin-left: 6px;
  color: #e600c9;
  vertical-align: middle;
}
.akh-fl > :not(.akh-fl__text) {
  width: 100%;
  min-width: 0;
}
.akh-fl > :not(.akh-fl__text) > :where(input, select, textarea, button, div) {
  width: 100%;
}
/* But: the .akh-switch toggle inside .akh-switch-row should NOT
 * stretch — its size is set on the .akh-switch element itself
 * (min-width 70px). Unset the inherited width:100% so the toggle
 * stays pill-sized instead of taking the full label column. */
.akh-fl .akh-switch-row .akh-switch {
  width: auto;
  flex: 0 0 auto;
}
.akh-fl .akh-switch-row {
  /* Tighten the gap between title + toggle and keep the row from
   * stretching the toggle by accident. */
  justify-content: space-between;
}
.akh-fl:not(:has(.akh-slider)):not(:has(.akh-vc)):not(:has(.akh-dim)):not(:has(textarea)) > :not(.akh-fl__text) {
  justify-self: stretch;
  width: 100%;
}
/* Wide widgets (dimensions, sliders, switches, textareas) need the
 * label above, control below — they're tall enough that an inline
 * layout would crowd. Selects and text inputs stay INLINE (label
 * left, control right) — set later by the default grid in .akh-fl. */
.akh-fl:has(.akh-dim),
.akh-fl:has(.akh-slider),
.akh-fl:has(.akh-switch-row),
.akh-fl:has(textarea) {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: 8px;
}
.akh-fl:has(.akh-dim) .akh-fl__text,
.akh-fl:has(.akh-slider) .akh-fl__text,
.akh-fl:has(.akh-switch-row) .akh-fl__text,
.akh-fl:has(textarea) .akh-fl__text {
  max-width: 100%;
}
/* Hide the outer Puck-rendered label text when the inner widget
 * renders its own title row — avoids label duplication. */
.akh-fl:has(.akh-slider) .akh-fl__text,
.akh-fl:has(.akh-switch-row) .akh-fl__text,
.akh-fl:has(.akh-dim) .akh-fl__text {
  display: none;
}
/* Dimensions widget header — title + device icon (left), unit (right),
 * all on one row. */
.akh-dim__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 26px;
  margin-bottom: 4px;
}
.akh-dim__title {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--rp-text);
  font-size: 13px;
  font-weight: 500;
}
.akh-dim__device {
  display: inline-flex;
  align-items: center;
  color: #e600c9;
}
.akh-dim__device svg { display: block; }
.akh-dim__head .akh-dim__unit { margin-left: auto; }
.akh-dim__head .akh-dim__unit select {
  height: 28px;
  border-radius: 4px;
}
/* Selects and text inputs: keep inline — the outer CleanFieldLabel
 * already shows the field name + device icon, so the inner __head
 * (title row) is redundant. Hide it; the control sits alone on the
 * right of the label. */
.akh-fl:has(.akh-responsive-select) .akh-responsive-select__head,
.akh-fl:has(.akh-responsive-text) .akh-responsive-text__head {
  display: none;
}
.akh-fl--ro { opacity: .55; }
/* Dark-theme native inputs (text/select/textarea Puck renders by default) */
.akh-rp__section-body :where(input[type="text"], input[type="number"], textarea, select) {
  width: 100%;
  height: 32px;
  padding: 0 10px;
  border: 1px solid var(--rp-line-2);
  border-radius: 3px;
  background: var(--rp-bg-3);
  color: var(--rp-text);
  font: 13px/1.2 ui-sans-serif, system-ui, sans-serif;
  outline: 0;
  transition: border-color .12s ease, box-shadow .12s ease;
}
.akh-rp__section-body textarea {
  height: auto;
  min-height: 72px;
  padding: 8px 10px;
}
.akh-rp__section-body :where(input, textarea, select):focus {
  border-color: var(--rp-accent-blue);
  box-shadow: 0 0 0 1px var(--rp-accent-blue);
}
.akh-rp__section-body select {
  appearance: none;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='%2364748b' d='M0 0l5 6 5-6z'/></svg>");
  background-repeat: no-repeat;
  background-position: right 10px center;
  padding-right: 28px;
}
.akh-rp__section-body :where([class*="Select"], [class*="select"]) {
  width: 150px;
  max-width: none;
}
.akh-rp__section-body :where([class*="Select"] button, [class*="select"] button) {
  width: 100%;
  justify-content: space-between;
}

/* ── VisualChoice: Elementor-style icon button group ── */
.akh-vc-row {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
}
.akh-vc-row--stack {
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  gap: 8px;
}
.akh-vc-row__title {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  min-width: 110px;
  color: var(--rp-text);
  font-size: 12px;
  font-weight: 500;
  letter-spacing: .01em;
}
/* Container for VisualChoice's device icon. Same trap as the slider
 * one — used to draw a fake desktop monitor via ::before/::after that
 * overdrew the real DeviceIcon SVG. Now just hosts the SVG so the
 * icon switches between desktop/tablet/mobile correctly. */
.akh-vc-row__device {
  display: inline-flex;
  align-items: center;
  color: #e600c9;
}
.akh-vc-row__device svg {
  width: 13px;
  height: 13px;
  display: block;
}
/* Icon button group — always full-width, buttons share the row
 * equally. Elementor parity: even when there are 4 vs 6 options,
 * each button claims an equal fraction of the available width. */
.akh-vc {
  display: flex;
  width: 100% !important;
  max-width: 100%;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  box-shadow: 0 1px 2px rgba(15, 23, 42, .04);
}
.akh-vc-row--stack .akh-vc-row__title {
  width: 100%;
  min-width: 0;
}
.akh-vc-row--stack .akh-vc {
  align-self: stretch;
}
.akh-vc__btn {
  appearance: none;
  background: transparent;
  border: 0;
  border-left: 1px solid #cbd5e1;
  flex: 1 1 0;
  min-width: 0;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #475569;
  cursor: pointer;
  transition: background .12s ease, color .12s ease;
}
.akh-vc__btn:first-child { border-left: 0; }
.akh-vc__btn:hover { color: var(--rp-text); background: #f1f5f9; }
.akh-vc__btn.is-active {
  background: var(--rp-accent);
  color: #fff;
}

/* ── Dimensions: linked 4-input widget (padding/margin) ── */
.akh-dim {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.akh-dim__row {
  display: flex;
  justify-content: flex-end;
}
.akh-dim__unit select {
  width: auto !important;
  min-width: 58px;
  height: 24px !important;
  padding: 0 22px 0 8px !important;
  font-size: 11px !important;
  background-color: transparent !important;
  border-color: transparent !important;
  color: var(--rp-text-dim) !important;
}
.akh-dim__grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr) auto;
  gap: 4px;
  align-items: stretch;
}
.akh-dim__side {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}
.akh-dim__side input {
  width: 100%;
  height: 30px !important;
  text-align: center;
  font-size: 12px !important;
  padding: 0 4px !important;
  border-radius: 3px !important;
}
.akh-dim__side span {
  font-size: 10.5px;
  color: var(--rp-text-dim);
}
.akh-dim__link {
  appearance: none;
  background: var(--rp-bg-3);
  border: 1px solid var(--rp-line-2);
  border-radius: 3px;
  width: 30px;
  height: 30px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--rp-text-dim);
  cursor: pointer;
  margin-bottom: 18px; /* align with input row, not label row */
}
.akh-dim__link:hover { color: var(--rp-text); }
.akh-dim__link.is-active {
  background: var(--rp-accent);
  border-color: var(--rp-accent);
  color: #fff;
}

/* ── Responsive select + text: title row over native control ──
 * Mirrors the SliderInput structure so all responsive fields share
 * a consistent look — title-left / device-icon-right header, with
 * the control filling the row below. */
/* Inline 70/30: title head (70%) left, control (30%) right — matches
 * the plain .akh-fl rows so the whole panel reads consistently. Was
 * flex-column (title stacked above control). */
.akh-responsive-select,
.akh-responsive-text {
  display: grid;
  grid-template-columns: minmax(0, 7fr) minmax(0, 3fr);
  align-items: center;
  gap: 10px;
  width: 100%;
}
.akh-responsive-select__head,
.akh-responsive-text__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 22px;
}
.akh-responsive-select__title,
.akh-responsive-text__title {
  color: var(--rp-text);
  font-size: 13px;
  font-weight: 500;
}
.akh-responsive-select__device,
.akh-responsive-text__device {
  color: #e600c9;
  display: inline-flex;
  align-items: center;
}
.akh-responsive-select__input,
.akh-responsive-text__input {
  width: 100% !important;
  height: 32px !important;
  padding: 0 10px !important;
  border-radius: 4px !important;
}

/* ── AI Assistant (sidebar panel: history + chat thread) ── */
.akh-ai2 { display: flex; flex-direction: column; height: 100%; min-height: 0; }
.akh-ai2__bar {
  display: flex;
  gap: 6px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--rp-line, #e5e7eb);
}
.akh-ai2__sessions-btn, .akh-ai2__new-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 6px 10px;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 7px;
  background: #fff;
  font-size: 12px;
  font-weight: 500;
  color: var(--rp-text, #334155);
  cursor: pointer;
}
.akh-ai2__new-btn { margin-left: auto; }
.akh-ai2__sessions-btn:hover, .akh-ai2__new-btn:hover { background: #f8fafc; }
.akh-ai2__sessions { flex: 1 1 auto; overflow-y: auto; padding: 8px; display: flex; flex-direction: column; gap: 4px; }
.akh-ai2__session {
  text-align: left;
  border: 1px solid var(--rp-line, #e5e7eb);
  border-radius: 8px;
  background: #fff;
  padding: 9px 10px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.akh-ai2__session:hover { border-color: #7c3aed; background: #faf5ff; }
.akh-ai2__session-title { font-size: 12.5px; font-weight: 500; color: #0f172a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.akh-ai2__session-meta { font-size: 10.5px; color: #94a3b8; }
.akh-ai2__empty { padding: 24px; text-align: center; font-size: 12px; color: #94a3b8; }
.akh-ai2__thread { flex: 1 1 auto; overflow-y: auto; padding: 12px; display: flex; flex-direction: column; gap: 8px; }
.akh-ai2__hello { margin: auto; text-align: center; color: #94a3b8; padding: 20px; }
.akh-ai2__hello-icon { display: inline-flex; color: #7c3aed; margin-bottom: 8px; }
.akh-ai2__hello p { font-size: 12.5px; line-height: 1.5; margin: 0; }
.akh-ai2__msg { display: flex; }
.akh-ai2__msg--user { justify-content: flex-end; }
.akh-ai2__msg--assistant { justify-content: flex-start; }
.akh-ai2__bubble {
  max-width: 85%;
  padding: 8px 11px;
  border-radius: 12px;
  font-size: 12.5px;
  line-height: 1.45;
  white-space: pre-wrap;
  word-break: break-word;
}
.akh-ai2__msg--user .akh-ai2__bubble { background: #7c3aed; color: #fff; border-bottom-right-radius: 4px; }
.akh-ai2__msg--assistant .akh-ai2__bubble { background: #f1f5f9; color: #0f172a; border-bottom-left-radius: 4px; }
.akh-ai2__typing { letter-spacing: 2px; color: #94a3b8; }
.akh-ai2__error { margin: 0 12px; font-size: 12px; color: #dc2626; background: #fef2f2; border-radius: 6px; padding: 6px 8px; }
.akh-ai2__composer { border-top: 1px solid var(--rp-line, #e5e7eb); padding: 10px 12px; display: flex; flex-direction: column; gap: 8px; }
.akh-ai2__model {
  width: 100%;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 7px;
  padding: 6px 8px;
  font-size: 11.5px;
  color: #334155;
  background: #fff;
}
.akh-ai2__model:focus { outline: 0; border-color: #7c3aed; }
.akh-ai2__modes { display: flex; gap: 5px; }
.akh-ai2__mode {
  flex: 1 1 0;
  padding: 5px 4px;
  border: 1px solid var(--rp-line, #e5e7eb);
  border-radius: 6px;
  background: #fff;
  font-size: 11.5px;
  font-weight: 500;
  color: #64748b;
  cursor: pointer;
}
.akh-ai2__mode.is-active { border-color: #7c3aed; background: #f5f3ff; color: #6d28d9; }
.akh-ai2__mode:disabled { opacity: .45; cursor: not-allowed; }
.akh-ai2__input {
  width: 100%;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 8px;
  padding: 9px 10px;
  font-size: 12.5px;
  line-height: 1.5;
  resize: vertical;
  color: #0f172a;
}
.akh-ai2__input:focus { outline: 0; border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124, 58, 237, .12); }
.akh-ai2__run {
  width: 100%;
  padding: 9px;
  border: 0;
  border-radius: 8px;
  background: #7c3aed;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}
.akh-ai2__run:disabled { opacity: .55; cursor: default; }

/* ── GalleryPicker: image source control + media modal ── */
.akh-gp { display: flex; flex-direction: column; gap: 8px; width: 100%; }
.akh-gp__preview {
  width: 100%;
  height: 120px;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 8px;
  background:
    repeating-conic-gradient(#f1f5f9 0% 25%, #fff 0% 50%) 50% / 16px 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
.akh-gp__preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
.akh-gp__empty { font-size: 12px; color: #94a3b8; }
.akh-gp__actions { display: flex; gap: 6px; }
.akh-gp__btn {
  flex: 1 1 0;
  height: 32px;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 6px;
  background: #fff;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--rp-text, #334155);
  cursor: pointer;
}
.akh-gp__btn--primary { background: var(--primary, #0f5931); border-color: var(--primary, #0f5931); color: #fff; }
.akh-gp__btn:hover { filter: brightness(0.97); }
.akh-gp__url {
  width: 100%;
  height: 30px;
  padding: 0 8px;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 6px;
  font-size: 12px;
  color: var(--rp-text, #334155);
}
/* Modal */
.akh-gpm {
  position: fixed;
  inset: 0;
  z-index: 10000;
  background: rgba(15, 23, 42, .55);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}
.akh-gpm__panel {
  width: min(840px, 94vw);
  height: min(620px, 88vh);
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 24px 70px rgba(15, 23, 42, .35);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.akh-gpm__head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  border-bottom: 1px solid #e2e8f0;
}
.akh-gpm__title { font-size: 15px; font-weight: 700; color: #0f172a; }
.akh-gpm__search { flex: 1 1 auto; }
.akh-gpm__search input {
  width: 100%;
  height: 34px;
  padding: 0 12px;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  font-size: 13px;
}
.akh-gpm__upload {
  height: 34px;
  padding: 0 16px;
  border: 0;
  border-radius: 8px;
  background: var(--primary, #0f5931);
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}
.akh-gpm__upload:disabled { opacity: .6; cursor: default; }
.akh-gpm__close {
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 8px;
  background: #f1f5f9;
  color: #475569;
  font-size: 15px;
  cursor: pointer;
}
.akh-gpm__body { flex: 1 1 auto; overflow-y: auto; padding: 16px; }
.akh-gpm__state { padding: 40px; text-align: center; color: #94a3b8; font-size: 13px; }
.akh-gpm__state--err { color: #dc2626; }
.akh-gpm__grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
  gap: 12px;
}
.akh-gpm__item {
  display: flex;
  flex-direction: column;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  overflow: hidden;
  padding: 0;
  transition: border-color .12s ease, transform .12s ease, box-shadow .12s ease;
}
.akh-gpm__item:hover { border-color: var(--primary, #0f5931); transform: translateY(-2px); box-shadow: 0 8px 20px rgba(15, 23, 42, .12); }
.akh-gpm__item img { width: 100%; height: 110px; object-fit: cover; background: #f8fafc; display: block; }
.akh-gpm__name {
  font-size: 11px;
  color: #64748b;
  padding: 6px 8px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* ── DynamicField: Title / Link with dynamic-tag picker ── */
.akh-dyn { width: 100%; }
.akh-dyn__field {
  position: relative;
  display: flex;
  align-items: stretch;
  border: 1px solid var(--rp-line-2);
  border-radius: 6px;
  background: #fff;
  overflow: visible;
}
.akh-dyn__field--area { align-items: flex-start; }
.akh-dyn__input,
.akh-dyn__textarea {
  flex: 1 1 auto;
  min-width: 0;
  border: 0 !important;
  outline: 0;
  background: transparent;
  font-size: 13px;
  color: var(--rp-text);
  padding: 8px 10px;
  resize: vertical;
}
.akh-dyn__textarea { min-height: 70px; line-height: 1.5; font-family: inherit; }
.akh-dyn__icons {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 0 4px;
  flex: 0 0 auto;
}
.akh-dyn__icons--area { align-items: flex-start; padding-top: 6px; }
.akh-dyn__btn {
  width: 26px;
  height: 26px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 0;
  background: transparent;
  color: #64748b;
  border-radius: 4px;
  cursor: pointer;
  transition: background .12s ease, color .12s ease;
}
.akh-dyn__btn:hover { background: #f1f5f9; color: #0f172a; }
.akh-dyn__btn--db:hover { color: #be123c; }
.akh-dyn__menu {
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  width: 230px;
  max-height: 320px;
  overflow-y: auto;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  box-shadow: 0 14px 40px rgba(15, 23, 42, .2);
  z-index: 60;
  padding: 6px;
}
.akh-dyn__menu-title {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .04em;
  color: #94a3b8;
  padding: 6px 8px 4px;
}
.akh-dyn__menu-grouplabel {
  font-size: 11px;
  font-weight: 600;
  color: #475569;
  padding: 8px 8px 2px;
}
.akh-dyn__menu-item {
  display: block;
  width: 100%;
  text-align: left;
  border: 0;
  background: transparent;
  font-size: 12.5px;
  color: #334155;
  padding: 6px 8px;
  border-radius: 5px;
  cursor: pointer;
}
.akh-dyn__menu-item:hover { background: #f0fdf4; color: #0f5931; }

/* ── SliderInput: slider + number + unit dropdown ── */
/* ── ColorPicker field (swatch + hex + palette popover) ── */
.akh-color { position: relative; display: flex; flex-direction: column; gap: 8px; }
.akh-color__head {
  display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 26px;
}
.akh-color__title { color: var(--rp-text); font-size: 14px; font-weight: 500; }
.akh-color__device { display: inline-flex; align-items: center; color: #e600c9; }
.akh-color__device svg { width: 13px; height: 13px; display: block; }
.akh-color__control { display: flex; align-items: center; gap: 8px; }
.akh-color__swatch {
  flex: 0 0 auto; width: 34px; height: 30px; border-radius: 8px; cursor: pointer;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.6);
}
.akh-color__swatch.is-empty {
  background:
    linear-gradient(45deg, #e2e8f0 25%, transparent 25%) -5px 0/12px 12px,
    linear-gradient(-45deg, #e2e8f0 25%, transparent 25%) -5px 0/12px 12px,
    linear-gradient(45deg, transparent 75%, #e2e8f0 75%) 0 0/12px 12px,
    linear-gradient(-45deg, transparent 75%, #e2e8f0 75%) 0 0/12px 12px,
    #fff;
}
.akh-color__hex {
  flex: 1 1 auto; min-width: 0; height: 30px; border-radius: 8px; padding: 0 9px;
  border: 1px solid var(--rp-line-2, #cbd5e1); background: #fff;
  font: 500 12.5px/1 ui-monospace, SFMono-Regular, Menlo, monospace; color: var(--rp-text, #334155);
}
.akh-color__hex:focus { outline: 0; border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124,58,237,.12); }
.akh-color__clear {
  flex: 0 0 auto; width: 26px; height: 30px; border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 8px; background: #fff; color: #94a3b8; font-size: 18px; line-height: 1; cursor: pointer;
}
.akh-color__clear:hover { color: #ef4444; border-color: #fecaca; background: #fef2f2; }
.akh-color__pop {
  position: absolute; z-index: 60; top: calc(100% + 6px); left: 0; right: 0;
  background: #fff; border: 1px solid var(--rp-line, #e5e7eb); border-radius: 12px;
  box-shadow: 0 18px 50px rgba(15, 23, 42, .2); padding: 12px; display: flex; flex-direction: column; gap: 8px;
}
.akh-color__pop-row { display: flex; align-items: center; gap: 10px; }
.akh-color__native { flex: 0 0 auto; width: 38px; height: 38px; border-radius: 9px; overflow: hidden; border: 1px solid var(--rp-line-2, #cbd5e1); cursor: pointer; }
.akh-color__native input { width: 150%; height: 150%; margin: -25%; border: 0; padding: 0; background: none; cursor: pointer; }
.akh-color__alpha { flex: 1 1 auto; display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 8px; }
.akh-color__alpha-label { font-size: 11px; color: #94a3b8; }
.akh-color__alpha input { width: 100%; }
.akh-color__alpha-num { font-size: 11px; color: var(--rp-text, #334155); min-width: 34px; text-align: right; }
.akh-color__pop-label { font-size: 11px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: .04em; }
.akh-color__swatches { display: grid; grid-template-columns: repeat(8, 1fr); gap: 6px; }
.akh-color__chip {
  width: 100%; aspect-ratio: 1; border-radius: 6px; cursor: pointer;
  border: 1px solid rgba(15,23,42,.12); box-shadow: inset 0 0 0 1px rgba(255,255,255,.4);
}
.akh-color__chip:hover { transform: scale(1.12); border-color: #7c3aed; }

.akh-slider {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.akh-slider__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 26px;
}
.akh-slider__title {
  display: inline-flex;
  align-items: center;
  gap: 12px;
  color: var(--rp-text);
  font-size: 14px;
  font-weight: 500;
}
/* Container for the device icon next to a slider title. The actual
 * shape is rendered by the DeviceIcon React component (real SVG that
 * switches between desktop/tablet/mobile). The previous version drew
 * a hard-coded desktop-monitor shape via ::before/::after, which
 * overdrew the SVG so the icon ALWAYS looked like a desktop monitor
 * regardless of the current viewport — now removed. */
.akh-slider__device {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #e600c9;
}
.akh-slider__device svg {
  width: 13px;
  height: 13px;
  display: block;
}
.akh-slider__row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 70px;
  gap: 14px;
  align-items: center;
}
.akh-slider__num {
  height: 30px !important;
  text-align: center;
  font-size: 12px !important;
  padding: 0 6px !important;
  border-radius: 3px !important;
}
.akh-slider__range {
  -webkit-appearance: none;
  appearance: none;
  width: 100%;
  height: 4px;
  background: var(--rp-line);
  border-radius: 999px;
  outline: 0;
  margin: 0;
}
.akh-slider__unit {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}
.akh-slider__unit span {
  min-width: 36px;
  text-align: right;
  color: var(--rp-text-dim);
  font-size: 11px;
}
.akh-slider__unit select {
  width: auto !important;
  min-width: 50px;
  height: 22px !important;
  padding: 0 18px 0 6px !important;
  border-color: transparent !important;
  background-color: transparent !important;
  color: var(--rp-text-dim) !important;
  font-size: 11px !important;
  line-height: 22px !important;
}
.akh-slider__helper {
  margin: 0;
  color: #8a94a6;
  font-size: 12px;
  font-style: italic;
  line-height: 1.35;
}
.akh-slider__range::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 14px;
  height: 14px;
  border-radius: 999px;
  background: #fff;
  border: 1px solid var(--rp-line-2);
  box-shadow: 0 1px 2px rgba(15,23,42,.12);
  cursor: pointer;
}
.akh-slider__range::-moz-range-thumb {
  width: 14px;
  height: 14px;
  border-radius: 999px;
  background: #fff;
  border: 1px solid var(--rp-line-2);
  box-shadow: 0 1px 2px rgba(15,23,42,.12);
  cursor: pointer;
}
.akh-grid-gap__inputs {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 36px;
  border: 1px solid var(--rp-line-2);
  border-radius: 3px;
  overflow: hidden;
  background: #fff;
}
.akh-grid-gap__inputs input {
  height: 32px !important;
  border: 0 !important;
  border-right: 1px solid var(--rp-line-2) !important;
  border-radius: 0 !important;
  text-align: center;
  padding: 0 6px !important;
  font-size: 12px !important;
}
.akh-grid-gap__inputs button {
  appearance: none;
  border: 0;
  background: #d1d5db;
  color: #111827;
  font-size: 12px;
  line-height: 1;
  cursor: pointer;
}
.akh-grid-gap__labels {
  display: grid;
  grid-template-columns: 1fr 1fr 36px;
  margin-top: 4px;
  color: #8a94a6;
  font-size: 11px;
  text-align: center;
}
.akh-switch-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 32px;
  color: var(--rp-text-dim);
  font-size: 14px;
}
.akh-switch-row__title {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex: 1 1 auto;
  min-width: 0;
  /* Keep "Grid Outline" + device icon on one line. */
  white-space: nowrap;
  font-size: 13px;
  font-weight: 500;
  color: var(--rp-text);
}
.akh-switch-row__title i {
  display: inline-flex;
  align-items: center;
  color: #e600c9;
  flex: 0 0 auto;
}
/* ── Page Settings panel (Settings / Style / Advanced) ── */
.akh-pgset { display: flex; flex-direction: column; padding: 14px; }
.akh-pgset__tabs {
  display: flex;
  border-bottom: 1px solid var(--rp-line, #e2e8f0);
  margin-bottom: 12px;
}
.akh-pgset__tabs button {
  flex: 1 1 0;
  appearance: none;
  background: transparent;
  border: 0;
  border-bottom: 2px solid transparent;
  padding: 8px 4px;
  font-size: 12.5px;
  font-weight: 500;
  color: #64748b;
  cursor: pointer;
}
.akh-pgset__tabs button.is-active {
  color: var(--rp-text, #0f172a);
  border-bottom-color: var(--primary, #0f5931);
}
.akh-pgset__saved {
  font-size: 11px;
  color: #0f5931;
  background: #ecfdf5;
  border-radius: 4px;
  padding: 3px 8px;
  margin-bottom: 8px;
  align-self: flex-start;
}
.akh-pgset__body { display: flex; flex-direction: column; gap: 12px; }
.akh-pgset__field { display: flex; flex-direction: column; gap: 5px; }
.akh-pgset__field > span { font-size: 12px; font-weight: 500; color: var(--rp-text, #334155); }
.akh-pgset__field--row { flex-direction: row; align-items: center; justify-content: space-between; }
.akh-pgset__field input,
.akh-pgset__field select,
.akh-pgset__field textarea {
  width: 100%;
  height: 34px;
  padding: 0 10px;
  border: 1px solid var(--rp-line-2, #cbd5e1);
  border-radius: 6px;
  font-size: 13px;
  background: #fff;
  color: var(--rp-text, #0f172a);
  box-sizing: border-box;
}
.akh-pgset__field textarea { height: auto; padding: 8px 10px; resize: vertical; line-height: 1.5; }
.akh-pgset__code { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12px; }
.akh-pgset__dim {
  border: 1px solid var(--rp-line, #e2e8f0);
  border-radius: 8px;
  padding: 10px;
}
.akh-pgset__hint { font-size: 11px; color: #94a3b8; line-height: 1.4; margin: 0; }
.akh-pgset__hint code { background: #f1f5f9; padding: 1px 4px; border-radius: 3px; font-size: 11px; }

.akh-switch {
  display: inline-flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  min-width: 70px;
  height: 28px;
  padding: 0 4px 0 10px;
  border: 0;
  border-radius: 999px;
  background: #e5e7eb;
  color: #64748b;
  font-size: 11px;
  cursor: pointer;
}
.akh-switch.is-on {
  background: #f0abfc;
  color: #7e22ce;
}
.akh-switch i {
  width: 22px;
  height: 22px;
  border-radius: 999px;
  background: #fff;
  box-shadow: 0 1px 2px rgba(15,23,42,.18);
}
.akh-c__slot--grid.akh-c__slot--grid-outline {
  outline: 1px dashed rgba(100, 116, 139, .35);
  outline-offset: -1px;
}
.akh-builder__empty {
  border: 1px dashed #cbd5e1;
  border-radius: 8px;
  padding: 20px;
  background: #f8fafc;
  color: var(--akh-muted);
}
.akh-builder__empty strong,
.akh-builder__empty span {
  display: block;
}
.akh-builder__empty strong {
  color: var(--akh-ink);
  margin-bottom: 6px;
}
.akh-builder .puck {
  --puck-color-azure-09: #0f172a;
}
.akh-builder__panel::-webkit-scrollbar,
.akh-builder__canvas::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
.akh-builder__panel::-webkit-scrollbar-thumb,
.akh-builder__canvas::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 999px;
}
@media (max-width: 1100px) {
  .akh-builder__topbar {
    grid-template-columns: 1fr;
    height: auto;
    padding: 12px;
  }
  .akh-builder__actions,
  .akh-builder__viewport {
    justify-content: flex-start;
  }
  .akh-builder__body {
    grid-template-columns: 260px minmax(0, 1fr);
  }
  .akh-builder__right {
    display: none;
  }
}

/* ─────────────────────────────────────────────────────────────────
 *  ON-CANVAS CONTAINER CHROME — Elementor-style
 *  - Hover: 1px dashed pink outline on the container
 *  - Selected: 1px solid pink outline + centered pink toolbar tab
 *  - Empty content slot: large gray "+" centered inside
 *  Targets Puck's _DraggableComponent-* + _ActionBar_* classes via
 *  attribute selectors so the styling survives puck class-hash bumps.
 * ───────────────────────────────────────────────────────────────── */
.akh-builder {
  --akh-elc-pink:        #d63384;    /* Elementor-ish accent (toolbar) */
  --akh-elc-pink-soft:   #f7d8e6;    /* tab background */
  --akh-elc-pink-dark:   #b02a6d;    /* hover/press */
  --akh-elc-grey:        #cbd5e1;    /* hover dashed */
  --akh-elc-select:      #9da5ae;    /* selected outline (neutral cool grey) */
  --akh-dnd-color:       #f0abfc;    /* Elementor draggable placeholder */
  --akh-dnd-outline:     #10b981;    /* receiving container outline */
}

/* Kill Puck's default overlay hover + selected outlines entirely — we draw
 * our own outlines directly on the component DOM via .akh-is-selected + the
 * scoped nested-Container hover rule below. */
.akh-builder__frame [class*="_DraggableComponent--hover_"] > [class*="_DraggableComponent-overlayWrapper_"] > [class*="_DraggableComponent-overlay_"],
.akh-builder__frame [class*="_DraggableComponent--isSelected_"] > [class*="_DraggableComponent-overlayWrapper_"] > [class*="_DraggableComponent-overlay_"] {
  outline: 0 !important;
  background: transparent !important;
}

/* Hover outline — ONLY on NESTED containers (a Container that has another
 * Container as an ancestor). The outermost / top-level parent container
 * stays chrome-less on hover; only its inner children show the dashed
 * outline when the cursor enters them. */
/* Hover outline — ONLY on NESTED containers (a Container that has another
 * Container as an ancestor). The outermost / top-level parent container
 * stays chrome-less on hover; only its inner children show the dashed
 * outline when the cursor enters them. */
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]) :is([data-puck-component="Container"], [data-puck-component^="Container-"]):hover {
  outline: 1px dashed var(--akh-elc-con-in, #9DA5AE) !important;
  outline-offset: -1px;
}

/* ── DRAG-TIME chrome — ELEMENTOR-STYLE ──
 *
 * Elementor pattern (from editor-preview.css):
 *   1. .e-con.e-dragging-over { outline: 1px solid var(--outline-color) }
 *      → ONLY the receiving container shows a thin solid outline.
 *   2. .elementor-sortable-placeholder { background: var(--e-p-draggable-color);
 *        animation: placeholder-widget 500ms }
 *      → a SOLID colored bar at the exact insertion slot, animated in.
 *   3. Everything else stays at-rest clean. No outlines on other containers,
 *      no blue tint mess on every dropzone.
 *
 * Puck equivalents:
 *   - Receiving container  -> dropzone with _DropZone--isDestination_ class.
 *   - Insertion bar        -> [data-dnd-placeholder] element (the in-flow
 *     stub Puck inserts at the drop position; sized to the dragged item).
 */

/* (1) Kill every Puck blue outline + tint on dropzones during drag. */
.akh-builder__frame [data-puck-entry][data-puck-dragging] [data-puck-dropzone]:not([data-puck-dropzone="root"]),
.akh-builder__frame [data-puck-entry][data-puck-dragging] [class*="_DropZone_"]:not([data-puck-dropzone="root"]) {
  outline: 0 !important;
  background: transparent !important;
}

/* (2) Receiving dropzone -> thin 1px solid emerald outline only.
 *     Mirrors Elementor's e-con/e-dragging-over state. */
.akh-builder__frame [data-puck-entry][data-puck-dragging] [class*="_DropZone--isDestination_"]:not([data-puck-dropzone="root"]) {
  outline: 1px solid var(--akh-dnd-outline) !important;
  outline-offset: -1px !important;
  background: transparent !important;
}

/* (4) Selected container during drag: keep the 2px dark-grey outline.
 *     The destination cue is on the inner dropzone — they don't fight. */
.akh-builder__frame:has([data-puck-entry][data-puck-dragging])
  :is([data-puck-component="Container"], [data-puck-component^="Container-"]).akh-is-selected {
  outline: 2px solid #475569;
  outline-offset: -2px;
}

[data-dnd-dragging][data-puck-component],
[data-dnd-dragging]:has(:is([data-puck-component="Container"], [data-puck-component^="Container-"])) {
  cursor: move !important;
  pointer-events: none !important;
  background: transparent !important;
  outline: 0 !important;
  border: 0 !important;
  box-shadow: none !important;
}
.akh-builder:has([data-dnd-dragging]),
.akh-builder:has([data-dnd-dragging]) *,
body.akh-builder-open:has([data-dnd-dragging]),
body.akh-builder-open:has([data-dnd-dragging]) * {
  cursor: move !important;
}
[data-dnd-dragging][data-puck-component] > *,
[data-dnd-dragging]:has(:is([data-puck-component="Container"], [data-puck-component^="Container-"])) > * {
  opacity: 0 !important;
  visibility: hidden !important;
  pointer-events: none !important;
}
/* Drag preview card — green tile with the dragged element's label + icon.
 * Per-type rules below set --akh-drag-label and --akh-drag-icon; the
 * ::before/::after pseudos read them so we never hardcode "Container". */
[data-dnd-dragging][data-puck-component],
[data-dnd-dragging]:has([data-puck-component]) {
  --akh-drag-label: "Element";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='4' y='4' width='16' height='16' rx='2'/%3E%3C/svg%3E");
}

/* Per-component label + icon. Placed-on-canvas items get a unique id
 * suffix (e.g. "Heading-abc123"), while picker drags use the bare type
 * — match BOTH via ="X" and ^="X-". The :has(...) form covers
 * cases where Puck wraps the component one level deep. Container kept
 * last so a Container holding e.g. a Heading still labels as Container
 * when the outermost wrapper itself is the Container — the exact-match
 * rules above (which match the dragged element directly) win for the
 * inner-component drags. */
[data-dnd-dragging][data-puck-component="Columns"],
[data-dnd-dragging][data-puck-component^="Columns-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Columns"], [data-puck-component^="Columns-"])) {
  --akh-drag-label: "Columns";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='4' width='18' height='16' rx='1'/%3E%3Cpath d='M9 4v16M15 4v16'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="Spacer"],
[data-dnd-dragging][data-puck-component^="Spacer-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Spacer"], [data-puck-component^="Spacer-"])) {
  --akh-drag-label: "Spacer";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M5 12h14M9 8l-4 4 4 4M15 8l4 4-4 4'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="Divider"],
[data-dnd-dragging][data-puck-component^="Divider-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Divider"], [data-puck-component^="Divider-"])) {
  --akh-drag-label: "Divider";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4 12h16'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="Heading"],
[data-dnd-dragging][data-puck-component^="Heading-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Heading"], [data-puck-component^="Heading-"])) {
  --akh-drag-label: "Heading";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M7 5v14M17 5v14M7 12h10'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="Paragraph"],
[data-dnd-dragging][data-puck-component^="Paragraph-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Paragraph"], [data-puck-component^="Paragraph-"])) {
  --akh-drag-label: "Paragraph";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M5 7h14M5 12h14M5 17h9'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="RichText"],
[data-dnd-dragging][data-puck-component^="RichText-"],
[data-dnd-dragging]:has(> :is([data-puck-component="RichText"], [data-puck-component^="RichText-"])) {
  --akh-drag-label: "Rich Text";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M5 6h10M5 12h14M5 18h7'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="Button"],
[data-dnd-dragging][data-puck-component^="Button-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Button"], [data-puck-component^="Button-"])) {
  --akh-drag-label: "Button";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='4' y='8' width='16' height='8' rx='4'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="Image"],
[data-dnd-dragging][data-puck-component^="Image-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Image"], [data-puck-component^="Image-"])) {
  --akh-drag-label: "Image";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='4' y='5' width='16' height='14' rx='1'/%3E%3Cpath d='M8 10a1 1 0 100-2 1 1 0 000 2zM20 16l-4-5-3 4-2-2-3 4'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="EcommerceHero"],
[data-dnd-dragging][data-puck-component^="EcommerceHero-"],
[data-dnd-dragging]:has(> :is([data-puck-component="EcommerceHero"], [data-puck-component^="EcommerceHero-"])) {
  --akh-drag-label: "Ecommerce Hero";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='5' width='18' height='14' rx='1'/%3E%3Cpath d='M3 10h18M7 14h6M7 17h4'/%3E%3C/svg%3E");
}
[data-dnd-dragging][data-puck-component="FeatureCards"],
[data-dnd-dragging][data-puck-component^="FeatureCards-"],
[data-dnd-dragging]:has(> :is([data-puck-component="FeatureCards"], [data-puck-component^="FeatureCards-"])) {
  --akh-drag-label: "Feature Cards";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='6' width='5' height='12' rx='1'/%3E%3Crect x='10' y='6' width='5' height='12' rx='1'/%3E%3Crect x='17' y='6' width='4' height='12' rx='1'/%3E%3C/svg%3E");
}
/* Container last — only paints "Container" when the dragged wrapper IS
 * the container (not when it contains one). The descendant-based rule
 * above (now scoped to direct child) avoids cross-contamination from
 * nested Containers holding other components. */
[data-dnd-dragging][data-puck-component="Container"],
[data-dnd-dragging][data-puck-component^="Container-"],
[data-dnd-dragging]:has(> :is([data-puck-component="Container"], [data-puck-component^="Container-"])) {
  --akh-drag-label: "Container";
  --akh-drag-icon: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='4' y='6' width='16' height='12' rx='1' stroke-dasharray='2 2'/%3E%3C/svg%3E");
}

[data-dnd-dragging][data-puck-component]::before,
[data-dnd-dragging]:has([data-puck-component])::before {
  content: var(--akh-drag-label, "Element");
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  width: 132px;
  height: 96px;
  padding: 0 10px 16px;
  box-sizing: border-box;
  background: linear-gradient(180deg, #10b981 0%, #059669 100%);
  border: 1px solid rgba(255, 255, 255, .42);
  border-radius: 8px;
  box-shadow: 0 10px 20px rgba(5, 150, 105, .28);
  font: 500 12px/1.2 ui-sans-serif, system-ui, sans-serif;
  color: #ffffff;
  letter-spacing: .01em;
  pointer-events: none;
}
[data-dnd-dragging][data-puck-component]::after,
[data-dnd-dragging]:has([data-puck-component])::after {
  content: "";
  position: absolute;
  top: 22px;
  left: 50px;
  z-index: 3;
  width: 32px;
  height: 24px;
  background: var(--akh-drag-icon) no-repeat center / contain;
  pointer-events: none;
}
/* The element-anchored drag card above is REPLACED by AkhDragGhost — a
 * fixed card that follows the cursor (no jump across the drawer→canvas
 * boundary). Neutralize the old ::before/::after card; the dragged
 * element's own content stays hidden via the child-hide rule above. */
[data-dnd-dragging][data-puck-component]::before,
[data-dnd-dragging]:has([data-puck-component])::before,
[data-dnd-dragging][data-puck-component]::after,
[data-dnd-dragging]:has([data-puck-component])::after {
  content: none !important;
  display: none !important;
}
/* Hide Puck's default action toolbar (the pink tab with label + up-arrow
 * + copy + delete). Replaced by a single pencil affordance at the
 * top-right corner of the selected / hovered element (see below).
 * Container has its own ParentContainerToolbar that lives separately. */
.akh-builder__frame [class*="_DraggableComponent-actions_"] {
  display: none !important;
}

/* Pencil edit-affordance — small pink-tinted square at the top-right
 * corner of any selected or hovered non-Container component. Visual
 * cue only; clicking the element body still drives selection. */
.akh-builder__frame [data-puck-component]:not([data-puck-component="Container"]):not([data-puck-component^="Container-"]).akh-is-selected,
.akh-builder__frame [data-puck-component]:not([data-puck-component="Container"]):not([data-puck-component^="Container-"]):hover {
  position: relative;
}
.akh-builder__frame [data-puck-component]:not([data-puck-component="Container"]):not([data-puck-component^="Container-"]).akh-is-selected::after,
.akh-builder__frame [data-puck-component]:not([data-puck-component="Container"]):not([data-puck-component^="Container-"]):hover::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  width: 22px;
  height: 22px;
  background:
    var(--akh-elc-pink-soft)
    url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%234a1530' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 20h9'/%3E%3Cpath d='M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z'/%3E%3C/svg%3E")
    no-repeat center / 13px 13px;
  border: 1px solid var(--akh-elc-pink);
  border-radius: 2px;
  z-index: 5;
  pointer-events: none;
}
/* Selected pencil — stronger tint so it reads against the dark outline. */
.akh-builder__frame [data-puck-component]:not([data-puck-component="Container"]):not([data-puck-component^="Container-"]).akh-is-selected::after {
  background-color: #f4b8d3;
}

/* Container handle — small box icon at top-left corner, click-selects.
 * ONLY rendered on NESTED containers (Container inside another Container).
 * The outermost / top-level parent container does NOT get a corner box —
 * it's the page's outer parent, identified by the toolbar tab instead.
 * Selector uses descendant Container-inside-Container so the rule matches
 * only Containers that have another Container as an ancestor. */
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]) :is([data-puck-component="Container"], [data-puck-component^="Container-"])::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 22px;
  height: 22px;
  background:
    #cbd5e1
    url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 14 14'%3E%3Crect x='2.5' y='3.5' width='9' height='7' fill='none' stroke='%23000000' stroke-width='1' rx='0.5'/%3E%3C/svg%3E")
    no-repeat center / 14px 14px;
  border: 0;
  z-index: 5;
  pointer-events: auto;
  cursor: pointer;
  opacity: 0;
  transition: opacity .1s ease;
}
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]) :is([data-puck-component="Container"], [data-puck-component^="Container-"]):hover::before { opacity: 1; }
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]) :is([data-puck-component="Container"], [data-puck-component^="Container-"]):hover:not(:has(:is([data-puck-component="Container"], [data-puck-component^="Container-"]):hover))::before {
  background-color: #94a3b8;
}
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]) :is([data-puck-component="Container"], [data-puck-component^="Container-"]).akh-is-selected::before {
  opacity: 1;
  background-color: #94a3b8;
}

/* Selected container — 2px dark-grey solid outline; wins over hover. */
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]).akh-is-selected,
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]).akh-is-selected:hover {
  outline: 2px solid #475569 !important;
  outline-offset: -2px !important;
  outline-color: #475569 !important;
}

/* Hide Puck's default toolbar for Containers — replaced by ParentContainerToolbar */
.akh-builder.is-container-selected .akh-builder__frame [class*="_DraggableComponent-actionsOverlay_"] {
  opacity: 0 !important;
  pointer-events: none !important;
}

/* ── ParentContainerToolbar — premium green "tab" stuck to the top edge
 * of the outermost Container. Subtle gradient + sharp shadow gives it
 * depth; trapezoid clip-path keeps the Elementor-tab silhouette. */
.akh-ptbar {
  display: inline-flex !important;
  flex-direction: row !important;
  align-items: stretch;
  gap: 0;
  padding: 0 9px;
  background: linear-gradient(180deg, #10b981 0%, #059669 100%);
  color: #ffffff;
  border: 0;
  border-radius: 0;
  clip-path: polygon(0 0, 100% 0, calc(100% - 9px) 100%, 9px 100%);
  height: 22px;
  font: 600 11px/1 ui-sans-serif, system-ui, sans-serif;
  letter-spacing: .02em;
  user-select: none;
  filter: drop-shadow(0 4px 9px rgba(16, 185, 129, 0.22)) drop-shadow(0 1px 2px rgba(15, 23, 42, 0.16));
}
.akh-ptbar__btn {
  appearance: none;
  background: transparent;
  border: 0;
  padding: 0;
  width: 22px;
  height: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ecfdf5;
  cursor: pointer;
  font: inherit;
  line-height: 1;
  transition: background .12s ease, color .12s ease;
}
.akh-ptbar__btn:hover {
  background: rgba(255, 255, 255, 0.18);
  color: #ffffff;
}
.akh-ptbar__btn:active {
  background: rgba(0, 0, 0, 0.12);
}
.akh-ptbar__btn--danger:hover {
  background: rgba(190, 18, 60, 0.55);
  color: #ffffff;
}
.akh-ptbar__drag {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 100%;
  color: #ecfdf5;
  /* Default: pointer (click = select container). Switches to grabbing while
   * the user is actively pressing — see :active below. */
  cursor: pointer;
  border-left: 1px solid rgba(255, 255, 255, 0.22);
  border-right: 1px solid rgba(255, 255, 255, 0.22);
  transition: background .12s ease, color .12s ease;
}
.akh-ptbar__drag:hover {
  background: rgba(255, 255, 255, 0.18);
  color: #ffffff;
}
.akh-ptbar__drag:active { cursor: move; background: rgba(0, 0, 0, 0.18); }
.akh-ptbar svg { display: block; }
/* During an active Puck drag, make the parent toolbar pointer-transparent
 * so dnd-kit's collision detection sees the dropzone UNDERNEATH the toolbar.
 * Without this, the toolbar's pointer-events: auto + z-index: 9999 would
 * block drops into the area the toolbar visually overlaps with. */
.akh-builder__frame:has([data-puck-entry][data-puck-dragging]) .akh-ptbar {
  pointer-events: none !important;
}
/* Hide the green hover/select frame while dragging — drag has its own
 * emerald destination cue; two frames would fight. */
.akh-builder__frame:has([data-puck-entry][data-puck-dragging]) .akh-ptbar-outline {
  display: none !important;
}

/* Background-only suppression: Puck paints blue-tint backgrounds on the
 * overlay + dropzone during hover/select/drag states which visually blots
 * out the container contents. Kill the BACKGROUNDS only — leave outlines
 * alone so Puck's drop indicators still show, and dnd-kit hit detection
 * stays untouched (it uses element bounds, not paint). */
.akh-builder__frame [class*="_DraggableComponent_"] {
  --overlay-background: transparent;
}
.akh-builder__frame [class*="_DraggableComponent-overlay_"] {
  background: transparent !important;
}
/* Suppress ALL DropZone state backgrounds — resting "area selected",
 * hover-over-area, and destination tints. The user wants the parent
 * container highlighted by border/outline only (no sky-blue fill that
 * blots the contents). Puck's outline cues stay intact so drop targets
 * are still visible. */
.akh-builder__frame [class*="_DropZone--isAreaSelected_"]:not([data-puck-dropzone="root"]),
.akh-builder__frame [class*="_DropZone--hoveringOverArea_"]:not([data-puck-dropzone="root"]),
.akh-builder__frame [class*="_DropZone--isDestination_"]:not([data-puck-dropzone="root"]) {
  background: transparent !important;
}

/* Empty-container dashed outline — visual cue at rest only, drop indicators
 * (outlines on Puck's drop modifier classes) stay as Puck's defaults. */
.akh-builder__frame [class*="_DropZone_"]:not([data-puck-dropzone="root"]):empty {
  outline: 1px dashed #cbd5e1 !important;
  outline-offset: -1px !important;
}

/* Empty Container content slot — also gives a minimum drop area + the
 * dashed outline so the empty inside is obviously droppable. Horizontal-only:
 * let the EMPTY drop area span the full container (override the inline boxed/
 * width maxWidth cap) so the dashed border sits one padding-width from the
 * edge — same gap for px, %, any unit. Does NOT touch height/min-height. */
.akh-builder__frame :is([data-puck-component="Container"], [data-puck-component^="Container-"]) [data-puck-dropzone]:not([data-puck-dropzone="root"]):empty {
  position: relative;
  min-height: 100px;
  max-width: 100% !important;
  outline: 1px dashed #cbd5e1 !important;
  outline-offset: -1px;
}

/* ── DRAG-TIME: aggressively expand drop hit zones.
 *
 * Two layers of padding to give the user a wide ring around each child
 * container where they can land a drop on the parent slot:
 *
 *  1. Section.akh-c padding (the container's outer 10px ring) → 40px during
 *     drag. Cursor lands here = parent's WRAPPER, falls through to parent
 *     slot for drop targeting.
 *  2. Slot.akh-c__slot padding (between children inside the slot) → 40px
 *     during drag. Cursor in this band = slot is deepest hit-target.
 *
 * Puck contracts hit zones by 6px on each side (BUFFER in chunk
 * PK2F2YZX.mjs:3199). With 40px padding, that leaves ~28px usable per side,
 * which is reliably hittable.
 *
 * Visualized with a faint pink tint so the user can SEE where the drop area
 * is during drag. Only applies while [data-puck-dragging] is on the document. */
/* DRAG-TIME visual: keep the canvas STABLE during drag. No padding tweaks
 * or background tints that would shift layout. Just keep things visually
 * identical to the at-rest hover state. */
.akh-builder__frame:has([data-puck-entry][data-puck-dragging]) :is([data-puck-component="Container"], [data-puck-component^="Container-"]) > .akh-c {
  background: transparent !important;
  transition: none !important;
}
.akh-builder__frame:has([data-puck-entry][data-puck-dragging])
  :is([data-puck-component="Container"], [data-puck-component^="Container-"]) > .akh-c > [data-puck-dropzone]:not([data-puck-dropzone="root"]) {
  box-sizing: border-box !important;
  margin: -12px !important;
  padding: 12px !important;
  background: transparent !important;
  transition: none !important;
}
.akh-builder__frame:has([data-puck-entry][data-puck-dragging])
  :is([data-puck-component="Container"], [data-puck-component^="Container-"]) > .akh-c > [data-puck-dropzone]:not([data-puck-dropzone="root"]):not(:empty) {
  outline-offset: -12px !important;
}

/* Row-direction children: independent vertical sizing + equal-share
 * horizontal split.
 *
 * 1. align-self: flex-start — default align-items: stretch would force
 *    every sibling to the tallest one's height, so a tall empty
 *    container next to a short heading-only container made BOTH look
 *    tall. flex-start sizes each child to its own content.
 *
 * 2. flex: 1 1 0 — without this, row children with empty or tiny
 *    content collapsed to 0 width and disappeared. flex:1 1 0 makes
 *    every row child claim an equal share of the parent's width:
 *    2 children → 50/50, 3 → 33.33% each, 4 → 25% each. min-width:0
 *    is required so text inside doesn't force a floor.
 *
 * 3. User-set explicit width per child still wins — Container.render's
 *    useIsoLayoutEffect pushes inline width + flex-grow:0 onto the
 *    wrapper, and inline styles beat these CSS defaults.
 *
 * Only applies to ROW slots; column/grid keep stretch + own width
 * forcing (handled by the rules further below). */
.akh-c__slot--dir-row > [data-puck-component],
.akh-c__slot--dir-row-reverse > [data-puck-component] {
  align-self: flex-start;
  flex: 1 1 0;
  min-width: 0;
}

/* Child width stretch when parent slot is column or grid.
 * Puck wraps each rendered component in a [data-puck-component]
 * DraggableComponent. That wrapper sizes to content, so flex children
 * shrink even when the parent slot has align-items: stretch. Without
 * these rules, switching a Container direction to column makes its
 * child Containers squeeze to the width of their inner text. Row
 * direction is left untouched so multi-column layouts keep
 * content-sized children. */
.akh-c__slot--dir-column > [data-puck-component],
.akh-c__slot--dir-column-reverse > [data-puck-component],
.akh-c__slot--grid > [data-puck-component] {
  width: 100%;
  max-width: 100%;
  min-width: 0;
}
.akh-c__slot--dir-column > [data-puck-component] > .akh-c,
.akh-c__slot--dir-column-reverse > [data-puck-component] > .akh-c,
.akh-c__slot--grid > [data-puck-component] > .akh-c {
  width: 100%;
  box-sizing: border-box;
}
/* Direct .akh-c children of column/grid slots (the public render path
 * has no DraggableComponent wrapper between the slot and the section). */
.akh-c__slot--dir-column > .akh-c,
.akh-c__slot--dir-column-reverse > .akh-c,
.akh-c__slot--grid > .akh-c {
  width: 100%;
  box-sizing: border-box;
}

/* ── Mobile-default auto-stack (Elementor parity) ──
 * On mobile viewport, row-direction slots auto-wrap their children to
 * full width (each child takes its own row). Users who want a child to
 * stay narrow on mobile must explicitly set widthMobile — the Container
 * render tags wrappers with data-akh-mw="set" whenever the user has
 * a non-empty widthMobile, and that attribute exempts the wrapper from
 * these default-stretch rules so the user explicit mobile width wins.
 *
 * Both editor (data-viewport="mobile") and frontend (@media) get the
 * same treatment so the preview matches the published page. */
.akh-builder__frame[data-viewport="mobile"] :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) {
  flex-wrap: wrap !important;
}
.akh-builder__frame[data-viewport="mobile"] :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) > [data-puck-component]:not([data-akh-mw="set"]) {
  width: 100% !important;
  flex: 1 1 100% !important;
  max-width: 100% !important;
  min-width: 0;
  margin-left: 0 !important;
  margin-right: 0 !important;
}
.akh-builder__frame[data-viewport="mobile"] :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) > [data-puck-component]:not([data-akh-mw="set"]) > .akh-c,
.akh-builder__frame[data-viewport="mobile"] :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) > .akh-c:not([data-akh-mw="set"]) {
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box;
}
/* BROAD mobile auto-stack — EVERY Container (top-level / stacked / grid /
 * row), not just row children, goes full-width on mobile, overriding the
 * desktop-width cascade. Columns in a manual mobile-row carry an explicit
 * widthMobile (data-akh-mw="set") and stay exempt so they keep sharing. */
.akh-builder__frame[data-viewport="mobile"] :is([data-puck-component="Container"], [data-puck-component^="Container-"]):not([data-akh-mw="set"]) {
  width: 100% !important;
  max-width: 100% !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
}
.akh-builder__frame[data-viewport="mobile"] :is([data-puck-component="Container"], [data-puck-component^="Container-"]):not([data-akh-mw="set"]) > .akh-c {
  width: 100% !important;
  max-width: 100% !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
}
.akh-builder__frame[data-viewport="mobile"] .akh-c__slot--mobile-row-explicit {
  flex-wrap: nowrap !important;
}
.akh-builder__frame[data-viewport="mobile"] .akh-c__slot--mobile-row-explicit > [data-puck-component]:not([data-akh-mw="set"]) {
  width: auto !important;
  flex: 1 1 0 !important;
  max-width: 100% !important;
  min-width: 0;
  margin-left: 0 !important;
  margin-right: 0 !important;
}
.akh-builder__frame[data-viewport="mobile"] .akh-c__slot--mobile-row-explicit > [data-puck-component]:not([data-akh-mw="set"]) > .akh-c {
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box;
}
@media (max-width: 767px) {
  :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) {
    flex-wrap: wrap !important;
  }
  :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) > [data-puck-component]:not([data-akh-mw="set"]) {
    width: 100% !important;
    flex: 1 1 100% !important;
    max-width: 100% !important;
    min-width: 0;
    margin-left: 0 !important;
    margin-right: 0 !important;
  }
  :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) > [data-puck-component]:not([data-akh-mw="set"]) > .akh-c,
  :is(.akh-c__slot--dir-row, .akh-c__slot--dir-row-reverse):not(.akh-c__slot--mobile-row-explicit) > .akh-c:not([data-akh-mw="set"]) {
    width: 100% !important;
    max-width: 100% !important;
    box-sizing: border-box;
  }
  /* Broad: every container full-width on mobile (frontend has no Puck wrapper
   * — the section IS the flex item and carries data-akh-mw). Explicit mobile
   * width stays exempt. */
  .akh-c:not([data-akh-mw="set"]) {
    width: 100% !important;
    max-width: 100% !important;
    margin-left: 0 !important;
    margin-right: 0 !important;
  }
  .akh-c__slot--mobile-row-explicit {
    flex-wrap: nowrap !important;
  }
  .akh-c__slot--mobile-row-explicit > [data-puck-component]:not([data-akh-mw="set"]) {
    width: auto !important;
    flex: 1 1 0 !important;
    max-width: 100% !important;
    min-width: 0;
    margin-left: 0 !important;
    margin-right: 0 !important;
  }
  .akh-c__slot--mobile-row-explicit > [data-puck-component]:not([data-akh-mw="set"]) > .akh-c,
  .akh-c__slot--mobile-row-explicit > .akh-c:not([data-akh-mw="set"]) {
    width: 100% !important;
    max-width: 100% !important;
    flex: 1 1 0 !important;
    min-width: 0;
    box-sizing: border-box;
  }
}

/* The "+" button rendered by Container.render when puck.isEditing.
 * Hidden by default; CSS :has() shows it ONLY when the container's content
 * dropzone is empty (no other rendered children). */
.akh-c__add {
  display: none;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 42px;
  height: 42px;
  border: 0;
  border-radius: 999px;
  background: #f1f5f9;
  color: #64748b;
  font: 300 28px/1 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  cursor: pointer;
  padding: 0;
  z-index: 2;
  pointer-events: auto;
  transition: background .12s ease, color .12s ease, transform .12s ease;
}
.akh-c__add:hover {
  background: #e2e8f0;
  color: #334155;
  transform: translate(-50%, -50%) scale(1.05);
}
/* Show "+" only when the container has an empty content dropzone */
.akh-builder__frame [data-puck-component="Container"]:has([data-puck-dropzone]:empty) .akh-c__add {
  display: flex;
  align-items: center;
  justify-content: center;
}

/* All custom drag-drop CSS overrides removed.
 *
 * Puck's native drag-drop now runs untouched:
 *   - dnd-kit handles collision/hit detection with its own logic
 *   - Puck's default outlines (_DropZone--isDestination_, --isAreaSelected_,
 *     --hoveringOverArea_, --hover_) draw their normal blue chrome
 *   - No layout mutations during drag, no extra outlines, no synthetic
 *     pointer events from our toolbar drag handle
 *
 * Only kept: the EMPTY-state dashed outline so users can see drop targets
 * at rest, and our selection outline (.akh-is-selected, 2px dark grey). */
`;
