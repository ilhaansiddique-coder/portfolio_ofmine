import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { parseCities } from "@/lib/shipping-zone";
import ShippingClient from "./ShippingClient";

export const dynamic = "force-dynamic";

export default async function ShippingPage() {
  const { prisma } = await getPrismaForRequest();
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/cdlogin");

  try {
    const data = await prisma.shippingZone.findMany({
      orderBy: { id: "asc" },
    });

    const items = data.map((z) => ({
      id: z.id,
      name: z.name,
      cities: parseCities(z.cities),
      rate: Number(z.rate),
      estimated_days: z.estimatedDays ?? "",
      is_active: z.isActive,
    }));

    return <ShippingClient initialData={{ items }} />;
  } catch {
    return <ShippingClient initialData={{ items: [] }} />;
  }
}
