"use client";

import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { api } from "@/lib/api";
import DashboardLayout from "@/components/DashboardLayout";
import ConfirmDialog from "@/components/ConfirmDialog";
import Modal from "@/components/Modal";
import Toast from "@/components/Toast";
import { useLang } from "@/lib/LanguageContext";
import { SafeImg } from "@/components/SafeImage";
import MediaGallery from "@/components/MediaGallery";
import { theme } from "@/lib/theme";

import { useAutoSlug } from "@/lib/useAutoSlug";
import {
  FiPlus, FiEdit2, FiTrash2, FiEye, FiEyeOff, FiX,
  FiChevronDown, FiChevronUp, FiSearch, FiMove,
} from "react-icons/fi";
import { TableSkeleton } from "@/components/DashboardSkeleton";
import {
  DndContext, closestCenter, PointerSensor, useSensor, useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext, arrayMove, useSortable, verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

/* ───── drag-reorderable section-order panel ───── */
const SECTION_META: Record<string, { icon: string; label: string }> = {
  hero: { icon: "🎯", label: "Hero Section" },
  problem: { icon: "⚠️", label: "Problem Section" },
  products: { icon: "📦", label: "Products" },
  features: { icon: "✨", label: "Features / Benefits" },
  how_it_works: { icon: "🔢", label: "How It Works" },
  testimonials: { icon: "💬", label: "Testimonials" },
  faq: { icon: "❓", label: "FAQ" },
  checkout: { icon: "🎉", label: "Checkout & Thank You" },
};

function SortableSectionRow({
  id, visible, onToggleVisible,
}: {
  id: string;
  visible: boolean;
  onToggleVisible: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  const meta = SECTION_META[id] || { icon: "📄", label: id };
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.6 : 1,
    zIndex: isDragging ? 10 : undefined,
  };
  const pinned = id === "checkout";
  return (
    <div ref={setNodeRef} style={style}
      className={`flex items-center gap-2 rounded-lg border bg-white px-3 py-2 ${isDragging ? "border-[var(--primary)] shadow-md" : "border-gray-200"} ${visible ? "" : "opacity-60"}`}>
      <button type="button" {...attributes} {...listeners}
        className="cursor-grab active:cursor-grabbing touch-none text-gray-400 hover:text-gray-700" title="Drag to reorder" aria-label="Drag to reorder">
        <FiMove className="w-4 h-4" />
      </button>
      <span className="text-sm">{meta.icon}</span>
      <span className={`flex-1 text-sm font-medium ${visible ? "text-gray-700" : "text-gray-400 line-through"}`}>
        {meta.label}
        {pinned && <span className="ml-1.5 text-[10px] font-normal text-gray-400">(always last on page)</span>}
      </span>
      <button type="button" onClick={onToggleVisible}
        className={`p-1 transition-colors ${visible ? "text-green-500 hover:text-green-700" : "text-red-400 hover:text-red-600"}`}
        title={visible ? "Hide section" : "Show section"}>
        {visible ? <FiEye className="w-4 h-4" /> : <FiEyeOff className="w-4 h-4" />}
      </button>
    </div>
  );
}

function SectionOrderPanel({
  order, visibility, onReorder, onToggleVisible,
}: {
  order: string[];
  visibility: Record<string, boolean>;
  onReorder: (next: string[]) => void;
  onToggleVisible: (key: string) => void;
}) {
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));
  function handleDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const from = order.indexOf(String(active.id));
    const to = order.indexOf(String(over.id));
    if (from < 0 || to < 0) return;
    onReorder(arrayMove(order, from, to));
  }
  return (
    <div className="rounded-xl border border-gray-200 bg-gray-50/60 p-3">
      <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-gray-700">
        <FiMove className="w-4 h-4 text-[var(--primary)]" /> Section order
      </div>
      <p className="mb-3 text-xs text-gray-500">Drag to reorder how sections appear on the landing page. Use the eye to show/hide. (Applies to the default template.)</p>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={order} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {order.map((key) => (
              <SortableSectionRow key={key} id={key}
                visible={visibility[key] !== false}
                onToggleVisible={() => onToggleVisible(key)} />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  );
}

const inputCls = theme.input;
const labelCls = theme.label;

/* ───── types ───── */
interface LandingPage {
  id: number;
  slug: string;
  title: string;
  is_active: boolean;
  root_redirect?: boolean;
  primary_color: string;
  hero_headline: string;
  hero_subheadline: string;
  hero_image: string;
  hero_video_autoplay?: boolean;
  hero_cta: string;
  hero_trust_text: string;
  hero_badge: string;
  problem_title: string;
  problem_points: string;
  features: string;
  testimonials: string;
  how_it_works: string;
  faq: string;
  products: string;
  products_title: string;
  products_subtitle: string;
  features_title: string;
  features_image: string;
  testimonials_title: string;
  testimonials_mode: string; // "all_site" | "select" | "custom"
  how_it_works_title: string;
  how_it_works_subtitle: string;
  faq_title: string;
  checkout_title: string;
  checkout_subtitle: string;
  checkout_btn_text: string;
  shipping_cost: string;
  custom_shipping: boolean;
  show_email: boolean;
  show_city: boolean;
  guarantee_text: string;
  success_message: string;
  meta_title: string;
  meta_description: string;
  whatsapp: string;
  contact_mode?: string;
  section_visibility: Record<string, boolean>;
  section_order: string[];
  template?: "default" | "akbd" | "ayurex";
  template_data?: Record<string, unknown> | string | null;
}

interface ProductOption {
  id: number;
  name: string;
  price: number;
  image?: string;
}

interface ProductEntry { product_id: number; quantity: number }
interface FeatureEntry { icon: string; title: string; description: string }
interface ProblemEntry { text: string; icon: string }
interface TestimonialEntry { name: string; review: string; rating: number; image?: string }
interface StepEntry { title: string; description: string }
interface FaqEntry { question: string; answer: string }

/* ───── empty form ───── */
const emptyForm = {
  title: "",
  slug: "",
  is_active: true,
  // When true, this LP is the base-URL redirect target for storefront-disabled
  // tenants (root domain → this LP). Only one LP can hold it at a time.
  root_redirect: false,
  primary_color: "#0f5931",
  hero_headline: "",
  hero_subheadline: "",
  hero_image: "",
  hero_video_autoplay: false,
  hero_cta: "",
  hero_trust_text: "",
  hero_badge: "",
  problem_title: "",
  problem_points: [] as ProblemEntry[],
  features: [] as FeatureEntry[],
  testimonials: [] as TestimonialEntry[],
  how_it_works: [] as StepEntry[],
  faq: [] as FaqEntry[],
  products: [] as ProductEntry[],
  products_title: "",
  products_subtitle: "",
  features_title: "",
  features_image: "",
  testimonials_title: "",
  testimonials_mode: "custom",
  how_it_works_title: "",
  how_it_works_subtitle: "",
  faq_title: "",
  checkout_title: "",
  checkout_subtitle: "",
  checkout_btn_text: "",
  shipping_cost: "60",
  custom_shipping: false,
  show_email: false,
  show_city: true,
  guarantee_text: "",
  success_message: "",
  meta_title: "",
  meta_description: "",
  whatsapp: "",
  contact_mode: "inherit",
  section_visibility: { hero: true, problem: true, products: true, features: true, how_it_works: true, testimonials: true, faq: true, checkout: true } as Record<string, boolean>,
  // Display order of the standard sections (drag-reorderable). Checkout is kept
  // in the list but pinned last on the frontend as the conversion anchor.
  section_order: ["hero", "problem", "products", "features", "how_it_works", "testimonials", "faq", "checkout"],
  // Visual template — picked via a chooser before the form opens.
  template: "default" as "default" | "akbd" | "ayurex",
  // Akbd-only template data. Empty strings/arrays for the default template.
  td_doctor_photo: "",
  td_doctor_name: "",
  td_doctor_credentials: [] as string[],
  td_doctor_reg_number: "",
  td_doctor_role: "",
  td_chamber_heading: "",
  td_chamber_address_lines: [] as string[],
  td_faq_heading: "",
  td_stats: [
    { label: "অভিজ্ঞতা", value: 10, suffix: " বছর+" },
    { label: "রোগী", value: 8000, suffix: "+" },
    { label: "প্রতিষ্টান", value: 3, suffix: "+" },
    { label: "সুস্থতার হার", value: 90, suffix: " শতাংশ +" },
  ] as Array<{ label: string; value: number; suffix: string }>,
  // Ayurex template content. Empty strings → the template's built-in default
  // copy renders, so a blank field never blanks the page. Saved into the
  // template_data JSON column (only when template === "ayurex").
  ayx: {} as Record<string, string>,
};

// Ayurex editable text blocks — drives both the dashboard editor and the
// template_data payload. label = dashboard caption, multiline = textarea.
const AYX_FIELDS: { key: string; label: string; multiline?: boolean }[] = [
  { key: "challenge_heading", label: "Challenge heading" },
  { key: "claim_text", label: "Claim block", multiline: true },
  { key: "social_text", label: "Social proof line", multiline: true },
  { key: "usage_text", label: "Usage instructions", multiline: true },
  { key: "positioning_text", label: "Positioning line", multiline: true },
  { key: "aspirational_text", label: "Aspirational line", multiline: true },
  { key: "herbal_note", label: "Herbal / consult note", multiline: true },
  { key: "teaser_text", label: "80+ ingredient teaser", multiline: true },
  { key: "sub_heading", label: "Sub heading" },
  { key: "brand_line", label: "Brand line" },
  { key: "strength_text", label: "Strength block", multiline: true },
  { key: "romantic_heading", label: "Ingredients section heading" },
  { key: "ingredient_intro", label: "Ingredient intro line", multiline: true },
  { key: "usage_safety_text", label: "Usage / safety note", multiline: true },
  { key: "course_text", label: "Course line", multiline: true },
  { key: "delivery_fee_text", label: "Delivery fee line" },
  { key: "hekim_text", label: "Hekim call-back note", multiline: true },
  { key: "notice_text", label: "Notice line" },
  { key: "form_intro_text", label: "Form intro (above the form)", multiline: true },
  { key: "closing_text_1", label: "Closing line 1", multiline: true },
  { key: "closing_text_2", label: "Closing line 2", multiline: true },
  { key: "commitment_text", label: "Commitment line", multiline: true },
  { key: "order_btn_text", label: "Final order button text" },
];

type FormState = typeof emptyForm;

/* ───── collapsible section ───── */
function Section({
  title,
  icon,
  open,
  onToggle,
  visible,
  onVisibilityToggle,
  children,
}: {
  title: string;
  icon: string;
  open: boolean;
  onToggle: () => void;
  visible?: boolean;
  onVisibilityToggle?: () => void;
  children: React.ReactNode;
}) {
  const isHidden = visible === false;
  return (
    <div className={`border rounded-xl transition-opacity ${isHidden ? "border-red-200 opacity-60" : "border-gray-100"}`}>
      <div className="flex items-center bg-gray-50 hover:bg-gray-100 transition-colors rounded-t-xl">
        <button type="button" onClick={onToggle} className="flex-1 flex items-center justify-between px-4 py-3">
          <span className={`flex items-center gap-2 text-sm font-semibold ${isHidden ? "text-gray-400 line-through" : "text-gray-700"}`}>
            {icon} {title}
            {isHidden && <span className="text-[10px] text-red-400 font-normal no-underline ml-1">(hidden)</span>}
          </span>
          {open ? <FiChevronUp /> : <FiChevronDown />}
        </button>
        {onVisibilityToggle && (
          <button type="button" onClick={onVisibilityToggle} className={`px-3 py-3 transition-colors ${isHidden ? "text-red-400 hover:text-red-600" : "text-green-500 hover:text-green-700"}`}
            title={isHidden ? "Show section" : "Hide section"}>
            {isHidden ? <FiEyeOff className="w-4 h-4" /> : <FiEye className="w-4 h-4" />}
          </button>
        )}
      </div>
      {open && <div className="p-4 space-y-3">{children}</div>}
    </div>
  );
}

/* ───── main page ───── */
interface InitialData { items: LandingPage[] }

export default function LandingPagesClient({ initialData }: { initialData?: InitialData }) {
  const { t } = useLang();
  const generateSlug = useAutoSlug();

  const [items, setItems] = useState<LandingPage[]>(initialData?.items ?? []);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");

  const [modalOpen, setModalOpen] = useState(false);
  // Template picker — shown after clicking "+ Add" and before the form modal.
  const [pickerOpen, setPickerOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [galleryTarget, setGalleryTarget] = useState<string>("hero"); // "hero", "testimonial-{idx}", "problem-{idx}"
  const [siteReviews, setSiteReviews] = useState<TestimonialEntry[]>([]);
  const [siteReviewsLoaded, setSiteReviewsLoaded] = useState(false);

  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [toast, setToast] = useState({ message: "", type: "success" as "success" | "error" });
  const showToast = (message: string, type: "success" | "error" = "success") =>
    setToast({ message, type });

  // Collapsible sections
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const toggle = (key: string) => setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  const isOpen = (key: string) => !!expanded[key];
  const toggleVis = (key: string) => setForm((f) => ({
    ...f,
    section_visibility: { ...f.section_visibility, [key]: f.section_visibility[key] === false ? true : false },
  }));

  const reorderSections = (next: string[]) => setForm((f) => ({ ...f, section_order: next }));

  // Products picker
  const [allProducts, setAllProducts] = useState<ProductOption[]>([]);
  const [productSearch, setProductSearch] = useState("");

  /* ───── data fetching ───── */
  const fetchAll = useCallback((background = false) => {
    if (!background) setLoading(true);
    api.admin
      .getLandingPages()
      .then((res: { data?: LandingPage[] }) => setItems(res.data || (res as unknown as LandingPage[]) || []))
      .catch(() => {
        if (!background) showToast(t("landingPages.loadError"), "error");
      })
      .finally(() => setLoading(false));
  }, []);

  /* ───── helpers ───── */
  const safeParseJson = <T,>(val: string | T[] | undefined | null, fallback: T[]): T[] => {
    if (Array.isArray(val)) return val;
    if (!val) return fallback;
    try {
      return JSON.parse(val as string);
    } catch {
      return fallback;
    }
  };

  const countProducts = (item: LandingPage): number => {
    return safeParseJson<ProductEntry>(item.products, []).length;
  };

  /* ───── open create / edit ───── */
  // Picker is the gate between "+ Add" and the actual form: clicking Add now
  // shows two cards (Default + Akbd). Picking one closes the picker, sets the
  // template on the empty form, and opens the form modal.
  const openCreate = () => {
    setEditId(null);
    setForm(emptyForm);
    setExpanded({});
    setPickerOpen(true);
    fetchProducts();
  };

  const pickTemplate = (tpl: "default" | "akbd" | "ayurex") => {
    // Two modes:
    //  - Create flow (no editId): reset form to emptyForm + chosen template.
    //  - Edit flow (editId set):  swap template only, keep every other field
    //    so the user doesn't lose content when switching templates.
    if (editId) {
      setForm((f) => ({
        ...f,
        template: tpl,
        // akbd renders only image-based testimonials — flip mode so the form
        // shows the right input set, but DON'T wipe the testimonials array.
        testimonials_mode: tpl === "akbd" ? "custom" : f.testimonials_mode,
      }));
    } else {
      setForm({
        ...emptyForm,
        template: tpl,
        testimonials_mode: tpl === "akbd" ? "custom" : emptyForm.testimonials_mode,
      });
    }
    setPickerOpen(false);
    setModalOpen(true);
  };

  const openEdit = async (passed: LandingPage) => {
    // Refetch fresh from /admin/landing-pages/[id] before populating the form.
    // The cached `items[]` list may have been loaded by the dev server before
    // the template / template_data columns were added, in which case those
    // fields are missing from the cached row but the single-row endpoint's
    // raw-SQL fallback always returns them. Falls back to the cached row if
    // the refetch fails for any reason (network blip, auth quirk).
    let item = passed;
    try {
      const fresh = await api.admin.getLandingPage(passed.id);
      if (fresh && (fresh.data ?? fresh)) item = (fresh.data ?? fresh) as LandingPage;
    } catch { /* keep the cached row */ }
    setEditId(item.id);
    setForm({
      title: item.title || "",
      slug: item.slug || "",
      is_active: item.is_active,
      root_redirect: !!item.root_redirect,
      // Must be a real hex literal — `<input type="color">` rejects CSS
      // tokens like "var(--primary)" with a runtime warning. Normalize stale
      // values from older DB rows into the system default.
      primary_color: (item.primary_color && /^#[0-9a-fA-F]{6}$/.test(item.primary_color)) ? item.primary_color : "#0f5931",
      hero_headline: item.hero_headline || "",
      hero_subheadline: item.hero_subheadline || "",
      hero_image: item.hero_image || "",
      hero_video_autoplay: !!item.hero_video_autoplay,
      hero_cta: item.hero_cta || "",
      hero_trust_text: item.hero_trust_text || "",
      hero_badge: item.hero_badge || "",
      problem_title: item.problem_title || "",
      problem_points: (() => {
        const raw = safeParseJson<any>(item.problem_points, []);
        return raw.map((p: any) => typeof p === "string" ? { text: p, icon: "" } : { text: p.text || "", icon: p.icon || "" });
      })(),
      features: safeParseJson<FeatureEntry>(item.features, []),
      testimonials: safeParseJson<TestimonialEntry>(item.testimonials, []),
      how_it_works: safeParseJson<StepEntry>(item.how_it_works, []),
      faq: safeParseJson<FaqEntry>(item.faq, []),
      products: safeParseJson<ProductEntry>(item.products, []),
      products_title: item.products_title || "",
      products_subtitle: item.products_subtitle || (item as any).products_sub || "",
      features_title: item.features_title || "",
      features_image: item.features_image || "",
      testimonials_title: item.testimonials_title || "",
      testimonials_mode: item.testimonials_mode || "custom",
      how_it_works_title: item.how_it_works_title || "",
      how_it_works_subtitle: item.how_it_works_subtitle || (item as any).how_it_works_sub || "",
      faq_title: item.faq_title || "",
      checkout_title: item.checkout_title || "",
      checkout_subtitle: item.checkout_subtitle || "",
      checkout_btn_text: item.checkout_btn_text || "",
      shipping_cost: String(item.shipping_cost ?? 60),
      custom_shipping: item.custom_shipping ?? false,
      show_email: item.show_email ?? false,
      show_city: item.show_city ?? true,
      guarantee_text: item.guarantee_text || "",
      success_message: item.success_message || "",
      meta_title: item.meta_title || "",
      meta_description: item.meta_description || "",
      whatsapp: item.whatsapp || "",
      contact_mode: item.contact_mode || "inherit",
      section_visibility: (() => {
        try { return JSON.parse(String(item.section_visibility || "{}")); } catch { return {}; }
      })(),
      // Saved drag order; merge with the default so any newly-added section
      // still shows even if the saved order predates it.
      section_order: (() => {
        const DEF = ["hero", "problem", "products", "features", "how_it_works", "testimonials", "faq", "checkout"];
        const raw = item.section_order;
        const saved = Array.isArray(raw) ? raw.filter((k): k is string => typeof k === "string" && DEF.includes(k)) : [];
        return [...saved, ...DEF.filter((k) => !saved.includes(k))];
      })(),
      // Template + template_data — read back so the editor renders the right
      // template-specific fields. template_data arrives as a parsed object
      // (or a JSON string in older data); handle both.
      // Heuristic fallback: if the API didn't return `template` (e.g. dev
      // server has a stale Prisma client from before the column was added),
      // infer akbd from the presence of doctor/chamber fields in template_data.
      template: (() => {
        const apiTemplate = (item as any).template;
        if (apiTemplate === "akbd" || apiTemplate === "default" || apiTemplate === "ayurex") return apiTemplate;
        const td = (item as any).template_data;
        const obj = typeof td === "string"
          ? (() => { try { return JSON.parse(td); } catch { return {}; } })()
          : (td || {});
        if (obj && (obj.doctor_name || obj.doctor_photo || obj.chamber_address_lines)) {
          // eslint-disable-next-line no-console
          console.warn(`[LandingPages] template field missing for "${item.slug}", inferring "akbd" from template_data. Restart dev server to refresh Prisma client.`);
          return "akbd";
        }
        return "default";
      })(),
      td_doctor_photo: (() => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return obj.doctor_photo || "";
      })(),
      td_doctor_name: ((): string => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return obj.doctor_name || "";
      })(),
      td_doctor_credentials: ((): string[] => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return Array.isArray(obj.doctor_credentials) ? obj.doctor_credentials : [];
      })(),
      td_doctor_reg_number: ((): string => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return obj.doctor_reg_number || "";
      })(),
      td_doctor_role: ((): string => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return obj.doctor_role || "";
      })(),
      td_chamber_heading: ((): string => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return obj.chamber_heading || "";
      })(),
      td_chamber_address_lines: ((): string[] => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return Array.isArray(obj.chamber_address_lines) ? obj.chamber_address_lines : [];
      })(),
      td_faq_heading: ((): string => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return obj.faq_heading || "";
      })(),
      td_stats: ((): Array<{ label: string; value: number; suffix: string }> => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        return Array.isArray(obj.stats) && obj.stats.length > 0 ? obj.stats : emptyForm.td_stats;
      })(),
      // Ayurex: hydrate the editable text overrides from template_data.
      ayx: ((): Record<string, string> => {
        const td = (item as any).template_data;
        const obj = typeof td === "string" ? (() => { try { return JSON.parse(td); } catch { return {}; } })() : (td || {});
        const out: Record<string, string> = {};
        for (const f of AYX_FIELDS) if (typeof obj[f.key] === "string") out[f.key] = obj[f.key];
        return out;
      })(),
    });
    setExpanded({});
    setModalOpen(true);
    fetchProducts();
  };

  const fetchProducts = () => {
    api.admin
      .getProducts("per_page=200")
      .then((res: { data?: Record<string, unknown>[] }) => {
        const data = res.data || (res as unknown as Record<string, unknown>[]) || [];
        setAllProducts(
          Array.isArray(data)
            ? data.map((p) => ({
                id: p.id as number,
                name: (p.name as string) || "",
                price: Number(p.price) || 0,
                image: (p.image as string) || "",
              }))
            : []
        );
      })
      .catch(() => {});
  };

  /* ───── title -> slug ───── */
  const handleTitleChange = (val: string) => {
    setForm((prev) => ({ ...prev, title: val }));
    if (!editId) {
      generateSlug(val, (slug: string) => setForm((prev) => ({ ...prev, slug })));
    }
  };

  /* ───── image upload ───── */
  const handleImageUpload = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      showToast("Invalid image", "error");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      showToast("Image too large", "error");
      return;
    }
    setUploading(true);
    try {
      const res = await api.admin.upload(file);
      setForm((prev) => ({ ...prev, hero_image: res.url || res.path }));
      showToast("Image uploaded");
    } catch {
      showToast("Upload failed", "error");
    } finally {
      setUploading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImageUpload(file);
    e.target.value = "";
  };

  /* ───── product picker helpers ───── */
  const addProduct = (product: ProductOption) => {
    if (form.products.some((p) => p.product_id === product.id)) {
      showToast("Already added", "error");
      return;
    }
    setForm((prev) => ({
      ...prev,
      products: [...prev.products, { product_id: product.id, quantity: 1 }],
    }));
    setProductSearch("");
  };

  const removeProduct = (productId: number) => {
    setForm((prev) => ({
      ...prev,
      products: prev.products.filter((p) => p.product_id !== productId),
    }));
  };

  const updateProductQty = (productId: number, qty: number) => {
    setForm((prev) => ({
      ...prev,
      products: prev.products.map((p) =>
        p.product_id === productId ? { ...p, quantity: Math.max(1, qty) } : p
      ),
    }));
  };

  const getProductName = (productId: number) => {
    return allProducts.find((p) => p.id === productId)?.name || `#${productId}`;
  };

  /* ───── dynamic list helpers ───── */
  const updateField = <K extends keyof FormState>(key: K, val: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: val }));
  };

  /* ───── submit ───── */
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaving(true);

    const payload: Record<string, unknown> = {
      title: form.title,
      slug: form.slug || undefined,
      is_active: form.is_active,
      root_redirect: form.root_redirect,
      primary_color: form.primary_color,
      hero_headline: form.hero_headline || undefined,
      hero_subheadline: form.hero_subheadline || undefined,
      hero_image: form.hero_image || undefined,
      hero_video_autoplay: !!form.hero_video_autoplay,
      hero_cta: form.hero_cta || undefined,
      hero_trust_text: form.hero_trust_text || undefined,
      hero_badge: form.hero_badge || undefined,
      problem_title: form.problem_title || undefined,
      problem_points: JSON.stringify(form.problem_points),
      features: JSON.stringify(form.features),
      testimonials: JSON.stringify(form.testimonials),
      how_it_works: JSON.stringify(form.how_it_works),
      faq: JSON.stringify(form.faq),
      products: JSON.stringify(form.products),
      products_title: form.products_title || undefined,
      products_subtitle: form.products_subtitle || undefined,
      features_title: form.features_title || undefined,
      features_image: form.features_image || undefined,
      testimonials_title: form.testimonials_title || undefined,
      testimonials_mode: form.testimonials_mode,
      how_it_works_title: form.how_it_works_title || undefined,
      how_it_works_subtitle: form.how_it_works_subtitle || undefined,
      faq_title: form.faq_title || undefined,
      checkout_title: form.checkout_title || undefined,
      checkout_subtitle: form.checkout_subtitle || undefined,
      checkout_btn_text: form.checkout_btn_text || undefined,
      shipping_cost: form.custom_shipping ? (form.shipping_cost !== "" ? Number(form.shipping_cost) : 0) : undefined,
      custom_shipping: form.custom_shipping,
      show_email: form.show_email,
      show_city: form.show_city,
      guarantee_text: form.guarantee_text || undefined,
      success_message: form.success_message || undefined,
      meta_title: form.meta_title || undefined,
      meta_description: form.meta_description || undefined,
      whatsapp: form.whatsapp || undefined,
      contact_mode: form.contact_mode || "inherit",
      section_visibility: JSON.stringify(form.section_visibility),
      // Drag order — sent as an array (schema: z.array(z.string())). Stored on
      // the sectionOrder JSON column; the default template renders by it.
      section_order: form.section_order,
      template: form.template,
      // Only ship template_data when akbd/ayurex is selected. For default pages
      // we send null so the column doesn't accumulate stale fields if the user
      // switches templates later.
      template_data: form.template === "akbd"
        ? {
            doctor_photo: form.td_doctor_photo || "",
            doctor_name: form.td_doctor_name || "",
            doctor_credentials: form.td_doctor_credentials || [],
            doctor_reg_number: form.td_doctor_reg_number || "",
            doctor_role: form.td_doctor_role || "",
            chamber_heading: form.td_chamber_heading || "চেম্বারের ঠিকানা",
            chamber_address_lines: form.td_chamber_address_lines || [],
            faq_heading: form.td_faq_heading || "প্রায়শই জিজ্ঞাসিত প্রশ্নাবলী",
            stats: (form.td_stats || [])
              .filter((s) => (s.label || "").trim() !== "")
              .map((s) => ({ label: s.label, value: Number(s.value) || 0, suffix: s.suffix || "" })),
          }
        : form.template === "ayurex"
        // Ship only the non-empty overrides — blank fields fall back to the
        // template's built-in defaults. `problems` and `ingredient_groups`
        // are preserved verbatim from whatever was loaded (advanced edit).
        ? Object.fromEntries(
            Object.entries(form.ayx || {}).filter(([, v]) => typeof v === "string" && v.trim() !== "")
          )
        : null,
    };

    try {
      if (editId) {
        const res = await api.admin.updateLandingPage(editId, payload);
        const updated = res.data || res;
        setItems((prev) => prev.map((x) => (x.id === editId ? { ...x, ...updated } : x)));
        showToast(t("landingPages.updated"));
      } else {
        const res = await api.admin.createLandingPage(payload);
        const created = res.data || res;
        setItems((prev) => [created, ...prev]);
        showToast(t("landingPages.created"));
      }
      setModalOpen(false);
    } catch {
      showToast(t("landingPages.error"), "error");
    } finally {
      setSaving(false);
    }
  };

  /* ───── delete ───── */
  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await api.admin.deleteLandingPage(deleteId);
      setItems((prev) => prev.filter((x) => x.id !== deleteId));
      showToast(t("landingPages.deleted"));
      setDeleteId(null);
    } catch {
      showToast(t("landingPages.deleteError"), "error");
    } finally {
      setDeleting(false);
    }
  };

  /* ───── filter ───── */
  const filtered = items.filter(
    (item) =>
      (item.title || "").toLowerCase().includes(search.toLowerCase()) ||
      (item.slug || "").toLowerCase().includes(search.toLowerCase())
  );

  const filteredProducts = allProducts.filter(
    (p) =>
      p.name.toLowerCase().includes(productSearch.toLowerCase()) &&
      !form.products.some((fp) => fp.product_id === p.id)
  );

  /* ───── render ───── */
  return (
    <DashboardLayout title={t("landingPages.title")}>
      <Toast message={toast.message} type={toast.type} onClose={() => setToast({ ...toast, message: "" })} />
      <ConfirmDialog
        open={!!deleteId}
        message={t("landingPages.confirmDelete")}
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
        loading={deleting}
      />

      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
        {/* toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-52">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder={t("landingPages.search")}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-[var(--primary)] focus:outline-none"
            />
          </div>
          <button
            onClick={openCreate}
            className="flex items-center gap-2 px-4 py-2.5 bg-[var(--primary)] text-white rounded-xl text-sm font-semibold hover:bg-[var(--primary-light)] transition-colors"
          >
            <FiPlus className="w-4 h-4" />
            {t("landingPages.addNew")}
          </button>
        </div>

        {/* table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {loading ? (
            <TableSkeleton />
          ) : (
            <>
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    {[
                      t("landingPages.thTitle"),
                      t("landingPages.thSlug"),
                      t("landingPages.thProducts"),
                      t("landingPages.thStatus"),
                      "",
                    ].map((h, i) => (
                      <th key={i} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 whitespace-nowrap">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-gray-400">
                        {t("landingPages.empty")}
                      </td>
                    </tr>
                  ) : (
                    filtered.map((item) => (
                      <motion.tr
                        key={item.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="hover:bg-gray-50 transition-colors"
                      >
                        <td className="px-4 py-3 font-medium text-gray-800">{item.title}</td>
                        <td className="px-4 py-3 text-gray-500 font-mono text-xs">{item.slug}</td>
                        <td className="px-4 py-3 text-gray-600">{countProducts(item)}</td>
                        <td className="px-4 py-3">
                          <span
                            className={`text-xs px-2 py-1 rounded-full font-medium ${
                              item.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                            }`}
                          >
                            {item.is_active ? t("common.active") : t("common.inactive")}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => openEdit(item)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Edit"
                            >
                              <FiEdit2 className="w-3.5 h-3.5" />
                            </button>
                            <a
                              href={`/${item.slug}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                              title="View"
                            >
                              <FiEye className="w-3.5 h-3.5" />
                            </a>
                            <button
                              onClick={() => setDeleteId(item.id)}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete"
                            >
                              <FiTrash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile — card list. Title + slug + products count + status
              * pill + edit/view/delete actions. No horizontal scroll on
              * narrow viewports. */}
            <ul className="md:hidden divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <li className="py-12 text-center text-sm text-gray-400">{t("landingPages.empty")}</li>
              ) : filtered.map((item) => (
                <li key={item.id} className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-gray-900 truncate">{item.title}</div>
                      <div className="mt-0.5 text-xs text-gray-500 font-mono truncate">{item.slug}</div>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium shrink-0 ${item.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {item.is_active ? t("common.active") : t("common.inactive")}
                    </span>
                  </div>
                  <div className="text-xs text-gray-600">
                    {t("landingPages.thProducts")}: <span className="font-medium text-gray-800">{countProducts(item)}</span>
                  </div>
                  <div className="flex items-center gap-1.5 justify-end border-t border-gray-100 pt-2">
                    <button onClick={() => openEdit(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Edit">
                      <FiEdit2 className="w-4 h-4" />
                    </button>
                    <a href={`/${item.slug}`} target="_blank" rel="noopener noreferrer" className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors" title="View">
                      <FiEye className="w-4 h-4" />
                    </a>
                    <button onClick={() => setDeleteId(item.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors" title="Delete">
                      <FiTrash2 className="w-4 h-4" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
            </>
          )}
        </div>
      </motion.div>

      {/* ───── TEMPLATE PICKER MODAL ─────
          Shown after "+ Add" and before the form. Lets the user choose between
          the default form-based layout and the akbd doctor-style template. */}
      <Modal
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        title="Choose a Template"
        size="2xl"
      >
        <div className="p-6">
          <p className="text-sm text-gray-500 mb-5">Pick a visual layout for this landing page. Scroll each preview to see the full page. You can edit the content next.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* ── DEFAULT TEMPLATE PREVIEW ── */}
            <button
              type="button"
              onClick={() => pickTemplate("default")}
              className="group text-left rounded-2xl border-2 border-gray-200 hover:border-[var(--primary)] transition-colors p-2 bg-white"
            >
              <div className="rounded-xl overflow-hidden border border-gray-200 bg-white">
                {/* faux browser chrome */}
                <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 border-b border-gray-200">
                  <span className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="w-2 h-2 rounded-full bg-yellow-400" />
                  <span className="w-2 h-2 rounded-full bg-green-400" />
                </div>
                <div className="h-[380px] overflow-y-auto bg-white pointer-events-none select-none">
                  <div className="text-[7px] leading-tight">
                    {/* hero */}
                    <div className="bg-emerald-600 text-white px-3 py-4 text-center space-y-1.5">
                      <div className="h-2 bg-white/90 rounded w-3/4 mx-auto" />
                      <div className="h-1.5 bg-white/60 rounded w-1/2 mx-auto" />
                      <div className="h-3 bg-white text-emerald-700 rounded-full w-2/5 mx-auto mt-2" />
                    </div>
                    {/* problem */}
                    <div className="px-3 py-3 space-y-1">
                      <div className="h-1.5 bg-gray-300 rounded w-1/3 mx-auto mb-1.5" />
                      {[0,1,2].map(i => <div key={i} className="h-1.5 bg-rose-100 rounded w-full" />)}
                    </div>
                    {/* products */}
                    <div className="px-3 py-3 bg-gray-50">
                      <div className="h-1.5 bg-gray-300 rounded w-1/4 mx-auto mb-2" />
                      <div className="grid grid-cols-3 gap-1.5">
                        {[0,1,2].map(i => (
                          <div key={i} className="bg-white rounded border border-gray-200 p-1 space-y-1">
                            <div className="h-8 bg-gray-200 rounded" />
                            <div className="h-1 bg-gray-300 rounded w-3/4" />
                            <div className="h-2 bg-emerald-600 rounded" />
                          </div>
                        ))}
                      </div>
                    </div>
                    {/* features */}
                    <div className="px-3 py-3 grid grid-cols-4 gap-1.5">
                      {[0,1,2,3].map(i => (
                        <div key={i} className="space-y-1 text-center">
                          <div className="h-4 w-4 bg-emerald-100 rounded-full mx-auto" />
                          <div className="h-1 bg-gray-200 rounded" />
                        </div>
                      ))}
                    </div>
                    {/* how it works */}
                    <div className="px-3 py-3 bg-emerald-50 space-y-1.5">
                      <div className="h-1.5 bg-emerald-300 rounded w-1/3 mx-auto mb-1" />
                      {[0,1,2].map(i => <div key={i} className="h-2 bg-white rounded shadow-sm" />)}
                    </div>
                    {/* testimonials */}
                    <div className="px-3 py-3 grid grid-cols-2 gap-1.5">
                      {[0,1].map(i => <div key={i} className="h-9 bg-gray-100 rounded border border-gray-200" />)}
                    </div>
                    {/* faq */}
                    <div className="px-3 py-3 space-y-1">
                      {[0,1,2].map(i => <div key={i} className="h-2.5 bg-gray-100 rounded border border-gray-200" />)}
                    </div>
                    {/* checkout */}
                    <div className="px-3 py-4 bg-emerald-600 space-y-1.5">
                      <div className="h-1.5 bg-white/80 rounded w-1/3 mx-auto mb-1" />
                      {[0,1,2].map(i => <div key={i} className="h-2.5 bg-white rounded" />)}
                      <div className="h-3 bg-emerald-900 rounded mt-1" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-bold text-base">Default</h3>
                <p className="text-xs text-gray-500 mt-0.5">Stock 8-section landing page — hero, problem, products, features, how-it-works, testimonials, FAQ, checkout.</p>
              </div>
            </button>

            {/* ── AKBD TEMPLATE PREVIEW ── */}
            <button
              type="button"
              onClick={() => pickTemplate("akbd")}
              className="group text-left rounded-2xl border-2 border-gray-200 hover:border-[var(--primary)] transition-colors p-2 bg-white"
            >
              <div className="rounded-xl overflow-hidden border border-gray-200 bg-white">
                <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 border-b border-gray-200">
                  <span className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="w-2 h-2 rounded-full bg-yellow-400" />
                  <span className="w-2 h-2 rounded-full bg-green-400" />
                </div>
                <div className="h-[380px] overflow-y-auto bg-[#f3f5f8] pointer-events-none select-none">
                  <div className="text-[7px] leading-tight">
                    {/* hero pill */}
                    <div className="px-3 pt-4 pb-2 text-center">
                      <div className="h-3 bg-[#2378d2] rounded-full w-1/2 mx-auto" />
                      <div className="h-1.5 bg-gray-400 rounded w-3/4 mx-auto mt-2" />
                    </div>
                    {/* doctor poster */}
                    <div className="px-3 py-2">
                      <div className="h-24 bg-gradient-to-b from-[#1a3a63] to-[#24507f] rounded-lg flex items-end justify-center">
                        <div className="w-10 h-16 bg-white/85 rounded-t-lg mb-0" />
                      </div>
                    </div>
                    {/* stats 2x2 */}
                    <div className="px-3 py-2 grid grid-cols-2 gap-1.5">
                      {[0,1,2,3].map(i => (
                        <div key={i} className="bg-white rounded-lg border border-gray-200 py-2 text-center space-y-1">
                          <div className="h-1 bg-gray-300 rounded w-1/2 mx-auto" />
                          <div className="h-2 bg-[#1a3a63] rounded w-2/3 mx-auto" />
                        </div>
                      ))}
                    </div>
                    {/* benefits panel */}
                    <div className="px-3 py-2">
                      <div className="bg-[#1a3a63] rounded-xl p-2 space-y-1">
                        <div className="h-2 bg-[#2378d2] rounded w-1/2 mx-auto mb-1" />
                        {[0,1,2].map(i => <div key={i} className="h-1.5 bg-white/30 rounded" />)}
                      </div>
                    </div>
                    {/* product + red CTA */}
                    <div className="px-3 py-2 space-y-1.5">
                      <div className="h-16 bg-white rounded-lg border border-gray-200" />
                      <div className="h-4 bg-[#e63946] rounded-full w-3/5 mx-auto" />
                      <div className="h-2 bg-[#2378d2] rounded w-2/5 mx-auto" />
                    </div>
                    {/* testimonials navy */}
                    <div className="px-3 py-2">
                      <div className="bg-[#1a3a63] rounded-xl p-2 grid grid-cols-3 gap-1">
                        {[0,1,2].map(i => <div key={i} className="h-10 bg-white/15 rounded" />)}
                      </div>
                    </div>
                    {/* chamber address */}
                    <div className="px-3 py-2">
                      <div className="bg-[#1a3a63] rounded-xl p-2 space-y-1">
                        <div className="h-2 bg-[#2378d2] rounded w-2/5 mx-auto mb-1" />
                        {[0,1].map(i => <div key={i} className="h-1.5 bg-white/30 rounded w-3/4 mx-auto" />)}
                      </div>
                    </div>
                    {/* faq */}
                    <div className="px-3 py-2 space-y-1">
                      {[0,1,2].map(i => <div key={i} className="h-2.5 bg-white rounded border border-gray-200" />)}
                    </div>
                    {/* checkout */}
                    <div className="px-3 py-3 bg-white border-t border-gray-200 space-y-1.5">
                      <div className="h-1.5 bg-gray-300 rounded w-1/3 mx-auto mb-1" />
                      {[0,1,2].map(i => <div key={i} className="h-2.5 bg-gray-100 rounded border border-gray-200" />)}
                      <div className="h-3 bg-[#e63946] rounded mt-1" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-bold text-base">Akbd (Doctor / Medical)</h3>
                <p className="text-xs text-gray-500 mt-0.5">Navy + teal doctor profile layout — doctor poster, animated stats, benefit panels, image testimonial carousel, chamber address, FAQ.</p>
              </div>
            </button>

            {/* ── AYUREX TEMPLATE PREVIEW ── */}
            <button
              type="button"
              onClick={() => pickTemplate("ayurex")}
              className="group text-left rounded-2xl border-2 border-gray-200 hover:border-[var(--primary)] transition-colors p-2 bg-white"
            >
              <div className="rounded-xl overflow-hidden border border-gray-200 bg-white">
                <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 border-b border-gray-200">
                  <span className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="w-2 h-2 rounded-full bg-yellow-400" />
                  <span className="w-2 h-2 rounded-full bg-green-400" />
                </div>
                <div className="h-[380px] overflow-y-auto bg-white pointer-events-none select-none">
                  <div className="text-[7px] leading-tight">
                    {/* hero green */}
                    <div className="px-3 py-3 bg-gradient-to-b from-[#0f5931] to-[#0a3d22] text-center space-y-1.5">
                      <div className="h-1.5 bg-white/30 rounded-full w-1/3 mx-auto" />
                      <div className="h-3 bg-white/80 rounded w-3/4 mx-auto" />
                      <div className="h-3 bg-[#ffb703] rounded-full w-2/5 mx-auto mt-1" />
                    </div>
                    {/* red offer strip */}
                    <div className="h-2 bg-[#e63946]" />
                    {/* problem grid */}
                    <div className="px-3 py-2 grid grid-cols-3 gap-1">
                      {[0,1,2,3,4,5].map(i => <div key={i} className="h-6 bg-[#f6faf7] rounded border border-[#e3efe7]" />)}
                    </div>
                    {/* order band */}
                    <div className="px-3 py-1.5 text-center"><div className="h-3 bg-[#ffb703] rounded-full w-3/5 mx-auto" /></div>
                    {/* benefit blocks */}
                    <div className="px-3 py-2 grid grid-cols-3 gap-1.5">
                      {[0,1,2].map(i => (
                        <div key={i} className="rounded-lg border border-[#e3efe7] overflow-hidden">
                          <div className="h-2 bg-[#0f5931]" />
                          <div className="p-1 space-y-0.5">{[0,1,2].map(j => <div key={j} className="h-1 bg-gray-200 rounded" />)}</div>
                        </div>
                      ))}
                    </div>
                    {/* product shot */}
                    <div className="px-3 py-2"><div className="h-16 bg-[#f6faf7] rounded-lg border border-gray-200" /></div>
                    {/* ingredients */}
                    <div className="px-3 py-2 grid grid-cols-2 gap-1.5">
                      {[0,1].map(i => (
                        <div key={i} className="rounded-lg border border-gray-200 p-1 space-y-0.5">
                          <div className="h-1.5 bg-[#0f5931] rounded w-1/2" />
                          {[0,1,2,3].map(j => <div key={j} className="h-1 bg-[#f4faf6] rounded border border-[#e3efe7]" />)}
                        </div>
                      ))}
                    </div>
                    {/* yellow highlight */}
                    <div className="px-3 py-2"><div className="h-8 bg-[#fff7d6] rounded-lg border border-[#ffe07a]" /></div>
                    {/* testimonials */}
                    <div className="px-3 py-2 grid grid-cols-3 gap-1">
                      {[0,1,2].map(i => <div key={i} className="h-9 bg-white rounded border border-gray-200" />)}
                    </div>
                    {/* checkout */}
                    <div className="px-3 py-3 bg-[#f6faf7] space-y-1.5">
                      <div className="h-1.5 bg-gray-300 rounded w-1/3 mx-auto mb-1" />
                      {[0,1,2].map(i => <div key={i} className="h-2.5 bg-white rounded border border-gray-200" />)}
                      <div className="h-3 bg-[#ffb703] rounded mt-1" />
                    </div>
                    {/* footer */}
                    <div className="px-3 py-3 bg-gradient-to-b from-[#0f5931] to-[#0a3d22] space-y-1">
                      <div className="h-2 bg-white/70 rounded w-1/2 mx-auto" />
                      <div className="h-3 bg-[#ffb703] rounded-full w-2/5 mx-auto" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-bold text-base">Ayurex (Herbal / Single-Product)</h3>
                <p className="text-xs text-gray-500 mt-0.5">Green herbal long-form sales page — hero, problem icons, benefit blocks, 80-ingredient showcase, usage, testimonials, repeating order CTAs, COD checkout.</p>
              </div>
            </button>
          </div>
        </div>
      </Modal>

      {/* ───── CREATE / EDIT MODAL ───── */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editId ? t("landingPages.editTitle") : `${t("landingPages.newTitle")} — ${form.template === "akbd" ? "Akbd" : form.template === "ayurex" ? "Ayurex" : "Default"}`}
        size="xl"
        headerAction={
          // Base-URL redirect toggle — lives in the modal header so it's
          // visible on EVERY template (default + akbd) without scrolling.
          // When ON, this LP becomes the root ("/") redirect target for
          // storefront-disabled tenants. Saved with the page; only one LP can
          // hold it at a time (server unsets the others).
          <label
            className={`flex items-center gap-2 text-xs font-medium px-2.5 py-1.5 rounded-lg border cursor-pointer transition-colors ${
              form.root_redirect
                ? "bg-emerald-50 border-emerald-300 text-emerald-700"
                : "bg-gray-50 border-gray-200 text-gray-600 hover:border-gray-300"
            }`}
            title="When ON, your base URL (/) redirects to this landing page. Used for storefront-disabled stores. Only one page can be the target."
          >
            <input
              type="checkbox"
              checked={!!form.root_redirect}
              onChange={(e) => setForm({ ...form, root_redirect: e.target.checked })}
              className="w-3.5 h-3.5 accent-emerald-600"
            />
            <span className="whitespace-nowrap">Base URL redirect</span>
          </label>
        }
      >
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Template banner — clarifies which sections are wired and shows how
              to switch. Edit re-opens the form on the existing template; to
              change template, the user should re-create the page. */}
          <div className={`rounded-xl p-3 text-sm flex items-center gap-3 ${form.template === "akbd" ? "bg-[#eef4fb] border border-[#c5dcf2]" : "bg-emerald-50 border border-emerald-200"}`}>
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-lg ${form.template === "akbd" ? "bg-[#2378d2] text-white" : form.template === "ayurex" ? "bg-[#0f5931] text-white" : "bg-emerald-600 text-white"}`}>
              {form.template === "akbd" ? "🩺" : form.template === "ayurex" ? "🌿" : "📄"}
            </div>
            <div className="flex-1">
              <div className="font-semibold">
                Template: {form.template === "akbd" ? "Akbd (Doctor / Medical)" : form.template === "ayurex" ? "Ayurex (Herbal / Single-Product)" : "Default"}
              </div>
              <div className="text-xs text-gray-600 mt-0.5">
                {form.template === "akbd"
                  ? "Hero pill + subtitle → doctor card → benefits → why-choose → image testimonials → chamber → FAQ → checkout. Problem/Products sections are not used."
                  : form.template === "ayurex"
                  ? "Green herbal long-form page: hero → problem icons → benefit blocks → product shots → 80-ingredient showcase → usage → testimonials → repeating order CTAs → COD checkout. Set the product, price, hero image & WhatsApp; section copy ships as editable defaults."
                  : "Full 8-section stock layout: hero, problem, products, features, how-it-works, testimonials, FAQ, checkout."}
              </div>
            </div>
            {/* "Change" button shown on BOTH create AND edit. On edit,
                pickTemplate keeps form fields intact — only template swaps. */}
            {(
              <button
                type="button"
                onClick={() => { setModalOpen(false); setPickerOpen(true); }}
                className="text-xs px-3 py-1.5 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 whitespace-nowrap"
              >
                Change
              </button>
            )}
          </div>

          {/* ─── 1. Basic Info (always open) ─── */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              {"📋"} {t("landingPages.basicInfo")}
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className={labelCls}>{t("landingPages.labelTitle")}</label>
                <input
                  required
                  value={form.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                  className={inputCls}
                  placeholder="Amazing Product Page"
                />
              </div>
              <div>
                <label className={labelCls}>{t("landingPages.labelSlug")}</label>
                <input
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value })}
                  className={inputCls}
                  placeholder="auto-generated-from-title"
                />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className={labelCls}>{t("landingPages.labelPrimaryColor")}</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    // <input type="color"> only accepts "#rrggbb". Coerce any
                    // non-hex value (e.g. legacy "var(--primary)" rows) to a
                    // sane default so React stops printing a runtime warning.
                    value={/^#[0-9a-fA-F]{6}$/.test(form.primary_color) ? form.primary_color : "#0f5931"}
                    onChange={(e) => setForm({ ...form, primary_color: e.target.value })}
                    className="w-10 h-10 rounded-lg border border-gray-200 cursor-pointer"
                  />
                  <input
                    value={form.primary_color}
                    onChange={(e) => setForm({ ...form, primary_color: e.target.value })}
                    className={inputCls}
                    placeholder="var(--primary)"
                  />
                </div>
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2 text-sm cursor-pointer pb-2">
                  <input
                    type="checkbox"
                    checked={form.is_active}
                    onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
                    className="w-4 h-4 accent-[var(--primary)]"
                  />
                  {t("landingPages.labelActive")}
                </label>
              </div>
            </div>
            <div>
              <label className={labelCls}>{t("landingPages.labelWhatsapp")}</label>
              <input
                value={form.whatsapp}
                onChange={(e) => setForm({ ...form, whatsapp: e.target.value })}
                className={inputCls}
                placeholder="01XXXXXXXXX"
              />
              <p className="text-[10px] text-gray-400 mt-1">{t("landingPages.whatsappHint")}</p>
            </div>
            <div>
              <label className={labelCls}>Floating Bubble Mode</label>
              <select
                value={form.contact_mode || "inherit"}
                onChange={(e) => setForm({ ...form, contact_mode: e.target.value })}
                className={inputCls}
              >
                <option value="inherit">Inherit from site setting</option>
                <option value="whatsapp">WhatsApp (chat)</option>
                <option value="phone">Phone Call (tel:)</option>
                <option value="messenger">Messenger (m.me)</option>
                <option value="all">All — expandable (WhatsApp + Phone + Messenger)</option>
              </select>
              <p className="text-[10px] text-gray-400 mt-1">
                Override the global floating-bubble behavior just for this landing page.
                WhatsApp/Phone use the number above; Messenger uses the site&apos;s Facebook
                URL. &quot;All&quot; shows one icon that expands every available channel.
              </p>
            </div>
          </div>

          {/* ─── 1b. Akbd Template Data (akbd template only) ─── */}
          {form.template === "akbd" && (
            <Section title="Doctor & Chamber (Akbd Template)" icon="🩺" open={isOpen("akbd_template_data")} onToggle={() => toggle("akbd_template_data")}
              visible={form.section_visibility.akbd_chamber !== false} onVisibilityToggle={() => toggleVis("akbd_chamber")}>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>Doctor Name</label>
                  <input
                    value={form.td_doctor_name}
                    onChange={(e) => setForm({ ...form, td_doctor_name: e.target.value })}
                    className={inputCls}
                    placeholder="Dr. P.B Shuvo"
                  />
                </div>
                <div>
                  <label className={labelCls}>Doctor Role / Title</label>
                  <input
                    value={form.td_doctor_role}
                    onChange={(e) => setForm({ ...form, td_doctor_role: e.target.value })}
                    className={inputCls}
                    placeholder="Consultant (Homeo Medicine)"
                  />
                </div>
              </div>
              <div>
                <label className={labelCls}>Doctor Photo</label>
                {form.td_doctor_photo ? (
                  <div className="relative rounded-xl overflow-hidden border border-gray-200 mb-2 inline-block">
                    <SafeImg src={form.td_doctor_photo} alt="Doctor" className="max-h-40 object-cover" />
                    <button type="button" onClick={() => setForm({ ...form, td_doctor_photo: "" })}
                      className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full"><FiX className="w-3.5 h-3.5" /></button>
                  </div>
                ) : null}
                <div className="flex gap-2">
                  <button type="button" onClick={() => { setGalleryTarget("td_doctor_photo"); setGalleryOpen(true); }}
                    className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[var(--primary)] transition-colors text-sm text-gray-500">
                    🖼️ Pick from gallery
                  </button>
                </div>
              </div>
              <div>
                <label className={labelCls}>Doctor Credentials (one per line)</label>
                <textarea
                  rows={4}
                  value={(form.td_doctor_credentials || []).join("\n")}
                  onChange={(e) => setForm({ ...form, td_doctor_credentials: e.target.value.split("\n").filter(Boolean) })}
                  className={inputCls + " resize-none"}
                  placeholder={"DHMS, BHB (Dhaka)\nDHC (Dhaka)\nঅভিজ্ঞতা ১২ বছর\n১২,০০০+ পেশেন্ট"}
                />
                <p className="text-[10px] text-gray-400 mt-1">Each line becomes a separate credential line in the navy info card.</p>
              </div>
              <div>
                <label className={labelCls}>Register Doctor / Govt. Reg. (teal pill)</label>
                <input
                  value={form.td_doctor_reg_number}
                  onChange={(e) => setForm({ ...form, td_doctor_reg_number: e.target.value })}
                  className={inputCls}
                  placeholder="Register Doctor, Govt. Reg. 34412"
                />
              </div>
              <div>
                <label className={labelCls}>Chamber Heading</label>
                <input
                  value={form.td_chamber_heading}
                  onChange={(e) => setForm({ ...form, td_chamber_heading: e.target.value })}
                  className={inputCls}
                  placeholder="চেম্বারের ঠিকানা"
                />
              </div>
              <div>
                <label className={labelCls}>Chamber Address (one line per row)</label>
                <textarea
                  rows={3}
                  value={(form.td_chamber_address_lines || []).join("\n")}
                  onChange={(e) => setForm({ ...form, td_chamber_address_lines: e.target.value.split("\n") })}
                  className={inputCls + " resize-none"}
                  placeholder={"ইন্টারন্যাশনাল হোমিও\nলালদিঘি, চট্টগ্রাম\nফ্রি পরামর্শের জন্য ফোন করুন"}
                />
                <p className="text-[10px] text-gray-400 mt-1">The phone field below (WhatsApp) is shown in red under the address. Leave blank to omit.</p>
              </div>
              <div>
                <label className={labelCls}>FAQ Section Heading</label>
                <input
                  value={form.td_faq_heading}
                  onChange={(e) => setForm({ ...form, td_faq_heading: e.target.value })}
                  className={inputCls}
                  placeholder="প্রায়শই জিজ্ঞাসিত প্রশ্নাবলী"
                />
              </div>
            </Section>
          )}

          {/* ─── 1c. Akbd Stats Counters (akbd template only) ─── */}
          {form.template === "akbd" && (
            <Section title="Stats Counters (Akbd Template)" icon="📊" open={isOpen("akbd_stats")} onToggle={() => toggle("akbd_stats")}
              visible={form.section_visibility.akbd_stats !== false} onVisibilityToggle={() => toggleVis("akbd_stats")}>
              <p className="text-[11px] text-gray-500">
                Animated counters shown right under the doctor poster. Counts up 1→Number on scroll into view.
                Bengali numerals auto. Values ≥ 1000 get comma grouping (8000 → ৮,০০০).
                Suffix e.g. &quot;+&quot;, &quot; বছর+&quot;, &quot; শতাংশ +&quot;.
              </p>
              <div className="grid sm:grid-cols-2 gap-3">
                {(form.td_stats || []).map((s, i) => (
                  <div key={i} className="relative border border-gray-200 rounded-xl p-3 space-y-2 bg-gray-50">
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, td_stats: form.td_stats.filter((_, j) => j !== i) })}
                      className="absolute top-2 right-2 p-1 text-red-500 hover:text-red-700"
                      title="Remove stat"
                    >
                      <FiX className="w-3.5 h-3.5" />
                    </button>
                    <div>
                      <label className="block text-[10px] text-gray-400 font-medium mb-0.5">Label</label>
                      <input
                        value={s.label}
                        onChange={(e) => { const a = [...form.td_stats]; a[i] = { ...a[i], label: e.target.value }; setForm({ ...form, td_stats: a }); }}
                        className={inputCls}
                        placeholder="অভিজ্ঞতা"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] text-gray-400 font-medium mb-0.5">Number</label>
                        <input
                          type="number"
                          value={s.value}
                          onChange={(e) => { const a = [...form.td_stats]; a[i] = { ...a[i], value: Number(e.target.value) || 0 }; setForm({ ...form, td_stats: a }); }}
                          className={inputCls}
                          placeholder="10"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-gray-400 font-medium mb-0.5">Suffix</label>
                        <input
                          value={s.suffix}
                          onChange={(e) => { const a = [...form.td_stats]; a[i] = { ...a[i], suffix: e.target.value }; setForm({ ...form, td_stats: a }); }}
                          className={inputCls}
                          placeholder="+"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setForm({ ...form, td_stats: [...(form.td_stats || []), { label: "", value: 0, suffix: "+" }] })}
                className="mt-1 text-xs text-[var(--primary)] font-semibold"
              >
                + Add stat
              </button>
            </Section>
          )}

          {/* ─── Ayurex content (all body copy editable) ─── */}
          {form.template === "ayurex" && (
            <Section title="Ayurex Content (all sections)" icon="🌿" open={isOpen("ayxContent")} onToggle={() => toggle("ayxContent")}>
              <p className="text-xs text-gray-500 mb-3">
                Edit any block below. Leave a field blank to keep the built-in default text. The 80-ingredient list and the 6 problem cards keep their defaults unless edited in code.
              </p>
              <div className="space-y-3">
                {AYX_FIELDS.map((fld) => (
                  <div key={fld.key}>
                    <label className="block text-xs font-medium text-gray-500 mb-1">{fld.label}</label>
                    {fld.multiline ? (
                      <textarea
                        rows={2}
                        value={form.ayx?.[fld.key] || ""}
                        onChange={(e) => setForm({ ...form, ayx: { ...form.ayx, [fld.key]: e.target.value } })}
                        className={inputCls + " resize-y"}
                        placeholder="(default)"
                      />
                    ) : (
                      <input
                        value={form.ayx?.[fld.key] || ""}
                        onChange={(e) => setForm({ ...form, ayx: { ...form.ayx, [fld.key]: e.target.value } })}
                        className={inputCls}
                        placeholder="(default)"
                      />
                    )}
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* ─── Section order (drag to reorder + show/hide) ─── */}
          {(!form.template || form.template === "default") ? (
            <SectionOrderPanel
              order={form.section_order}
              visibility={form.section_visibility}
              onReorder={reorderSections}
              onToggleVisible={toggleVis}
            />
          ) : (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
              The <strong>{form.template === "akbd" ? "Doctor (akbd)" : "Ayurex"}</strong> template uses a fixed bespoke layout, so section drag-ordering doesn&apos;t apply. Use the default template for reorderable sections.
            </div>
          )}

          {/* ─── 2. Hero Section ─── */}
          <Section
            title={form.template === "akbd" ? "Hero (top pill + subtitle + product image)" : t("landingPages.heroSection")}
            icon="🎯"
            open={isOpen("hero")}
            onToggle={() => toggle("hero")}
            visible={form.section_visibility.hero !== false}
            onVisibilityToggle={() => toggleVis("hero")}>
            {/* Akbd-specific Hero pill text — the teal pill at top of page.
                Default template doesn't render this prominently, so we only
                show it in akbd mode. Re-uses the hero_badge column. */}
            {form.template === "akbd" && (
              <div>
                <label className={labelCls}>Hero Pill Text (teal badge at top)</label>
                <input
                  value={form.hero_badge}
                  onChange={(e) => setForm({ ...form, hero_badge: e.target.value })}
                  className={inputCls}
                  placeholder="জার্মানি ফর্মুলায় তৈরী"
                />
              </div>
            )}
            <div className="grid sm:grid-cols-2 gap-4">
              {/* Headline — default template only. Akbd uses the pill above. */}
              {form.template !== "akbd" && (
                <div>
                  <label className={labelCls}>{t("landingPages.labelHeadline")}</label>
                  <input
                    value={form.hero_headline}
                    onChange={(e) => setForm({ ...form, hero_headline: e.target.value })}
                    className={inputCls}
                    placeholder="Transform your life today"
                  />
                </div>
              )}
              <div className={form.template === "akbd" ? "sm:col-span-2" : ""}>
                <label className={labelCls}>{t("landingPages.labelCtaButton")}</label>
                <input
                  value={form.hero_cta}
                  onChange={(e) => setForm({ ...form, hero_cta: e.target.value })}
                  className={inputCls}
                  placeholder={form.template === "akbd" ? "অর্ডার করতে ক্লিক করুন" : "Order Now"}
                />
                {form.template === "akbd" && (
                  <p className="text-[10px] text-gray-400 mt-1">Text shown on the red CTA buttons that appear after benefits + after testimonials.</p>
                )}
              </div>
            </div>
            <div>
              <label className={labelCls}>
                {form.template === "akbd" ? "Subtitle (below the hero pill)" : t("landingPages.labelSubheadline")}
              </label>
              <textarea
                rows={2}
                value={form.hero_subheadline}
                onChange={(e) => setForm({ ...form, hero_subheadline: e.target.value })}
                className={inputCls + " resize-none"}
                placeholder={form.template === "akbd" ? "পা'য়ু'পথের বিভিন্ন সমস্যার স্থায়ী ও কার্যকরী সমাধান।" : ""}
              />
            </div>
            {/* Trust text + autoplay — default template only */}
            {form.template !== "akbd" && (
              <div>
                <label className={labelCls}>{t("landingPages.labelTrustBadges")}</label>
                <textarea
                  rows={3}
                  value={form.hero_trust_text}
                  onChange={(e) => setForm({ ...form, hero_trust_text: e.target.value })}
                  className={inputCls + " resize-none"}
                  placeholder={"ত্বক-বান্ধব ফেব্রিক\nসারা বাংলাদেশে ডেলিভারি\nক্যাশ অন ডেলিভারি"}
                />
                <p className="text-[10px] text-gray-400 mt-1">{t("landingPages.trustBadgesHint")}</p>
              </div>
            )}
            <div>
              <label className={labelCls}>
                {form.template === "akbd" ? "Product Image (shown after benefits panel)" : t("landingPages.labelHeroImage")}
              </label>
              {form.hero_image ? (
                <div className="relative rounded-xl overflow-hidden border border-gray-200 mb-2">
                  {form.hero_image.includes("youtube.com") || form.hero_image.includes("youtu.be") ? (
                    <div className="aspect-video bg-black">
                      <iframe src={form.hero_image.replace("watch?v=", "embed/").replace("youtu.be/", "youtube.com/embed/")}
                        className="w-full h-full" allowFullScreen />
                    </div>
                  ) : form.hero_image.match(/\.(mp4|webm|mov)$/i) ? (
                    <video src={form.hero_image} controls className="w-full max-h-40 bg-black" />
                  ) : (
                    <SafeImg src={form.hero_image} alt="Hero" className="w-full max-h-40 object-cover" />
                  )}
                  <button type="button" onClick={() => setForm({ ...form, hero_image: "" })}
                    className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full shadow-md hover:bg-red-600">
                    <FiX className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : null}
              <div className="flex gap-2">
                <button type="button" onClick={() => { setGalleryTarget("hero"); setGalleryOpen(true); }}
                  className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[var(--primary)] transition-colors text-sm text-gray-500 flex-1">
                  {"🖼️"} {t("landingPages.mediaGallery")}
                </button>
                <label className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[var(--primary)] transition-colors text-sm text-gray-500">
                  <input type="file" accept="image/*,video/*" onChange={handleFileSelect} className="hidden" />
                  {uploading ? "..." : `⬆️ ${t("landingPages.upload")}`}
                </label>
              </div>
              {/* Autoplay toggle — only relevant when the hero asset is a video.
                  Akbd renders an <Image> only, no video support, so we gate
                  this whole block to the default template. */}
              {form.template !== "akbd" && form.hero_image && (form.hero_image.match(/\.(mp4|webm|mov)$/i) || form.hero_image.includes("youtube.com") || form.hero_image.includes("youtu.be")) && (
                <label className="mt-3 flex items-center justify-between gap-3 p-3 border border-gray-200 rounded-xl bg-gray-50 cursor-pointer">
                  <div>
                    <div className="text-sm font-medium text-gray-700">Autoplay video</div>
                    <div className="text-[11px] text-gray-500">Plays automatically (muted) when visitors land on the page.</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, hero_video_autoplay: !form.hero_video_autoplay })}
                    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${form.hero_video_autoplay ? "bg-[var(--primary)]" : "bg-gray-300"}`}
                    aria-pressed={form.hero_video_autoplay}
                  >
                    <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${form.hero_video_autoplay ? "translate-x-5" : "translate-x-0.5"}`} />
                  </button>
                </label>
              )}
            </div>
          </Section>

          {/* ─── 3. Problem Section (default template only — akbd doesn't render this) ─── */}
          {form.template !== "akbd" && (
          <Section title={t("landingPages.problemSection")} icon="⚠️" open={isOpen("problem")} onToggle={() => toggle("problem")}
            visible={form.section_visibility.problem !== false} onVisibilityToggle={() => toggleVis("problem")}>
            <div>
              <label className={labelCls}>{t("landingPages.labelSectionTitle")}</label>
              <input
                value={form.problem_title}
                onChange={(e) => setForm({ ...form, problem_title: e.target.value })}
                className={inputCls}
                placeholder="Are you facing these problems?"
              />
            </div>
            {form.problem_points.map((point, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <div className="shrink-0">
                  {point.icon ? (
                    <div className="relative w-10 h-10 rounded-xl overflow-hidden border border-gray-200">
                      <SafeImg src={point.icon} alt="" className="w-full h-full object-cover" />
                      <button type="button" onClick={() => {
                        const updated = [...form.problem_points];
                        updated[idx] = { ...updated[idx], icon: "" };
                        updateField("problem_points", updated);
                      }} className="absolute -top-0.5 -right-0.5 p-0.5 bg-red-500 text-white rounded-full">
                        <FiX className="w-2 h-2" />
                      </button>
                    </div>
                  ) : (
                    <button type="button" onClick={() => { setGalleryTarget(`problem-${idx}`); setGalleryOpen(true); }}
                      className="w-10 h-10 rounded-xl bg-gray-200 flex items-center justify-center cursor-pointer hover:bg-gray-300 transition-colors text-gray-400 text-xs" title="Add icon/image">
                      🖼️
                    </button>
                  )}
                </div>
                <input
                  value={point.text}
                  onChange={(e) => {
                    const updated = [...form.problem_points];
                    updated[idx] = { ...updated[idx], text: e.target.value };
                    updateField("problem_points", updated);
                  }}
                  className={inputCls + " flex-1"}
                  placeholder={`Problem point ${idx + 1}`}
                />
                <button
                  type="button"
                  onClick={() => updateField("problem_points", form.problem_points.filter((_, i) => i !== idx))}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <FiX className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => updateField("problem_points", [...form.problem_points, { text: "", icon: "" }])}
              className="flex items-center gap-1 text-xs font-medium text-[var(--primary)] hover:underline"
            >
              <FiPlus className="w-3.5 h-3.5" /> {t("landingPages.addPoint")}
            </button>
          </Section>
          )}

          {/* ─── 4. Products — default template only.
              Akbd has its product picker INSIDE the Checkout section so the
              two related fields (product + checkout config) live together. */}
          {form.template !== "akbd" && (
          <Section title={t("landingPages.productsSection")} icon="📦" open={isOpen("products")} onToggle={() => toggle("products")}
            visible={form.section_visibility.products !== false} onVisibilityToggle={() => toggleVis("products")}>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className={labelCls}>{t("landingPages.labelSectionTitle")}</label>
                <input value={form.products_title} onChange={(e) => setForm({ ...form, products_title: e.target.value })} className={inputCls} placeholder="আমাদের প্রোডাক্ট" />
              </div>
              <div>
                <label className={labelCls}>{t("landingPages.labelSubtitle")}</label>
                <input value={form.products_subtitle} onChange={(e) => setForm({ ...form, products_subtitle: e.target.value })} className={inputCls} placeholder="ত্বক-বান্ধব ও প্রিমিয়াম মানের" />
              </div>
            </div>
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:border-[var(--primary)] focus:outline-none"
                placeholder={t("landingPages.searchProducts")}
              />
              {productSearch && filteredProducts.length > 0 && (
                <div className="absolute z-[100] left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                  {filteredProducts.slice(0, 10).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => addProduct(p)}
                      className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm flex items-center gap-2 transition-colors"
                    >
                      {p.image && (
                        <SafeImg src={p.image} alt={p.name} className="w-8 h-8 rounded object-cover" />
                      )}
                      <span className="flex-1 truncate">{p.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {form.products.length > 0 && (
              <div className="space-y-2">
                {form.products.map((entry, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                    <span className="flex-1 text-sm font-medium text-gray-700 truncate">
                      {getProductName(entry.product_id)}
                    </span>
                    <div className="flex items-center gap-1">
                      <label className="text-xs text-gray-500">{t("landingPages.qty")}</label>
                      <input
                        type="number"
                        min={1}
                        value={entry.quantity}
                        onChange={(e) => updateProductQty(entry.product_id, Number(e.target.value))}
                        className="w-16 px-2 py-1 border border-gray-200 rounded text-sm text-center focus:border-[var(--primary)] focus:outline-none"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeProduct(entry.product_id)}
                      className="p-1 text-red-500 hover:bg-red-50 rounded transition-colors"
                    >
                      <FiX className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Section>
          )}

          {/* ─── 5. Features / Benefits ─── */}
          <Section
            title={form.template === "akbd" ? "Benefits (checkmark bullets)" : t("landingPages.featuresSection")}
            icon={form.template === "akbd" ? "✅" : "✨"}
            open={isOpen("features")}
            onToggle={() => toggle("features")}
            visible={form.section_visibility.features !== false}
            onVisibilityToggle={() => toggleVis("features")}>
            <div className="mb-3">
              <label className={labelCls}>
                {form.template === "akbd"
                  ? "Panel Heading (teal pill at top of benefits panel)"
                  : t("landingPages.labelSectionTitle")}
              </label>
              <input
                value={form.features_title}
                onChange={(e) => setForm({ ...form, features_title: e.target.value })}
                className={inputCls}
                placeholder={form.template === "akbd" ? "আপনি যে উপকার পাবেন" : "🔥 কেন এই প্রোডাক্ট ব্যবহার করবেন?"}
              />
            </div>
            {/* "Image Badge" repurposes the hero_badge column for the default
                template. Akbd already exposes that same column at the top of
                the Hero section as the teal pill — we hide it here so the
                same field isn't editable in two places with different labels. */}
            {form.template !== "akbd" && (
              <div className="mb-3">
                <label className={labelCls}>{t("landingPages.labelImageBadge")}</label>
                <input
                  value={form.hero_badge}
                  onChange={(e) => setForm({ ...form, hero_badge: e.target.value })}
                  className={inputCls}
                  placeholder="Skin-Friendly Fabric"
                />
                <p className="text-[10px] text-gray-400 mt-1">{t("landingPages.imageBadgeHint")}</p>
              </div>
            )}
            {/* Features image — akbd doesn't render it (the doctor poster +
                product image are populated elsewhere). Default template puts
                it next to the feature list. */}
            {form.template !== "akbd" && (
              <div className="mb-3">
                <label className={labelCls}>{t("landingPages.labelFeaturesImage")}</label>
              {form.features_image ? (
                <div className="relative rounded-xl overflow-hidden border border-gray-200 mb-2">
                  {form.features_image.match(/\.(mp4|webm|mov)$/i) ? (
                    <video src={form.features_image} className="w-full max-h-40 object-cover" controls />
                  ) : form.features_image.includes("youtube.com") || form.features_image.includes("youtu.be") ? (
                    <div className="aspect-video"><iframe src={form.features_image.replace("watch?v=", "embed/")} className="w-full h-full rounded-xl" allowFullScreen /></div>
                  ) : (
                    <SafeImg src={form.features_image} alt="Features" className="w-full max-h-40 object-cover" />
                  )}
                  <div className="absolute top-2 right-2 flex gap-1">
                    <button type="button" onClick={() => { setGalleryTarget("features"); setGalleryOpen(true); }}
                      className="p-1.5 bg-white/90 rounded-lg text-xs hover:bg-white">🖼️</button>
                    <button type="button" onClick={() => setForm({ ...form, features_image: "" })}
                      className="p-1.5 bg-red-500 text-white rounded-lg text-xs hover:bg-red-600">✕</button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button type="button" onClick={() => { setGalleryTarget("features"); setGalleryOpen(true); }}
                    className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[var(--primary)] transition-colors text-sm text-gray-500 flex-1">
                    {"🖼️"} {t("landingPages.gallerySelect")}
                  </button>
                </div>
              )}
              <p className="text-[10px] text-gray-400 mt-1">{t("landingPages.featuresImageHint")}</p>
              </div>
            )}
            {form.features.map((feat, idx) => (
              <div key={idx} className="p-3 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    value={feat.icon}
                    onChange={(e) => {
                      const updated = [...form.features];
                      updated[idx] = { ...updated[idx], icon: e.target.value };
                      updateField("features", updated);
                    }}
                    className="w-16 px-2 py-1.5 border border-gray-200 rounded-lg text-sm text-center focus:border-[var(--primary)] focus:outline-none"
                    placeholder="🔥"
                  />
                  <input
                    value={feat.title}
                    onChange={(e) => {
                      const updated = [...form.features];
                      updated[idx] = { ...updated[idx], title: e.target.value };
                      updateField("features", updated);
                    }}
                    className={inputCls + " flex-1"}
                    placeholder="Feature title"
                  />
                  <button
                    type="button"
                    onClick={() => updateField("features", form.features.filter((_, i) => i !== idx))}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <FiX className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={feat.description}
                  onChange={(e) => {
                    const updated = [...form.features];
                    updated[idx] = { ...updated[idx], description: e.target.value };
                    updateField("features", updated);
                  }}
                  className={inputCls + " resize-none"}
                  placeholder="Feature description"
                />
              </div>
            ))}
            <button
              type="button"
              onClick={() => updateField("features", [...form.features, { icon: "", title: "", description: "" }])}
              className="flex items-center gap-1 text-xs font-medium text-[var(--primary)] hover:underline"
            >
              <FiPlus className="w-3.5 h-3.5" /> {t("landingPages.addFeature")}
            </button>
          </Section>

          {/* ─── 6. Testimonials ─── */}
          {/* ─── 6. How It Works ─── */}
          <Section
            title={form.template === "akbd" ? "Why Choose Us (checkmark bullets)" : t("landingPages.howItWorks")}
            icon={form.template === "akbd" ? "💡" : "🔢"}
            open={isOpen("how_it_works")}
            onToggle={() => toggle("how_it_works")}
            visible={form.section_visibility.how_it_works !== false}
            onVisibilityToggle={() => toggleVis("how_it_works")}>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className={labelCls}>{t("landingPages.labelSectionTitle")}</label>
                <input value={form.how_it_works_title} onChange={(e) => setForm({ ...form, how_it_works_title: e.target.value })} className={inputCls} placeholder="কিভাবে ব্যবহার করবেন?" />
              </div>
              <div>
                <label className={labelCls}>{t("landingPages.labelSubtitle")}</label>
                <input value={form.how_it_works_subtitle} onChange={(e) => setForm({ ...form, how_it_works_subtitle: e.target.value })} className={inputCls} placeholder="অত্যন্ত সহজ ৪টি ধাপ" />
              </div>
            </div>
            {form.how_it_works.map((step, idx) => (
              <div key={idx} className="p-3 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 flex items-center justify-center bg-[var(--primary)] text-white text-xs font-bold rounded-full shrink-0">
                    {idx + 1}
                  </span>
                  <input
                    value={step.title}
                    onChange={(e) => {
                      const updated = [...form.how_it_works];
                      updated[idx] = { ...updated[idx], title: e.target.value };
                      updateField("how_it_works", updated);
                    }}
                    className={inputCls + " flex-1"}
                    placeholder="Step title"
                  />
                  <button
                    type="button"
                    onClick={() => updateField("how_it_works", form.how_it_works.filter((_, i) => i !== idx))}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <FiX className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={step.description}
                  onChange={(e) => {
                    const updated = [...form.how_it_works];
                    updated[idx] = { ...updated[idx], description: e.target.value };
                    updateField("how_it_works", updated);
                  }}
                  className={inputCls + " resize-none"}
                  placeholder="Step description"
                />
              </div>
            ))}
            {form.how_it_works.length < 5 && (
              <button
                type="button"
                onClick={() => updateField("how_it_works", [...form.how_it_works, { title: "", description: "" }])}
                className="flex items-center gap-1 text-xs font-medium text-[var(--primary)] hover:underline"
              >
                <FiPlus className="w-3.5 h-3.5" /> {t("landingPages.addStep")}
              </button>
            )}
            {form.how_it_works.length >= 5 && (
              <p className="text-xs text-gray-400">{t("landingPages.maxSteps")}</p>
            )}
          </Section>

          {/* ─── 7. Testimonials ─── */}
          <Section
            title={form.template === "akbd" ? "Customer Review Images (image carousel)" : t("landingPages.testimonials")}
            icon={form.template === "akbd" ? "🖼️" : "💬"}
            open={isOpen("testimonials")}
            onToggle={() => toggle("testimonials")}
            visible={form.section_visibility.testimonials !== false}
            onVisibilityToggle={() => toggleVis("testimonials")}>
            <div className="mb-3">
              <label className={labelCls}>{t("landingPages.labelSectionTitle")}</label>
              <input value={form.testimonials_title} onChange={(e) => setForm({ ...form, testimonials_title: e.target.value })} className={inputCls} placeholder="গ্রাহকদের মন্তব্য" />
            </div>

            {/* Mode selector — hidden for akbd, which always uses an image-only carousel */}
            {form.template !== "akbd" && (
            <div className="mb-4">
              <label className={labelCls}>{t("landingPages.labelSource")}</label>
              <div className="flex gap-2">
                {[
                  { id: "all_site", label: `🌐 ${t("landingPages.modeAllSite")}`, desc: t("landingPages.modeAllSiteDesc") },
                  { id: "select", label: `📋 ${t("landingPages.modeSelect")}`, desc: t("landingPages.modeSelectDesc") },
                  { id: "custom", label: `✍️ ${t("landingPages.modeCustom")}`, desc: t("landingPages.modeCustomDesc") },
                ].map((mode) => (
                  <button key={mode.id} type="button"
                    onClick={() => {
                      setForm({ ...form, testimonials_mode: mode.id });
                      if (mode.id === "select" && !siteReviewsLoaded) {
                        fetch("/api/v1/reviews/approved", { credentials: "include" }).then(r => r.json()).then(data => {
                          setSiteReviews((Array.isArray(data) ? data : []).map((r: Record<string, unknown>) => ({
                            name: (r.customer_name as string) || "", review: (r.review as string) || "",
                            rating: Number(r.rating) || 5, image: (r.image as string) || "",
                          })));
                          setSiteReviewsLoaded(true);
                        }).catch(() => {});
                      }
                    }}
                    className={`flex-1 p-3 rounded-xl text-xs font-medium text-center transition-all border-2 ${
                      form.testimonials_mode === mode.id
                        ? "border-[var(--primary)] bg-[var(--primary)]/5 text-[var(--primary)]"
                        : "border-gray-100 text-gray-500 hover:border-gray-200"
                    }`}>
                    <div className="text-sm mb-0.5">{mode.label}</div>
                    <div className="text-[10px] opacity-70">{mode.desc}</div>
                  </button>
                ))}
              </div>
            </div>
            )}

            {/* AKBD mode — image-only review screenshots. Each tile uploads one image. */}
            {form.template === "akbd" && (
              <div className="space-y-3">
                <p className="text-xs text-gray-500">Upload pre-designed review screenshots (image-only). Each image becomes a slide in the carousel — no name/rating/text needed.</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {form.testimonials.map((test, idx) => (
                    <div key={idx} className="relative rounded-xl border-2 border-gray-200 overflow-hidden aspect-[3/4] bg-gray-50">
                      {test.image ? (
                        <>
                          <SafeImg src={test.image} alt={`Review ${idx + 1}`} className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => updateField("testimonials", form.testimonials.filter((_, i) => i !== idx))}
                            className="absolute top-1.5 right-1.5 p-1 bg-red-500 text-white rounded-full shadow"
                            title="Remove"
                          ><FiX className="w-3 h-3" /></button>
                          <button
                            type="button"
                            onClick={() => { setGalleryTarget(`testimonial-${idx}`); setGalleryOpen(true); }}
                            className="absolute bottom-1.5 right-1.5 px-2 py-1 bg-white/90 rounded text-[10px] hover:bg-white"
                          >Replace</button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => { setGalleryTarget(`testimonial-${idx}`); setGalleryOpen(true); }}
                          className="w-full h-full flex flex-col items-center justify-center gap-1 text-gray-400 hover:text-[var(--primary)] hover:bg-gray-100 transition-colors"
                        >
                          <span className="text-2xl">🖼️</span>
                          <span className="text-xs">Pick image</span>
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => updateField("testimonials", [...form.testimonials, { name: "", review: "", rating: 5, image: "" }])}
                    className="rounded-xl border-2 border-dashed border-gray-300 hover:border-[var(--primary)] transition-colors aspect-[3/4] flex flex-col items-center justify-center gap-1 text-gray-400 hover:text-[var(--primary)]"
                  >
                    <FiPlus className="w-6 h-6" />
                    <span className="text-xs font-medium">Add image</span>
                  </button>
                </div>
              </div>
            )}

            {/* ALL SITE mode — no form needed, renders dynamically */}
            {form.template !== "akbd" && form.testimonials_mode === "all_site" && (
              <div className="bg-blue-50 rounded-xl p-4 text-center text-sm text-blue-700">
                {"✅"} {t("landingPages.allSiteInfo")}
              </div>
            )}

            {/* SELECT mode — browse site reviews and pick */}
            {form.template !== "akbd" && form.testimonials_mode === "select" && (
              <div className="space-y-3">
                {/* Selected reviews */}
                {form.testimonials.length > 0 && (
                  <div>
                    <p className="text-xs font-medium text-gray-500 mb-2">{t("landingPages.selected")} ({form.testimonials.length}):</p>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {form.testimonials.map((t, idx) => (
                        <div key={idx} className="flex items-center gap-2 p-2 bg-green-50 rounded-lg text-sm">
                          {t.image && <SafeImg src={t.image} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />}
                          <span className="flex-1 truncate font-medium">{t.name}</span>
                          <span className="text-xs text-gray-400">⭐{t.rating}</span>
                          <button type="button" onClick={() => updateField("testimonials", form.testimonials.filter((_, i) => i !== idx))}
                            className="p-1 text-red-400 hover:text-red-600"><FiX className="w-3 h-3" /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {/* Browse site reviews */}
                <p className="text-xs font-medium text-gray-500">{t("landingPages.availableReviews")}</p>
                <div className="max-h-64 overflow-y-auto space-y-2 border border-gray-100 rounded-xl p-2">
                  {siteReviews.length === 0 ? (
                    <p className="text-center text-xs text-gray-400 py-4">{t("landingPages.noReviews")}</p>
                  ) : siteReviews.filter(sr => !form.testimonials.some(t => t.name === sr.name && t.review === sr.review)).map((sr, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-3 bg-gray-50 rounded-lg">
                      {sr.image && <SafeImg src={sr.image} alt="" className="w-8 h-8 rounded-full object-cover shrink-0 mt-0.5" />}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm">{sr.name}</span>
                          <span className="text-xs text-amber-500">{"⭐".repeat(sr.rating)}</span>
                        </div>
                        <p className="text-xs text-gray-500 line-clamp-2 mt-0.5">{sr.review}</p>
                      </div>
                      <button type="button" onClick={() => updateField("testimonials", [...form.testimonials, sr])}
                        className="shrink-0 p-1.5 bg-[var(--primary)] text-white rounded-lg hover:bg-[var(--primary-light)] transition-colors text-xs">
                        <FiPlus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CUSTOM mode — manual entry (default template only) */}
            {form.template !== "akbd" && form.testimonials_mode === "custom" && (
              <div className="space-y-3">
                {form.testimonials.map((test, idx) => (
                  <div key={idx} className="p-3 bg-gray-50 rounded-lg space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="shrink-0">
                        {test.image ? (
                          <div className="relative w-10 h-10 rounded-full overflow-hidden border border-gray-200">
                            <SafeImg src={test.image} alt={test.name} className="w-full h-full object-cover" />
                            <button type="button" onClick={() => {
                              const updated = [...form.testimonials];
                              updated[idx] = { ...updated[idx], image: "" };
                              updateField("testimonials", updated);
                            }} className="absolute -top-0.5 -right-0.5 p-0.5 bg-red-500 text-white rounded-full">
                              <FiX className="w-2 h-2" />
                            </button>
                          </div>
                        ) : (
                          <button type="button" onClick={() => { setGalleryTarget(`testimonial-${idx}`); setGalleryOpen(true); }}
                            className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer hover:bg-gray-300 transition-colors text-gray-400 text-xs" title="Add photo">
                            📷
                          </button>
                        )}
                      </div>
                      <input value={test.name} onChange={(e) => { const u = [...form.testimonials]; u[idx] = { ...u[idx], name: e.target.value }; updateField("testimonials", u); }}
                        className={inputCls + " flex-1"} placeholder="Customer name" />
                      <div className="flex items-center gap-1">
                        <label className="text-xs text-gray-500">⭐</label>
                        <input type="number" min={1} max={5} value={test.rating}
                          onChange={(e) => { const u = [...form.testimonials]; u[idx] = { ...u[idx], rating: Math.min(5, Math.max(1, Number(e.target.value))) }; updateField("testimonials", u); }}
                          className="w-14 px-2 py-1.5 border border-gray-200 rounded-lg text-sm text-center focus:border-[var(--primary)] focus:outline-none" />
                      </div>
                      <button type="button" onClick={() => updateField("testimonials", form.testimonials.filter((_, i) => i !== idx))}
                        className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"><FiX className="w-4 h-4" /></button>
                    </div>
                    <textarea rows={2} value={test.review} onChange={(e) => { const u = [...form.testimonials]; u[idx] = { ...u[idx], review: e.target.value }; updateField("testimonials", u); }}
                      className={inputCls + " resize-none"} placeholder="Customer review" />
                  </div>
                ))}
                <button type="button" onClick={() => updateField("testimonials", [...form.testimonials, { name: "", review: "", rating: 5, image: "" }])}
                  className="flex items-center gap-1 text-xs font-medium text-[var(--primary)] hover:underline">
                  <FiPlus className="w-3.5 h-3.5" /> {t("landingPages.addTestimonial")}
                </button>
              </div>
            )}
          </Section>

          {/* ─── 8. FAQ ─── */}
          <Section title={t("landingPages.faq")} icon="❓" open={isOpen("faq")} onToggle={() => toggle("faq")}
            visible={form.section_visibility.faq !== false} onVisibilityToggle={() => toggleVis("faq")}>
            <div className="mb-3">
              <label className={labelCls}>{t("landingPages.labelSectionTitle")}</label>
              <input value={form.faq_title} onChange={(e) => setForm({ ...form, faq_title: e.target.value })} className={inputCls} placeholder="সাধারণ কিছু প্রশ্ন (FAQ)" />
            </div>
            {form.faq.map((item, idx) => (
              <div key={idx} className="p-3 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    value={item.question}
                    onChange={(e) => {
                      const updated = [...form.faq];
                      updated[idx] = { ...updated[idx], question: e.target.value };
                      updateField("faq", updated);
                    }}
                    className={inputCls + " flex-1"}
                    placeholder="Question"
                  />
                  <button
                    type="button"
                    onClick={() => updateField("faq", form.faq.filter((_, i) => i !== idx))}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <FiX className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  rows={2}
                  value={item.answer}
                  onChange={(e) => {
                    const updated = [...form.faq];
                    updated[idx] = { ...updated[idx], answer: e.target.value };
                    updateField("faq", updated);
                  }}
                  className={inputCls + " resize-none"}
                  placeholder="Answer"
                />
              </div>
            ))}
            <button
              type="button"
              onClick={() => updateField("faq", [...form.faq, { question: "", answer: "" }])}
              className="flex items-center gap-1 text-xs font-medium text-[var(--primary)] hover:underline"
            >
              <FiPlus className="w-3.5 h-3.5" /> {t("landingPages.addFaq")}
            </button>
          </Section>

          {/* ─── 9. Checkout & Thank You ─── */}
          <Section title={t("landingPages.checkoutSection")} icon="🎉" open={isOpen("checkout")} onToggle={() => toggle("checkout")}>
            {/* Akbd product picker — lives at the top of the checkout section
                because akbd doesn't render a separate Products section, but
                the checkout panel still needs ONE product to sell. */}
            {form.template === "akbd" && (
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-xl">
                <label className={labelCls}>Product to Sell</label>
                <p className="text-[11px] text-gray-500 mb-2">Pick the product the checkout form will order. First product is used.</p>
                <div className="relative">
                  <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:border-[var(--primary)] focus:outline-none bg-white"
                    placeholder={t("landingPages.searchProducts")}
                  />
                  {productSearch && filteredProducts.length > 0 && (
                    <div className="absolute z-[100] left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                      {filteredProducts.slice(0, 10).map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => addProduct(p)}
                          className="w-full text-left px-3 py-2 hover:bg-gray-50 text-sm flex items-center gap-2 transition-colors"
                        >
                          {p.image && (
                            <SafeImg src={p.image} alt={p.name} className="w-8 h-8 rounded object-cover" />
                          )}
                          <span className="flex-1 truncate">{p.name}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                {form.products.length > 0 && (
                  <div className="space-y-2 mt-2">
                    {form.products.map((entry) => (
                      <div key={entry.product_id} className="flex items-center gap-3 p-2 bg-white rounded-lg">
                        <span className="flex-1 text-sm font-medium text-gray-700 truncate">
                          {getProductName(entry.product_id)}
                        </span>
                        <div className="flex items-center gap-1">
                          <label className="text-xs text-gray-500">{t("landingPages.qty")}</label>
                          <input
                            type="number"
                            min={1}
                            value={entry.quantity}
                            onChange={(e) => updateProductQty(entry.product_id, Number(e.target.value))}
                            className="w-16 px-2 py-1 border border-gray-200 rounded text-sm text-center focus:border-[var(--primary)] focus:outline-none"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => removeProduct(entry.product_id)}
                          className="p-1 text-red-500 hover:bg-red-50 rounded transition-colors"
                        ><FiX className="w-4 h-4" /></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelCls}>{t("landingPages.labelCheckoutTitle")}</label>
                <input value={form.checkout_title} onChange={(e) => setForm({ ...form, checkout_title: e.target.value })}
                  className={inputCls} placeholder="🛒 আপনার অর্ডার দিন এখনই" />
              </div>
              <div>
                <label className={labelCls}>Order Button Text</label>
                <input value={form.checkout_btn_text} onChange={(e) => setForm({ ...form, checkout_btn_text: e.target.value })}
                  className={inputCls} placeholder="অর্ডার কনফার্ম করুন" />
              </div>
            </div>
            <div>
              <label className={labelCls}>Checkout Subtitle</label>
              <input value={form.checkout_subtitle} onChange={(e) => setForm({ ...form, checkout_subtitle: e.target.value })}
                className={inputCls} placeholder="নিচের ফরমটি পূরণ করে অর্ডারটি কনফার্ম করুন।" />
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.custom_shipping} onChange={(e) => setForm({ ...form, custom_shipping: e.target.checked })}
                  className="w-4 h-4 accent-[var(--primary)]" />
                <span className="font-medium">Custom Shipping Cost</span>
                <span className="text-xs text-gray-400">(overrides site shipping zones)</span>
              </label>
              {form.custom_shipping && (
                <div>
                  <label className={labelCls}>Fixed Shipping Cost (৳)</label>
                  <input type="number" min="0" value={form.shipping_cost} onChange={(e) => setForm({ ...form, shipping_cost: e.target.value })}
                    className={inputCls} placeholder="60" />
                  <p className="text-[10px] text-gray-400 mt-1">This fixed rate will be used instead of shipping zones</p>
                </div>
              )}
            </div>
            <div className="flex flex-wrap gap-4">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.show_email} onChange={(e) => setForm({ ...form, show_email: e.target.checked })}
                  className="w-4 h-4 accent-[var(--primary)]" />
                Show Email Field
              </label>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.show_city} onChange={(e) => setForm({ ...form, show_city: e.target.checked })}
                  className="w-4 h-4 accent-[var(--primary)]" />
                Show City Field
              </label>
            </div>
            <div>
              <label className={labelCls}>Guarantee Text</label>
              <textarea rows={2} value={form.guarantee_text} onChange={(e) => setForm({ ...form, guarantee_text: e.target.value })}
                className={inputCls + " resize-none"} placeholder="১০০% সন্তুষ্টি গ্যারান্টি" />
            </div>
            <div>
              <label className={labelCls}>Thank You Message</label>
              <textarea rows={2} value={form.success_message} onChange={(e) => setForm({ ...form, success_message: e.target.value })}
                className={inputCls + " resize-none"} placeholder="আপনার অর্ডার সফলভাবে গৃহীত হয়েছে!" />
            </div>
          </Section>

          {/* ─── 10. SEO ─── */}
          <Section title="SEO" icon="🔍" open={isOpen("seo")} onToggle={() => toggle("seo")}>
            <div>
              <label className={labelCls}>Meta Title</label>
              <input
                value={form.meta_title}
                onChange={(e) => setForm({ ...form, meta_title: e.target.value })}
                className={inputCls}
                placeholder="Page title for search engines"
              />
            </div>
            <div>
              <label className={labelCls}>Meta Description</label>
              <textarea
                rows={2}
                value={form.meta_description}
                onChange={(e) => setForm({ ...form, meta_description: e.target.value })}
                className={inputCls + " resize-none"}
                placeholder="Brief description for search engines"
              />
            </div>
          </Section>

          {/* ─── Submit ─── */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-2.5 bg-[var(--primary)] text-white rounded-xl text-sm font-semibold hover:bg-[var(--primary-light)] transition-colors disabled:opacity-50"
            >
              {saving
                ? "Saving..."
                : editId
                ? "Update"
                : "Create"}
            </button>
          </div>
        </form>
      </Modal>

      {/* Media Gallery */}
      <MediaGallery
        open={galleryOpen}
        onClose={() => setGalleryOpen(false)}
        onSelect={(url) => {
          if (galleryTarget === "hero") {
            setForm({ ...form, hero_image: url });
          } else if (galleryTarget === "features") {
            setForm({ ...form, features_image: url });
          } else if (galleryTarget === "td_doctor_photo") {
            setForm({ ...form, td_doctor_photo: url });
          } else if (galleryTarget.startsWith("testimonial-")) {
            const idx = Number(galleryTarget.split("-")[1]);
            if (!isNaN(idx) && idx >= 0 && idx < form.testimonials.length) {
              const updated = [...form.testimonials];
              updated[idx] = { ...updated[idx], image: url };
              updateField("testimonials", updated);
            }
          } else if (galleryTarget.startsWith("problem-")) {
            const idx = Number(galleryTarget.split("-")[1]);
            if (!isNaN(idx) && idx >= 0 && idx < form.problem_points.length) {
              const updated = [...form.problem_points];
              updated[idx] = { ...updated[idx], icon: url };
              updateField("problem_points", updated);
            }
          }
        }}
      />
    </DashboardLayout>
  );
}
