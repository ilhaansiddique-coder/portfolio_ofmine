"use client";

import { useState, useEffect, useRef } from "react";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import { FiCheck, FiPhone, FiMapPin, FiPackage } from "react-icons/fi";
import { toBn } from "@/utils/toBn";
import { useSiteSettings } from "@/lib/SiteSettingsContext";
import { trackThankYou } from "@/lib/analytics";
import { Editable } from "@/storefront-engine/editor/Editable";

interface OrderData {
  id: number;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  customer_address: string;
  city: string;
  subtotal: number;
  shipping_cost: number;
  total: number;
  payment_method: string;
  payment_status: string;
  transaction_id?: string;
  status: string;
  created_at: string;
  items: { id: number; product_name: string; price: number; quantity: number }[];
}

const statusLabels: Record<string, { label: string; color: string }> = {
  pending: { label: "অপেক্ষমাণ", color: "bg-yellow-100 text-yellow-800" },
  processing: { label: "প্রসেসিং", color: "bg-indigo-100 text-indigo-800" },
  on_hold: { label: "অন হোল্ড", color: "bg-orange-100 text-orange-800" },
  confirmed: { label: "নিশ্চিত", color: "bg-blue-100 text-blue-800" },
  shipped: { label: "কুরিয়ার পাঠানো হয়েছে", color: "bg-purple-100 text-purple-800" },
  delivered: { label: "ডেলিভারি সম্পন্ন", color: "bg-green-100 text-green-800" },
  cancelled: { label: "বাতিল", color: "bg-red-100 text-red-800" },
};

const paymentLabels: Record<string, string> = {
  cod: "ক্যাশ অন ডেলিভারি",
  bkash: "বিকাশ",
  nagad: "নগদ",
  bank: "ব্যাংক ট্রান্সফার",
};

export default function OrderConfirmationPage() {
  const params = useParams();
  const token = params.token as string;
  const siteSettings = useSiteSettings();
  const siteName = siteSettings.site_name || "Site";
  const sitePhone = siteSettings.phone || "";
  const [order, setOrder] = useState<OrderData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`/api/v1/orders/token/${token}`, { headers: { Accept: "application/json" } })
      .then(r => {
        if (!r.ok) throw new Error("Not found");
        return r.json();
      })
      .then(data => setOrder(data))
      .catch(() => setError("অর্ডার খুঁজে পাওয়া যায়নি।"))
      .finally(() => setLoading(false));
  }, [token]);

  // Fire a "ThankYou" event once the order receipt loads — once per order
  // (sessionStorage dedupe so a page refresh doesn't re-count it).
  const tyFired = useRef(false);
  useEffect(() => {
    if (!order || tyFired.current) return;
    tyFired.current = true;
    try {
      const k = `cd_ty_${order.id}`;
      if (sessionStorage.getItem(k)) return;
      sessionStorage.setItem(k, "1");
    } catch { /* sessionStorage unavailable — still fire once this mount */ }
    trackThankYou({
      order_id: order.id,
      value: Number(order.total) || undefined,
      content_ids: (order.items || []).map((i) => i.id),
      num_items: (order.items || []).reduce((s, i) => s + i.quantity, 0) || undefined,
    });
  }, [order]);

  if (loading) {
    return (
      <section className="py-16 bg-gray-100 min-h-[70vh]">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="animate-pulse space-y-4">
            <div className="h-16 w-16 bg-gray-200 rounded-full mx-auto" />
            <div className="h-6 bg-gray-200 rounded-xl w-64 mx-auto" />
            <div className="h-4 bg-gray-200 rounded-xl w-48 mx-auto" />
          </div>
        </div>
      </section>
    );
  }

  if (error || !order) {
    return (
      <section className="py-16 bg-gray-100 min-h-[70vh]">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-white rounded-2xl p-10 shadow-sm">
            <div className="text-4xl mb-4">😔</div>
            <h1 className="text-xl font-bold text-gray-800 mb-2">{error || "অর্ডার খুঁজে পাওয়া যায়নি"}</h1>
            <p className="text-gray-500 text-sm">এই লিঙ্কটি সঠিক নয় অথবা অর্ডারটি মুছে ফেলা হয়েছে।</p>
          </div>
        </div>
      </section>
    );
  }

  const st = statusLabels[order.status] || { label: order.status, color: "bg-gray-100 text-gray-800" };
  const steps = ["pending", "processing", "confirmed", "shipped", "delivered"];
  const currentIdx = steps.indexOf(order.status);
  const isCancelled = order.status === "cancelled" || order.status === "on_hold";

  return (
    <section className="py-8 md:py-16 bg-gray-100 min-h-[70vh]">
      <div className="max-w-2xl mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          {/* Success / Status Banner */}
          <div className="bg-white rounded-[2rem] p-6 md:p-10 shadow-xl border border-gray-100 mb-6">
            <div className="text-center mb-8">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${isCancelled ? "bg-red-100" : "bg-green-100"}`}>
                <FiCheck className={`w-8 h-8 ${isCancelled ? "text-red-600" : "text-green-600"}`} />
              </div>
              <Editable
                section="order"
                field={isCancelled ? "cancelledTitle" : "successTitle"}
                defaultValue={isCancelled ? "অর্ডার বাতিল হয়েছে" : "অর্ডার সফল হয়েছে!"}
                label={isCancelled ? "Cancelled title" : "Success title"}
              >
                {(v, ep) => (
                  <h1 {...ep} className={`text-2xl md:text-3xl font-extrabold text-gray-800 mb-2 ${ep.className ?? ""}`}>
                    {v || (isCancelled ? "অর্ডার বাতিল হয়েছে" : "অর্ডার সফল হয়েছে!")}
                  </h1>
                )}
              </Editable>
              <p className="text-gray-500 text-sm">
                <Editable section="order" field="orderNumberLabel" defaultValue="অর্ডার নম্বর:" label="Order number label">
                  {(v, ep) => <span {...ep}>{v || "অর্ডার নম্বর:"}</span>}
                </Editable>{" "}
                <span className="font-bold text-primary">#{toBn(order.id)}</span>
              </p>
              <p className="text-gray-400 text-xs mt-1">
                {new Date(order.created_at).toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>

            {/* Order Tracking */}
            {!isCancelled && (
              <div className="flex items-center mb-8 px-4 pb-6">
                {steps.map((step, i) => {
                  const isActive = i <= currentIdx;
                  const isCurrent = i === currentIdx;
                  const stepLabels: Record<string, string> = {
                    pending: "অপেক্ষমাণ", processing: "প্রসেসিং", confirmed: "নিশ্চিত", shipped: "কুরিয়ার", delivered: "ডেলিভারি"
                  };
                  return (
                    <div key={step} className="flex items-center" style={{ flex: i < steps.length - 1 ? 1 : "none" }}>
                      {/* Fixed-width circle column; label is absolutely
                          positioned so its (variable) Bangla width can't
                          push the circles apart — every connector stays an
                          equal flex-1, so spacing is uniform. */}
                      <div className="relative w-7 shrink-0">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${isCurrent ? "bg-primary text-white ring-2 ring-primary/30" : isActive ? "bg-primary text-white" : "bg-gray-200 text-gray-400"}`}>
                          {isActive ? "✓" : toBn(i + 1)}
                        </div>
                        <span className={`absolute left-1/2 -translate-x-1/2 top-full mt-1 text-[10px] whitespace-nowrap ${isActive ? "text-primary font-semibold" : "text-gray-400"}`}>{stepLabels[step]}</span>
                      </div>
                      {i < steps.length - 1 && <div className={`flex-1 h-0.5 mx-1 ${i < currentIdx ? "bg-primary" : "bg-gray-200"}`} />}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Status Badge */}
            <div className="flex justify-center mb-6">
              <span className={`text-sm px-4 py-1.5 rounded-full font-semibold ${st.color}`}>{st.label}</span>
            </div>

            {/* Customer Info */}
            <div className="bg-gray-50 rounded-2xl p-5 space-y-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <FiPackage className="w-4 h-4 text-primary shrink-0" />
                <span className="font-semibold">{order.customer_name}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <FiPhone className="w-4 h-4 text-gray-400 shrink-0" />
                <span>{order.customer_phone}</span>
              </div>
              <div className="flex items-start gap-2 text-sm text-gray-600">
                <FiMapPin className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
                <span>{order.customer_address}{order.city ? `, ${order.city}` : ""}</span>
              </div>
            </div>

            {/* Items */}
            <div className="space-y-3 mb-6">
              <Editable section="order" field="itemsHeading" defaultValue="অর্ডারকৃত পণ্য" label="Items heading">
                {(v, ep) => (
                  <h3 {...ep} className={`font-bold text-sm text-gray-700 px-1 ${ep.className ?? ""}`}>
                    {v || "অর্ডারকৃত পণ্য"}
                  </h3>
                )}
              </Editable>
              {order.items.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div>
                    <p className="text-sm font-medium text-gray-800">{item.product_name}</p>
                    <p className="text-xs text-gray-400">{toBn(item.quantity)}টি × ৳{toBn(item.price)}</p>
                  </div>
                  <span className="text-sm font-bold text-primary">৳{toBn(item.price * item.quantity)}</span>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="bg-gray-50 rounded-2xl p-5 space-y-2">
              <div className="flex justify-between text-sm">
                <Editable section="order" field="subtotalLabel" defaultValue="সাবটোটাল" label="Subtotal label">
                  {(v, ep) => <span {...ep} className={`text-gray-500 ${ep.className ?? ""}`}>{v || "সাবটোটাল"}</span>}
                </Editable>
                <span className="font-semibold">৳{toBn(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <Editable section="order" field="shippingLabel" defaultValue="শিপিং চার্জ" label="Shipping label">
                  {(v, ep) => <span {...ep} className={`text-gray-500 ${ep.className ?? ""}`}>{v || "শিপিং চার্জ"}</span>}
                </Editable>
                <span className="font-semibold">৳{toBn(order.shipping_cost)}</span>
              </div>
              <div className="flex justify-between text-lg font-extrabold pt-2 border-t-2 border-primary/20">
                <Editable section="order" field="totalLabel" defaultValue="সর্বমোট" label="Total label">
                  {(v, ep) => <span {...ep}>{v || "সর্বমোট"}</span>}
                </Editable>
                <span className="text-primary">৳{toBn(order.total)}</span>
              </div>
            </div>

            {/* Payment Info */}
            <div className="mt-4 flex flex-wrap gap-2 justify-center">
              <span className="text-xs px-3 py-1.5 rounded-full bg-gray-100 text-gray-600">
                {paymentLabels[order.payment_method] || order.payment_method}
              </span>
              <Editable
                section="order"
                field={order.payment_status === "paid" ? "paymentPaidLabel" : "paymentDueLabel"}
                defaultValue={order.payment_status === "paid" ? "পেমেন্ট সম্পন্ন" : "পেমেন্ট বাকি"}
                label={order.payment_status === "paid" ? "Paid badge" : "Unpaid badge"}
              >
                {(v, ep) => (
                  <span {...ep} className={`text-xs px-3 py-1.5 rounded-full font-medium ${order.payment_status === "paid" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"} ${ep.className ?? ""}`}>
                    {v || (order.payment_status === "paid" ? "পেমেন্ট সম্পন্ন" : "পেমেন্ট বাকি")}
                  </span>
                )}
              </Editable>
              {order.transaction_id && (
                <span className="text-xs px-3 py-1.5 rounded-full bg-blue-100 text-blue-700">
                  TrxID: {order.transaction_id}
                </span>
              )}
            </div>

            {/* Footer */}
            <div className="mt-8 text-center">
              <Editable section="order" field="thankYouMessage" defaultValue="ধন্যবাদ আপনার অর্ডারের জন্য! শীঘ্রই আমরা যোগাযোগ করব।" label="Thank-you message">
                {(v, ep) => (
                  <p {...ep} className={`text-xs text-gray-400 ${ep.className ?? ""}`}>
                    {v || "ধন্যবাদ আপনার অর্ডারের জন্য! শীঘ্রই আমরা যোগাযোগ করব।"}
                  </p>
                )}
              </Editable>
              <p className="text-xs text-gray-400 mt-1">{[siteName, sitePhone].filter(Boolean).join(" | ")}</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
