import type { ComponentType } from "react";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import GoCartCartPage from "@/themes/go-cart/pages/CartPage";
import type { CartPageProps } from "@/storefront-engine/types/pages";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Cart",
};

export default async function CartRoute() {
  const theme = await getActiveTheme();
  let ActivePage: ComponentType<CartPageProps> = GoCartCartPage;

  if (theme.pages.loadCartPage) {
    try {
      ActivePage = await theme.pages.loadCartPage();
    } catch {
      ActivePage = GoCartCartPage;
    }
  }

  return (
    <div className={`theme-${theme.id}`}>
      <ThemeErrorBoundary themeId={theme.id} fallback={<GoCartCartPage />}>
        <ActivePage />
      </ThemeErrorBoundary>
    </div>
  );
}
