/**
 * /terms — thin shell.
 *
 * Loads the tenant's saved terms content, resolves the active
 * storefront theme, and renders the theme's TermsPage when one is
 * registered. Falls back to the legacy default-theme TermsView when
 * the active theme has no override — preserves backward compatibility
 * for tenants on the default theme.
 */

import type { ComponentType } from "react";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSetting } from "@/lib/settingsCache";
import type { PrismaClient } from "@prisma/client";
import { toBilingual, type Bilingual } from "@/lib/bilingual";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { PolicyContent, TermsPageProps } from "@/storefront-engine/types/pages";
import TermsView from "./TermsView";

export const dynamic = "force-dynamic";

interface PolicySection { title: Bilingual; content: Bilingual }

const DEFAULT_TERMS: PolicyContent = {
  title: { en: "Terms & Conditions", bn: "শর্তাবলী" },
  lastUpdated: { en: "January 1, 2025", bn: "১ জানুয়ারি ২০২৫" },
  intro: {
    en: "Please read these terms and conditions carefully before using our website and services.",
    bn: "আমাদের ওয়েবসাইট ও সেবা ব্যবহার করার আগে অনুগ্রহ করে এই শর্তাবলী মনোযোগ দিয়ে পড়ুন।",
  },
  sections: [],
};

function normalizePolicy(raw: unknown, fallback: PolicyContent): PolicyContent {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const sections = Array.isArray(r.sections) ? r.sections : fallback.sections;
  return {
    title: toBilingual(r.title ?? fallback.title),
    lastUpdated: toBilingual(r.lastUpdated ?? fallback.lastUpdated),
    intro: toBilingual(r.intro ?? fallback.intro),
    sections: sections.map((s) => {
      const o = (s && typeof s === "object" ? s : {}) as Record<string, unknown>;
      return { title: toBilingual(o.title), content: toBilingual(o.content) } as PolicySection;
    }),
  };
}

async function getContent(prisma: PrismaClient, tenantId: number): Promise<PolicyContent> {
  try {
    const value = await getSetting(prisma, tenantId, "page_terms");
    if (value) return normalizePolicy(JSON.parse(value), DEFAULT_TERMS);
  } catch { /* */ }
  return DEFAULT_TERMS;
}

async function resolveLang(prisma: PrismaClient, tenantId: number): Promise<"en" | "bn"> {
  try {
    const value = await getSetting(prisma, tenantId, "site_language");
    if (value === "bn" || value === "en") return value;
  } catch { /* */ }
  return "en";
}

export async function generateMetadata(): Promise<Metadata> {
  const { prisma, tenant } = await getPrismaForRequest();
  const content = await getContent(prisma, tenant.id);
  return {
    title: content.title.bn || content.title.en || "Terms & Conditions",
    description: content.intro.bn || content.intro.en,
  };
}

export default async function TermsRoute() {
  const { prisma, tenant } = await getPrismaForRequest();
  const [content, lang] = await Promise.all([
    getContent(prisma, tenant.id),
    resolveLang(prisma, tenant.id),
  ]);
  await headers();

  let ActivePage: ComponentType<TermsPageProps> | null = null;
  let activeThemeId = "default";
  try {
    const theme = await getActiveTheme();
    activeThemeId = theme.id;
    if (theme.pages.loadTermsPage) {
      ActivePage = await theme.pages.loadTermsPage().catch(() => null);
    }
  } catch { /* fall through to legacy view */ }

  if (ActivePage) {
    return (
      <div className={`theme-${activeThemeId}`}>
        <ThemeErrorBoundary themeId={activeThemeId} fallback={<TermsView content={content} />}>
          <ActivePage content={content} lang={lang} />
        </ThemeErrorBoundary>
      </div>
    );
  }

  return <TermsView content={content} />;
}
