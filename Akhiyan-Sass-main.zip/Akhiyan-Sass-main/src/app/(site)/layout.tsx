import type { Metadata } from "next";
import { cache } from "react";
import { unstable_cache } from "next/cache";
import { Hind_Siliguri, Playfair_Display, Manrope, Bricolage_Grotesque } from "next/font/google";
import "../globals.css";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { UI_PREF_COOKIE } from "@/lib/ui-prefs";
import ClientLayout from "@/components/ClientLayout";
import DashboardDarkScope from "@/components/DashboardDarkScope";
import ImpersonationBanner from "@/components/ImpersonationBanner";
import HeadScripts from "@/components/HeadScripts";
import StorefrontFeaturesWatcher from "@/components/StorefrontFeaturesWatcher";
import StorefrontUnavailable from "@/components/StorefrontUnavailable";
import TenantExpired from "@/components/TenantExpired";
import { maybeGetPrismaForRequest } from "@/lib/prisma-tenant";
import { lookupTenantByHostAnyStatus } from "@/lib/tenant";
import { validityState } from "@/lib/tenant-validity";
import { buildThemeCss } from "@/lib/theme-tokens";
import { autoCaptureSiteUrl } from "@/lib/auto-site-url";
import { featureKeyForStorefrontPath } from "@/lib/storefront-route-features";
import { getRootRedirectSlug } from "@/lib/lp-root-redirect";
import { landingSlugFromHeaders, isActiveLandingPage } from "@/lib/landing-page-detect";
import { isPublishedCmsPage } from "@/lib/cms-page-detect";
import { logShortlinkClick } from "@/lib/shortlink-click";
import { hasFeature, type TenantFeatures } from "@/lib/tenant-features";
import type { PrismaClient } from "@prisma/client";
import { getActiveStorefrontTheme } from "@/lib/storefront-themes/active";
import { THEME_FONT_VARIABLE_CLASSES, getThemeFontVariable } from "@/lib/storefront-themes/fonts";
import { getActiveTheme as getActiveThemeV2 } from "@/storefront-engine/loader";
import { loadThemeOverrides } from "@/storefront-engine/editor/loadOverrides";
import type { OverridesMap } from "@/storefront-engine/editor/EditModeContext";
import type { ComponentType } from "react";
import type { NavbarProps, FooterProps, CartDrawerProps } from "@/storefront-engine/types/pages";

// Font loading strategy (perf-tuned for mobile LCP):
//   - PRIMARY body font (Hind Siliguri) is display: "swap" + preload.
//     Previously "block" — but FOIT (invisible text until the Bengali WOFF2
//     arrives) was the single biggest mobile render-blocking cost (~1.4s on
//     PageSpeed). With "swap" the system fallback paints instantly and the
//     webfont swaps in. adjustFontFallback keeps fallback metrics matched so
//     the swap causes no visible reflow / CLS. preload stays so the real
//     font still arrives ASAP and the swap happens early.
//   - HEADING font (Bricolage) moved to display: "swap" + dropped preload.
//     "block" was hiding hero h1 text until the WOFF2 arrived, killing LCP
//     on slow mobile networks. With "swap" the system fallback paints
//     instantly, then the webfont swaps in (adjustFontFallback prevents
//     visible reflow).
//   - Secondary fonts (Playfair, Manrope) keep "swap" — only used in
//     customizer-selectable spots, never on the critical path.
//   - Weights trimmed to the ones the UI actually renders. Each extra
//     weight = a separate WOFF2 fetch.
//   - All four are kept declared because the dashboard customizer lets
//     admins pick any of them as the live heading/body font.
const hindSiliguri = Hind_Siliguri({
  variable: "--font-hind-siliguri",
  subsets: ["bengali", "latin"],
  weight: ["400", "500", "700"],
  display: "swap",
  preload: true,
  adjustFontFallback: true,
});


const playfairDisplay = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  weight: ["400", "700"],
  display: "swap",
  adjustFontFallback: true,
});

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  weight: ["400", "600"],
  display: "swap",
  adjustFontFallback: true,
});

const bricolage = Bricolage_Grotesque({
  variable: "--font-bricolage",
  subsets: ["latin"],
  weight: ["500", "700"],
  display: "swap",
  preload: false,
  adjustFontFallback: true,
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

// Two layers of caching keep this off Postgres:
//
//  1. `unstable_cache` — cross-request shared cache, 60s TTL, tagged so the
//     admin Settings PUT (which calls revalidateAll("settings")) busts it
//     immediately. Settings change rarely; 60s lag is fine for SEO/branding.
//  2. `cache()` — per-request dedupe so the metadata generator and the
//     SiteSettingsContext provider (both called in the same render pipeline)
//     share one fetch instead of two.
//
// Before this layer, every page load did 2 full `siteSetting.findMany()`
// queries — pg_stat_activity showed it hammering Neon every ~3s.
// Tenant-keyed cache: each tenant gets its own settings cache slot, revalidated
// by tag `t${tenantId}:settings` so admin saves on tenant A don't bust tenant B.
function makeFetchSiteSettings(prisma: PrismaClient, tenantId: number) {
  return unstable_cache(
    async (): Promise<Record<string, string | null>> => {
      const rows = await prisma.siteSetting.findMany({
        select: { key: true, value: true },
      });
      const out: Record<string, string | null> = {};
      for (const r of rows) out[r.key] = r.value ?? null;
      return out;
    },
    [`t${tenantId}:site-settings`],
    { tags: [`t${tenantId}:settings`], revalidate: 60 },
  );
}
const loadSiteSettings = cache(async (prisma: PrismaClient, tenantId: number): Promise<Record<string, string | null>> => {
  try { return await makeFetchSiteSettings(prisma, tenantId)(); }
  catch { return {}; }
});

export async function generateMetadata(): Promise<Metadata> {
  const ctx = await maybeGetPrismaForRequest();
  if (!ctx) return { title: "Store not found" };
  const { prisma, tenant } = ctx;
  const settings = await loadSiteSettings(prisma, tenant.id);
  const siteName = settings.site_name || "Site";
  const description = settings.site_description || settings.meta_description || "";
  const logo = settings.site_logo || "/logo.png";
  // Favicon comes from the dashboard setting; fall back to the site logo, then a default.
  // Append a short hash so browsers refetch when the admin uploads a new one.
  const faviconRaw = settings.favicon || settings.site_logo || "/logo.png";
  const faviconVersion = (faviconRaw.match(/\d{6,}/)?.[0] ?? "1").slice(-6);
  const faviconUrl = `${faviconRaw}${faviconRaw.includes("?") ? "&" : "?"}v=${faviconVersion}`;
  const faviconType = faviconRaw.toLowerCase().endsWith(".svg")
    ? "image/svg+xml"
    : faviconRaw.toLowerCase().endsWith(".ico")
      ? "image/x-icon"
      : "image/png";
  return {
    title: {
      default: siteName,
      template: `%s — ${siteName}`,
    },
    description,
    metadataBase: new URL(SITE_URL),
    icons: {
      icon: [{ url: faviconUrl, type: faviconType }],
      shortcut: [{ url: faviconUrl, type: faviconType }],
      apple: [{ url: faviconUrl }],
    },
    // Pin the current tenant id into a meta tag so the client realtime hook
    // can pick it up without an extra round-trip.
    other: { "x-tenant-id": String(tenant.id) },
    openGraph: {
      type: "website",
      siteName,
      title: siteName,
      description,
      url: SITE_URL,
      images: [{ url: logo, width: 512, height: 512, alt: siteName }],
    },
    twitter: {
      card: "summary_large_image",
      title: siteName,
      description,
      images: [logo],
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const ctx = await maybeGetPrismaForRequest();
  if (!ctx) {
    // Host didn't resolve to an ACTIVE tenant. Distinguish a suspended/expired
    // tenant (→ friendly renew page) from a truly-unknown host (→ generic 404).
    const h = await headers();
    const raw = await lookupTenantByHostAnyStatus(h.get("host"));
    if (raw && (raw.status === "suspended" || validityState(raw.expiresAt).state === "expired")) {
      const daysAgo = raw.expiresAt ? Math.abs(validityState(raw.expiresAt).daysLeft ?? 0) : null;
      return <TenantExpired tenantName={raw.name} daysAgo={daysAgo} />;
    }
    return <TenantNotFoundShell />;
  }
  const { prisma, tenant } = ctx;

  // Dynamic expiry enforcement. The suspension cron flips status→suspended, but
  // it only fires if a scheduler hits /api/v1/cron/tenant-expiry. To make
  // expiry work regardless, also block an active-but-lapsed tenant here: an
  // active row whose expiresAt has passed renders the renew page immediately.
  {
    const v = validityState((tenant as { expiresAt?: Date | null }).expiresAt ?? null);
    if (v.state === "expired") {
      return <TenantExpired tenantName={tenant.name} daysAgo={Math.abs(v.daysLeft ?? 0)} />;
    }
  }

  // Tenant feature map (used for route gating + minimal-chrome decision).
  const tenantFeatures = (tenant as { features?: TenantFeatures }).features ?? null;
  // Landing-page-only tenants have the storefront master switch OFF. The
  // /order receipt is intentionally ungated (NEVER_GATE) so it still works
  // for them — but it must NOT show the storefront Navbar/Footer.
  const storefrontEnabled = hasFeature(tenantFeatures, "storefront.enabled");

  // ── Authoritative clean-root-URL detection (DB, not URL heuristic) ──
  // Both landing pages AND Puck CMS pages live at clean root URLs (/about) that
  // the proxy rewrites to /lp/<slug>. We confirm against the DB which kind it
  // is. This drives the feature gate (LP → catalog.landing_pages; CMS →
  // content.pages; neither → the normal storefront rule) AND the chrome
  // decision: ONLY landing pages render chrome-less — CMS pages keep the
  // navbar/footer so they look like normal storefront pages. React.cache +
  // unstable_cache dedupe the lookups within and across requests.
  const { isLandingPageRoute, isCmsPageRoute } = await (async () => {
    const h = await headers();
    const candidate = landingSlugFromHeaders(h.get("x-pathname") || "", h.get("x-lp-clean"));
    if (!candidate) return { isLandingPageRoute: false, isCmsPageRoute: false };
    const isLp = await isActiveLandingPage(prisma, tenant.id, candidate);
    if (isLp) return { isLandingPageRoute: true, isCmsPageRoute: false };
    const isCms = await isPublishedCmsPage(prisma, tenant.id, candidate);
    return { isLandingPageRoute: false, isCmsPageRoute: isCms };
  })();

  // ── Base-URL shortlink ──
  // A shortlink with an EMPTY slug is the tenant's root ("/") redirect: hitting
  // the base URL forwards to its target. Resolved here (before the storefront
  // gate) so it works whether the storefront is on or off, and takes
  // precedence over the LP root-redirect setting. redirect() throws
  // NEXT_REDIRECT, so resolve the target OUTSIDE the try/catch and call last.
  {
    const h = await headers();
    const path = h.get("x-pathname") || "";
    if (path === "/") {
      let rootTarget: string | null = null;
      try {
        const rootLink = await prisma.shortlink.findUnique({ where: { slug: "" } });
        if (rootLink?.isActive && rootLink.targetUrl) {
          await logShortlinkClick(prisma, rootLink.id, h);
          rootTarget = rootLink.targetUrl;
        }
      } catch { /* no root shortlink / table missing — fall through */ }
      if (rootTarget) redirect(rootTarget);
    }
  }

  // Gate storefront/landing-page features before doing any further work.
  {
    const h = await headers();
    const path = h.get("x-pathname") || "";
    // Landing pages gate ONLY on catalog.landing_pages and CMS pages ONLY on
    // content.pages — NEVER on the storefront master switch. Both flags are the
    // authoritative DB checks above, so turning storefront OFF leaves LPs/CMS
    // pages reachable as long as their own toggle is ON; a stray slug that is
    // neither still gates normally.
    const required = isLandingPageRoute
      ? ("catalog.landing_pages" as ReturnType<typeof featureKeyForStorefrontPath>)
      : isCmsPageRoute
        ? ("content.pages" as ReturnType<typeof featureKeyForStorefrontPath>)
        : featureKeyForStorefrontPath(path);
    if (required) {
      if (!hasFeature(tenantFeatures, required)) {
        // Storefront-disabled tenant hitting the bare root. We do NOT redirect
        // to a landing page by default — the default is the "Coming soon" stub
        // below. Redirect ONLY when the admin explicitly opted in by toggling
        // "Base URL redirect" on a landing page (root_redirect_lp_slug). A
        // base-URL shortlink, the other opt-in, is handled earlier (before this
        // gate). Redirect to the CLEAN URL (/<slug>); the proxy rewrites it and
        // the DB check re-gates on catalog.landing_pages, so it renders
        // chrome-less even with storefront off. redirect() throws NEXT_REDIRECT,
        // so resolve the target OUTSIDE any try/catch and call it last.
        if (path === "/" && !storefrontEnabled) {
          let target: string | null = null;
          try {
            const slug = await getRootRedirectSlug(prisma);
            if (slug) {
              const lp = await prisma.landingPage.findUnique({
                where: { slug },
                select: { isActive: true },
              });
              if (lp?.isActive) target = `/${slug}`;
            }
          } catch { /* fall through to unavailable */ }
          if (target) redirect(target);
        }
        return <StorefrontUnavailable />;
      }
    }
  }

  // Load all site settings server-side so the SiteSettingsContext hydrates synchronously.
  // This eliminates the logo flash on reload caused by the previous client-side fetch.
  const allSettings = await loadSiteSettings(prisma, tenant.id);

  // STRIP PRIVATE KEYS before passing to the client. SiteSettingsContext is
  // serialized into the HTML payload that ships to every visitor's browser
  // — without this filter, FB CAPI tokens, SMTP password, courier creds,
  // etc. would be readable by anyone hitting View Source. Mirrors the same
  // PRIVATE_KEYS list the public /api/v1/settings endpoint enforces.
  const PRIVATE_KEYS = new Set([
    "fb_capi_access_token",
    "fb_test_event_code",
    "steadfast_api_key",
    "steadfast_secret_key",
    "smtp_pass",
    "smtp_user",
    "pathao_client_id",
    "pathao_client_secret",
    "pathao_username",
    "pathao_password",
    "pathao_access_token",
    "pathao_refresh_token",
    "pathao_token_expires_at",
    "pathao_web_token",
    "pathao_web_token_auto",
    "admin_email",
  ]);
  const settings: Record<string, string | null> = {};
  for (const k of Object.keys(allSettings)) {
    if (!PRIVATE_KEYS.has(k)) settings[k] = allSettings[k];
  }

  // Auto-capture the production site URL from the request host the first time
  // a non-local request reaches us. Fixes localhost-link-in-emails forever
  // without requiring the admin to set NEXT_PUBLIC_SITE_URL or APP_URL by hand.
  // Idempotent + non-blocking — a no-op once set.
  void autoCaptureSiteUrl(prisma, tenant.id);
  const fbDomainVerification = settings.fb_domain_verification || null;
  const siteName = settings.site_name || "Site";
  const siteLogoUrl = settings.site_logo
    ? (settings.site_logo.startsWith("http") ? settings.site_logo : `${SITE_URL}${settings.site_logo}`)
    : `${SITE_URL}/logo.png`;
  const orgPhone = settings.phone || "";
  const sameAs = [settings.facebook, settings.instagram, settings.youtube].filter(Boolean) as string[];

  // Build the theme CSS variables block from saved customizer tokens.
  // Rendered into <head> so it overrides the defaults in globals.css before paint (no FOUC).
  const themeCss = buildThemeCss(settings);

  // Resolve the active language SERVER-SIDE so initial paint already matches
  // the user's saved preference. Without this, every dashboard refresh would
  // flash Bangla → English (or vice-versa) as the client useEffect catches up.
  // Path comes from middleware via the x-pathname header.
  const reqHeaders = await headers();
  const pathname = reqHeaders.get("x-pathname") || "";
  const isDashboardPath = pathname.startsWith("/dashboard");
  // isLandingPageRoute computed above from the authoritative DB check — used
  // here to hide the storefront navbar/footer on landing pages.
  const dashboardLang = (settings.dashboard_language === "en" ? "en" : settings.dashboard_language === "bn" ? "bn" : "en");
  const siteLang = (settings.site_language === "en" ? "en" : "bn");
  const initialLang: "en" | "bn" = isDashboardPath ? dashboardLang as "en" | "bn" : siteLang;
  const langClass = initialLang === "en" ? "lang-en" : "lang-bn";

  // Read saved dark-mode cookie so SSR ships <html class="dark"> on the very
  // first byte — no light→dark flicker on refresh. Dark mode is intentionally
  // SCOPED TO THE DASHBOARD ONLY — the customer-facing storefront stays light
  // regardless of the admin's preference (the storefront is the brand surface
  // shoppers see and shouldn't follow the operator's personal UI choice).
  const cookieStore = await cookies();
  const isDark = cookieStore.get(UI_PREF_COOKIE.darkMode)?.value === "1";
  const darkClass = isDark && isDashboardPath ? "dark" : "";

  // Active storefront theme — only applies on storefront pages (the
  // dashboard surface keeps the default site fonts regardless of which
  // theme the tenant picked for shoppers). When the active theme
  // declares a custom font, we add its CSS-variable class to <html>
  // AND inject a body-level style that overrides the default sans stack
  // for storefront pages only.
  const activeTheme = isDashboardPath ? null : await getActiveStorefrontTheme().catch(() => null);
  const themeFontClass = activeTheme ? (THEME_FONT_VARIABLE_CLASSES[activeTheme.id] ?? "") : "";
  const themeFontVar = activeTheme ? getThemeFontVariable(activeTheme.id) : null;

  // Resolve theme CHROME (Navbar + Footer) from the v2 engine. The picker
  // already wrote the same id into the v1 setting, so v1 + v2 stay aligned.
  // Chrome lives on every storefront page, so we resolve here in the layout
  // (not in route shells) and pass the component refs into ClientLayout.
  // If the active theme has no chrome override or the dynamic import fails,
  // ClientLayout falls back to the default site chrome.
  let activeNavbarComponent: ComponentType<NavbarProps> | null = null;
  let activeFooterComponent: ComponentType<FooterProps> | null = null;
  let activeCartDrawerComponent: ComponentType<CartDrawerProps> | null = null;
  if (!isDashboardPath) {
    try {
      const themeV2 = await getActiveThemeV2();
      if (themeV2.chrome?.loadNavbar) {
        activeNavbarComponent = await themeV2.chrome.loadNavbar().catch(() => null);
      }
      if (themeV2.chrome?.loadFooter) {
        activeFooterComponent = await themeV2.chrome.loadFooter().catch(() => null);
      }
      if (themeV2.chrome?.loadCartDrawer) {
        activeCartDrawerComponent = await themeV2.chrome.loadCartDrawer().catch(() => null);
      }
    } catch { /* engine unreachable — fall through to default chrome */ }
  }

  // Theme scope class — wraps the entire storefront body so theme-scoped
  // CSS (`:where(.theme-go-cart) ...`) matches inside chrome + content.
  // Dashboard pages get no theme class so dashboard styling stays neutral.
  const themeScopeClass = !isDashboardPath && activeTheme ? `theme-${activeTheme.id}` : "";

  // Per-tenant theme content overrides (admin's edits via the inline
  // editor). Loaded once here in the layout — shared across every
  // storefront page during the same request via the unstable_cache slot
  // in `loadThemeOverrides`. Empty object on dashboard or when the
  // tenant has never edited.
  let themeContentOverrides: OverridesMap = {};
  if (!isDashboardPath && activeTheme) {
    themeContentOverrides = await loadThemeOverrides(activeTheme.id, initialLang);
  }

  return (
    <html lang={initialLang} className={`${hindSiliguri.variable} ${playfairDisplay.variable} ${manrope.variable} ${bricolage.variable} ${themeFontClass} ${themeScopeClass} antialiased ${langClass} ${darkClass}`} data-scroll-behavior="smooth" suppressHydrationWarning>
      <head>
        {fbDomainVerification && (
          <meta name="facebook-domain-verification" content={fbDomainVerification} />
        )}
        {/* Resource hints: warm up TLS to hot 3rd-party origins before the
            browser even discovers their requests. Saves 100-300ms on slow
            mobile. preconnect = full handshake; dns-prefetch = name only.
            CDN gets full preconnect (every page hits it for images).
            Tracking gets dns-prefetch only (tracking is deferred via
            ClientLayout, full preconnect would waste a connection slot). */}
        <link rel="preconnect" href={process.env.CDN_BASE_URL || `https://cdn.${process.env.BASE_DOMAIN || "contradigital.agency"}`} crossOrigin="" />
        <link rel="dns-prefetch" href="https://connect.facebook.net" />
        <link rel="dns-prefetch" href="https://www.googletagmanager.com" />
        <link rel="dns-prefetch" href="https://www.google-analytics.com" />
        <link rel="dns-prefetch" href="https://www.clarity.ms" />
        <style id="theme-tokens" dangerouslySetInnerHTML={{ __html: themeCss }} />
        {/* Theme font override — only present when the active storefront
          * theme declares its own font (e.g. "go-cart" → Outfit).
          * Specificity + !important match the lang-en rule in globals.css
          * line 313-316 (which itself uses !important) so the theme font
          * wins on Latin text. Bangla pages keep Hind Siliguri because
          * Outfit has no বাংলা glyph coverage. */}
        {themeFontVar && themeScopeClass && (
          <style id="theme-storefront-font" dangerouslySetInnerHTML={{ __html: `
            /* Theme font override. Chained with the theme scope class
               (e.g. .theme-go-cart) so it raises specificity above the
               site-wide globals.css rules at line 313-316 + 364-368 which
               use \`html.lang-en *\` + \`!important\` to force Bricolage
               on every element. Without the theme prefix, the universal
               selector rule wins via source order. */
            html.${themeScopeClass}.lang-en body,
            html.${themeScopeClass}.lang-en *,
            html.${themeScopeClass}.lang-en *::before,
            html.${themeScopeClass}.lang-en *::after,
            html.${themeScopeClass}.lang-en input,
            html.${themeScopeClass}.lang-en textarea,
            html.${themeScopeClass}.lang-en select,
            html.${themeScopeClass}.lang-en button,
            html.${themeScopeClass}.lang-en h1,
            html.${themeScopeClass}.lang-en h2,
            html.${themeScopeClass}.lang-en h3,
            html.${themeScopeClass}.lang-en h4,
            html.${themeScopeClass}.lang-en h5,
            html.${themeScopeClass}.lang-en h6 {
              font-family: var(${themeFontVar}), system-ui, -apple-system, "Segoe UI", sans-serif !important;
            }
            html.${themeScopeClass}.lang-bn body {
              font-family: var(--font-hind-siliguri), "Hind Siliguri", system-ui, sans-serif !important;
            }
          ` }} />
        )}
      </head>
      <body className="min-h-screen bg-background" suppressHydrationWarning>
        {/* Always-visible top banner if super-admin impersonation is active.
            Renders nothing otherwise. */}
        <ImpersonationBanner />
        {/* React 19 refuses to render inline <script> in JSX (even via next/script).
            HeadScripts is a client-only side-effect component that injects
            the JSON-LD + js-ready class via the DOM API after mount. */}
        <HeadScripts
          orgJsonLd={{
            "@context": "https://schema.org",
            "@type": "Organization",
            name: siteName,
            url: SITE_URL,
            logo: siteLogoUrl,
            ...(orgPhone && {
              contactPoint: {
                "@type": "ContactPoint",
                telephone: orgPhone,
                contactType: "customer service",
                availableLanguage: ["Bengali", "English"],
              },
            }),
            ...(sameAs.length > 0 && { sameAs }),
          }}
        />
        <StorefrontFeaturesWatcher />
        <DashboardDarkScope />
        <ClientLayout
          initialSettings={settings}
          initialLang={initialLang}
          storefrontEnabled={storefrontEnabled}
          NavbarComponent={activeNavbarComponent}
          FooterComponent={activeFooterComponent}
          CartDrawerComponent={activeCartDrawerComponent}
          storefrontThemeId={activeTheme?.id ?? null}
          themeContentOverrides={themeContentOverrides}
          isLandingPageRoute={isLandingPageRoute}
        >{children}</ClientLayout>
      </body>
    </html>
  );
}

/**
 * Standalone HTML shell shown when the request hostname doesn't resolve to
 * any registered tenant. No Navbar/Footer/providers — this is what visitors
 * to a misspelled or unprovisioned subdomain land on.
 */
function TenantNotFoundShell() {
  return (
    <html lang="en">
      <body
        className="min-h-screen bg-zinc-50 text-zinc-900"
        style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' }}
      >
        <main className="grid min-h-screen place-items-center px-6">
          <div className="max-w-sm text-center">
            <p className="text-xs font-semibold uppercase tracking-wider text-zinc-400">404</p>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">Store not found</h1>
            <p className="mt-3 text-sm text-zinc-500">
              No active store is registered for this address. If you&apos;re the owner, check the
              subdomain or contact support.
            </p>
          </div>
        </main>
      </body>
    </html>
  );
}
