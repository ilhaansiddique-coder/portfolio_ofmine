"use client";

import { useEffect } from "react";
import Link from "next/link";
import { FiAlertTriangle, FiHome, FiRefreshCw } from "react-icons/fi";

// Stale-chunk detection: after a deploy the JS chunk hashes rotate, so HTML
// cached by the browser/CDN points at chunk files that 404. The dynamic-import
// failure is caught HERE (render phase), not by the global window listener, so
// we self-heal at the boundary: hard-reload once to fetch fresh HTML. A
// sessionStorage guard stops an infinite loop if the fresh HTML is also stale
// (e.g. still cached at the CDN edge → needs a purge, not another reload).
function isChunkError(msg: string): boolean {
  return /Loading chunk [\w-]+ failed|Failed to load chunk|ChunkLoadError|error loading dynamically imported module|Importing a module script failed|Loading CSS chunk/i.test(msg);
}

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("App error:", error);
    if (typeof window !== "undefined" && isChunkError(error?.message || error?.name || "")) {
      const KEY = "cd_chunk_reload_at";
      let last = 0;
      try { last = Number(sessionStorage.getItem(KEY) || 0); } catch { /* ignore */ }
      if (Date.now() - last > 10_000) {
        try { sessionStorage.setItem(KEY, String(Date.now())); } catch { /* ignore */ }
        window.location.reload();
      }
    }
  }, [error]);

  return (
    <section className="min-h-[70vh] flex items-center justify-center bg-background px-4">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-sale-red/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <FiAlertTriangle className="w-8 h-8 text-sale-red" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Something went wrong</h2>
        <p className="text-text-muted mb-8">{error?.message || "An unexpected error occurred. Please try again."}</p>
        {error?.digest && (
          <p className="text-xs text-text-muted/70 mb-6 font-mono">Error ID: {error.digest}</p>
        )}
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button
            onClick={reset}
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-primary hover:bg-primary-dark text-white font-bold rounded-xl transition-colors"
          >
            <FiRefreshCw className="w-4 h-4" />
            Try again
          </button>
          <Link
            href="/"
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 border-2 border-primary text-primary hover:bg-primary hover:text-white font-bold rounded-xl transition-colors"
          >
            <FiHome className="w-4 h-4" />
            Go to home
          </Link>
        </div>
      </div>
    </section>
  );
}
