import { cache, Suspense } from "react";
import { unstable_cache } from "next/cache";
import Link from "next/link";
import { notFound } from "next/navigation";
import { FiTruck, FiShield, FiStar } from "react-icons/fi";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { inStockWhere } from "@/lib/productFilters";
import type { PrismaClient } from "@prisma/client";
import { serialize } from "@/lib/serialize";
import { mapApiProduct, type Product } from "@/data/products";
import { toBn } from "@/utils/toBn";
import ProductCard from "@/components/ProductCard";
import { ProductGalleryWithVariants, ReviewsSection, TText } from "@/components/ProductDetailClient";
import OtherProductsList from "@/components/OtherProductsList";
import EditableText from "@/storefront-engine/editor/EditableText";
import type { Metadata } from "next";
import type { ComponentType } from "react";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { ProductPageProps } from "@/storefront-engine/types/pages";

// Multi-tenant: must be dynamic — getPrismaForRequest reads the host header
// to resolve the tenant, so ISR can't safely cache by URL alone.
export const dynamic = "force-dynamic";

interface RawPdpVariant {
  id: number;
  label: string;
  price: unknown;
  original_price?: unknown;
  stock?: unknown;
  unlimited_stock?: unknown;
  image?: string;
}

function resolveImage(img: string): string {
  if (img.startsWith("/storage/")) return img;
  return img;
}

// Raw product read. Pure given (prisma, slug) — safe for the data cache.
async function loadProduct(prisma: PrismaClient, slug: string) {
  try {
    const decoded = decodeURIComponent(slug);
    const product = await prisma.product.findFirst({
      // Hide PDP for fully out-of-stock or inactive products → 404.
      // Customer can't land on a page they can't buy from.
      where: {
        AND: [
          { OR: [{ slug }, { slug: decoded }] },
          { isActive: true },
          inStockWhere,
        ],
      },
      include: {
        category: { select: { id: true, name: true, slug: true } },
        brand:    { select: { id: true, name: true, slug: true } },
        variants: { where: { isActive: true }, orderBy: { sortOrder: "asc" } },
      },
    });
    if (!product) return null;
    return serialize(product);
  } catch {
    return null;
  }
}

// Cross-request cache. force-dynamic disables the route cache (host header →
// tenant), but the per-visit tenant-DB read — cold-start included on idle
// Neon — was paid by EVERY visitor on the highest-traffic storefront page.
// Cached under the exact same tenant-namespaced tag + 60s window the shop
// and homepage already use, so staleness behaviour is identical and product
// edits flush it on the same path. React cache() still dedupes the
// generateMetadata + page calls within one request.
const getProduct = cache(
  (prisma: PrismaClient, tenantId: number, slug: string) =>
    unstable_cache(
      () => loadProduct(prisma, slug),
      ["pdp", String(tenantId), slug],
      { tags: [`t${tenantId}:products`], revalidate: 60 },
    )(),
);

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { prisma, tenant } = await getPrismaForRequest();
  const { slug } = await params;
  const product = await getProduct(prisma, tenant.id, slug);
  if (!product) return { title: "পণ্য পাওয়া যায়নি" };

  const name = product.name_bn || product.name;
  const desc = product.description_bn || product.description || "";

  return {
    title: name,
    description: desc.slice(0, 160) || `${name} — অর্ডার করুন।`,
    openGraph: {
      title: name,
      description: desc.slice(0, 160) || name,
      images: product.image?.startsWith("http") ? [product.image] : undefined,
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { prisma, tenant } = await getPrismaForRequest();
  const { slug } = await params;
  const raw = await getProduct(prisma, tenant.id, slug);

  if (!raw) notFound();

  const product = {
    id: raw.id as number,
    name: (raw.name as string) || "",
    nameBn: (raw.name_bn as string) || (raw.name as string) || "",
    slug: (raw.slug as string) || slug,
    price: Number(raw.price) || 0,
    originalPrice: raw.original_price != null ? Number(raw.original_price) : undefined,
    image: resolveImage((raw.image as string) || "/placeholder.svg"),
    category: typeof raw.category === "string" ? raw.category : (raw.category as { name?: string })?.name || "",
    categoryBn: typeof raw.category === "string" ? raw.category : (raw.category as { name?: string })?.name || "",
    badge: (raw.badge as string) || undefined,
    badgeColor: (raw.badge_color as string) || undefined,
    description: (raw.description as string) || "",
    descriptionBn: (raw.description_bn as string) || (raw.description as string) || "",
    // The Product.images column is `String?` in Prisma — admin saves a
    // JSON-stringified array (e.g. `["uploads/a.webp","uploads/b.webp"]`).
    // Handle both shapes defensively: array (already parsed) or string
    // (raw from DB). Filter out empty/null entries.
    images: (() => {
      const raw_images = raw.images;
      let arr: unknown[] = [];
      if (Array.isArray(raw_images)) {
        arr = raw_images;
      } else if (typeof raw_images === "string" && raw_images.trim()) {
        try { const p = JSON.parse(raw_images); if (Array.isArray(p)) arr = p; } catch {}
      }
      return arr
        .map((u) => (typeof u === "string" ? u.trim() : ""))
        .filter((u): u is string => !!u)
        .map(resolveImage);
    })(),
    videoUrl: (raw.video_url as string) || undefined,
    stock: Number(raw.stock) || 0,
    unlimitedStock: Boolean(raw.unlimited_stock),
    hasVariations: raw.has_variations || false,
    variationType: (raw.variation_type as string) || "",
    variants: Array.isArray(raw.variants) ? (raw.variants as RawPdpVariant[]).map((v) => ({
      id: v.id,
      label: v.label,
      price: Number(v.price),
      original_price: v.original_price != null ? Number(v.original_price) : undefined,
      stock: Number(v.stock) || 0,
      unlimited_stock: Boolean(v.unlimited_stock),
      image: v.image ? resolveImage(v.image) : undefined,
    })) : [],
  };

  const theme = await getActiveTheme();
  if (theme.pages.loadProductPage) {
    let ActivePage: ComponentType<ProductPageProps> | null = null;
    try {
      ActivePage = await theme.pages.loadProductPage();
    } catch {
      ActivePage = null;
    }
    if (ActivePage) {
      const themeProduct = {
        ...product,
        category_id: raw.category_id as number | undefined,
        category_slug: (raw.category as { slug?: string } | undefined)?.slug,
      };
      return (
        <div className={`theme-${theme.id}`}>
          <ThemeErrorBoundary themeId={theme.id} fallback={<div />}>
            <ActivePage product={themeProduct} />
          </ThemeErrorBoundary>
        </div>
      );
    }
  }

  const displayName = product.nameBn || product.name;
  const discount = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;

  const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  // Brand name for JSON-LD — avoid a separate DB round-trip just for this.
  // Falls back to env or a static default; not worth a query per page render.
  const siteName = process.env.NEXT_PUBLIC_SITE_NAME || "Site";
  const productJsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: displayName,
    description: product.descriptionBn || product.description || "",
    image: product.image.startsWith("http") ? product.image : `${SITE_URL}${product.image}`,
    url: `${SITE_URL}/products/${slug}`,
    brand: { "@type": "Brand", name: siteName },
    offers: {
      "@type": "Offer",
      price: product.price,
      priceCurrency: "BDT",
      availability: "https://schema.org/InStock",
      url: `${SITE_URL}/products/${slug}`,
    },
    ...(product.categoryBn ? { category: product.categoryBn } : {}),
  };

  return (
    <section className="py-8 md:py-12 bg-background-alt min-h-[70vh]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd) }} />
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-2 text-sm text-text-muted mb-6">
          <Link href="/" className="hover:text-primary transition-colors">
            <EditableText section="product" field="crumbHome" defaultValue="" label="Breadcrumb · Home" fallback={<TText en="Home" bn="হোম" />} />
          </Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-primary transition-colors">
            <EditableText section="product" field="crumbShop" defaultValue="" label="Breadcrumb · Shop" fallback={<TText en="Shop" bn="শপ" />} />
          </Link>
          <span>/</span>
          <span className="text-foreground truncate max-w-48">{displayName}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-8 md:gap-12">
          <ProductGalleryWithVariants
            mainImage={product.image}
            images={product.images}
            videoUrl={product.videoUrl}
            alt={displayName}
            productId={product.id}
            productName={displayName}
            price={product.price}
            productStock={product.stock}
            productUnlimitedStock={product.unlimitedStock}
            hasVariations={product.hasVariations}
            variationType={product.variationType}
            variants={product.variants}
            galleryOverlay={<>
              {discount > 0 && (
                <span className="absolute top-4 right-4 z-10 bg-sale-red text-white text-sm font-bold px-3 py-1.5 rounded-full" suppressHydrationWarning>-{toBn(discount)}%</span>
              )}
              {product.badge && (
                <span className={`absolute top-4 left-4 z-10 ${product.badgeColor || "bg-primary"} text-white text-sm font-bold px-3 py-1.5 rounded-full`}>{product.badge}</span>
              )}
            </>}
            detailsTop={<>
              {product.categoryBn && (
                <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full mb-3">
                  {product.categoryBn}
                </span>
              )}
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">{displayName}</h1>
              {!product.hasVariations && (
                <div className="mt-4 flex items-center gap-3">
                  <span className="text-3xl font-bold text-primary" suppressHydrationWarning>৳{toBn(product.price)}</span>
                  {product.originalPrice && (
                    <span className="text-xl text-text-light line-through" suppressHydrationWarning>৳{toBn(product.originalPrice)}</span>
                  )}
                  {discount > 0 && (
                    <span className="text-sm font-bold text-sale-red bg-sale-red/10 px-2.5 py-1 rounded-lg" suppressHydrationWarning>
                      {toBn(discount)}%{" "}
                      <EditableText section="product" field="discountSuffix" defaultValue="" label="Discount suffix" fallback={<TText en="off" bn="ছাড়" />} />
                    </span>
                  )}
                </div>
              )}
            </>}
            detailsBottom={
              <div className="mt-6 grid grid-cols-3 gap-3">
                {[
                  { id: "badge1", icon: FiTruck, en: "Fast Delivery", bn: "দ্রুত ডেলিভারি" },
                  { id: "badge2", icon: FiShield, en: "Skin Friendly", bn: "ত্বক-বান্ধব" },
                  { id: "badge3", icon: FiStar, en: "Premium Quality", bn: "প্রিমিয়াম মান" },
                ].map((b) => (
                  <div key={b.id} className="flex items-center gap-2 p-2.5 bg-white rounded-xl border border-border">
                    <b.icon className="w-4 h-4 text-primary shrink-0" />
                    <EditableText
                      section="product"
                      field={b.id}
                      defaultValue=""
                      label={`Trust badge · ${b.id}`}
                      className="text-xs font-medium text-text-body"
                      fallback={<TText en={b.en} bn={b.bn} />}
                    />
                  </div>
                ))}
              </div>
            }
          />
        </div>

        {product.descriptionBn && (
          <div className="mt-10 bg-white rounded-2xl border border-border p-6 md:p-8">
            <EditableText
              section="product"
              field="descriptionHeading"
              defaultValue=""
              label="Description heading"
              as="h2"
              className="text-xl font-bold text-foreground mb-4"
              fallback={<TText en="Product Description" bn="পণ্যের বিবরণ" />}
            />
            <div className="text-text-body leading-relaxed whitespace-pre-line">{product.descriptionBn}</div>
          </div>
        )}

        <ReviewsSection productId={product.id} />

        {/* Related products stream in separately — the main product paints
            the moment its own query resolves; this section can take its time
            without blocking the rest of the page. */}
        <Suspense fallback={<RelatedSkeleton />}>
          <RelatedProducts prisma={prisma} tenantId={tenant.id} categoryId={raw.category_id as number} excludeId={product.id} />
        </Suspense>

        {/* Other products: cross-category browse so users discover items
            beyond the current category. Streams independently. */}
        <Suspense fallback={<RelatedSkeleton />}>
          <OtherProducts prisma={prisma} tenantId={tenant.id} categoryId={raw.category_id as number} excludeId={product.id} />
        </Suspense>
      </div>
    </section>
  );
}

// ─── Related products: own async server component, own Suspense boundary ───

async function RelatedProducts({ prisma, tenantId, categoryId, excludeId }: { prisma: PrismaClient; tenantId: number; categoryId: number; excludeId: number }) {
  let related: Product[] = [];
  try {
    const relatedRows = await unstable_cache(
      () =>
        prisma.product.findMany({
          where: { isActive: true, categoryId, id: { not: excludeId }, AND: [inStockWhere] },
          include: {
            category: { select: { id: true, name: true, slug: true } },
            variants: { where: { isActive: true }, orderBy: { sortOrder: "asc" }, select: { id: true, label: true, price: true, originalPrice: true, stock: true, unlimitedStock: true, image: true, sortOrder: true } },
          },
          orderBy: { sortOrder: "asc" },
          take: 4,
        }),
      ["pdp-related", String(tenantId), String(categoryId), String(excludeId)],
      { tags: [`t${tenantId}:products`], revalidate: 60 },
    )();
    related = relatedRows.map((p) => mapApiProduct(serialize(p)));
  } catch {}

  if (related.length === 0) return null;

  return (
    <div className="mt-12">
      <EditableText
        section="product"
        field="relatedHeading"
        defaultValue=""
        label="Related products heading"
        as="h2"
        className="text-xl font-bold text-foreground mb-6"
        fallback={<TText en="Related Products" bn="সম্পর্কিত পণ্য" />}
      />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
        {related.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}

// ─── Other products: cross-category browse strip with infinite scroll ───
//
// Surfaces items from categories OTHER than the current product's so users
// can discover the rest of the catalog without leaving the PDP. The first
// page (20 items) is server-rendered for fast first paint + SEO; subsequent
// pages stream in via IntersectionObserver in the client component. Same
// API endpoint (/api/v1/products) the shop page uses, with the new
// exclude_category_id + exclude_id filters.
const OTHER_PER_PAGE = 20;

async function OtherProducts({ prisma, tenantId, categoryId, excludeId }: { prisma: PrismaClient; tenantId: number; categoryId: number; excludeId: number }) {
  let other: Product[] = [];
  try {
    const otherRows = await unstable_cache(
      () =>
        prisma.product.findMany({
          where: {
            isActive: true,
            deletedAt: null,
            id: { not: excludeId },
            // NOT this category → guarantees no overlap with Related Products.
            categoryId: { not: categoryId },
            AND: [inStockWhere],
          },
          include: {
            category: { select: { id: true, name: true, slug: true } },
            variants: {
              where: { isActive: true },
              orderBy: { sortOrder: "asc" },
              select: { id: true, label: true, price: true, originalPrice: true, stock: true, unlimitedStock: true, image: true, sortOrder: true },
            },
          },
          // Bestsellers first, then storefront sortOrder. Same ordering as the
          // client-side fetch (sort_by=sold_count, sort_dir=desc) so page 2
          // continues seamlessly from where page 1 ended.
          orderBy: [{ soldCount: "desc" }, { sortOrder: "asc" }],
          take: OTHER_PER_PAGE,
        }),
      ["pdp-other", String(tenantId), String(categoryId), String(excludeId)],
      { tags: [`t${tenantId}:products`], revalidate: 60 },
    )();
    other = otherRows.map((p) => mapApiProduct(serialize(p)));
  } catch {}

  if (other.length === 0) return null;

  return (
    <div className="mt-12">
      <EditableText
        section="product"
        field="otherHeading"
        defaultValue=""
        label="Other products heading"
        as="h2"
        className="text-xl font-bold text-foreground mb-6"
        fallback={<TText en="Other Products" bn="অন্যান্য পণ্য" />}
      />
      <OtherProductsList
        initial={other}
        excludeCategoryId={categoryId}
        excludeId={excludeId}
        perPage={OTHER_PER_PAGE}
      />
    </div>
  );
}

function RelatedSkeleton() {
  return (
    <div className="mt-12">
      <div className="h-6 w-40 bg-gray-200 rounded animate-pulse mb-6" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-white rounded-2xl border border-border overflow-hidden">
            <div className="aspect-square w-full bg-gray-200 animate-pulse" />
            <div className="p-3 space-y-2">
              <div className="h-4 w-3/4 bg-gray-200 rounded animate-pulse" />
              <div className="h-5 w-1/2 bg-gray-200 rounded animate-pulse" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
