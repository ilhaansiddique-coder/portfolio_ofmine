/**
 * /blog — thin shell.
 *
 * Fetches the tenant's published posts server-side and dispatches to
 * the active storefront theme's `loadBlogPage` slot. When the active
 * theme has no blog override (e.g. the default theme), falls back to
 * the legacy client `<BlogClient>` which fetches its own data via the
 * public API.
 */

import type { ComponentType } from "react";
import type { Metadata } from "next";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSetting } from "@/lib/settingsCache";
import { serialize } from "@/lib/serialize";
import type { PrismaClient } from "@prisma/client";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { BlogListingPageProps, BlogPostSummary } from "@/storefront-engine/types/pages";
import BlogClient from "./BlogClient";
import { getCmsPage, renderCmsContent } from "../p/[slug]/cms-shared";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Blog",
  description: "Read latest posts, tips and updates.",
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function shape(row: any): BlogPostSummary {
  return {
    id: Number(row.id),
    title: row.title || "",
    slug: row.slug || "",
    excerpt: row.excerpt || "",
    image: row.image || null,
    author_name: row.author?.name || row.author_name || "Author",
    created_at: row.created_at || row.createdAt || row.published_at || row.publishedAt || new Date().toISOString(),
  };
}

async function resolveLang(prisma: PrismaClient, tenantId: number): Promise<"en" | "bn"> {
  try {
    const value = await getSetting(prisma, tenantId, "site_language");
    if (value === "bn" || value === "en") return value;
  } catch { /* */ }
  return "en";
}

export default async function BlogPage() {
  const { prisma, tenant } = await getPrismaForRequest();

  // WordPress-style "posts page": when the admin designates a CMS page as the
  // blog page (Site Settings → blog_page_slug), render it at /blog instead of
  // the default post listing. Falls through if unset or unpublished.
  {
    const blogSlug = (await getSetting(prisma, tenant.id, "blog_page_slug").catch(() => null))?.trim();
    if (blogSlug) {
      const cms = await getCmsPage(prisma, tenant.id, blogSlug);
      if (cms?.publishedData) return renderCmsContent(cms.publishedData);
    }
  }

  let posts: BlogPostSummary[] = [];
  try {
    const rows = await prisma.blogPost.findMany({
      where: { isPublished: true },
      orderBy: { createdAt: "desc" },
      include: { author: { select: { id: true, name: true } } },
    });
    posts = rows.map((r) => shape(serialize(r)));
  } catch { /* db error — render empty state */ }

  const lang = await resolveLang(prisma, tenant.id);

  let ActivePage: ComponentType<BlogListingPageProps> | null = null;
  let activeThemeId = "default";
  try {
    const theme = await getActiveTheme();
    activeThemeId = theme.id;
    if (theme.pages.loadBlogPage) {
      ActivePage = await theme.pages.loadBlogPage().catch(() => null);
    }
  } catch { /* fall through */ }

  if (ActivePage) {
    return (
      <div className={`theme-${activeThemeId}`}>
        <ThemeErrorBoundary themeId={activeThemeId} fallback={<BlogClient />}>
          <ActivePage posts={posts} lang={lang} />
        </ThemeErrorBoundary>
      </div>
    );
  }

  return <BlogClient />;
}
