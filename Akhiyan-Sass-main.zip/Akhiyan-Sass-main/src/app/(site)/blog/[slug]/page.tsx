import type { ComponentType } from "react";
import { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSetting } from "@/lib/settingsCache";
import { serialize } from "@/lib/serialize";
import type { PrismaClient } from "@prisma/client";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { BlogPostPageProps, BlogPostSummary } from "@/storefront-engine/types/pages";
import BlogPostView from "./BlogPostView";

export const dynamic = "force-dynamic";

/** Wire shape passed to the client view. Flat strings/numbers only — no
 *  Prisma model identity, no Dates — so server→client serialization
 *  stays clean. */
interface BlogPostShape {
  id: number;
  title: string;
  slug: string;
  excerpt?: string;
  content: string;
  image?: string | null;
  author_name: string;
  created_at: string;
}

/** Normalise a Prisma BlogPost row (with its `author` relation) into the
 *  flat shape the view expects. Handles either `createdAt`/`isPublished`
 *  camelCase or the legacy snake_case aliases produced by `serialize`. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function shape(row: any): BlogPostShape {
  return {
    id: Number(row.id),
    title: row.title || "",
    slug: row.slug || "",
    excerpt: row.excerpt || "",
    content: row.content || "",
    image: row.image || null,
    author_name: row.author?.name || row.author_name || "Author",
    created_at: row.created_at || row.createdAt || row.published_at || row.publishedAt || new Date().toISOString(),
  };
}

function summary(p: BlogPostShape): BlogPostSummary {
  return {
    id: p.id, title: p.title, slug: p.slug, excerpt: p.excerpt,
    image: p.image, author_name: p.author_name, created_at: p.created_at,
  };
}

async function resolveLang(prisma: PrismaClient, tenantId: number): Promise<"en" | "bn"> {
  try {
    const value = await getSetting(prisma, tenantId, "site_language");
    if (value === "bn" || value === "en") return value;
  } catch { /* */ }
  return "en";
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  try {
    const { prisma } = await getPrismaForRequest();
    const row = await prisma.blogPost.findFirst({
      where: { slug, isPublished: true },
      include: { author: { select: { id: true, name: true } } },
    });
    if (!row) return { title: "Post Not Found" };
    const post = shape(serialize(row));
    return {
      title: post.title,
      description: post.excerpt,
      openGraph: {
        title: post.title,
        description: post.excerpt,
        images: post.image ? [post.image] : [],
      },
    };
  } catch {
    return { title: "Blog" };
  }
}

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { prisma, tenant } = await getPrismaForRequest();

  let post: BlogPostShape | null = null;
  try {
    const row = await prisma.blogPost.findFirst({
      where: { slug, isPublished: true },
      include: { author: { select: { id: true, name: true } } },
    });
    if (row) post = shape(serialize(row));
  } catch { /* db error — fall through to notFound */ }

  if (!post) return notFound();

  // Pull a handful of recent posts and drop the current one from the
  // list — gives the reader something to jump to next. Failure here is
  // non-fatal; the main post still renders.
  let related: BlogPostShape[] = [];
  try {
    const rows = await prisma.blogPost.findMany({
      where: { isPublished: true, slug: { not: slug } },
      orderBy: { createdAt: "desc" },
      take: 3,
      include: { author: { select: { id: true, name: true } } },
    });
    related = rows.map((r) => shape(serialize(r)));
  } catch { /* listing flaky — render without related */ }

  const lang = await resolveLang(prisma, tenant.id);

  // Dispatch to active theme's blog post page when registered.
  let ActivePage: ComponentType<BlogPostPageProps> | null = null;
  let activeThemeId = "default";
  try {
    const theme = await getActiveTheme();
    activeThemeId = theme.id;
    if (theme.pages.loadBlogPostPage) {
      ActivePage = await theme.pages.loadBlogPostPage().catch(() => null);
    }
  } catch { /* fall through */ }

  if (ActivePage) {
    return (
      <div className={`theme-${activeThemeId}`}>
        <ThemeErrorBoundary themeId={activeThemeId} fallback={<BlogPostView post={post} related={related} />}>
          <ActivePage
            post={{ ...summary(post), content: post.content }}
            related={related.map(summary)}
            lang={lang}
          />
        </ThemeErrorBoundary>
      </div>
    );
  }

  return <BlogPostView post={post} related={related} />;
}
