"use client";

/**
 * Single blog post — default theme view.
 *
 * Visual language aligned with the rest of the default theme: primary
 * gradient hero band, container layout, soft slate body, prose section.
 * Editable wrappers cover the labels admins might want to reword in
 * place (Back link, author byline, share heading, related heading).
 *
 * Extracted from `page.tsx` so the inline `<Editable>` function children
 * stay on the client side of the server/client boundary.
 */

import Link from "next/link";
import { FiClock, FiUser, FiArrowLeft, FiArrowRight, FiFacebook, FiMessageCircle, FiTwitter, FiLink2 } from "react-icons/fi";
import { useState } from "react";
import { TText } from "@/components/ProductDetailClient";
import { sanitizeRichText } from "@/lib/sanitize-html";
import { Editable } from "@/storefront-engine/editor/Editable";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt?: string;
  content: string;
  image?: string | null;
  author_name: string;
  created_at: string;
}

interface BlogPostViewProps {
  post: BlogPost;
  related?: BlogPost[];
  shareUrl?: string;
}

export default function BlogPostView({ post, related = [], shareUrl }: BlogPostViewProps) {
  const [copied, setCopied] = useState(false);
  const url = shareUrl || (typeof window !== "undefined" ? window.location.href : "");
  const encoded = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(post.title);
  const fbHref = `https://www.facebook.com/sharer/sharer.php?u=${encoded}`;
  const waHref = `https://wa.me/?text=${encodedTitle}%20${encoded}`;
  const twHref = `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encoded}`;

  async function copyLink() {
    try {
      if (typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch { /* clipboard blocked — silent */ }
  }

  return (
    <article className="bg-background min-h-[70vh]">
      {/* Hero band — primary gradient backdrop with breadcrumb + title + meta. */}
      <header className="relative bg-linear-to-br from-primary via-primary-light to-primary-dark overflow-hidden">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 bg-white/5 rounded-full" />
          <div className="absolute -bottom-28 -left-28 w-[420px] h-[420px] bg-white/5 rounded-full" />
        </div>
        <div className="container mx-auto px-4 py-14 md:py-20 relative z-10">
          <div className="max-w-3xl">
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 text-white/70 hover:text-white text-sm transition-colors mb-6"
            >
              <FiArrowLeft className="w-4 h-4" />
              <Editable section="blogPost" field="backToBlogLabel" defaultValue="" label="Back to Blog label">
                {(v, ep) => <span {...ep}>{v || <TText en="Back to Blog" bn="ব্লগে ফিরুন" />}</span>}
              </Editable>
            </Link>

            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-5">
              {post.title}
            </h1>

            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-white/80">
              <div className="flex items-center gap-2">
                <FiClock className="w-4 h-4" />
                <span suppressHydrationWarning>
                  {new Date(post.created_at).toLocaleDateString(undefined, {
                    year: "numeric", month: "long", day: "numeric",
                  })}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <FiUser className="w-4 h-4" />
                <span>{post.author_name}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 -mt-10 md:-mt-16 relative z-20">
        <div className="max-w-3xl mx-auto">
          {post.image && (
            <div className="relative aspect-[21/9] rounded-2xl overflow-hidden mb-10 shadow-xl ring-1 ring-black/5 bg-white">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div
            className="prose prose-lg max-w-none text-text-body leading-relaxed prose-headings:text-foreground prose-a:text-primary prose-strong:text-foreground"
            dangerouslySetInnerHTML={{ __html: sanitizeRichText(post.content) }}
          />

          {/* Author + share row */}
          <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <FiUser className="w-6 h-6 text-primary" />
              </div>
              <div>
                <Editable section="blogPost" field="authorLabel" defaultValue="" label="Author byline label">
                  {(v, ep) => (
                    <p {...ep} className={`text-xs text-text-muted ${ep.className ?? ""}`}>
                      {v || <TText en="Written by" bn="লিখেছেন" />}
                    </p>
                  )}
                </Editable>
                <p className="font-bold text-foreground">{post.author_name}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Editable section="blogPost" field="shareLabel" defaultValue="" label="Share label">
                {(v, ep) => (
                  <span {...ep} className={`text-sm text-text-muted mr-1 ${ep.className ?? ""}`}>
                    {v || <TText en="Share:" bn="শেয়ার:" />}
                  </span>
                )}
              </Editable>
              <a
                href={fbHref}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Share on Facebook"
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg bg-background-alt hover:bg-primary/10 text-primary transition-colors"
              >
                <FiFacebook className="w-4 h-4" />
              </a>
              <a
                href={waHref}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Share on WhatsApp"
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg bg-background-alt hover:bg-primary/10 text-primary transition-colors"
              >
                <FiMessageCircle className="w-4 h-4" />
              </a>
              <a
                href={twHref}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Share on Twitter"
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg bg-background-alt hover:bg-primary/10 text-primary transition-colors"
              >
                <FiTwitter className="w-4 h-4" />
              </a>
              <button
                type="button"
                onClick={copyLink}
                aria-label="Copy link"
                className="w-9 h-9 inline-flex items-center justify-center rounded-lg bg-background-alt hover:bg-primary/10 text-primary transition-colors"
                title={copied ? "Copied!" : "Copy link"}
              >
                <FiLink2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Related posts */}
      {related.length > 0 && (
        <section className="bg-background-alt mt-16 py-14 md:py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <Editable section="blogPost" field="relatedHeading" defaultValue="" label="Related posts heading">
                {(v, ep) => (
                  <h2 {...ep} className={`text-2xl md:text-3xl font-bold text-foreground mb-8 ${ep.className ?? ""}`}>
                    {v || <TText en="More from the blog" bn="ব্লগের আরও পোস্ট" />}
                  </h2>
                )}
              </Editable>

              <div className="grid md:grid-cols-3 gap-6">
                {related.map((p) => (
                  <Link
                    key={p.id}
                    href={`/blog/${p.slug}`}
                    className="group bg-white border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all"
                  >
                    <div className="relative aspect-[16/9] bg-gray-100 overflow-hidden">
                      {p.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={p.image}
                          alt={p.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-text-muted/40 text-3xl">
                          ✦
                        </div>
                      )}
                    </div>
                    <div className="p-5">
                      <p className="text-xs text-text-muted mb-2" suppressHydrationWarning>
                        {new Date(p.created_at).toLocaleDateString()}
                      </p>
                      <h3 className="text-base font-bold text-foreground line-clamp-2 group-hover:text-primary transition-colors">
                        {p.title}
                      </h3>
                      {p.excerpt && (
                        <p className="text-sm text-text-muted line-clamp-2 mt-2">
                          {p.excerpt}
                        </p>
                      )}
                      <span className="inline-flex items-center gap-1 mt-3 text-primary text-sm font-bold">
                        <Editable section="blogPost" field="readMoreLabel" defaultValue="" label="Related read-more label">
                          {(v, ep) => <span {...ep}>{v || <TText en="Read More" bn="আরও পড়ুন" />}</span>}
                        </Editable>
                        <FiArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
    </article>
  );
}
