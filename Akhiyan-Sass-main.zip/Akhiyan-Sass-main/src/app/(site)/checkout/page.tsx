/**
 * /checkout — thin server shell.
 *
 * Resolves the active storefront theme and dispatches to its
 * CheckoutPage when one is registered. Falls back to the legacy
 * default-theme `<CheckoutView>` client component otherwise. All
 * checkout state lives client-side (CartContext + form state) so this
 * shell does no data fetching — it only picks which view to render.
 */

import type { ComponentType } from "react";
import type { Metadata } from "next";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { CheckoutPageProps } from "@/storefront-engine/types/pages";
import CheckoutView from "./CheckoutView";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Complete your purchase securely.",
};

export default async function CheckoutRoute() {
  let ActivePage: ComponentType<CheckoutPageProps> | null = null;
  let activeThemeId = "default";
  try {
    const theme = await getActiveTheme();
    activeThemeId = theme.id;
    if (theme.pages.loadCheckoutPage) {
      ActivePage = await theme.pages.loadCheckoutPage().catch(() => null);
    }
  } catch { /* fall through to default view */ }

  if (ActivePage) {
    return (
      <div className={`theme-${activeThemeId}`}>
        <ThemeErrorBoundary themeId={activeThemeId} fallback={<CheckoutView />}>
          <ActivePage />
        </ThemeErrorBoundary>
      </div>
    );
  }

  return <CheckoutView />;
}
