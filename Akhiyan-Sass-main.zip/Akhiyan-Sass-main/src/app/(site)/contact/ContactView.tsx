"use client";

/**
 * Client-rendered view for the legacy default-theme contact layout.
 * Extracted from `page.tsx` so the inline `<Editable>` function children
 * stay on the client side of the server/client boundary.
 */

import { FiMail } from "react-icons/fi";
import MotionFadeIn from "@/components/MotionFadeIn";
import ContactForm from "@/components/ContactForm";
import ContactInfo from "@/components/ContactInfo";
import { TText } from "@/components/ProductDetailClient";
import type { Bilingual } from "@/lib/bilingual";
import { Editable } from "@/storefront-engine/editor/Editable";

interface ContactContent {
  heroBadge: Bilingual;
  heroTitle: Bilingual;
  heroSubtitle: Bilingual;
  formTitle: Bilingual;
  formNameLabel: Bilingual;
  formEmailLabel: Bilingual;
  formPhoneLabel: Bilingual;
  formSubjectLabel: Bilingual;
  formMessageLabel: Bilingual;
  formSubmitText: Bilingual;
  formSuccessText: Bilingual;
  infoTitle: Bilingual;
  infoSubtitle: Bilingual;
  hoursTitle: Bilingual;
  hoursText: Bilingual;
}

export default function ContactView({ content: c }: { content: ContactContent }) {
  return (
    <div className="min-h-screen bg-background">
      <section className="relative bg-linear-to-br from-primary via-primary-light to-primary-dark overflow-hidden">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 bg-white/5 rounded-full" />
          <div className="absolute -bottom-28 -left-28 w-[420px] h-[420px] bg-white/5 rounded-full" />
        </div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10 text-center">
          <MotionFadeIn>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/15 rounded-full text-white/90 text-sm mb-6 backdrop-blur-sm">
              <FiMail className="w-4 h-4" />
              <Editable section="contact" field="heroBadge" defaultValue={c.heroBadge.en || c.heroBadge.bn} label="Hero badge">
                {(v, ep) => <span {...ep}>{v || <TText en={c.heroBadge.en} bn={c.heroBadge.bn} />}</span>}
              </Editable>
            </span>
            <Editable section="contact" field="heroTitle" defaultValue={c.heroTitle.en || c.heroTitle.bn} label="Hero title">
              {(v, ep) => (
                <h1 {...ep} className={`text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 ${ep.className ?? ""}`}>
                  {v || <TText en={c.heroTitle.en} bn={c.heroTitle.bn} />}
                </h1>
              )}
            </Editable>
            <Editable section="contact" field="heroSubtitle" defaultValue={c.heroSubtitle.en || c.heroSubtitle.bn} label="Hero subtitle">
              {(v, ep) => (
                <p {...ep} className={`text-white/80 text-lg max-w-xl mx-auto leading-relaxed ${ep.className ?? ""}`}>
                  {v || <TText en={c.heroSubtitle.en} bn={c.heroSubtitle.bn} />}
                </p>
              )}
            </Editable>
          </MotionFadeIn>
        </div>
      </section>

      <section className="py-16 md:py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-10 max-w-6xl mx-auto">
            <MotionFadeIn className="lg:col-span-2">
              <div className="bg-white border border-border rounded-2xl p-6 md:p-8 shadow-sm">
                <Editable section="contact" field="formTitle" defaultValue={c.formTitle.en || c.formTitle.bn} label="Form title">
                  {(v, ep) => (
                    <h2 {...ep} className={`text-2xl font-bold text-foreground mb-6 ${ep.className ?? ""}`}>
                      {v || <TText en={c.formTitle.en} bn={c.formTitle.bn} />}
                    </h2>
                  )}
                </Editable>
                <ContactForm />
              </div>
            </MotionFadeIn>

            <ContactInfo />
          </div>
        </div>
      </section>
    </div>
  );
}
