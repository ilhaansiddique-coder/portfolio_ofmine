"use client";

/**
 * Client-rendered view for the legacy default-theme about layout.
 * Extracted from `page.tsx` so the inline `<Editable>` function children
 * stay on the client side of the server/client boundary.
 */

import { FiHeart, FiTarget, FiUsers, FiAward, FiStar, FiShield, FiTruck, FiSmile } from "react-icons/fi";
import MotionFadeIn from "@/components/MotionFadeIn";
import { MotionStaggerContainer, MotionStaggerItem } from "@/components/MotionStagger";
import { TText } from "@/components/ProductDetailClient";
import type { Bilingual } from "@/lib/bilingual";
import { Editable } from "@/storefront-engine/editor/Editable";

interface StatItem { value: Bilingual; label: Bilingual }
interface TimelineItem { year: Bilingual; event: Bilingual }
interface WhyUsItem { title: Bilingual; desc: Bilingual; icon?: string }
interface TeamMember { name: Bilingual; role: Bilingual; initials: string }

export interface AboutContent {
  heroBadge: Bilingual;
  heroTitle: Bilingual;
  heroSubtitle: Bilingual;
  missionTitle: Bilingual;
  missionDescription: Bilingual;
  stats: StatItem[];
  storyTitle: Bilingual;
  storyP1: Bilingual;
  storyP2: Bilingual;
  storyP3: Bilingual;
  timeline: TimelineItem[];
  whyUsTitle: Bilingual;
  whyUsSubtitle: Bilingual;
  whyUsItems: WhyUsItem[];
  teamTitle: Bilingual;
  teamSubtitle: Bilingual;
  teamMembers: TeamMember[];
}

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  shield: FiShield,
  truck: FiTruck,
  star: FiStar,
  smile: FiSmile,
};

export default function AboutView({ content }: { content: AboutContent }) {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative bg-linear-to-br from-primary via-primary-light to-primary-dark overflow-hidden">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 bg-white/5 rounded-full" />
          <div className="absolute -bottom-28 -left-28 w-[420px] h-[420px] bg-white/5 rounded-full" />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-28 relative z-10 text-center">
          <MotionFadeIn>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/15 rounded-full text-white/90 text-sm mb-6 backdrop-blur-sm">
              <FiHeart className="w-4 h-4 text-red-300" />
              <Editable section="about" field="heroBadge" defaultValue={content.heroBadge.en || content.heroBadge.bn} label="Hero badge">
                {(v, ep) => <span {...ep}>{v || <TText en={content.heroBadge.en} bn={content.heroBadge.bn} />}</span>}
              </Editable>
            </span>
            <Editable section="about" field="heroTitle" defaultValue={content.heroTitle.en || content.heroTitle.bn} label="Hero title">
              {(v, ep) => (
                <h1 {...ep} className={`text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-5 ${ep.className ?? ""}`}>
                  {v || <TText en={content.heroTitle.en} bn={content.heroTitle.bn} />}
                </h1>
              )}
            </Editable>
            <Editable section="about" field="heroSubtitle" defaultValue={content.heroSubtitle.en || content.heroSubtitle.bn} label="Hero subtitle">
              {(v, ep) => (
                <p {...ep} className={`text-white/80 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed ${ep.className ?? ""}`}>
                  {v || <TText en={content.heroSubtitle.en} bn={content.heroSubtitle.bn} />}
                </p>
              )}
            </Editable>
          </MotionFadeIn>
        </div>
      </section>

      {/* Mission */}
      <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4">
          <MotionFadeIn className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-2xl mb-6">
              <FiTarget className="w-8 h-8 text-primary" />
            </div>
            <Editable section="about" field="missionTitle" defaultValue={content.missionTitle.en || content.missionTitle.bn} label="Mission title">
              {(v, ep) => (
                <h2 {...ep} className={`text-3xl md:text-4xl font-bold text-foreground mb-4 section-heading ${ep.className ?? ""}`}>
                  {v || <TText en={content.missionTitle.en} bn={content.missionTitle.bn} />}
                </h2>
              )}
            </Editable>
            <Editable section="about" field="missionDescription" defaultValue={content.missionDescription.en || content.missionDescription.bn} label="Mission description">
              {(v, ep) => (
                <p {...ep} className={`text-text-body text-lg leading-relaxed mt-6 ${ep.className ?? ""}`}>
                  {v || <TText en={content.missionDescription.en} bn={content.missionDescription.bn} />}
                </p>
              )}
            </Editable>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
              {content.stats.map((stat, i) => {
                const n = i + 1;
                return (
                  <div key={i} className="bg-primary/5 border border-primary/10 rounded-2xl p-6">
                    <Editable section="about" field={`stat${n}Value`} defaultValue={stat.value.en || stat.value.bn} label={`Stat ${n} value`}>
                      {(v, ep) => (
                        <p {...ep} className={`text-4xl font-bold text-primary mb-1 ${ep.className ?? ""}`}>
                          {v || <TText en={stat.value.en} bn={stat.value.bn} />}
                        </p>
                      )}
                    </Editable>
                    <Editable section="about" field={`stat${n}Label`} defaultValue={stat.label.en || stat.label.bn} label={`Stat ${n} label`}>
                      {(v, ep) => (
                        <p {...ep} className={`text-text-muted font-medium ${ep.className ?? ""}`}>
                          {v || <TText en={stat.label.en} bn={stat.label.bn} />}
                        </p>
                      )}
                    </Editable>
                  </div>
                );
              })}
            </div>
          </MotionFadeIn>
        </div>
      </section>

      {/* Story */}
      <section className="py-16 md:py-20 bg-background-alt">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
            <MotionFadeIn direction="right">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
                <FiHeart className="w-4 h-4" />
                <Editable section="about" field="storyEyebrow" defaultValue="Our Story" label="Story eyebrow">
                  {(v, ep) => <span {...ep}>{v || <TText en="Our Story" bn="আমাদের গল্প" />}</span>}
                </Editable>
              </div>
              <Editable section="about" field="storyTitle" defaultValue={content.storyTitle.en || content.storyTitle.bn} label="Story title">
                {(v, ep) => (
                  <h2 {...ep} className={`text-3xl md:text-4xl font-bold text-foreground mb-6 ${ep.className ?? ""}`}>
                    {v || <TText en={content.storyTitle.en} bn={content.storyTitle.bn} />}
                  </h2>
                )}
              </Editable>
              <div className="space-y-4 text-text-body leading-relaxed">
                <Editable section="about" field="storyP1" defaultValue={content.storyP1.en || content.storyP1.bn} label="Story paragraph 1">
                  {(v, ep) => <p {...ep}>{v || <TText en={content.storyP1.en} bn={content.storyP1.bn} />}</p>}
                </Editable>
                <Editable section="about" field="storyP2" defaultValue={content.storyP2.en || content.storyP2.bn} label="Story paragraph 2">
                  {(v, ep) => <p {...ep}>{v || <TText en={content.storyP2.en} bn={content.storyP2.bn} />}</p>}
                </Editable>
                <Editable section="about" field="storyP3" defaultValue={content.storyP3.en || content.storyP3.bn} label="Story paragraph 3">
                  {(v, ep) => <p {...ep}>{v || <TText en={content.storyP3.en} bn={content.storyP3.bn} />}</p>}
                </Editable>
              </div>
            </MotionFadeIn>
            <MotionFadeIn direction="left" delay={0.15}>
              <div className="bg-linear-to-br from-primary/10 to-primary/5 border border-primary/15 rounded-3xl p-8 md:p-10">
                <div className="text-center mb-8"><span className="text-7xl">👶</span></div>
                <div className="space-y-4">
                  {content.timeline.map((item, i) => {
                    const n = i + 1;
                    return (
                      <div key={i} className="flex items-start gap-4">
                        <Editable section="about" field={`timeline${n}Year`} defaultValue={item.year.en || item.year.bn} label={`Timeline ${n} year`}>
                          {(v, ep) => (
                            <span {...ep} className={`px-3 py-1 bg-primary text-white text-xs font-bold rounded-lg shrink-0 mt-0.5 ${ep.className ?? ""}`}>
                              {v || <TText en={item.year.en} bn={item.year.bn} />}
                            </span>
                          )}
                        </Editable>
                        <Editable section="about" field={`timeline${n}Event`} defaultValue={item.event.en || item.event.bn} label={`Timeline ${n} event`}>
                          {(v, ep) => (
                            <p {...ep} className={`text-text-body text-sm ${ep.className ?? ""}`}>
                              {v || <TText en={item.event.en} bn={item.event.bn} />}
                            </p>
                          )}
                        </Editable>
                      </div>
                    );
                  })}
                </div>
              </div>
            </MotionFadeIn>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4">
          <MotionFadeIn className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-primary/10 rounded-2xl mb-4">
              <FiAward className="w-7 h-7 text-primary" />
            </div>
            <Editable section="about" field="whyUsTitle" defaultValue={content.whyUsTitle.en || content.whyUsTitle.bn} label="Why-us title">
              {(v, ep) => (
                <h2 {...ep} className={`text-3xl md:text-4xl font-bold text-foreground section-heading ${ep.className ?? ""}`}>
                  {v || <TText en={content.whyUsTitle.en} bn={content.whyUsTitle.bn} />}
                </h2>
              )}
            </Editable>
            <Editable section="about" field="whyUsSubtitle" defaultValue={content.whyUsSubtitle.en || content.whyUsSubtitle.bn} label="Why-us subtitle">
              {(v, ep) => (
                <p {...ep} className={`text-text-muted mt-6 max-w-xl mx-auto ${ep.className ?? ""}`}>
                  {v || <TText en={content.whyUsSubtitle.en} bn={content.whyUsSubtitle.bn} />}
                </p>
              )}
            </Editable>
          </MotionFadeIn>
          <MotionStaggerContainer staggerDelay={0.12} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {content.whyUsItems.map((item, i) => {
              const IconComp = ICON_MAP[item.icon ?? ""] ?? FiStar;
              const n = i + 1;
              return (
                <MotionStaggerItem
                  key={i}
                  className="bg-white border border-border rounded-2xl p-6 text-center hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group"
                >
                  <div className="w-14 h-14 mx-auto bg-primary/10 group-hover:bg-primary rounded-2xl flex items-center justify-center mb-4 transition-colors duration-300">
                    <IconComp className="w-6 h-6 text-primary group-hover:text-white transition-colors duration-300" />
                  </div>
                  <Editable section="about" field={`why${n}Title`} defaultValue={item.title.en || item.title.bn} label={`Why ${n} title`}>
                    {(v, ep) => (
                      <h3 {...ep} className={`font-bold text-foreground text-base mb-2 ${ep.className ?? ""}`}>
                        {v || <TText en={item.title.en} bn={item.title.bn} />}
                      </h3>
                    )}
                  </Editable>
                  <Editable section="about" field={`why${n}Desc`} defaultValue={item.desc.en || item.desc.bn} label={`Why ${n} description`}>
                    {(v, ep) => (
                      <p {...ep} className={`text-text-muted text-sm leading-relaxed ${ep.className ?? ""}`}>
                        {v || <TText en={item.desc.en} bn={item.desc.bn} />}
                      </p>
                    )}
                  </Editable>
                </MotionStaggerItem>
              );
            })}
          </MotionStaggerContainer>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 md:py-20 bg-primary">
        <div className="container mx-auto px-4">
          <MotionFadeIn className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-14 h-14 bg-white/15 rounded-2xl mb-4">
              <FiUsers className="w-7 h-7 text-white" />
            </div>
            <Editable section="about" field="teamTitle" defaultValue={content.teamTitle.en || content.teamTitle.bn} label="Team title">
              {(v, ep) => (
                <h2 {...ep} className={`text-3xl md:text-4xl font-bold text-white mb-3 ${ep.className ?? ""}`}>
                  {v || <TText en={content.teamTitle.en} bn={content.teamTitle.bn} />}
                </h2>
              )}
            </Editable>
            <Editable section="about" field="teamSubtitle" defaultValue={content.teamSubtitle.en || content.teamSubtitle.bn} label="Team subtitle">
              {(v, ep) => (
                <p {...ep} className={`text-white/70 max-w-xl mx-auto ${ep.className ?? ""}`}>
                  {v || <TText en={content.teamSubtitle.en} bn={content.teamSubtitle.bn} />}
                </p>
              )}
            </Editable>
          </MotionFadeIn>
          <MotionStaggerContainer staggerDelay={0.12} className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {content.teamMembers.map((member, i) => {
              const n = i + 1;
              return (
                <MotionStaggerItem
                  key={i}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center hover:bg-white/20 transition-colors"
                >
                  <div className="w-16 h-16 mx-auto bg-white/20 rounded-full flex items-center justify-center mb-3">
                    <span className="text-2xl font-bold text-white">{member.initials}</span>
                  </div>
                  <Editable section="about" field={`team${n}Name`} defaultValue={member.name.en || member.name.bn} label={`Team ${n} name`}>
                    {(v, ep) => (
                      <h3 {...ep} className={`font-bold text-white text-sm md:text-base ${ep.className ?? ""}`}>
                        {v || <TText en={member.name.en} bn={member.name.bn} />}
                      </h3>
                    )}
                  </Editable>
                  <Editable section="about" field={`team${n}Role`} defaultValue={member.role.en || member.role.bn} label={`Team ${n} role`}>
                    {(v, ep) => (
                      <p {...ep} className={`text-white/60 text-xs mt-1 ${ep.className ?? ""}`}>
                        {v || <TText en={member.role.en} bn={member.role.bn} />}
                      </p>
                    )}
                  </Editable>
                </MotionStaggerItem>
              );
            })}
          </MotionStaggerContainer>
        </div>
      </section>
    </div>
  );
}
