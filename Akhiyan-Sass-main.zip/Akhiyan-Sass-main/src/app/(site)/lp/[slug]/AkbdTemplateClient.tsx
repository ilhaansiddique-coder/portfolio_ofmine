"use client";

/**
 * Akbd-style landing page template — navy + teal doctor/medical landing page.
 * Designed to visually match https://www.akbd.live/
 *
 * Sections (in order):
 *   1. Hero badge + subtitle
 *   2. Doctor card (photo + navy info card)
 *   2b. Stats bar (animated 1→N counters)
 *   3. Benefits panel ("আপনি যে উপকার পাবেন")
 *   4. Product image + red CTA + phone
 *   5. Why-choose-us panel ("আমাদের থেকে কেনো নিবেন?")
 *   6. Testimonials carousel (navy cards)
 *   7. Red CTA again
 *   8. Chamber address panel
 *   9. FAQ accordion
 *  10. Checkout (billing left, order summary right) — uses the same checkout logic
 *      shape as the default template but with akbd colors.
 */

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import { api } from "@/lib/api";
import { trackInitiateCheckout, trackPurchase, trackViewContent } from "@/lib/analytics";
import LpContactBubble from "@/components/LpContactBubble";
import { sanitizeInline } from "@/lib/sanitize-html";

// Brand palette — accent #2378d2 powers all pills, CTAs (non-red), arrows,
// dot indicator, doctor name badge, and the teal-position role in the original
// akbd design. Navy stays as the dark panel surface.
const NAVY = "#1a3a63";
const NAVY_DEEP = "#0f2849";
const TEAL = "#2378d2";       // brand accent
const TEAL_DARK = "#1c5fa6";  // hover/darker accent
const RED = "#e63946";
const RED_DARK = "#c52936";

function toBn(n: string | number): string {
  return String(n).replace(/[0-9]/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
}

interface ResolvedProduct {
  id: number;
  name: string;
  slug: string;
  price: number;
  original_price?: number;
  image: string;
  description?: string;
  stock: number;
  selected_quantity: number;
  has_variations?: boolean;
  variation_type?: string;
  custom_shipping?: boolean;
  shipping_cost?: number;
  variants?: { id: number; label: string; price: number; original_price?: number; stock: number; image?: string; isActive?: boolean }[];
}

// Field names arrive as snake_case because the API `serialize()` helper
// recursively converts every camelCase key — including inside JSON columns —
// before sending the payload to the client.
interface TemplateData {
  doctor_photo?: string;
  doctor_name?: string;
  doctor_credentials?: string[]; // lines like "DHMS, BHB (Dhaka)"
  doctor_role?: string;
  doctor_reg_number?: string;
  product_image?: string;
  chamber_heading?: string;
  chamber_address_lines?: string[];
  chamber_phone_label?: string;
  cta_button_text?: string;
  faq_heading?: string;
  stats?: Array<{ label: string; value: number; suffix: string }>;
}

interface AkbdPage {
  id: number;
  slug: string;
  title: string;
  hero_headline?: string;
  hero_subheadline?: string;
  hero_image?: string;
  hero_badge?: string;
  features?: string;
  how_it_works?: string;
  testimonials?: string;
  faq?: string;
  guarantee_text?: string;
  whatsapp?: string;
  contact_mode?: string;
  primary_color?: string;
  template_data?: TemplateData | string | null;
  checkout_btn_text?: string;
  custom_shipping?: boolean;
  shipping_cost?: number;
  show_email?: boolean;
  show_city?: boolean;
  section_visibility?: string;
  resolved_products?: ResolvedProduct[];
}

function parseJSON<T>(s: string | undefined | null, fallback: T): T {
  if (!s) return fallback;
  try { return JSON.parse(s) as T; } catch { return fallback; }
}

export default function AkbdTemplateClient({ page }: { page: AkbdPage }) {
  const td: TemplateData = (typeof page.template_data === "string"
    ? parseJSON<TemplateData>(page.template_data, {})
    : page.template_data || {});

  const benefits = parseJSON<Array<{ icon?: string; title?: string; description?: string }>>(page.features, []);
  const whyChoose = parseJSON<Array<{ title?: string; description?: string }>>(page.how_it_works, []);
  const testimonials = parseJSON<Array<{ name: string; review: string; rating: number; image: string }>>(page.testimonials, []);
  const faq = parseJSON<Array<{ question: string; answer: string }>>(page.faq, []);

  const ctaLabel = td.cta_button_text || "অর্ডার করতে ক্লিক করুন";
  const phone = page.whatsapp || td.chamber_phone_label || "";

  // Per-section visibility — same JSON map the dashboard form writes. Default
  // true when a key is missing so existing pages keep every section visible.
  const vis = parseJSON<Record<string, boolean>>(page.section_visibility, {});
  const show = (key: string) => vis[key] !== false;

  // InitiateCheckout fires on the CTA click that takes the user to the order
  // form (the "purchase now" buttons that scroll to #checkout) — not on
  // scroll-into-view and not at submit. Fired once, with the full product
  // payload + all available parameters so Meta/GA4 get a complete event.
  const icProducts = page.resolved_products || [];
  const icProduct = icProducts[0];
  const icQty = icProduct?.selected_quantity || 1;
  const icSubtotal = icProduct ? Number(icProduct.price) * icQty : 0;
  const icFiredCta = useRef(false);
  const fireInitiateCheckout = () => {
    if (icFiredCta.current || !icProduct) return;
    icFiredCta.current = true;
    trackInitiateCheckout({
      content_ids: [String(icProduct.id)],
      content_name: icProduct.name,
      contents: [{
        id: icProduct.id,
        quantity: icQty,
        item_price: Number(icProduct.price) || 0,
        name: icProduct.name,
      }],
      num_items: icQty,
      value: icSubtotal,
    });
  };

  return (
    <div className="akbd-root">
      {/* 1. Hero badge */}
      {show("hero") && (
        <section className="akbd-hero">
          <div className="akbd-pill" dangerouslySetInnerHTML={{ __html: sanitizeInline(page.hero_badge || "জার্মানি ফর্মুলায় তৈরী") }} />
          {page.hero_subheadline && <p className="akbd-hero-sub" dangerouslySetInnerHTML={{ __html: sanitizeInline(page.hero_subheadline) }} />}
        </section>
      )}

      {/* 2. Doctor poster — only the photo itself.
          The credentials, name, registration, and role are baked INTO the
          poster image (Bengali title at top, DHMS/Consultant labels at the
          bottom), so we drop both the navy info card and the curved name
          bar — they were duplicating what's already in the poster. */}
      {show("akbd_chamber") && td.doctor_photo && (
        <section className="akbd-doctor-poster">
          <Image
            src={td.doctor_photo}
            alt={td.doctor_name || "Doctor"}
            width={720}
            height={900}
            className="akbd-doctor-poster-img"
            priority
            sizes="(max-width: 720px) 92vw, 720px"
          />
        </section>
      )}

      {/* 2b. Stats bar — animated counters under the doctor poster */}
      {show("akbd_stats") && <StatsBar td={td} />}

      {/* 3. Benefits panel */}
      {show("features") && benefits.length > 0 && (
        <section className="akbd-panel">
          <div className="akbd-panel-heading">আপনি যে উপকার পাবেন</div>
          <div className="akbd-bullets">
            {benefits.map((b, i) => (
              <div key={i} className="akbd-bullet">
                <span className="akbd-check">✓</span>
                <span>{b.description || b.title}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Product image + CTA + phone */}
      {(td.product_image || page.hero_image) && (
        <section className="akbd-product">
          <div className="akbd-product-card">
            <Image src={td.product_image || page.hero_image!} alt={page.title} width={500} height={400} className="akbd-product-img" />
          </div>
        </section>
      )}
      <div className="akbd-cta-row">
        <a href="#checkout" className="akbd-cta-btn" onClick={fireInitiateCheckout}>{ctaLabel}</a>
        {phone && <a href={`tel:${phone}`} className="akbd-phone">{phone}</a>}
      </div>

      {/* 5. Why choose us */}
      {show("how_it_works") && whyChoose.length > 0 && (
        <section className="akbd-panel">
          <div className="akbd-panel-heading">আমাদের থেকে কেনো নিবেন?</div>
          <div className="akbd-bullets akbd-bullets-2col">
            {whyChoose.map((w, i) => (
              <div key={i} className="akbd-bullet">
                <span className="akbd-check">✓</span>
                <span>{w.description || w.title}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Testimonials */}
      {show("testimonials") && testimonials.length > 0 && (
        <section className="akbd-testimonials">
          <div className="akbd-pill">সম্মানিত গ্রাহকের মন্তব্য</div>
          <TestimonialsCarousel items={testimonials} />
        </section>
      )}

      {/* 7. CTA again */}
      <div className="akbd-cta-row">
        <a href="#checkout" className="akbd-cta-btn" onClick={fireInitiateCheckout}>{ctaLabel}</a>
      </div>

      {/* 8. Address */}
      {show("akbd_chamber") && (td.chamber_address_lines && td.chamber_address_lines.length > 0) && (
        <section className="akbd-panel akbd-address-panel">
          <div className="akbd-panel-heading">{td.chamber_heading || "চেম্বারের ঠিকানা"}</div>
          <div className="akbd-address">
            {td.chamber_address_lines.map((l, i) => <div key={i}>{l}</div>)}
            {phone && <div className="akbd-address-phone"><a href={`tel:${phone}`}>{phone}</a></div>}
          </div>
        </section>
      )}

      {/* 9. Checkout — moved above the FAQ so users hit the order form first. */}
      <section id="checkout" className="akbd-checkout-wrap">
        <CheckoutPanel page={page} />
      </section>

      {/* 10. FAQ — now under the checkout. People who scroll past the form
          are typically the ones with questions, so the order makes sense. */}
      {show("faq") && faq.length > 0 && (
        <section className="akbd-faq-wrap">
          <div className="akbd-pill">{td.faq_heading || "প্রায়শই জিজ্ঞাসিত প্রশ্নাবলী"}</div>
          <FaqAccordion items={faq} />
        </section>
      )}

      {/* Floating contact bubble — mode from the LP's contact_mode
          (whatsapp / phone / messenger / all). */}
      <LpContactBubble pageWhatsapp={page.whatsapp} pageContactMode={page.contact_mode} />

      {/* Plain <style> with SSR'd content — guarantees no FOUC on reload.
          styled-jsx defers injection to client-side JS, which left bare text
          visible for a frame before hydration. */}
      <style dangerouslySetInnerHTML={{ __html: `
        :root {
          --akbd-navy: ${NAVY};
          --akbd-navy-deep: ${NAVY_DEEP};
          --akbd-teal: ${TEAL};
          --akbd-teal-dark: ${TEAL_DARK};
          --akbd-red: ${RED};
          --akbd-red-dark: ${RED_DARK};
        }
        .akbd-root {
          font-family: "Noto Sans Bengali", "Hind Siliguri", system-ui, sans-serif;
          background: #f3f5f8;
          color: #1a1a1a;
          min-height: 100vh;
          padding-bottom: 0;
        }
        .akbd-root * { box-sizing: border-box; }

        .akbd-pill {
          display: inline-block;
          background: var(--akbd-teal);
          color: #fff;
          padding: 14px 36px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 24px;
          letter-spacing: 0.2px;
        }

        /* Hero */
        .akbd-hero {
          text-align: center;
          padding: 32px 16px 14px;
        }
        .akbd-hero-sub {
          color: #1a1a1a;
          font-size: 23px;
          font-weight: 600;
          line-height: 1.5;
          margin: 20px auto 0;
          max-width: 720px;
        }

        /* Doctor poster — single full-width image card, no overlay UI.
           All doctor info (name, credentials, reg number, role) is
           baked into the image so we don't draw it again in HTML. */
        .akbd-doctor-poster {
          max-width: 760px;
          margin: 28px auto;
          padding: 0 16px;
          text-align: center;
        }
        .akbd-doctor-poster-img {
          width: 100%;
          max-width: 720px;
          height: auto;
          display: block;
          margin: 0 auto;
          border-radius: 14px;
        }

        /* Stats bar — 2x2 animated counter cards */
        .akbd-stats {
          max-width: 800px;
          margin: 24px auto;
          padding: 0 16px;
        }
        .akbd-stats-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 18px;
        }
        .akbd-stat-card {
          background: #fff;
          border: 1px solid #e2e6ea;
          border-radius: 16px;
          box-shadow: 0 6px 18px rgba(15, 40, 73, 0.06);
          padding: 26px 18px;
          text-align: center;
        }
        .akbd-stat-label {
          color: #5a6470;
          font-size: 18px;
          font-weight: 600;
          margin-bottom: 8px;
        }
        .akbd-stat-num {
          color: var(--akbd-navy);
          font-size: 30px;
          font-weight: 800;
          line-height: 1.2;
          font-variant-numeric: tabular-nums;
        }

        /* Panels */
        .akbd-panel {
          max-width: 800px;
          margin: 24px auto;
          background: var(--akbd-navy);
          color: #fff;
          border-radius: 16px;
          padding: 28px 24px;
        }
        .akbd-panel-heading {
          background: var(--akbd-teal);
          color: #fff;
          text-align: center;
          padding: 12px 24px;
          border-radius: 10px;
          font-weight: 700;
          font-size: 21px;
          margin: 0 auto 22px;
          width: fit-content;
        }
        .akbd-bullets {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px 24px;
        }
        .akbd-bullets-2col {
          grid-template-columns: repeat(2, 1fr);
        }
        .akbd-bullet {
          display: flex;
          gap: 10px;
          font-size: 17px;
          line-height: 1.55;
          align-items: flex-start;
        }
        .akbd-check {
          flex-shrink: 0;
          width: 26px;
          height: 26px;
          border-radius: 50%;
          background: var(--akbd-teal);
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 14px;
        }

        /* Product */
        .akbd-product {
          max-width: 460px;
          margin: 24px auto 12px;
        }
        .akbd-product-card {
          background: #fff;
          border-radius: 16px;
          padding: 16px;
          box-shadow: 0 4px 20px rgba(26, 58, 99, 0.1);
        }
        .akbd-product-img {
          width: 100%;
          height: auto;
          display: block;
          border-radius: 8px;
        }

        /* CTA */
        .akbd-cta-row {
          text-align: center;
          padding: 18px 16px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }
        .akbd-cta-btn {
          background: var(--akbd-red);
          color: #fff !important;
          text-decoration: none;
          padding: 12px 32px;
          border-radius: 999px;
          font-weight: 700;
          font-size: 16px;
          box-shadow: 0 4px 14px rgba(230, 57, 70, 0.35);
          transition: background 0.15s;
        }
        .akbd-cta-btn:hover { background: var(--akbd-red-dark); }
        .akbd-phone {
          color: var(--akbd-red);
          font-weight: 700;
          font-size: 18px;
          text-decoration: none;
        }

        /* Address — bigger text, phone styled as teal pill button
           that mirrors the chamber heading pill at the top of the panel. */
        .akbd-address {
          text-align: center;
          font-size: 18px;
          line-height: 1.75;
          font-weight: 500;
        }
        .akbd-address-phone {
          margin-top: 18px;
          text-align: center;
        }
        .akbd-address-phone a {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: var(--akbd-teal);
          color: #fff !important;
          font-weight: 700;
          font-size: 22px;
          letter-spacing: 0.5px;
          padding: 12px 32px;
          border-radius: 10px;
          text-decoration: none;
          transition: background 0.15s;
        }
        .akbd-address-phone a:hover {
          background: var(--akbd-teal-dark);
        }

        /* Testimonials */
        .akbd-testimonials {
          max-width: 1200px;
          margin: 32px auto;
          padding: 0 16px;
          text-align: center;
        }
        /* Testimonial carousel — cards stand free, arrows sit outside, dots below.
           Matches the akbd.live multi-card row look: no outer border, no fill. */
        .akbd-test-carousel {
          position: relative;
          margin-top: 22px;
          padding: 0 56px;
        }
        .akbd-test-arrow {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 34px;
          height: 34px;
          border-radius: 6px;
          background: transparent;
          color: #1a3a63;
          border: 1.5px solid #c5d1de;
          cursor: pointer;
          font-size: 22px;
          line-height: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0;
          padding-bottom: 3px;
          z-index: 2;
          transition: all 0.15s;
        }
        .akbd-test-arrow:hover {
          background: var(--akbd-teal);
          color: #fff;
          border-color: var(--akbd-teal);
        }
        .akbd-test-arrow-l { left: 0; }
        .akbd-test-arrow-r { right: 0; }
        .akbd-test-viewport {
          overflow: hidden;
        }
        .akbd-test-track {
          display: flex;
          will-change: transform;
          transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .akbd-test-frame {
          background: transparent;
          padding: 0 12px;
          box-sizing: border-box;
        }
        .akbd-test-img {
          width: 100%;
          height: auto;
          display: block;
          border-radius: 8px;
        }
        .akbd-test-dots {
          display: flex;
          justify-content: center;
          gap: 6px;
          margin-top: 18px;
        }
        .akbd-test-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #c5d1de;
          border: none;
          cursor: pointer;
          padding: 0;
          transition: all 0.2s;
        }
        .akbd-test-dot.active {
          background: #6b7a8a;
        }

        /* FAQ */
        .akbd-faq-wrap {
          max-width: 800px;
          margin: 24px auto 0;
          padding: 0 16px 60px;
          text-align: center;
        }
        .akbd-faq {
          margin-top: 18px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          text-align: left;
        }
        .akbd-faq-item {
          background: #fff;
          border-radius: 999px;
          padding: 0;
          box-shadow: 0 1px 4px rgba(0,0,0,0.05);
          overflow: hidden;
        }
        .akbd-faq-item.open {
          border-radius: 16px;
        }
        .akbd-faq-q {
          width: 100%;
          background: #fff;
          border: none;
          padding: 14px 22px;
          font-family: inherit;
          font-size: 15px;
          font-weight: 600;
          text-align: left;
          cursor: pointer;
          display: flex;
          justify-content: space-between;
          align-items: center;
          color: #1a1a1a;
        }
        .akbd-faq-q-icon {
          color: var(--akbd-teal);
          font-size: 20px;
          font-weight: 700;
        }
        .akbd-faq-a {
          padding: 0 22px 16px;
          font-size: 14px;
          line-height: 1.6;
          color: #444;
        }

        /* Checkout */
        .akbd-checkout-wrap {
          background: var(--akbd-navy);
          color: #fff;
          padding: 32px 16px 60px;
          margin-top: 28px;
        }
        .akbd-checkout-inner {
          max-width: 1000px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 28px;
        }
        .akbd-checkout-h {
          font-size: 18px;
          font-weight: 700;
          margin: 0 0 16px;
        }
        .akbd-form-field {
          margin-bottom: 14px;
        }
        .akbd-form-field label {
          display: block;
          font-size: 14px;
          font-weight: 600;
          margin-bottom: 6px;
        }
        .akbd-form-field input, .akbd-form-field textarea {
          width: 100%;
          padding: 10px 14px;
          border: none;
          border-radius: 8px;
          font-family: inherit;
          font-size: 15px;
          color: #1a1a1a;
          background: #fff;
        }
        .akbd-order-card {
          background: #fff;
          color: #1a1a1a;
          border-radius: 12px;
          padding: 18px;
        }
        .akbd-order-row {
          display: flex;
          justify-content: space-between;
          padding: 10px 0;
          border-bottom: 1px solid #eee;
          font-size: 14px;
        }
        .akbd-order-row:last-of-type { border-bottom: none; }
        .akbd-order-total {
          font-weight: 700;
          font-size: 16px;
        }
        .akbd-cod-box {
          background: #f4f6f8;
          border-radius: 8px;
          padding: 12px;
          margin: 12px 0;
        }
        .akbd-cod-h {
          font-weight: 700;
          font-size: 14px;
          margin-bottom: 4px;
        }
        .akbd-cod-text {
          color: #555;
          font-size: 12.5px;
        }
        .akbd-submit-btn {
          width: 100%;
          background: var(--akbd-teal);
          color: #fff;
          border: none;
          padding: 12px;
          border-radius: 8px;
          font-weight: 700;
          font-size: 15px;
          cursor: pointer;
          margin-top: 4px;
          font-family: inherit;
        }
        .akbd-submit-btn:hover { background: var(--akbd-teal-dark); }
        .akbd-submit-btn:disabled { opacity: 0.6; cursor: wait; }
        .akbd-privacy { font-size: 11.5px; color: #777; line-height: 1.5; margin-top: 10px; }

        /* Mobile */
        @media (max-width: 720px) {
          /* Doctor poster on mobile — tighter side padding */
          .akbd-doctor-poster { padding: 0 12px; margin: 18px auto; }
          /* Stats stay 2x2 on mobile, tighter gap + smaller numerals */
          .akbd-stats { padding: 0 16px; }
          .akbd-stats-grid { gap: 12px; }
          .akbd-stat-card { padding: 20px 10px; border-radius: 14px; }
          .akbd-stat-label { font-size: 15px; }
          .akbd-stat-num { font-size: 24px; }
          /* Inset full-width navy panels + product card so they don't touch the
             phone edges. 16px breathing room left and right. */
          .akbd-panel { margin-left: 16px; margin-right: 16px; }
          .akbd-product { margin-left: 16px; margin-right: 16px; max-width: calc(100% - 32px); }
          .akbd-doctor { padding-left: 16px; padding-right: 16px; }
          .akbd-bullets { grid-template-columns: 1fr; gap: 10px; }
          .akbd-bullets-2col { grid-template-columns: 1fr; }
          .akbd-checkout-inner { grid-template-columns: 1fr; }
          .akbd-test-frame { padding: 0; }
          .akbd-test-carousel { padding: 0 28px; }
          .akbd-test-arrow {
            width: 26px;
            height: 38px;
            font-size: 22px;
            border-radius: 4px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(2px);
          }
          .akbd-test-arrow-l { left: -2px; }
          .akbd-test-arrow-r { right: -2px; }
          .akbd-testimonials { padding: 0 8px; }

          /* Mobile typography — bump up so headings and body text are
             readable on phones. Bengali script especially benefits from
             larger sizes vs Latin at the same font-size. */
          .akbd-pill {
            font-size: 19px;
            padding: 11px 28px;
            border-radius: 10px;
          }
          .akbd-hero { padding: 24px 16px 10px; }
          .akbd-hero-sub {
            font-size: 21px;
            line-height: 1.5;
            margin-top: 16px;
          }
          .akbd-panel { padding: 22px 18px; }
          .akbd-panel-heading {
            font-size: 19px;
            padding: 11px 22px;
            margin-bottom: 20px;
          }
          .akbd-bullet { font-size: 18px; line-height: 1.6; gap: 12px; }
          .akbd-check { width: 28px; height: 28px; font-size: 15px; }
          .akbd-address { font-size: 17px; line-height: 1.7; }
          .akbd-address-phone a {
            font-size: 22px;
            padding: 12px 32px;
            letter-spacing: 0.4px;
          }
          .akbd-cta-btn { font-size: 17px; padding: 13px 34px; }
          .akbd-phone { font-size: 19px; }
          .akbd-faq-wrap { padding: 0 16px 30px; }
          .akbd-faq-q { font-size: 16px; padding: 16px 22px; }
          .akbd-faq-a { font-size: 15px; line-height: 1.7; padding: 0 22px 18px; }
          .akbd-checkout-wrap { padding: 28px 16px 60px; }
          .akbd-checkout-h { font-size: 19px; }
          .akbd-form-field label { font-size: 15px; }
          .akbd-form-field input,
          .akbd-form-field textarea { font-size: 16px; padding: 12px 14px; }
          .akbd-order-card { padding: 18px 16px; }
          .akbd-order-row { font-size: 15px; padding: 11px 0; }
          .akbd-order-total { font-size: 17px; }
          .akbd-cod-h { font-size: 15px; }
          .akbd-cod-text { font-size: 13.5px; }
          .akbd-submit-btn { font-size: 17px; padding: 14px; }
        }
      ` }} />
    </div>
  );
}

// ── Stats bar — 2x2 cards that count up 1→target when scrolled into view ──────
// Editable per-page via the dashboard akbd form (template_data.stats). When a
// page has no stats configured we fall back to these sensible defaults so older
// pages and the seed template still render a populated bar. toBn() renders the
// animated value in Bengali numerals; comma grouping (value ≥ 1000) survives
// the digit map because toBn only rewrites 0-9.
const AKBD_STATS_DEFAULT: Array<{ label: string; value: number; suffix: string }> = [
  { label: "অভিজ্ঞতা", value: 10, suffix: " বছর+" },
  { label: "রোগী", value: 8000, suffix: "+" },
  { label: "প্রতিষ্টান", value: 3, suffix: "+" },
  { label: "সুস্থতার হার", value: 90, suffix: " শতাংশ +" },
];

function StatsBar({ td }: { td: TemplateData }) {
  const stats = Array.isArray(td.stats) && td.stats.length > 0 ? td.stats : AKBD_STATS_DEFAULT;
  return (
    <section className="akbd-stats">
      <div className="akbd-stats-grid">
        {stats.map((s, i) => (
          <StatCard key={i} label={s.label} value={Number(s.value) || 0} suffix={s.suffix} />
        ))}
      </div>
    </section>
  );
}

function StatCard({ label, value, suffix }: { label: string; value: number; suffix: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [n, setN] = useState(1);
  const ran = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (!entries[0].isIntersecting || ran.current) return;
        ran.current = true;
        const dur = 1400;
        const t0 = performance.now();
        const tick = (t: number) => {
          const p = Math.min(1, (t - t0) / dur);
          const eased = 1 - Math.pow(1 - p, 3); // easeOutCubic
          setN(Math.max(1, Math.round(eased * value)));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.4 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [value]);

  const shown = value >= 1000 ? n.toLocaleString("en-US") : String(n);
  return (
    <div ref={ref} className="akbd-stat-card">
      <div className="akbd-stat-label">{label}</div>
      <div className="akbd-stat-num">{toBn(shown)}{suffix}</div>
    </div>
  );
}

// ── Testimonials carousel — translateX-based smooth slide ─────────────────────
// All images sit in a single flex track inside an overflow-hidden viewport.
// Clicking next/prev moves the track by one card-width with a CSS transition,
// so the change is a smooth left/right slide instead of a re-render flash.
function TestimonialsCarousel({ items }: { items: Array<{ name: string; review: string; rating: number; image: string }> }) {
  const images = items.map((t) => t.image).filter(Boolean);
  const [idx, setIdx] = useState(0);
  const [perSlide, setPerSlide] = useState(3);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const update = () => setPerSlide(window.innerWidth < 720 ? 1 : 3);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const maxIdx = Math.max(0, images.length - perSlide);
  const safeIdx = Math.min(idx, maxIdx);

  useEffect(() => {
    if (images.length <= perSlide || paused) return;
    const id = setInterval(() => setIdx((i) => (i >= maxIdx ? 0 : i + 1)), 4000);
    return () => clearInterval(id);
  }, [images.length, perSlide, paused, maxIdx]);

  if (images.length === 0) return null;

  const next = () => setIdx((i) => (i >= maxIdx ? 0 : i + 1));
  const prev = () => setIdx((i) => (i <= 0 ? maxIdx : i - 1));

  return (
    <div
      className="akbd-test-carousel"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <button
        type="button"
        aria-label="Previous testimonial"
        className="akbd-test-arrow akbd-test-arrow-l"
        onClick={prev}
      >
        ‹
      </button>
      <div className="akbd-test-viewport">
        <div
          className="akbd-test-track"
          style={{ transform: `translateX(-${safeIdx * (100 / perSlide)}%)` }}
        >
          {images.map((src, i) => (
            <div
              key={i}
              className="akbd-test-frame"
              style={{ flex: `0 0 ${100 / perSlide}%` }}
            >
              <Image
                src={src}
                alt={`Customer review ${i + 1}`}
                width={380}
                height={500}
                className="akbd-test-img"
                unoptimized
              />
            </div>
          ))}
        </div>
      </div>
      <button
        type="button"
        aria-label="Next testimonial"
        className="akbd-test-arrow akbd-test-arrow-r"
        onClick={next}
      >
        ›
      </button>
      {maxIdx > 0 && (
        <div className="akbd-test-dots">
          {Array.from({ length: maxIdx + 1 }).map((_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`Slide ${i + 1}`}
              className={`akbd-test-dot ${i === safeIdx ? "active" : ""}`}
              onClick={() => setIdx(i)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ── FAQ accordion ────────────────────────────────
function FaqAccordion({ items }: { items: Array<{ question: string; answer: string }> }) {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  return (
    <div className="akbd-faq">
      {items.map((q, i) => (
        <div key={i} className={`akbd-faq-item ${openIdx === i ? "open" : ""}`}>
          <button className="akbd-faq-q" onClick={() => setOpenIdx(openIdx === i ? null : i)}>
            <span>{q.question}</span>
            <span className="akbd-faq-q-icon">{openIdx === i ? "−" : "+"}</span>
          </button>
          {openIdx === i && <div className="akbd-faq-a">{q.answer}</div>}
        </div>
      ))}
    </div>
  );
}

// ── Checkout (simplified, akbd-styled) ────────────────────
function CheckoutPanel({ page }: { page: AkbdPage }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const fired = useRef(false);

  // Site shipping zones — used when this product is NOT on custom shipping.
  const [zones, setZones] = useState<{ id: number; name: string; rate: number; estimated_days?: string }[]>([]);
  const [zoneId, setZoneId] = useState<number | null>(null);
  // custom_shipping is known synchronously; zones must be fetched. Until the
  // fetch settles we DON'T know the real rate — never show a misleading
  // hardcoded fallback that then "jumps" to the real value.
  const [shippingReady, setShippingReady] = useState<boolean>(!!page.custom_shipping);

  const products = page.resolved_products || [];
  const product = products[0]; // primary product
  const qty = product?.selected_quantity || 1;
  const subtotal = product ? Number(product.price) * qty : 0;

  // Pull active shipping zones unless the LP overrides with custom shipping.
  useEffect(() => {
    if (page.custom_shipping) { setShippingReady(true); return; }
    let cancelled = false;
    fetch("/api/v1/shipping/zones", { headers: { Accept: "application/json" } })
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        if (cancelled) return;
        const list = (Array.isArray(data) ? data : data?.data || []) as typeof zones;
        setZones(list);
        if (list.length > 0) setZoneId(list[0].id);
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setShippingReady(true); });
    return () => { cancelled = true; };
  }, [page.custom_shipping]);

  const selectedZone = zones.find((z) => z.id === zoneId) || null;
  // Shipping resolution:
  //  • custom_shipping → the LP's fixed rate (0 is valid → nullish check)
  //  • else → the selected/only active shipping zone's rate
  //  • else (no zones configured at all) → 80 legacy fallback
  const shippingCost = page.custom_shipping
    ? (page.shipping_cost != null ? Number(page.shipping_cost) : 60)
    : (selectedZone ? Number(selectedZone.rate) : (zones.length > 0 ? Number(zones[0].rate) : 80));
  const total = subtotal + shippingCost;

  // === Incomplete-order capture ===
  // Mirror checkout/page.tsx: persist partial checkout to
  // /api/v1/incomplete-orders. source="landing". Two triggers so we never
  // miss it: (1) debounced 1.2s after a pause; (2) sendBeacon on page-hide /
  // tab-switch — catches the user filling the form and leaving WITHOUT a
  // pause (the debounce would otherwise be cleared on unmount).
  const capturePayloadRef = useRef<Record<string, unknown> | null>(null);

  useEffect(() => {
    if (submitting || success || !product) { capturePayloadRef.current = null; return; }
    const digits = phone.replace(/\D/g, "");
    if (!/^01[3-9]\d{8}$/.test(digits)) { capturePayloadRef.current = null; return; }

    const payload = {
      phone: digits,
      name: name || null,
      address: address || null,
      city: city || (selectedZone?.name || null),
      notes: `Landing page: ${page.slug}`,
      subtotal,
      shipping_cost: shippingCost,
      total,
      source: "landing",
      cart_items: [{
        product_id: product.id,
        variant_id: null,
        variant_label: null,
        name: product.name,
        price: Number(product.price) || 0,
        quantity: qty,
        image: product.image || null,
      }],
    };
    capturePayloadRef.current = payload;

    const handle = setTimeout(() => {
      fetch("/api/v1/incomplete-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
      }).catch(() => {});
    }, 1200);

    return () => clearTimeout(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submitting, success, product, name, phone, address, city, subtotal, shippingCost, total, selectedZone, qty]);

  // Flush on leave — covers "filled the form then left without pausing".
  useEffect(() => {
    const flush = () => {
      const p = capturePayloadRef.current;
      if (!p) return;
      try {
        const blob = new Blob([JSON.stringify(p)], { type: "application/json" });
        if (navigator.sendBeacon?.("/api/v1/incomplete-orders", blob)) return;
      } catch { /* fall through to fetch */ }
      fetch("/api/v1/incomplete-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(p),
        keepalive: true,
      }).catch(() => {});
    };
    const onVis = () => { if (document.visibilityState === "hidden") flush(); };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  useEffect(() => {
    if (!fired.current && product) {
      fired.current = true;
      trackViewContent({
        content_ids: [String(product.id)],
        content_name: product.name,
        content_type: "product",
        value: Number(product.price),
      });
    }
  }, [product]);

  // InitiateCheckout is fired by the parent AkbdTemplateClient when the user
  // clicks a "purchase now" CTA that scrolls to this form — see
  // fireInitiateCheckout(). Not tracked here.

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;
    const cleanPhone = phone.replace(/\D/g, "");
    if (!/^01[3-9]\d{8}$/.test(cleanPhone)) { alert("সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন।"); return; }
    if (!name.trim() || !address.trim()) { alert("নাম ও ঠিকানা দিন।"); return; }
    setSubmitting(true);
    try {
      const unitPrice = Number(product.price) || 0;
      // NOTE: InitiateCheckout is fired by the IntersectionObserver above
      // when the form scrolls into view — NOT here. Firing it at submit
      // collapsed it onto the Purchase event.
      const res = await api.createOrder({
        customer_name: name.trim(),
        customer_phone: cleanPhone,
        customer_address: address.trim(),
        customer_city: city.trim() || undefined,
        items: [{
          product_id: product.id,
          product_name: product.name,
          quantity: qty,
          price: unitPrice,
        }],
        payment_method: "cod",
        shipping_cost: shippingCost,
        subtotal,
        total,
        source: `lp:${page.slug}`,
      } as Record<string, unknown>);
      // Order id/token come back snake_cased by the API serializer.
      const orderRes = res as { id?: number; data?: { id?: number }; order_token?: string; token?: string };
      const orderIdNum = orderRes.id || orderRes.data?.id;
      const orderToken = orderRes.order_token || orderRes.token || "";
      const nameParts = name.trim().split(" ");
      trackPurchase({
        content_ids: [String(product.id)],
        content_name: product.name,
        contents: [{ id: product.id, quantity: qty, item_price: unitPrice }],
        num_items: qty,
        value: total,
        order_id: String(orderIdNum || ""),
        shipping: shippingCost,
        city: city.trim() || undefined,
      }, {
        // Advanced Matching — without these the Purchase EMQ stays ~3-4 and
        // FB attribution is poor. Also calls saveLastCustomer internally so
        // future events on this browser are enriched too.
        ph: cleanPhone,
        fn: nameParts[0] || undefined,
        ln: nameParts.length > 1 ? nameParts.slice(1).join(" ") : undefined,
        ct: city.trim() || undefined,
        country: "bd",
      });
      setSuccess(true);
      setTimeout(() => { window.location.href = `/order/${orderToken}`; }, 800);
    } catch (err: unknown) {
      alert((err instanceof Error ? err.message : "অর্ডার সম্পন্ন হয়নি, আবার চেষ্টা করুন।"));
    }
    setSubmitting(false);
  };

  if (success) {
    return (
      <div className="akbd-checkout-inner" style={{ gridTemplateColumns: "1fr", textAlign: "center" }}>
        <div>
          <h2>✓ অর্ডার সফলভাবে গৃহীত হয়েছে!</h2>
          <p>আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।</p>
        </div>
      </div>
    );
  }

  return (
    <form className="akbd-checkout-inner" onSubmit={onSubmit}>
      <div>
        <h3 className="akbd-checkout-h">Billing details</h3>
        <div className="akbd-form-field">
          <label>নাম *</label>
          <input name="name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div className="akbd-form-field">
          <label>ঠিকানা *</label>
          <input name="street-address" autoComplete="street-address" value={address} onChange={(e) => setAddress(e.target.value)} required />
        </div>
        <div className="akbd-form-field">
          <label>মোবাইল *</label>
          <input type="tel" name="tel" autoComplete="tel" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value)} required maxLength={11} />
        </div>
        {/* City / district field removed — name + address + mobile is enough.
            Server still accepts customer_city if it's ever sent. */}
      </div>

      <div>
        <h3 className="akbd-checkout-h">Your order</h3>
        <div className="akbd-order-card">
          {product && (
            <div className="akbd-order-row">
              <span>{product.name} × {qty}</span>
              <span>{subtotal}৳</span>
            </div>
          )}
          <div className="akbd-order-row">
            <span>Subtotal</span>
            <span>{subtotal}৳</span>
          </div>
          {!page.custom_shipping && zones.length > 1 && (
            <div className="akbd-order-row" style={{ display: "block" }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>ডেলিভারি এরিয়া</label>
              <select
                value={zoneId ?? ""}
                onChange={(e) => setZoneId(Number(e.target.value))}
                style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1px solid #d1d5db" }}
              >
                {zones.map((z) => (
                  <option key={z.id} value={z.id}>
                    {z.name} — ৳{z.rate}{z.estimated_days ? ` (${z.estimated_days})` : ""}
                  </option>
                ))}
              </select>
            </div>
          )}
          <div className="akbd-order-row">
            <span>Shipping</span>
            <span>{shippingReady ? `${shippingCost}৳` : "…"}</span>
          </div>
          <div className="akbd-order-row akbd-order-total">
            <span>Total</span>
            <span>{shippingReady ? `${total}৳` : "…"}</span>
          </div>
          <div className="akbd-cod-box">
            <div className="akbd-cod-h">Cash on delivery</div>
            <div className="akbd-cod-text">Pay with cash upon delivery.</div>
          </div>
          <button type="submit" className="akbd-submit-btn" disabled={submitting || !shippingReady}>
            {submitting
              ? "Processing..."
              : `${page.checkout_btn_text || "Place Order"}${shippingReady ? ` ${total}৳` : ""}`}
          </button>
          <p className="akbd-privacy">Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.</p>
        </div>
      </div>
    </form>
  );
}
