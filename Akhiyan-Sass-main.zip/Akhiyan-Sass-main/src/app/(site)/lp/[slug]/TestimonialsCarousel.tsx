"use client";

/**
 * Testimonials carousel — split out of LandingPageClient and loaded via
 * next/dynamic({ ssr:false }) so Swiper + its CSS are NOT in the initial
 * LP bundle. This is below the fold; lazy-loading it removes a large chunk
 * of unused/blocking JS from first paint (mobile TBT / main-thread win).
 */

import { FiStar, FiChevronLeft, FiChevronRight } from "react-icons/fi";
import { SafeNextImage } from "@/components/SafeImage";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";

type Testimonial = { name: string; review: string; rating: number; image?: string };

export default function TestimonialsCarousel({
  testimonials,
  color,
  title,
}: {
  testimonials: Testimonial[];
  color: string;
  title: string;
}) {
  return (
    <section className="py-10 md:py-14 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-8">
        <h2 className="text-3xl md:text-4xl font-extrabold text-center mb-6">{title}</h2>
        <div className="relative">
          <Swiper
            modules={[Autoplay, Pagination, Navigation]}
            spaceBetween={24}
            slidesPerView={1}
            breakpoints={{
              640: { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
            autoplay={{ delay: 4000, disableOnInteraction: false }}
            pagination={{ clickable: true, el: ".testimonial-dots" }}
            navigation={{ nextEl: ".testimonial-next", prevEl: ".testimonial-prev" }}
            loop={testimonials.length > 3}
            className="pb-12"
          >
            {testimonials.map((t, i) => (
              <SwiperSlide key={i}>
                <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border-b-4 h-full" style={{ borderColor: color }}>
                  <div className="flex mb-3 text-amber-400">
                    {Array.from({ length: 5 }).map((_, j) => (
                      <FiStar key={j} className={`w-4 h-4 ${j < t.rating ? "fill-amber-400" : "text-gray-200"}`} />
                    ))}
                  </div>
                  <p className="text-sm italic text-gray-700 mb-4 leading-relaxed line-clamp-4">&ldquo;{t.review}&rdquo;</p>
                  <div className="flex items-center gap-3">
                    {t.image ? (
                      <div className="w-9 h-9 rounded-full overflow-hidden shrink-0 relative">
                        <SafeNextImage src={t.image} alt={t.name} fill sizes="36px" className="object-cover" />
                      </div>
                    ) : (
                      <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0" style={{ backgroundColor: color }}>
                        {t.name[0]}
                      </div>
                    )}
                    <div className="font-bold text-gray-800 text-sm">{t.name}</div>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
          {/* Navigation arrows */}
          {testimonials.length > 3 && (
            <>
              <button className="testimonial-prev absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 z-10 w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center hover:shadow-xl transition-shadow hidden md:flex">
                <FiChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
              <button className="testimonial-next absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 z-10 w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center hover:shadow-xl transition-shadow hidden md:flex">
                <FiChevronRight className="w-5 h-5 text-gray-600" />
              </button>
            </>
          )}
          {/* Pagination dots */}
          <div className="testimonial-dots flex justify-center gap-1.5 mt-6" />
        </div>
      </div>
    </section>
  );
}
