/**
 * Shared landing-page loader + renderer, used by BOTH routes:
 *   - /lp/[slug]      (legacy path, still works)
 *   - /[slug]         (new clean root path, e.g. /ayurex)
 *
 * Keeping one implementation means the two routes never drift. The root
 * /[slug] route adds a reserved-word guard (it must not shadow /shop, /cart,
 * /about, etc.) before calling renderLandingPage().
 */
import { cache } from "react";
import { unstable_cache } from "next/cache";
import { notFound, redirect } from "next/navigation";
import type { Metadata } from "next";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import LandingPageClient from "./LandingPageClient";
import AkbdTemplateClient from "./AkbdTemplateClient";
import AyurexTemplateClient from "./AyurexTemplateClient";
import { LpEditProvider } from "./LpEdit";
import LpRealtimeRefresh from "./LpRealtimeRefresh";
import { getCmsPage, cmsPageMetadataFrom, renderCmsContent } from "../../p/[slug]/cms-shared";
import type { PrismaClient } from "@prisma/client";

export interface LandingPageData {
  id: number;
  slug: string;
  title: string;
  hero_headline?: string;
  hero_subheadline?: string;
  meta_title?: string;
  meta_description?: string;
  template?: string;
  template_data?: unknown;
  resolved_products?: Record<string, unknown>[];
  [key: string]: unknown;
}

async function loadLandingPage(prisma: PrismaClient, slug: string): Promise<LandingPageData | null> {
  try {
    const page = await prisma.landingPage.findFirst({ where: { slug, isActive: true } });
    if (!page) return null;
    let resolvedProducts: Record<string, unknown>[] = [];
    const prods = (page as { products?: string | null }).products;
    if (prods) {
      try {
        const productEntries = JSON.parse(prods) as { product_id: number; quantity?: number }[];
        const productIds = productEntries.map((p) => p.product_id);
        if (productIds.length > 0) {
          const products = await prisma.product.findMany({
            where: { id: { in: productIds } },
            include: { category: true, variants: { where: { isActive: true }, orderBy: { sortOrder: "asc" } } },
          });
          resolvedProducts = productEntries
            .map((entry) => {
              const product = products.find((p) => p.id === entry.product_id);
              if (!product) return null;
              return { ...serialize(product), selected_quantity: entry.quantity || 1 };
            })
            .filter(Boolean) as Record<string, unknown>[];
        }
      } catch { /* malformed products JSON — render without products */ }
    }
    return { ...(serialize(page) as Record<string, unknown>), resolved_products: resolvedProducts } as LandingPageData;
  } catch {
    return null;
  }
}

/** Cross-request cache, keyed by tenantId + slug. Tagged "landing-pages" so
 *  admin edits flush it instantly via revalidateAll("landing-pages"). */
export const getLandingPage = cache(
  (prisma: PrismaClient, tenantId: number, slug: string): Promise<LandingPageData | null> =>
    unstable_cache(
      () => loadLandingPage(prisma, slug),
      ["lp", String(tenantId), slug],
      { tags: ["landing-pages"], revalidate: 300 },
    )(),
);

export async function landingPageMetadata(slug: string): Promise<Metadata> {
  const { prisma, tenant } = await getPrismaForRequest();
  const page = await getLandingPage(prisma, tenant.id, slug);
  if (page) {
    return {
      title: page.meta_title || page.hero_headline || page.title,
      description: page.meta_description || page.hero_subheadline || "",
    };
  }
  // Not an LP — the same clean URL may be a CMS page. Use its SEO metadata.
  const cms = await getCmsPage(prisma, tenant.id, slug);
  return cmsPageMetadataFrom(cms);
}

/** Render the LP for `slug`, or notFound(). Shared by both routes. */
export async function renderLandingPage(slug: string): Promise<React.ReactElement> {
  const { prisma, tenant } = await getPrismaForRequest();
  const page = await getLandingPage(prisma, tenant.id, slug);
  if (!page) {
    // The proxy rewrites EVERY clean root URL /<slug> → /lp/<slug>, so this
    // resolver is the universal root-slug handler. When it's not a landing
    // page, fall through the other things that live at the root, in order:
    //   1. a published CMS page (renders as a NORMAL page — keeps chrome), then
    //   2. a shortlink redirect, then
    //   3. 404.
    const cms = await getCmsPage(prisma, tenant.id, slug);
    if (cms?.publishedData) {
      return renderCmsContent(cms.publishedData);
    }
    const link = await prisma.shortlink.findUnique({ where: { slug } }).catch(() => null);
    if (link && link.isActive && link.targetUrl) {
      redirect(link.targetUrl);
    }
    notFound();
  }

  let body: React.ReactNode;
  if (page.template === "akbd") {
    body = <AkbdTemplateClient page={page as Parameters<typeof AkbdTemplateClient>[0]["page"]} />;
  } else if (page.template === "ayurex") {
    body = <AyurexTemplateClient page={page as Parameters<typeof AyurexTemplateClient>[0]["page"]} />;
  } else {
    body = <LandingPageClient page={page} />;
  }
  return (
    <LpEditProvider pageId={page.id}>
      <LpRealtimeRefresh slug={page.slug} />
      {body}
    </LpEditProvider>
  );
}
