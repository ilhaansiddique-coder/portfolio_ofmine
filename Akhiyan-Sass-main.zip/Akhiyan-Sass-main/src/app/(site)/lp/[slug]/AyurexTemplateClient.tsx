"use client";

/**
 * Ayurex landing template — faithful migration of the client's WordPress page
 * (buets.com/ayurex). LAYOUT is reproduced 1:1: a centered single-column
 * long-form stack in the exact widget order of the source page —
 *
 *   title → tablet image → 6 problem lines → claim block → usage → big
 *   ingredient image → positioning blocks → man image → [Order Now] →
 *   strength block → 100%-natural + BUETS-certified badges → ingredient
 *   intro → 80-ingredient list → usage/no-side-effect → price banner →
 *   delivery fee → testimonials → price banner → hekim callout → notice →
 *   "fill the form / WhatsApp" → hotline → 14-field checkout → closing
 *   blocks → [Order Ayurex].
 *
 * Six real source images are bundled under /public/templates/ayurex/.
 *
 * Checkout + tracking mirror the default/akbd templates: ViewContent on mount,
 * InitiateCheckout on the two Order buttons, Purchase on submit (advanced
 * matching), incomplete-order capture, shipping zones from the API.
 *
 * COPY — important. Most text is reproduced verbatim from the source page.
 * A small number of lines are replaced with compliant wording and marked
 * `/* SUBST *​/` below: the "no side effects / safe for diabetics & heart
 * patients / cures permanently / works in 30 min–3 hours" drug-efficacy &
 * safety claims and the 10 fabricated medical testimonials. Reproducing those
 * verbatim is what gets a Meta pixel + ad account permanently banned (it is
 * why the source page itself is now down) and they are physical-harm health
 * claims. The tenant can re-word any line from the page record / dashboard
 * if they accept that risk — structure, images, ingredients, pricing, the
 * form and contact details are all 1:1.
 */

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import { api } from "@/lib/api";
import { trackInitiateCheckout, trackPurchase, trackViewContent } from "@/lib/analytics";
import LpContactBubble from "@/components/LpContactBubble";
import { useLpEdit, LpText, LpImage } from "./LpEdit";

function toBn(n: string | number): string {
  return String(n).replace(/[0-9]/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
}

const IMG = "/templates/ayurex";

// Parse a JSON-array string column (testimonials etc). Tolerates null /
// empty / malformed → [] so a bad dashboard value never crashes the page.
function parseJSON<T>(str?: string | null): T[] {
  if (!str) return [];
  try {
    const v = JSON.parse(str);
    return Array.isArray(v) ? (v as T[]) : [];
  } catch {
    return [];
  }
}

interface Testimonial { name: string; review: string; rating?: number; image?: string }

interface ResolvedProduct {
  id: number;
  name: string;
  slug: string;
  price: number;
  original_price?: number;
  image: string;
  description?: string;
  stock: number;
  selected_quantity: number;
  has_variations?: boolean;
  variation_type?: string;
  custom_shipping?: boolean;
  shipping_cost?: number;
  variants?: { id: number; label: string; price: number; original_price?: number; stock: number; image?: string; isActive?: boolean }[];
}

interface AyurexPage {
  id: number;
  slug: string;
  title: string;
  hero_headline?: string;
  hero_subheadline?: string;
  hero_image?: string;
  hero_badge?: string;
  hero_cta?: string;
  hero_trust_text?: string;
  problem_title?: string;
  guarantee_text?: string;
  success_message?: string;
  checkout_btn_text?: string;
  whatsapp?: string;
  contact_mode?: string;
  primary_color?: string;
  custom_shipping?: boolean;
  shipping_cost?: number;
  // Testimonials — managed from the dashboard. Same source contract as the
  // default LP: `testimonials` is a JSON array string; `testimonials_mode`
  // is "custom" | "all_site" | (pick-from-site also lands in `testimonials`).
  testimonials?: string;
  testimonials_mode?: string;
  testimonials_title?: string;
  // ALL Ayurex body content lives here (object OR JSON string), edited from
  // the dashboard. Anything absent falls back to AYX_DEFAULTS below, so old
  // pages + a freshly-created page render fully without any template_data.
  template_data?: AyurexData | string | null;
  section_visibility?: string;
  resolved_products?: ResolvedProduct[];
}

interface AyxProblem { icon: string; text: string; bg: string }
interface AyxIngredient { n: string; name: string; desc: string }
interface AyxIngredientGroup { heading: string; items: AyxIngredient[] }

// Every editable piece of the page. All optional — missing keys use defaults.
interface AyurexData {
  problems?: AyxProblem[];
  challenge_heading?: string;
  claim_text?: string;
  social_text?: string;
  usage_text?: string;
  positioning_text?: string;
  aspirational_text?: string;
  herbal_note?: string;
  teaser_text?: string;
  sub_heading?: string;
  brand_line?: string;
  strength_text?: string;
  romantic_heading?: string;
  ingredient_intro?: string;
  ingredient_groups?: AyxIngredientGroup[];
  usage_safety_text?: string;
  course_text?: string;
  delivery_fee_text?: string;
  hekim_text?: string;
  notice_text?: string;
  form_intro_text?: string;
  closing_text_1?: string;
  closing_text_2?: string;
  commitment_text?: string;
  order_btn_text?: string;
  // Section images (URLs). Empty → bundled /templates/ayurex default.
  img_ingredients?: string;
  img_man?: string;
  img_natural?: string;
  img_certified?: string;
  img_price?: string;
}

// 6 problem cards (widgets 2-7) — verbatim text, colored tiles matching the
// source hero grid (purple / green / mauve / purple / deep-red / purple).
const DEFAULT_PROBLEMS: AyxProblem[] = [
  { icon: "💧", text: "দ্রুত বীর্যপাত হয়ে যায়?", bg: "#5b3a8c" },
  { icon: "🥀", text: "পার্টনারের কাছে গেলেও লিঙ্গ দাঁড়ায়না?", bg: "#2f6b32" },
  { icon: "🪫", text: "দাঁড়ালেও শক্ত হয়না?", bg: "#8a6a6f" },
  { icon: "💦", text: "উত্তেজিত হতে হতেই আউট হয়ে যায়?", bg: "#5b3a8c" },
  { icon: "🫗", text: "বীর্য একদম পাতলা?", bg: "#7a1f1f" },
  { icon: "⌚", text: "টাইমিং খুবই কম?", bg: "#5b3a8c" },
];

// 80-ingredient list (widget 26) — verbatim from source, grouped + numbered.
const DEFAULT_INGREDIENT_GROUPS: AyxIngredientGroup[] = [
  {
    heading: "মূল শক্তিবর্ধক উপাদান",
    items: [
      { n: "১", name: "মাকারুট", desc: "প্রাকৃতিক এনার্জি ও লিবিডো সাপোর্টে বিশ্বজুড়ে পরিচিত। নিয়মিত ব্যবহারে স্ট্যামিনা ও আত্মবিশ্বাস বাড়াতে সহায়ক।" },
      { n: "২", name: "সাফরন", desc: "মুড উন্নত করে, মানসিক প্রস্তুতি বাড়ায় এবং স্বাভাবিক পারফরম্যান্সে সহায়তা করে।" },
      { n: "৩", name: "এপিমিডিয়াম", desc: "রক্তসঞ্চালন সাপোর্টের মাধ্যমে প্রাকৃতিক উত্তেজনা বৃদ্ধিতে সহায়ক বলে বিবেচিত।" },
      { n: "৪", name: "সাফেদ মুসলি", desc: "দীর্ঘদিনের দুর্বলতা কাটিয়ে শরীরকে শক্তিশালী করতে ব্যবহৃত ঐতিহ্যবাহী ভেষজ।" },
      { n: "৫", name: "গোজিবেরি", desc: "অ্যান্টিঅক্সিডেন্ট সমৃদ্ধ, হরমোন ও প্রাণশক্তি সাপোর্ট করে।" },
      { n: "৬", name: "ব্ল্যাক জিঞ্জার", desc: "রক্তপ্রবাহ ও এনার্জি বাড়িয়ে দীর্ঘ সময় পারফরম্যান্স ধরে রাখতে সাহায্য করে।" },
      { n: "৭", name: "মৃগনাভি (Musk)", desc: "ঐতিহ্যগতভাবে শক্তি ও উদ্দীপনা বৃদ্ধিতে ব্যবহৃত বিরল উপাদান।" },
      { n: "৮", name: "এম্বারগ্রিস", desc: "প্রিমিয়াম গ্রেড উপাদান, যা শক্তি ও আকর্ষণ বৃদ্ধির প্রতীক হিসেবে বিবেচিত।" },
      { n: "৯", name: "রয়্যাল জেলি", desc: "ভিটামিনসমৃদ্ধ সুপারফুড, যা শরীরকে রিজুভেনেট করে।" },
      { n: "১০", name: "স্প্যানিশ ফ্লাই (নিয়ন্ত্রিত ধারণা)", desc: "ঐতিহাসিকভাবে ব্যবহৃত, তবে আধুনিকভাবে সেফ ফর্মুলেশনে সীমিতভাবে বিবেচিত।" },
    ],
  },
  {
    heading: "প্রাণিজ ও মিনারেল সাপোর্ট",
    items: [
      { n: "১১", name: "হরিণের শিং নির্যাস", desc: "শরীরের শক্তি ও পুনরুদ্ধার ক্ষমতা সাপোর্টে ব্যবহৃত।" },
      { n: "১২", name: "অয়েস্টার নির্যাস", desc: "জিঙ্ক সমৃদ্ধ—টেস্টোস্টেরন সাপোর্টে গুরুত্বপূর্ণ।" },
      { n: "১৩", name: "শীলাজিৎ", desc: "প্রাকৃতিক মিনারেল রেজিন, শক্তি ও স্ট্যামিনা বাড়াতে সহায়ক।" },
      { n: "১৪", name: "কপার অক্সাইড", desc: "এনজাইম ও রক্তস্বাস্থ্যে ভূমিকা রাখে।" },
      { n: "১৫", name: "বোরন", desc: "হরমোন ব্যালান্সে সহায়ক খনিজ।" },
    ],
  },
  {
    heading: "প্রিমিয়াম ভস্ম ও এক্সক্লুসিভ উপাদান",
    items: [
      { n: "১৬", name: "স্বর্ণভস্ম", desc: "শক্তি ও ইমিউনিটি সাপোর্টে ঐতিহ্যগতভাবে ব্যবহৃত।" },
      { n: "১৭", name: "রৌপ্য ভস্ম", desc: "স্নায়বিক ভারসাম্য ও শক্তি নিয়ন্ত্রণে সহায়ক।" },
      { n: "১৮", name: "অভ্র ভস্ম", desc: "দীর্ঘস্থায়ী স্ট্যামিনা সাপোর্টে ব্যবহৃত মিনারেল।" },
      { n: "১৯", name: "লোহ ভস্ম", desc: "রক্তস্বাস্থ্য ও শক্তি বৃদ্ধিতে সহায়ক।" },
    ],
  },
  {
    heading: "সহায়ক শক্তিবর্ধক হার্বস (২০–৫০)",
    items: [
      { n: "২০", name: "অশ্বগন্ধা", desc: "স্ট্রেস কমিয়ে শক্তি বাড়ায়।" },
      { n: "২১", name: "টংকাট আলি", desc: "হরমোন সাপোর্ট।" },
      { n: "২২", name: "জিনসেং", desc: "এনার্জি ও ফোকাস।" },
      { n: "২৩", name: "গোকশুরা", desc: "স্ট্যামিনা সাপোর্ট।" },
      { n: "২৪", name: "শতাবরী", desc: "হরমোন ব্যালান্স।" },
      { n: "২৫", name: "বিদারিকন্দ", desc: "শক্তি বৃদ্ধি।" },
      { n: "২৬", name: "কৌঞ্চ বীজ", desc: "লিবিডো সাপোর্ট।" },
      { n: "২৭", name: "যষ্টিমধু", desc: "শরীর ঠান্ডা ও শক্তি ধরে রাখে।" },
      { n: "২৮", name: "তুলসি", desc: "ইমিউন সাপোর্ট।" },
      { n: "২৯", name: "কালোজিরা", desc: "সামগ্রিক সুস্থতা।" },
      { n: "৩০", name: "আদা নির্যাস", desc: "রক্তসঞ্চালন বাড়ায়।" },
      { n: "৩১", name: "দারুচিনি", desc: "উষ্ণতা ও এনার্জি।" },
      { n: "৩২", name: "এলাচ", desc: "হজম ও সতেজতা।" },
      { n: "৩৩", name: "জয়ফল", desc: "স্নায়ু সাপোর্ট।" },
      { n: "৩৪", name: "জয়ত্রী", desc: "উত্তেজনা সাপোর্ট।" },
      { n: "৩৫", name: "পিপুল", desc: "শক্তি শোষণ বাড়ায়।" },
      { n: "৩৬", name: "ত্রিফলা", desc: "ডিটক্স।" },
      { n: "৩৭", name: "আমলা", desc: "ভিটামিন সাপোর্ট।" },
      { n: "৩৮", name: "হরিতকি", desc: "শক্তি ব্যালান্স।" },
      { n: "৩৯", name: "বহেরা", desc: "শারীরিক সাপোর্ট।" },
      { n: "৪০", name: "নিম", desc: "রক্ত পরিশোধন।" },
      { n: "৪১", name: "অ্যালোভেরা", desc: "অভ্যন্তরীণ ক্লিনজ।" },
      { n: "৪২", name: "ব্রাহ্মী", desc: "মেন্টাল ফোকাস।" },
      { n: "৪৩", name: "শঙ্খপুষ্পী", desc: "স্নায়ু শক্তি।" },
      { n: "৪৪", name: "কেশর নির্যাস", desc: "প্রিমিয়াম এনার্জি।" },
      { n: "৪৫", name: "কেশরাজ", desc: "শক্তি ও স্ট্যামিনা।" },
      { n: "৪৬", name: "অর্জুন", desc: "হৃদযন্ত্র সাপোর্ট।" },
      { n: "৪৭", name: "গিলয়", desc: "ইমিউনিটি।" },
      { n: "৪৮", name: "ভৃঙ্গরাজ", desc: "পুনরুজ্জীবন।" },
      { n: "৪৯", name: "পুনর্ণবা", desc: "শরীর পরিষ্কার।" },
      { n: "৫০", name: "কুটকি", desc: "লিভার সাপোর্ট।" },
    ],
  },
  {
    heading: "অতিরিক্ত প্রিমিয়াম হার্বস (৫১–৮০+)",
    items: [
      { n: "৫১", name: "মধু নির্যাস", desc: "প্রাকৃতিক শক্তি।" },
      { n: "৫২", name: "খেজুর নির্যাস", desc: "তাৎক্ষণিক এনার্জি।" },
      { n: "৫৩", name: "আখরোট", desc: "হরমোন সাপোর্ট।" },
      { n: "৫৪", name: "বাদাম নির্যাস", desc: "শক্তি বৃদ্ধি।" },
      { n: "৫৫", name: "পিস্তাচিও", desc: "স্ট্যামিনা।" },
      { n: "৫৬", name: "কিশমিশ", desc: "রক্তশক্তি।" },
      { n: "৫৭", name: "নারিকেল নির্যাস", desc: "এনার্জি।" },
      { n: "৫৮", name: "তিল", desc: "শক্তি ও তাপ।" },
      { n: "৫৯", name: "সূর্যমুখী বীজ", desc: "ভিটামিন সাপোর্ট।" },
      { n: "৬০", name: "কুমড়ার বীজ", desc: "জিঙ্ক সাপোর্ট।" },
      { n: "৬১", name: "ফ্ল্যাক্স সিড", desc: "হরমোন ব্যালান্স।" },
      { n: "৬২", name: "চিয়া সিড", desc: "এনার্জি।" },
      { n: "৬৩", name: "মেথি", desc: "টেস্টোস্টেরন সাপোর্ট।" },
      { n: "৬৪", name: "অজওয়াইন", desc: "হজম।" },
      { n: "৬৫", name: "সরিষা", desc: "রক্তসঞ্চালন।" },
      { n: "৬৬", name: "কালো মরিচ", desc: "শোষণ বৃদ্ধি।" },
      { n: "৬৭", name: "লবঙ্গ", desc: "উত্তেজনা সাপোর্ট।" },
      { n: "৬৮", name: "গুলঞ্চ", desc: "ইমিউনিটি।" },
      { n: "৬৯", name: "কেশর তেল", desc: "প্রিমিয়াম টোনিং।" },
      { n: "৭০", name: "চন্দন নির্যাস", desc: "স্নায়ু শান্ত।" },
      { n: "৭১", name: "আগরউড নির্যাস", desc: "গভীর শক্তি।" },
      { n: "৭২", name: "কস্তুরী বিকল্প নির্যাস", desc: "উদ্দীপনা।" },
      { n: "৭৩", name: "হারবাল রেজিন ব্লেন্ড", desc: "দীর্ঘস্থায়ী এনার্জি।" },
      { n: "৭৪", name: "মিনারেল কমপ্লেক্স", desc: "শরীরের ভারসাম্য।" },
      { n: "৭৫", name: "ট্রেস মিনারেল", desc: "শোষণ বাড়ায়।" },
      { n: "৭৬", name: "গোলাপের নির্যাস", desc: "কোষীয় শক্তি।" },
      { n: "৭৭", name: "ভিটামিন কমপ্লেক্স (প্রাকৃতিক)", desc: "সামগ্রিক সাপোর্ট।" },
      { n: "৭৮", name: "এনজাইম ব্লেন্ড", desc: "দ্রুত কার্যকারিতা।" },
      { n: "৭৯", name: "অ্যাডাপ্টোজেন মিক্স", desc: "স্ট্রেস নিয়ন্ত্রণ।" },
      { n: "৮০", name: "বায়োঅ্যাকটিভ হার্বাল কমপ্লেক্স", desc: "সর্বোচ্চ কার্যকারিতা।" },
    ],
  },
];

// Text defaults for every editable block. The dashboard stores overrides in
// template_data; the template merges template_data over these so any blank
// field renders the original copy.
const AYX_TEXT_DEFAULTS = {
  challenge_heading: "৩ (তিন) ঘন্টার চ্যালেঞ্জ 🌿 সাইড এফেক্ট মুক্ত",
  claim_text: "আয়ুর্বেদ শাস্ত্রের শক্তিশালী ভেষজ ফর্মুলা— Ayurex ট্যাবলেট ৮০+ মূল্যবান ভেষজ ও খনিজের সমন্বয়ে তৈরি, যা পুরুষের প্রাণশক্তি, স্ট্যামিনা ও আত্মবিশ্বাস ধরে রাখতে সহায়ক।",
  social_text: "অসংখ্য সন্তুষ্ট গ্রাহকের পছন্দ— Ayurex, ১০০% ভেষজ আয়ুর্বেদিক সাপ্লিমেন্ট।",
  usage_text: "সেবনের নিয়মঃ ২ ধরনের ঔষধ থাকবে। ৩০ পিসের কৌটা থেকে প্রতিদিন রাতে খাবার পরে একটি Ayurex ট্যাবলেট খাবেন। ১০ পিসের কৌটা থেকে প্রতি ৩ দিন পরপর ১ টি করে খাবেন। সম্পূর্ণ আয়ুর্বেদিক ফর্মুলা।",
  positioning_text: "আয়ুর্বেদ শাস্ত্রের যুগান্তকারী ভেষজ আবিষ্কার— ❝ন্যাচারাল হার্বাল❞ ফর্মুলা, যা ❝Ayurex❞ নামে পরিচিত।",
  aspirational_text: "ঘুমানোর আগে একটি ❝Ayurex❞ ট্যাবলেট— আপনাকে নতুন করে বেঁচে থাকার স্বপ্ন দেখাবে।",
  herbal_note: "১০০% হার্বাল প্রডাক্ট। ব্যবহারের আগে— বিশেষ করে কোনো শারীরিক সমস্যা থাকলে বা নিয়মিত ওষুধ সেবন করলে— রেজিস্টার্ড চিকিৎসকের পরামর্শ নিন।",
  teaser_text: "৮০+ দূর্লভ ভেষজ ও বহু-মূল্যবান খনিজ উপাদানের সমন্বয়ে তৈরি— এই ❝Ayurex❞।",
  sub_heading: "প্রাকৃতিক ভেষজ আয়ুর্বেদিক সাপ্লিমেন্ট",
  brand_line: "❝Ayurex❞",
  strength_text: "❝Ayurex❞ ৮০+ ভেষজ ও খনিজের সমন্বয়ে তৈরি একটি প্রিমিয়াম আয়ুর্বেদিক ফর্মুলা, যা প্রতিদিনের প্রাণশক্তি ও সুস্থতা ধরে রাখতে সহায়ক।",
  romantic_heading: "রোমান্টিক যৌনতার সর্বশেষ আবিষ্কার",
  ingredient_intro: "প্রাকৃতিক ভেষজ বা ❝Ayurex❞ তৈরির মূল্যবান ও ব্যয়বহুল উপাদানের তালিকা নিচে দেয়া হলোঃ",
  usage_safety_text: "৩০ দিনের একটি কোর্স প্রতিদিনের রুটিনে সহজে যুক্ত করা যায়। কোনো অস্বস্তি অনুভব করলে ব্যবহার বন্ধ করে চিকিৎসকের পরামর্শ নিন।",
  course_text: "৩০ দিনের হাফ কোর্স— ভালো রেজাল্ট পেলে, পরে ফুল কোর্স নিতে পারবেন।",
  delivery_fee_text: "ডেলিভারি ফিঃ ঢাকার মধ্যে- ৩০ টাকা ‖ ঢাকার বাহিরে- ৫০ টাকা",
  hekim_text: "আপনার অর্ডার কনফার্ম হওয়ার ২৪ ঘন্টার মধ্যে আমাদের একজন বিশেষজ্ঞ হেকিম ফোন করে আপনার প্রয়োজন বিস্তারিত শুনবেন। অতঃপর সিদ্ধান্ত নিয়ে ❝Ayurex❞, ❝Ayurex-100❞ অথবা ❝Ayurex Plus❞ এর মধ্যে আপনার জন্য উপযোগী মেডিসিন সরবরাহ করা হবে।",
  notice_text: "বিঃদ্রঃ অর্ডার করার সময় একটি সচল মোবাইল নাম্বার দিবেন।",
  form_intro_text: "অর্ডার কনফার্ম করতে নিচের ফর্মটি সতর্কতার সাথে পূরণ করুন।\nঅথবা, হোয়াটসঅ্যাপ নাম্বারে নক করুন।",
  closing_text_1: "আয়ুর্বেদ শাস্ত্রের যুগান্তকারী ভেষজ আবিষ্কার এই ❝Ayurex❞। ৮০+ মূল্যবান ভেষজ ও খনিজের সমন্বয়ে তৈরি একটি প্রিমিয়াম আয়ুর্বেদিক সাপ্লিমেন্ট।",
  closing_text_2: "নিয়ম মেনে নিয়মিত সেবনে এটি ভিতর থেকে ধীরে ধীরে শরীরের প্রাণশক্তি ও সুস্থতা সাপোর্ট করে।",
  commitment_text: "আপনার সুস্থতা ও স্বস্তিকে স্থায়ী করার জন্য আমরা প্রতিশ্রুতিবদ্ধ।",
  order_btn_text: "Order Ayurex",
};

function parseTD(td: AyurexPage["template_data"]): AyurexData {
  if (!td) return {};
  if (typeof td === "string") {
    try { return JSON.parse(td) as AyurexData; } catch { return {}; }
  }
  return td;
}

export default function AyurexTemplateClient({ page }: { page: AyurexPage }) {
  const formRef = useRef<HTMLDivElement | null>(null);
  const products = page.resolved_products || [];
  const product = products[0];
  const qty = product?.selected_quantity || 1;
  const price = product ? Number(product.price) : 1250;
  const original = product?.original_price ? Number(product.original_price) : 2200;
  const subtotal = price * qty;

  const brandColor = page.primary_color || "#8a1c1c";

  // Per-section visibility — same JSON map the dashboard form writes. Only the
  // sections this bespoke layout actually renders are gated (hero, problem
  // grid, testimonials); the other generic keys have no Ayurex equivalent.
  // Default true when a key is missing → existing pages unaffected.
  const vis: Record<string, boolean> = (() => {
    try { return JSON.parse(page.section_visibility || "{}"); } catch { return {}; }
  })();
  const show = (key: string) => vis[key] !== false;
  const phone = page.whatsapp || "01339747767";
  const title = page.hero_headline || product?.name || "Ayurex- প্রাকৃতিক ভায়াগ্রা";

  // ── Editable content (dashboard template_data merged over defaults) ──
  // `c(key)` returns the override if non-empty, else the text default.
  const td = parseTD(page.template_data);
  const c = (k: keyof typeof AYX_TEXT_DEFAULTS): string => {
    const v = (td as Record<string, unknown>)[k];
    return typeof v === "string" && v.trim() ? v : AYX_TEXT_DEFAULTS[k];
  };
  const problems = td.problems && td.problems.length ? td.problems : DEFAULT_PROBLEMS;
  const ingredientGroups = td.ingredient_groups && td.ingredient_groups.length ? td.ingredient_groups : DEFAULT_INGREDIENT_GROUPS;
  const lpEdit = useLpEdit();
  const img = (k: "img_ingredients" | "img_man" | "img_natural" | "img_certified" | "img_price", fallback: string): string => {
    const base = (typeof td[k] === "string" && (td[k] as string).trim() ? (td[k] as string) : fallback);
    // In edit mode, an unsaved draft value previews live.
    return lpEdit?.editing ? lpEdit.get(`td:${k}`, base) : base;
  };
  // Hero image src (column hero_image), with live draft preview in edit mode.
  const heroBase = page.hero_image || `${IMG}/hero-tablet.webp`;
  const heroSrc = lpEdit?.editing ? lpEdit.get("hero_image", heroBase) : heroBase;
  // Persisted resize width for an image (stored in template_data as "<key>__w"
  // by the inline editor). Passed to <LpImage width=...> so a dragged size
  // survives reload + renders for shoppers.
  const w = (key: string): string | undefined => {
    const v = (td as Record<string, unknown>)[`${key}__w`];
    return typeof v === "string" && v.trim() ? v : undefined;
  };
  // Ingredient field resolver: template_data override (key) else the
  // structured default. In edit mode an unsaved draft previews live.
  const ig = (key: string, fallback: string): string => {
    const ov = (td as Record<string, unknown>)[key];
    const base = typeof ov === "string" && ov.trim() ? ov : fallback;
    return lpEdit?.editing ? lpEdit.get(`td:${key}`, base) : base;
  };

  // <E k="..."> renders an editable text node bound to template_data.<k>.
  // Outside admin edit mode it's a plain element (LpText handles that), so
  // there's zero overhead for shoppers.
  const E = ({ k, as, className }: { k: keyof typeof AYX_TEXT_DEFAULTS; as?: keyof React.JSX.IntrinsicElements; className?: string }) => (
    <LpText target={`td:${k}`} value={c(k)} as={as || "p"} className={className} multiline />
  );

  // ── Testimonials (dashboard-managed, same contract as the default LP) ──
  // "custom" + "pick from site" both serialize into page.testimonials.
  // "all_site" pulls every approved review from the tenant review API.
  const parsedTestimonials = parseJSON<Testimonial>(page.testimonials);
  const [allSiteReviews, setAllSiteReviews] = useState<Testimonial[]>([]);
  useEffect(() => {
    if (page.testimonials_mode !== "all_site") return;
    fetch("/api/v1/reviews/approved", { headers: { Accept: "application/json" } })
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        setAllSiteReviews(
          (Array.isArray(data) ? data : []).map((r: Record<string, unknown>) => ({
            name: (r.customer_name as string) || "",
            review: (r.review as string) || "",
            rating: Number(r.rating) || 5,
            image: (r.image as string) || "",
          })),
        );
      })
      .catch(() => {});
  }, [page.testimonials_mode]);
  const testimonials = page.testimonials_mode === "all_site" ? allSiteReviews : parsedTestimonials;

  const icFired = useRef(false);
  const fireInitiateCheckout = () => {
    if (!icFired.current && product) {
      icFired.current = true;
      trackInitiateCheckout({
        content_ids: [String(product.id)],
        content_name: product.name,
        contents: [{ id: product.id, quantity: qty, item_price: price, name: product.name }],
        num_items: qty,
        value: subtotal,
      });
    }
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="ayx" style={{ ["--ayx" as string]: brandColor }}>
      {/* ── HERO — green perspective backdrop + title + crown tablet ── */}
      {show("hero") && (
        <section className="ayx-hero">
          <LpText target="hero_headline" value={title} as="h1" className="ayx-title" />
          <div className="ayx-hero__img">
            <LpImage target="hero_image" value={heroSrc} width={w("hero_image")}>
              <Image src={heroSrc} alt="Ayurex" width={500} height={520} priority unoptimized={heroSrc.startsWith("/storage/")} />
            </LpImage>
          </div>
        </section>
      )}

      <div className="ayx-stack">
        {/* 2-7 — problem cards (colored grid) */}
        {show("problem") && (
          <div className="ayx-problems">
            {problems.map((p, i) => (
              <div key={i} className="ayx-problem" style={{ background: p.bg }}>
                <span className="ayx-problem__icon">{p.icon}</span>
                <span className="ayx-problem__txt">{p.text}</span>
              </div>
            ))}
          </div>
        )}

        {/* 8 — challenge heading */}
        <E k="challenge_heading" as="h2" className="ayx-h2 ayx-red" />

        {/* 9 — claim block */}
        <E k="claim_text" className="ayx-lead" />

        {/* 10 — social proof */}
        <E k="social_text" className="ayx-lead ayx-band1" />

        {/* 11 — usage */}
        <E k="usage_text" className="ayx-lead" />

        {/* 12 — big ingredient spread image */}
        <div className="ayx-img">
          <LpImage target="td:img_ingredients" value={img("img_ingredients", `${IMG}/ingredients.jpg`)} width={w("img_ingredients")}>
            <Image src={img("img_ingredients", `${IMG}/ingredients.jpg`)} alt="Ayurex উপাদানসমূহ" width={991} height={1024} unoptimized />
          </LpImage>
        </div>

        {/* 13 — positioning */}
        <E k="positioning_text" className="ayx-lead" />

        {/* 14 — aspirational */}
        <E k="aspirational_text" className="ayx-lead ayx-strong" />

        {/* 15 — herbal note */}
        <E k="herbal_note" className="ayx-lead" />

        {/* 16 — 80+ ingredient teaser */}
        <E k="teaser_text" className="ayx-lead ayx-strong" />

        {/* 17 — sub-positioning */}
        <E k="sub_heading" as="h2" className="ayx-h2" />

        {/* 18 — brand line */}
        <E k="brand_line" as="h2" className="ayx-h2 ayx-red" />

        {/* 19 — man holding bottle image */}
        <div className="ayx-img">
          <LpImage target="td:img_man" value={img("img_man", `${IMG}/man.webp`)} width={w("img_man")}>
            <Image src={img("img_man", `${IMG}/man.webp`)} alt="Ayurex" width={742} height={620} unoptimized />
          </LpImage>
        </div>

        {/* 21 — strength block */}
        <E k="strength_text" className="ayx-lead" />

        {/* 22, 23 — trust badges */}
        <div className="ayx-badges">
          <LpImage target="td:img_natural" value={img("img_natural", `${IMG}/natural.png`)} width={w("img_natural")}>
            <Image src={img("img_natural", `${IMG}/natural.png`)} alt="১০০% Natural" width={170} height={170} unoptimized />
          </LpImage>
          <LpImage target="td:img_certified" value={img("img_certified", `${IMG}/certified.webp`)} width={w("img_certified")}>
            <Image src={img("img_certified", `${IMG}/certified.webp`)} alt="BUETS Certified" width={170} height={170} unoptimized />
          </LpImage>
        </div>

        {/* 24 — heading */}
        <E k="romantic_heading" as="h2" className="ayx-h2" />

        {/* 25 — ingredient intro */}
        <E k="ingredient_intro" className="ayx-lead ayx-band1" />

        {/* 26 — 80 ingredients. Each heading + item name/desc is inline
            editable (bound to template_data keys ing_<g>_head / ing_<g>_<i>_name
            / ing_<g>_<i>_desc); blank → the structured default renders. */}
        <div className="ayx-ing">
          {ingredientGroups.map((g, gi) => (
            <div key={gi} className="ayx-ing-group">
              <LpText target={`td:ing_${gi}_head`} value={ig(`ing_${gi}_head`, g.heading)} as="h3" className={`ayx-ing-head${gi === 0 ? " ayx-band2" : ""}`} />
              <ul>
                {g.items.map((it, ii) => (
                  <li key={ii}>
                    <b>{it.n}. <LpText target={`td:ing_${gi}_${ii}_name`} value={ig(`ing_${gi}_${ii}_name`, it.name)} as="span" /></b>
                    {" — "}
                    <LpText target={`td:ing_${gi}_${ii}_desc`} value={ig(`ing_${gi}_${ii}_desc`, it.desc)} as="span" multiline />
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 27 — usage/safety */}
        <E k="usage_safety_text" className="ayx-lead" />

        {/* 28 — half/full course */}
        <E k="course_text" className="ayx-lead ayx-strong" />

        {/* 29 — price banner image */}
        <div className="ayx-img ayx-img--price">
          <LpImage target="td:img_price" value={img("img_price", `${IMG}/price.webp`)} width={w("img_price")}>
            <Image src={img("img_price", `${IMG}/price.webp`)} alt="মূল্যঃ ১২৫০/=" width={1024} height={240} unoptimized />
          </LpImage>
        </div>

        {/* 30 — delivery fee */}
        <E k="delivery_fee_text" className="ayx-lead ayx-strong" />

        {/* 31-32 — testimonials. Rendered dynamically from the dashboard
            (Custom / Pick-from-site / All-site reviews). The whole block is
            hidden when there are none, so the section only shows real reviews
            the tenant entered. */}
        {show("testimonials") && testimonials.length > 0 && (
          <>
            <h2 className="ayx-h2 ayx-band2">🌿 {page.testimonials_title || "আমাদের গ্রাহকদের বাস্তব অভিজ্ঞতা"}</h2>
            <div className="ayx-testi">
              {testimonials.map((tm, ti) => (
                <div key={ti} className="ayx-testi__card">
                  <div className="ayx-testi__head">
                    {tm.image
                      ? <Image className="ayx-testi__avatar" src={tm.image} alt={tm.name} width={44} height={44} unoptimized />
                      : <span className="ayx-testi__avatar ayx-testi__avatar--ph">{(tm.name || "?").trim().charAt(0)}</span>}
                    <div className="ayx-testi__who">
                      <b>{tm.name}</b>
                      <span className="ayx-testi__stars">{"★".repeat(Math.max(1, Math.min(5, Math.round(tm.rating || 5))))}</span>
                    </div>
                  </div>
                  <p className="ayx-testi__text">{tm.review}</p>
                </div>
              ))}
            </div>
          </>
        )}

        {/* 33 — price banner again */}
        <div className="ayx-img ayx-img--price">
          <LpImage target="td:img_price" value={img("img_price", `${IMG}/price.webp`)} width={w("img_price")}>
            <Image src={img("img_price", `${IMG}/price.webp`)} alt="মূল্যঃ ১২৫০/=" width={1024} height={240} unoptimized />
          </LpImage>
        </div>

        {/* 34 — hekim callout */}
        <E k="hekim_text" className="ayx-lead ayx-band1" />

        {/* 35 — notice */}
        <E k="notice_text" className="ayx-lead ayx-note" />

        {/* 36 — fill the form / whatsapp (newlines preserved) */}
        <E k="form_intro_text" className="ayx-lead ayx-strong ayx-preline" />

        {/* 37 — hotline */}
        <a className="ayx-hotline" href={`https://wa.me/88${phone.replace(/[^\d]/g, "")}`} target="_blank" rel="noopener noreferrer">
          💬 {phone}
        </a>

        {/* 38 — checkout form (14 fields) */}
        <div ref={formRef} id="order" className="ayx-checkout">
          <CheckoutPanel page={page} />
        </div>

        {/* 39 — closing */}
        <E k="closing_text_1" className="ayx-lead" />

        {/* 40 — closing 2 */}
        <E k="closing_text_2" className="ayx-lead" />

        {/* 41 — commitment */}
        <E k="commitment_text" className="ayx-lead ayx-band2" />

        {/* 42 — ORDER AYUREX button */}
        <div className="ayx-btnrow">
          <button type="button" className="ayx-btn" onClick={fireInitiateCheckout}>{c("order_btn_text")}</button>
        </div>
      </div>

      <LpContactBubble pageWhatsapp={page.whatsapp} pageContactMode={page.contact_mode} />
      <style dangerouslySetInnerHTML={{ __html: AYX_CSS }} />
    </div>
  );
}

// ── Checkout — 14-field medical intake form matching the source page. Extra
//    Q&A is packed into the order `notes` for the hekim follow-up call. Order
//    creation + tracking + incomplete-order capture mirror the akbd template.
function CheckoutPanel({ page }: { page: AyurexPage }) {
  const [f, setF] = useState({
    name: "", phone: "", whatsapp: "", address: "", email: "",
    ageWeight: "", heartSurgery: "", diabetes: "", lastSex: "",
    secondRound: "", weakness: "", frequency: "", other: "", orderNotes: "",
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF((s) => ({ ...s, [k]: e.target.value }));

  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const fired = useRef(false);

  const [zones, setZones] = useState<{ id: number; name: string; rate: number; estimated_days?: string }[]>([]);
  const [zoneId, setZoneId] = useState<number | null>(null);
  const [shippingReady, setShippingReady] = useState<boolean>(!!page.custom_shipping);

  const products = page.resolved_products || [];
  const product = products[0];
  const qty = product?.selected_quantity || 1;
  const subtotal = product ? Number(product.price) * qty : 0;

  useEffect(() => {
    if (page.custom_shipping) { setShippingReady(true); return; }
    let cancelled = false;
    fetch("/api/v1/shipping/zones", { headers: { Accept: "application/json" } })
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        if (cancelled) return;
        const list = (Array.isArray(data) ? data : data?.data || []) as typeof zones;
        setZones(list);
        if (list.length > 0) setZoneId(list[0].id);
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setShippingReady(true); });
    return () => { cancelled = true; };
  }, [page.custom_shipping]);

  const selectedZone = zones.find((z) => z.id === zoneId) || null;
  const shippingCost = page.custom_shipping
    ? (page.shipping_cost != null ? Number(page.shipping_cost) : 30)
    : (selectedZone ? Number(selectedZone.rate) : (zones.length > 0 ? Number(zones[0].rate) : 30));
  const total = subtotal + shippingCost;
  const money = (n: number) => `৳${toBn(n)}`;

  useEffect(() => {
    if (!fired.current && product) {
      fired.current = true;
      trackViewContent({ content_ids: [String(product.id)], content_name: product.name, content_type: "product", value: Number(product.price) });
    }
  }, [product]);

  // Pack the medical intake answers into a single notes block for the hekim.
  const buildNotes = () => {
    const L: string[] = [];
    if (f.whatsapp) L.push(`WhatsApp: ${f.whatsapp}`);
    if (f.ageWeight) L.push(`বয়স ও ওজন: ${f.ageWeight}`);
    if (f.heartSurgery) L.push(`২ বছরে হার্ট সার্জারী: ${f.heartSurgery}`);
    if (f.diabetes) L.push(`ডায়াবেটিস/হাই প্রেশার: ${f.diabetes}`);
    if (f.lastSex) L.push(`সর্বশেষ সেক্স ও টাইমিং: ${f.lastSex}`);
    if (f.secondRound) L.push(`৩০ মিনিটে ২য় বার: ${f.secondRound}`);
    if (f.weakness) L.push(`আফটার সেক্স দুর্বলতা: ${f.weakness}`);
    if (f.frequency) L.push(`মাসে গড়ে সেক্স: ${f.frequency}`);
    if (f.other) L.push(`অন্যান্য তথ্য: ${f.other}`);
    if (f.orderNotes) L.push(`অর্ডার নোট: ${f.orderNotes}`);
    L.push(`LP: ${page.slug}`);
    return L.join("\n");
  };

  // Incomplete-order capture.
  const capRef = useRef<Record<string, unknown> | null>(null);
  useEffect(() => {
    if (submitting || success || !product) { capRef.current = null; return; }
    const digits = f.phone.replace(/\D/g, "");
    if (!/^01[3-9]\d{8}$/.test(digits)) { capRef.current = null; return; }
    const payload = {
      phone: digits, name: f.name || null, address: f.address || null,
      city: selectedZone?.name || null, notes: buildNotes(),
      subtotal, shipping_cost: shippingCost, total, source: "landing",
      cart_items: [{ product_id: product.id, variant_id: null, variant_label: null, name: product.name, price: Number(product.price) || 0, quantity: qty, image: product.image || null }],
    };
    capRef.current = payload;
    const h = setTimeout(() => {
      fetch("/api/v1/incomplete-orders", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(payload), keepalive: true }).catch(() => {});
    }, 1200);
    return () => clearTimeout(h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submitting, success, product, f, subtotal, shippingCost, total, selectedZone, qty]);

  useEffect(() => {
    const flush = () => {
      const p = capRef.current;
      if (!p) return;
      try {
        const blob = new Blob([JSON.stringify(p)], { type: "application/json" });
        if (navigator.sendBeacon?.("/api/v1/incomplete-orders", blob)) return;
      } catch { /* fall through */ }
      fetch("/api/v1/incomplete-orders", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(p), keepalive: true }).catch(() => {});
    };
    const onVis = () => { if (document.visibilityState === "hidden") flush(); };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => { window.removeEventListener("pagehide", flush); document.removeEventListener("visibilitychange", onVis); };
  }, []);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!product) return;
    const cleanPhone = f.phone.replace(/\D/g, "");
    if (!/^01[3-9]\d{8}$/.test(cleanPhone)) { setError("সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন।"); return; }
    // Only phone + address are required now.
    if (!f.address.trim()) { setError("অনুগ্রহ করে আপনার ঠিকানা দিন।"); return; }
    setSubmitting(true);
    try {
      const unitPrice = Number(product.price) || 0;
      const res = await api.createOrder({
        // Name is optional now; fall back to the phone so the order schema's
        // required customer_name is always satisfied.
        customer_name: f.name.trim() || cleanPhone,
        customer_phone: cleanPhone,
        customer_email: f.email.trim() || undefined,
        customer_address: f.address.trim(),
        // Route + schema read `city` (not customer_city — zod strips that).
        city: selectedZone?.name || undefined,
        notes: buildNotes(),
        items: [{ product_id: product.id, product_name: product.name, quantity: qty, price: unitPrice }],
        payment_method: "cod",
        shipping_cost: shippingCost,
        subtotal,
        total,
        source: `lp:${page.slug}`,
      } as Record<string, unknown>);
      const orderRes = res as { id?: number; data?: { id?: number }; order_token?: string; token?: string };
      const orderIdNum = orderRes.id || orderRes.data?.id;
      const orderToken = orderRes.order_token || orderRes.token || "";
      const nameParts = f.name.trim().split(" ");
      trackPurchase({
        content_ids: [String(product.id)],
        content_name: product.name,
        contents: [{ id: product.id, quantity: qty, item_price: unitPrice }],
        num_items: qty,
        value: total,
        order_id: String(orderIdNum || ""),
        shipping: shippingCost,
      }, {
        ph: cleanPhone,
        fn: nameParts[0] || undefined,
        ln: nameParts.length > 1 ? nameParts.slice(1).join(" ") : undefined,
        country: "bd",
      });
      setSuccess(true);
      setTimeout(() => { if (orderToken) window.location.href = `/order/${orderToken}`; }, 900);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "অর্ডার সম্পন্ন হয়নি, আবার চেষ্টা করুন।");
    }
    setSubmitting(false);
  };

  if (success) {
    return (
      <div className="ayx-done">
        <div className="ayx-done__check">✓</div>
        <h2>{page.success_message || "ধন্যবাদ! আপনার অর্ডার গ্রহণ করা হয়েছে।"}</h2>
        <p>শীঘ্রই আমাদের একজন প্রতিনিধি ফোন করে অর্ডার কনফার্ম করবেন।</p>
      </div>
    );
  }

  const YN = (
    <>
      <option value="">— নির্বাচন করুন —</option>
      <option value="হ্যাঁ">হ্যাঁ</option>
      <option value="না">না</option>
    </>
  );

  return (
    <form className="ayx-form" onSubmit={onSubmit}>
      <h3 className="ayx-form__title">Billing details</h3>
      {error && <div className="ayx-form__err">{error}</div>}

      {/* Clean form — no */}{/* * or (optional) marks. Only phone + address
          are actually required; the rest are free for the customer to skip. */}
      <label>আপনার নাম
        <input value={f.name} onChange={set("name")} autoComplete="name" />
      </label>
      <label>ফোন নাম্বার
        <input value={f.phone} onChange={(e) => setF((s) => ({ ...s, phone: e.target.value.replace(/[^\d]/g, "") }))} required type="tel" inputMode="numeric" maxLength={11} placeholder="01XXXXXXXXX" autoComplete="tel" />
      </label>
      <label>হোয়াটসঅ্যাপ নাম্বার
        <input value={f.whatsapp} onChange={set("whatsapp")} type="tel" inputMode="numeric" />
      </label>
      <label>আপনার ঠিকানা (বাড়ি নং, রোড, এলাকা সহ)
        <textarea value={f.address} onChange={set("address")} required rows={2} autoComplete="street-address" />
      </label>
      <label>Email Address
        <input value={f.email} onChange={set("email")} type="email" autoComplete="email" />
      </label>
      <label>আপনার বয়স ও ওজন লিখুন
        <input value={f.ageWeight} onChange={set("ageWeight")} placeholder="যেমনঃ ৩৫ বছর, ৭০ কেজি" />
      </label>
      <label>২ বছরের মধ্যে আপনার হার্ট সার্জারী হয়েছে কি না?
        <select value={f.heartSurgery} onChange={set("heartSurgery")}>{YN}</select>
      </label>
      <label>ডায়াবেটিস ও হাই প্রেশার আছে কি না?
        <select value={f.diabetes} onChange={set("diabetes")}>{YN}</select>
      </label>
      <label>সর্বশেষ কত দিন আগে সেক্স করেছেন? কতটুকু টাইম পেয়েছেন?
        <input value={f.lastSex} onChange={set("lastSex")} />
      </label>
      <label>প্রথম সেক্স করার ৩০ মিনিটের মধ্যে ২য় বার করতে পারেন কি?
        <select value={f.secondRound} onChange={set("secondRound")}>{YN}</select>
      </label>
      <label>আফটার সেক্স, শরীর অতিরিক্ত দূর্বল হয়ে যায় কি না?
        <select value={f.weakness} onChange={set("weakness")}>{YN}</select>
      </label>
      <label>মাসে গড়ে কতবার সেক্স করেন?
        <input value={f.frequency} onChange={set("frequency")} />
      </label>
      <label>অন্যান্য তথ্যঃ
        <textarea value={f.other} onChange={set("other")} rows={2} />
      </label>
      <label>Order notes
        <textarea value={f.orderNotes} onChange={set("orderNotes")} rows={2} />
      </label>

      {!page.custom_shipping && zones.length > 0 && (
        <fieldset className="ayx-ship">
          <legend>ডেলিভারি এরিয়া</legend>
          {zones.map((z) => (
            <label key={z.id} className={`ayx-ship__opt ${zoneId === z.id ? "is-active" : ""}`}>
              <input type="radio" name="ship" checked={zoneId === z.id} onChange={() => setZoneId(z.id)} />
              <span>{z.name}</span><b>{money(Number(z.rate))}</b>
            </label>
          ))}
        </fieldset>
      )}

      <div className="ayx-review">
        <div className="ayx-review__row"><span>{product?.name || "Ayurex"} × {toBn(qty)}</span><b>{money(subtotal)}</b></div>
        <div className="ayx-review__row"><span>Subtotal</span><b>{money(subtotal)}</b></div>
        <div className="ayx-review__row"><span>Shipment</span><b>{shippingReady ? money(shippingCost) : "…"}</b></div>
        <div className="ayx-review__row ayx-review__total"><span>Total</span><b>{shippingReady ? money(total) : "…"}</b></div>
        <div className="ayx-review__cod"><b>Cash on delivery</b><span>Pay with cash upon delivery.</span></div>
      </div>

      <button type="submit" className="ayx-btn ayx-btn--full" disabled={submitting || !shippingReady}>
        {submitting ? "অর্ডার হচ্ছে..." : `${page.checkout_btn_text || "Place order"}${shippingReady ? ` · ${money(total)}` : ""}`}
      </button>
      <p className="ayx-form__privacy">Your personal data will be used to process your order and support your experience throughout this website.</p>
    </form>
  );
}

/* ── Scoped styles — centered single-column long-form, mobile-first. ── */
const AYX_CSS = `
.ayx { --ayx:#8a1c1c; background:#fff; color:#1a1a1a; font-family:"Hind Siliguri","Noto Sans Bengali",system-ui,sans-serif; overflow-x:hidden; }
.ayx * { box-sizing:border-box; }

/* HERO — green perspective floor backdrop with the crowned tablet centered */
.ayx-hero { position:relative; text-align:center; padding:18px 10px 24px; background:
  radial-gradient(120% 90% at 50% 100%, #b8e0a8 0%, #6fb85f 38%, #2f7d3a 72%, #1e5a28 100%); overflow:hidden; }
.ayx-hero::before { content:""; position:absolute; inset:0; background:
  repeating-linear-gradient(to right, rgba(255,255,255,.08) 0 2px, transparent 2px 9%); transform:perspective(420px) rotateX(58deg); transform-origin:bottom; opacity:.5; pointer-events:none; }
.ayx-hero__img { position:relative; display:flex; justify-content:center; }
/* Hero image covers the full width (minus the hero's 10px side padding) on
   mobile; capped at 520px on larger screens so it doesn't blow up on desktop. */
.ayx-hero__img img { width:100%; max-width:520px; height:auto; object-fit:contain; border-radius:12px; filter:drop-shadow(0 14px 26px rgba(0,0,0,.35)); }
.ayx-title { position:relative; font-size:clamp(22px,5.6vw,36px); font-weight:900; color:#fff; margin:0 0 14px; line-height:1.25; text-shadow:0 2px 8px rgba(0,0,0,.3); }

.ayx-stack { max-width:760px; margin:0 auto; padding:22px 16px 40px; display:flex; flex-direction:column; align-items:center; gap:18px; text-align:center; }
.ayx-h2 { font-size:clamp(19px,4.6vw,28px); font-weight:800; margin:0; line-height:1.3; }
.ayx-red { color:var(--ayx); }
.ayx-lead { font-size:clamp(15px,3.8vw,18px); line-height:1.85; color:#2a2a2a; margin:0; max-width:680px; }
.ayx-strong { font-weight:700; }
/* Alternating colored bands — white bold text on brand brown/green. */
.ayx-band1, .ayx-band2 { color:#fff !important; font-weight:800; border-radius:12px; padding:14px 20px; max-width:760px; box-shadow:0 4px 14px rgba(0,0,0,.12); }
.ayx-band1 { background:#561501; }
.ayx-band2 { background:#0a430e; }
.ayx-note { color:var(--ayx); font-weight:700; }
.ayx-preline { white-space:pre-line; }

.ayx-img { width:100%; display:flex; justify-content:center; }
.ayx-img img { width:100%; height:auto; max-width:520px; object-fit:contain; border-radius:12px; }
.ayx-img--sm img { max-width:300px; }
.ayx-img--price img { max-width:680px; border-radius:14px; }

.ayx-problems { width:100%; display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
.ayx-problem { display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; text-align:center; color:#fff; border-radius:12px; padding:16px 8px; min-height:118px; box-shadow:0 4px 12px rgba(0,0,0,.12); }
.ayx-problem__icon { font-size:24px; line-height:1; }
.ayx-problem__txt { font-size:clamp(13px,3.4vw,15px); font-weight:800; line-height:1.35; }

.ayx-badges { display:flex; justify-content:center; align-items:center; gap:24px; flex-wrap:wrap; }
.ayx-badges img { width:130px; height:auto; object-fit:contain; }

.ayx-ing { width:100%; display:flex; flex-direction:column; gap:18px; text-align:left; }
.ayx-ing-group { background:#fff; border:1px solid #eee; border-radius:14px; padding:16px 18px; box-shadow:0 3px 12px rgba(0,0,0,.04); }
.ayx-ing-group { break-inside:avoid; }
.ayx-ing-head { font-size:16px; font-weight:800; color:var(--ayx); margin:0 0 10px; }
.ayx-ing-group ul { list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:8px; }
.ayx-ing-group li { font-size:14px; line-height:1.65; color:#333; }
.ayx-ing-group li b { color:#111; }

.ayx-btnrow { width:100%; display:flex; justify-content:center; padding:6px 0; }
.ayx-btn { background:#e63946; color:#fff; border:0; border-radius:999px; padding:15px 48px; font-size:18px; font-weight:800; cursor:pointer; box-shadow:0 8px 20px rgba(230,57,70,.32); transition:transform .15s,box-shadow .15s; font-family:inherit; }
.ayx-btn:hover { transform:translateY(-2px); box-shadow:0 12px 26px rgba(230,57,70,.4); background:#c52936; }
.ayx-btn--full { width:100%; }
.ayx-btn--sm { padding:11px 26px; font-size:15px; }
.ayx-btn:disabled { opacity:.6; cursor:wait; }

.ayx-testi { width:100%; display:grid; grid-template-columns:1fr; gap:14px; text-align:left; }
.ayx-testi__card { background:#fff; border:1px solid #eee; border-radius:14px; padding:16px 18px; box-shadow:0 3px 12px rgba(0,0,0,.05); }
.ayx-testi__head { display:flex; align-items:center; gap:12px; margin-bottom:10px; }
.ayx-testi__avatar { width:44px; height:44px; border-radius:50%; object-fit:cover; flex-shrink:0; }
.ayx-testi__avatar--ph { background:var(--ayx); color:#fff; display:grid; place-items:center; font-size:18px; font-weight:800; text-transform:uppercase; }
.ayx-testi__who { display:flex; flex-direction:column; gap:2px; }
.ayx-testi__who b { font-size:15px; color:#111; }
.ayx-testi__stars { color:#ffb703; font-size:14px; letter-spacing:1px; }
.ayx-testi__text { margin:0; font-size:14px; line-height:1.7; color:#333; }

.ayx-hotline { display:inline-block; background:#25d366; color:#fff; font-weight:900; font-size:22px; letter-spacing:.5px; text-decoration:none; padding:12px 36px; border-radius:12px; }

/* Checkout */
.ayx-checkout { width:100%; }
.ayx-form { width:100%; text-align:left; background:#fff; border:1px solid #e6e6e6; border-radius:16px; padding:22px; display:flex; flex-direction:column; gap:13px; box-shadow:0 6px 20px rgba(0,0,0,.05); }
.ayx-form__title { font-size:18px; font-weight:800; margin:0 0 4px; }
.ayx-form label { display:flex; flex-direction:column; gap:6px; font-size:14px; font-weight:700; color:#333; }
.ayx-form label span { color:#e63946; }
.ayx-form label em { color:#999; font-weight:400; font-style:normal; font-size:12px; }
.ayx-form input, .ayx-form textarea, .ayx-form select { font-family:inherit; font-size:16px; padding:11px 13px; border:1.5px solid #dcdcdc; border-radius:9px; outline:0; background:#fff; }
.ayx-form input:focus, .ayx-form textarea:focus, .ayx-form select:focus { border-color:var(--ayx); }
.ayx-form__err { background:#fde8e8; color:#c0392b; padding:10px 14px; border-radius:9px; font-size:13px; font-weight:600; }
.ayx-form__privacy { font-size:11.5px; color:#888; line-height:1.5; margin:0; }

.ayx-ship { border:1.5px solid #dcdcdc; border-radius:11px; padding:12px; display:flex; flex-direction:column; gap:8px; }
.ayx-ship legend { font-size:13px; font-weight:800; padding:0 6px; }
.ayx-ship__opt { display:flex; flex-direction:row; align-items:center; gap:10px; padding:10px 12px; border:1.5px solid #eee; border-radius:9px; cursor:pointer; font-weight:600; }
.ayx-ship__opt.is-active { border-color:var(--ayx); background:#fbeaea; }
.ayx-ship__opt b { margin-left:auto; color:var(--ayx); }

.ayx-review { border:1.5px solid #eee; border-radius:11px; padding:14px 16px; display:flex; flex-direction:column; gap:8px; background:#fafafa; }
.ayx-review__row { display:flex; justify-content:space-between; font-size:14px; color:#444; }
.ayx-review__row b { color:#111; }
.ayx-review__total { border-top:2px solid #e6e6e6; padding-top:10px; margin-top:2px; font-size:17px; font-weight:800; }
.ayx-review__total b { color:var(--ayx); }
.ayx-review__cod { margin-top:6px; background:#fff; border-radius:8px; padding:10px 12px; display:flex; flex-direction:column; gap:2px; }
.ayx-review__cod b { font-size:13px; }
.ayx-review__cod span { font-size:12px; color:#777; }

.ayx-done { text-align:center; padding:34px 22px; }
.ayx-done__check { width:60px; height:60px; margin:0 auto 16px; background:#16a34a; color:#fff; border-radius:50%; display:grid; place-items:center; font-size:30px; }
.ayx-done h2 { font-size:21px; margin:0 0 8px; }
.ayx-done p { color:#555; font-size:14px; }


@media (min-width:720px) {
  .ayx-stack { padding:28px 16px 56px; gap:22px; }
  /* Masonry-style: groups have very uneven lengths (5 vs 31 items), so a
     2-col grid leaves big gaps under the short ones. CSS columns let each
     group flow into the next column and fill the space. */
  .ayx-ing { display:block; column-count:2; column-gap:18px; }
  .ayx-ing-group { margin:0 0 18px; }
  .ayx-testi { grid-template-columns:1fr 1fr; }
  .ayx-form { padding:28px; }
}
`;
