"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { FiCheck, FiChevronDown, FiMinus, FiPlus, FiPhone } from "react-icons/fi";
import { SafeImg, SafeNextImage } from "@/components/SafeImage";
import LpContactBubble from "@/components/LpContactBubble";
import { sanitizeInline } from "@/lib/sanitize-html";
import VideoPlayer from "@/components/ui/video-player";
import dynamic from "next/dynamic";
// Swiper + its CSS pulled OUT of the initial bundle. The carousel is below
// the fold; ssr:false + lazy chunk keeps it off first paint (mobile TBT win).
const TestimonialsCarousel = dynamic(() => import("./TestimonialsCarousel"), {
  ssr: false,
  loading: () => <div className="py-10 md:py-14 min-h-[18rem]" />,
});
import { api } from "@/lib/api";
import { useOption } from "@/lib/SiteSettingsContext";
import { trackViewContent, trackInitiateCheckout, trackPurchase, saveLastCustomer } from "@/lib/analytics";
import { LpText } from "./LpEdit";

interface ProductVariant {
  id: number; label: string; price: number; original_price?: number; stock: number; image?: string;
}

interface Product {
  id: number; name: string; slug: string; price: number; original_price?: number;
  image: string; description?: string; stock: number; selected_quantity: number;
  has_variations?: boolean; hasVariations?: boolean;
  variation_type?: string; variationType?: string;
  variants?: ProductVariant[];
  custom_shipping?: boolean; customShipping?: boolean;
  shipping_cost?: number; shippingCost?: number;
}

interface PageData {
  id: number; slug: string; title: string;
  hero_headline?: string; hero_subheadline?: string; hero_image?: string; hero_video_autoplay?: boolean;
  hero_cta?: string; hero_trust_text?: string; hero_badge?: string;
  problem_title?: string; problem_points?: string;
  features?: string; testimonials?: string; how_it_works?: string; faq?: string;
  products?: string; products_title?: string; products_subtitle?: string; products_sub?: string;
  features_title?: string; features_image?: string; testimonials_title?: string; testimonials_mode?: string;
  how_it_works_title?: string; how_it_works_subtitle?: string; how_it_works_sub?: string;
  faq_title?: string;
  checkout_title?: string; checkout_subtitle?: string;
  checkout_btn_text?: string; custom_shipping?: boolean; shipping_cost?: number;
  show_email?: boolean; show_city?: boolean;
  guarantee_text?: string; success_message?: string;
  section_visibility?: string;
  section_order?: string[] | null;
  whatsapp?: string;
  contact_mode?: string; // "inherit" | "whatsapp" | "phone"
  primary_color?: string; resolved_products?: Product[];
}

function parseJSON<T>(str?: string | null): T[] {
  if (!str) return [];
  try { return JSON.parse(str); } catch { return []; }
}

// True for any mp4/webm/mov/mkv/m4v URL — strips query/hash before testing
// so URLs like "/uploads/x.mp4?v=123" still match.
function isVideoFile(url?: string | null): boolean {
  if (!url) return false;
  const clean = url.split("?")[0].split("#")[0];
  return /\.(mp4|webm|mov|mkv|m4v|ogv)$/i.test(clean);
}
function isYouTube(url?: string | null): boolean {
  if (!url) return false;
  return url.includes("youtube.com") || url.includes("youtu.be");
}

export default function LandingPageClient({ page }: { page: PageData }) {
  const router = useRouter();
  const sitePhone = useOption<string>("phone") || "";
  // Falls back to the global theme primary CSS variable so customizer color
  // changes propagate to LP buttons/qty controls/totals when this LP doesn't
  // override its own primary_color.
  const color = page.primary_color || "var(--primary)";
  const vis: Record<string, boolean> = (() => {
    try { return JSON.parse(page.section_visibility || "{}"); } catch { return {}; }
  })();
  const show = (key: string) => vis[key] !== false; // default true if not set

  // Section display order. The admin reorders sections in the dashboard (drag);
  // we honor it here via CSS flex `order` so the source/DOM order stays stable
  // (SEO + #checkout anchor unaffected) while the visual order follows the form.
  // Unknown/missing keys fall back to the natural authoring order.
  const DEFAULT_SECTION_ORDER = ["hero", "problem", "products", "features", "how_it_works", "testimonials", "faq"];
  const savedOrder: string[] = Array.isArray(page.section_order)
    ? (page.section_order as string[])
    : [];
  const effectiveOrder = [
    ...savedOrder.filter((k) => DEFAULT_SECTION_ORDER.includes(k)),
    ...DEFAULT_SECTION_ORDER.filter((k) => !savedOrder.includes(k)),
  ];
  const ord = (key: string): number => {
    const i = effectiveOrder.indexOf(key);
    return i < 0 ? DEFAULT_SECTION_ORDER.length : i;
  };

  const products = page.resolved_products || [];
  const [quantities, setQuantities] = useState<Record<number, number>>(
    Object.fromEntries(products.map((p) => [p.id, p.selected_quantity || 1]))
  );
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "", city: "" });
  // Persist customer info as soon as form fills — boosts EMQ on subsequent
  // events on this browser (return visit → ViewContent already carries em/ph).
  useEffect(() => {
    if (!form.email && !form.phone && !form.name) return;
    saveLastCustomer({
      em: form.email || undefined,
      ph: form.phone || undefined,
      fn: form.name?.trim().split(/\s+/)[0] || undefined,
      ln: form.name?.trim().split(/\s+/).slice(1).join(" ") || undefined,
      ct: form.city || undefined,
      country: "bd",
    });
  }, [form.email, form.phone, form.name, form.city]);
  // Variant selection: productId → selected variantId (undefined = none selected)
  const [selectedVariants, setSelectedVariants] = useState<Record<number, number | undefined>>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const phoneRef = useRef<HTMLInputElement>(null);

  const validatePhone = (phone: string): string => {
    const digits = phone.replace(/\D/g, "");
    if (digits.length === 0) return "";
    if (digits.length !== 11) return `ফোন নম্বর অবশ্যই ১১ সংখ্যার হতে হবে (আপনি দিয়েছেন ${digits.length}টি)`;
    const validPrefixes = ["013","014","015","016","017","018","019"];
    if (!validPrefixes.some(p => digits.startsWith(p))) return "অবৈধ নম্বর — ০১৩/০১৪/০১৫/০১৬/০১৭/০১৮/০১৯ দিয়ে শুরু হতে হবে";
    return "";
  };
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [shippingZones, setShippingZones] = useState<{ id: number; name: string; rate: number; estimated_days?: string }[]>([]);
  const [selectedZone, setSelectedZone] = useState<number | null>(null);
  // Until the zones fetch settles we don't know the real rate — never show a
  // hardcoded fallback that then "jumps" to the real value.
  const [zonesFetched, setZonesFetched] = useState<boolean>(!!page.custom_shipping);

  // Fetch shipping zones on mount (skip if custom shipping)
  useEffect(() => {
    if (page.custom_shipping) { setZonesFetched(true); return; }
    fetch("/api/v1/shipping/zones").then((r) => r.json()).then((data) => {
      const zones = (Array.isArray(data) ? data : []).map((z: Record<string, unknown>) => ({
        id: z.id as number,
        name: z.name as string,
        rate: Number(z.rate),
        estimated_days: (z.estimated_days as string) || "",
      }));
      setShippingZones(zones);
      if (zones.length > 0) setSelectedZone(zones[0].id);
    }).catch(() => {}).finally(() => setZonesFetched(true));
  }, []);

  // ── Tracking ──
  // ViewContent — once per LP load. Mirrors product page behavior so FB sees
  // the LP visit as a product view (one event per product on the page).
  const viewContentFired = useRef(false);
  useEffect(() => {
    if (viewContentFired.current) return;
    if (products.length === 0) return;
    viewContentFired.current = true;
    // One ViewContent per product. For a single-product LP, mirrors PDP exactly.
    // For multi-product LP, FB still gets distinct content_ids per product.
    for (const p of products) {
      trackViewContent({
        content_ids: [p.id],
        content_name: p.name,
        value: p.price,
        content_category: "landing-page",
        sourceUrl: typeof window !== "undefined" ? window.location.href : undefined,
      });
    }
  }, [products]);

  // InitiateCheckout — fire once when the user clicks a "purchase now" CTA
  // that takes them to the order form (every CTA is an <a href="#checkout">).
  // This is the explicit checkout-intent signal Meta wants, not a passive
  // scroll-into-view. A delegated capture-phase listener covers all CTAs
  // (there are 7+) without wiring onClick onto each one. Live product /
  // quantity / subtotal are read from a ref at click time.
  const checkoutTracked = useRef(false);
  // Snapshot the full IC payload after every render (subtotal is declared
  // below this point, so it can't be read at render time here).
  const icPayloadRef = useRef<Parameters<typeof trackInitiateCheckout>[0] | null>(null);
  useEffect(() => {
    if (products.length === 0) { icPayloadRef.current = null; return; }
    icPayloadRef.current = {
      content_ids: products.map((p) => p.id),
      content_name: products.map((p) => p.name).join(", "),
      contents: products.map((p) => ({
        id: String(p.id),
        quantity: quantities[p.id] || 1,
        item_price: getProductPrice(p),
        name: p.name,
      })),
      num_items: products.reduce((s, p) => s + (quantities[p.id] || 1), 0),
      value: subtotal,
    };
  });
  useEffect(() => {
    const onDocClick = (ev: MouseEvent) => {
      if (checkoutTracked.current) return;
      const target = ev.target as HTMLElement | null;
      const a = target?.closest?.('a[href="#checkout"], a[href$="#checkout"]') as HTMLAnchorElement | null;
      if (!a) return;
      const payload = icPayloadRef.current;
      if (!payload) return;
      checkoutTracked.current = true;
      trackInitiateCheckout(payload);
    };
    document.addEventListener("click", onDocClick, true);
    return () => document.removeEventListener("click", onDocClick, true);
  }, []);

  const problemPointsRaw = parseJSON<any>(page.problem_points);
  const problemPoints = problemPointsRaw.map((p: any) => typeof p === "string" ? { text: p, icon: "" } : { text: p.text || "", icon: p.icon || "" });
  const features = parseJSON<{ icon?: string; title: string; description: string }>(page.features);
  const [allSiteReviews, setAllSiteReviews] = useState<{ name: string; review: string; rating: number; image?: string }[]>([]);
  const parsedTestimonials = parseJSON<{ name: string; review: string; rating: number; image?: string }>(page.testimonials);

  // Fetch all site reviews if mode is "all_site"
  useEffect(() => {
    if (page.testimonials_mode === "all_site") {
      fetch("/api/v1/reviews/approved").then(r => r.json()).then(data => {
        setAllSiteReviews((Array.isArray(data) ? data : []).map((r: Record<string, unknown>) => ({
          name: (r.customer_name as string) || "", review: (r.review as string) || "",
          rating: Number(r.rating) || 5, image: (r.image as string) || "",
        })));
      }).catch(() => {});
    }
  }, [page.testimonials_mode]);

  const testimonials = page.testimonials_mode === "all_site" ? allSiteReviews : parsedTestimonials;
  const howItWorks = parseJSON<{ title: string; description: string }>(page.how_it_works);
  const faqItems = parseJSON<{ question: string; answer: string }>(page.faq);

  // Get effective price for a product (variant price if selected)
  const getProductPrice = (p: Product) => {
    const variantId = selectedVariants[p.id];
    if (variantId && p.variants) {
      const variant = p.variants.find(v => v.id === variantId);
      if (variant) return variant.price;
    }
    return p.price;
  };

  const subtotal = products.reduce((sum, p) => {
    const hasVars = p.has_variations || p.hasVariations;
    const vars = p.variants || [];
    if (hasVars && vars.length > 0) {
      const variantId = selectedVariants[p.id];
      if (!variantId) return sum;
      const v = vars.find(v => v.id === variantId);
      if (!v) return sum;
      const vKey = `${p.id}_${v.id}`;
      return sum + v.price * (quantities[vKey as unknown as number] || 1);
    }
    return sum + getProductPrice(p) * (quantities[p.id] || 1);
  }, 0);
  const activeZone = shippingZones.find((z) => z.id === selectedZone);

  // Custom shipping: if any product has custom shipping (incl. 0 = free), use max of those.
  // The custom_shipping flag is the gate — value of 0 is valid and means free shipping.
  const customShippingValues = products
    .filter(p => p.custom_shipping || p.customShipping)
    .map(p => Number(p.shipping_cost ?? p.shippingCost ?? 0));
  const zoneShipping = page.custom_shipping ? (page.shipping_cost != null ? Number(page.shipping_cost) : 60) : (activeZone?.rate ?? (page.shipping_cost != null ? Number(page.shipping_cost) : 60));
  const shipping = customShippingValues.length > 0 ? Math.max(...customShippingValues) : zoneShipping;
  const total = subtotal + shipping;
  // Shipping is known instantly for custom shipping (page-level or product-
  // level); for zone-based it's only known once the zones fetch settles.
  const shippingReady = !!page.custom_shipping || customShippingValues.length > 0 || zonesFetched;

  // === Incomplete-order capture ===
  // Mirror checkout/page.tsx: persist (phone, name, email, address, city,
  // cart, totals) to /api/v1/incomplete-orders. Server upserts by phone,
  // silently skips invalid input, and auto-marks converted when the real
  // order is placed. source="landing" so the dashboard can tell LP
  // abandonment from main-checkout abandonment.
  //
  // TWO triggers so we never miss a capture:
  //   1. Debounced POST 1.2s after the user pauses (records mid-session).
  //   2. sendBeacon on page-hide / tab-switch — catches the common case where
  //      the user fills the form and leaves WITHOUT pausing (the debounce
  //      timeout would otherwise be cleared on unmount → nothing recorded).
  // The latest valid payload is kept in a ref so the unload handler can flush
  // it synchronously during the (un)load event.
  const capturePayloadRef = useRef<Record<string, unknown> | null>(null);

  useEffect(() => {
    if (submitting || products.length === 0) { capturePayloadRef.current = null; return; }
    const digits = form.phone.replace(/\D/g, "");
    if (!/^01[3-9]\d{8}$/.test(digits)) { capturePayloadRef.current = null; return; }

    type CartItem = {
      product_id: number; variant_id: number | null; variant_label: string | null;
      name: string; price: number; quantity: number; image: string | null;
    };
    const cart_items = products.flatMap((p): CartItem[] => {
      const hasVars = p.has_variations || p.hasVariations;
      const vars = p.variants || [];
      if (hasVars && vars.length > 0) {
        const variantId = selectedVariants[p.id];
        if (!variantId) return [];
        const variant = vars.find((v) => v.id === variantId);
        if (!variant) return [];
        const vKey = `${p.id}_${variant.id}`;
        return [{
          product_id: p.id,
          variant_id: variant.id,
          variant_label: variant.label,
          name: `${p.name} — ${variant.label}`,
          price: variant.price,
          quantity: quantities[vKey as unknown as number] || 1,
          image: variant.image || p.image || null,
        }];
      }
      return [{
        product_id: p.id,
        variant_id: null,
        variant_label: null,
        name: p.name,
        price: getProductPrice(p),
        quantity: quantities[p.id] || 1,
        image: p.image || null,
      }];
    });
    if (cart_items.length === 0) { capturePayloadRef.current = null; return; }

    const payload = {
      phone: digits,
      name: form.name || null,
      email: form.email || null,
      address: form.address || null,
      city: form.city || (activeZone?.name || null),
      notes: `Landing page: ${page.slug}`,
      subtotal,
      shipping_cost: shipping,
      total,
      source: "landing",
      cart_items,
    };
    capturePayloadRef.current = payload;

    // Debounced send while the user is still on the page.
    const handle = setTimeout(() => {
      fetch("/api/v1/incomplete-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
      }).catch(() => {});
    }, 1200);

    return () => clearTimeout(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submitting, form, products, quantities, selectedVariants, subtotal, shipping, total, activeZone]);

  // Flush on leave — covers "filled the form then left without pausing".
  useEffect(() => {
    const flush = () => {
      const p = capturePayloadRef.current;
      if (!p) return;
      try {
        const blob = new Blob([JSON.stringify(p)], { type: "application/json" });
        if (navigator.sendBeacon?.("/api/v1/incomplete-orders", blob)) return;
      } catch { /* fall through to fetch */ }
      fetch("/api/v1/incomplete-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(p),
        keepalive: true,
      }).catch(() => {});
    };
    const onVis = () => { if (document.visibilityState === "hidden") flush(); };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  const getMaxStock = (p: Product) => {
    const hasVars = p.has_variations || p.hasVariations;
    const variantId = selectedVariants[p.id];
    if (hasVars && variantId && p.variants) {
      const v = p.variants.find(v => v.id === variantId);
      if (v && !(v as any).unlimited_stock) return v.stock;
    }
    const unlimited = (p as any).unlimited_stock || (p as any).unlimitedStock;
    if (unlimited) return 999;
    return p.stock > 0 ? p.stock : 999;
  };

  const updateQty = (id: number, qty: number) => {
    const product = products.find(p => p.id === id);
    const maxQty = product ? getMaxStock(product) : 999;
    setQuantities((prev) => ({ ...prev, [id]: Math.min(Math.max(1, qty), maxQty) }));
  };

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    // Phone validation
    const phoneErr = validatePhone(form.phone);
    if (phoneErr) {
      setPhoneError(phoneErr);
      setSubmitting(false);
      phoneRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      phoneRef.current?.focus();
      return;
    }
    setPhoneError("");
    try {
      // Validate variant products have a selection
      for (const p of products) {
        const hasVars = p.has_variations || p.hasVariations;
        const vars = p.variants || [];
        if (hasVars && vars.length > 0 && !selectedVariants[p.id]) {
          setError(`"${p.name}" এর জন্য একটি অপশন সিলেক্ট করুন`);
          setSubmitting(false);
          return;
        }
      }
      const items = products.flatMap((p) => {
        const hasVars = p.has_variations || p.hasVariations;
        const vars = p.variants || [];
        if (hasVars && vars.length > 0) {
          const variantId = selectedVariants[p.id];
          if (!variantId) return [];
          const variant = vars.find(v => v.id === variantId);
          if (!variant) return [];
          const vKey = `${p.id}_${variant.id}`;
          return [{
            product_id: p.id, product_name: `${p.name} — ${variant.label}`,
            quantity: quantities[vKey as unknown as number] || 1, price: variant.price,
            variant_id: variant.id,
            variant_label: variant.label,
          }];
        }
        return [{
          product_id: p.id, product_name: p.name,
          quantity: quantities[p.id] || 1, price: p.price,
        }];
      });
      const res = await api.createOrder({
        customer_name: form.name, customer_phone: form.phone,
        customer_email: form.email || undefined,
        customer_address: form.address, city: form.city || "N/A",
        subtotal, shipping_cost: shipping, total,
        payment_method: "cod", items,
        notes: `Landing page: ${page.slug}`,
        lang: "bn",
      });
      // Purchase — fire BEFORE router.push so sendBeacon flushes to /api/v1/collect
      // before the navigation aborts in-flight fetches. Mirrors checkout/page.tsx.
      const orderIdNum = res.id || res.data?.id;
      // City: server overrides FB CAPI `ct` from order.parsedCity (background
      // Pathao parse). Browser pixel uses form value — dedup happens via
      // event_id so this just needs to match server's pre-override hash.
      trackPurchase({
        content_ids: items.map((i) => i.product_id),
        content_name: items.map((i) => i.product_name).join(", "),
        contents: items.map((i) => ({ id: i.product_id, quantity: i.quantity, item_price: i.price })),
        num_items: items.reduce((s, i) => s + i.quantity, 0),
        value: res.total || total,
        order_id: String(orderIdNum || ""),
        shipping,
        city: form.city || undefined,
      }, {
        em: form.email || undefined,
        ph: form.phone || undefined,
        fn: form.name || undefined,
        ln: form.name?.includes(" ") ? form.name.split(" ").slice(1).join(" ") : undefined,
        ct: form.city || undefined,
        country: "bd",
      });

      const token = res.order_token;
      if (token) {
        router.push(`/order/${token}`);
      } else {
        router.push(`/lp/${page.slug}/thank-you?order=${orderIdNum}`);
      }
    } catch (err) {
      setError((err as { message?: string }).message || "অর্ডার করতে সমস্যা হয়েছে");
    } finally {
      setSubmitting(false);
    }
  };

  const toBn = (n: number) => String(n).replace(/[0-9]/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);

  return (
    <div className="min-h-screen bg-[#faf9f8] text-[#1a1c1c] selection:bg-[color:var(--lp)] selection:text-white" suppressHydrationWarning style={{ "--lp": color, "--lp-light": `${color}15`, "--lp-medium": `${color}30` } as React.CSSProperties}>

      {/* ── Reorderable sections (visual order follows the admin's drag order via
            CSS `order`; checkout stays pinned last as the conversion anchor) ── */}
      <div className="flex flex-col">

      {/* ── HERO ── */}
      {show("hero") && page.hero_headline && (
        <header style={{ order: ord("hero") }} className="relative pt-[20px] pb-8 md:pt-[30px] md:pb-10 overflow-hidden">
          <div className="absolute inset-0 opacity-5" style={{ background: `radial-gradient(circle at top right, ${color}, transparent)` }} />
          <div className="max-w-4xl mx-auto px-6 md:px-8 flex flex-col items-center text-center relative z-10">
            <h1
              className="text-3xl md:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight mb-3 md:mb-6"
              style={{ color }}
              dangerouslySetInnerHTML={{ __html: sanitizeInline(page.hero_headline || "") }}
            />
            {page.hero_subheadline && (
              <p
                className="text-lg md:text-2xl text-gray-500 mb-4 md:mb-6 leading-relaxed max-w-2xl"
                dangerouslySetInnerHTML={{ __html: sanitizeInline(page.hero_subheadline) }}
              />
            )}
            {page.hero_image && (
              isVideoFile(page.hero_image) || isYouTube(page.hero_image) ? (
                // Native video file OR YouTube → unified VideoPlayer with custom
                // controls. Autoplay admin-toggleable; muted forced when on so
                // browser allows it.
                <div className="w-full mb-4 md:mb-6">
                  <VideoPlayer
                    src={page.hero_image}
                    autoPlay={!!page.hero_video_autoplay}
                    loop={!!page.hero_video_autoplay}
                    className="aspect-video md:aspect-[21/9] max-w-none"
                  />
                </div>
              ) : (
                <div className="relative w-full aspect-video md:aspect-[21/9] mb-4 md:mb-6 overflow-hidden group">
                  <SafeNextImage src={page.hero_image} alt={page.hero_headline || ""} fill sizes="(max-width: 768px) 100vw, 80vw" className="object-contain group-hover:scale-105 transition-transform duration-1000" priority />
                </div>
              )
            )}
            <div className="mb-4 md:mb-6">
              <a href="#checkout" className="inline-block px-10 py-5 rounded-full text-white text-lg font-bold shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all active:scale-95" style={{ backgroundColor: color }}>
                👉 {page.hero_cta || "এখনই অর্ডার করুন"}
              </a>
            </div>
            {page.hero_trust_text && (
              <div className="flex flex-wrap justify-center gap-3 text-sm font-medium text-gray-500">
                {page.hero_trust_text.split(/[\n,]/).filter(Boolean).map((t, i) => (
                  <span key={i} className="flex items-center gap-1.5 px-4 py-2 bg-green-50 text-green-700 rounded-full">
                    {t.trim()}
                  </span>
                ))}
              </div>
            )}
          </div>
          <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full blur-[120px] -z-10" style={{ backgroundColor: `${color}08` }} />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-green-100/10 rounded-full blur-[120px] -z-10" />
        </header>
      )}

      {/* ── PROBLEM ── */}
      {show("problem") && (page.problem_title || problemPoints.length > 0) && (
        <section style={{ order: ord("problem") }} className="py-8 md:py-10 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 md:px-8">
            {page.problem_title && (
              <div className="text-center mb-8">
                <LpText target="problem_title" value={page.problem_title || ""} as="h2" className="text-3xl md:text-4xl lg:text-5xl font-extrabold mb-4" style={{ color }} />
                <div className="h-1.5 w-20 mx-auto rounded-full" style={{ backgroundColor: `${color}40` }} />
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {problemPoints.map((point: { text: string; icon: string }, i: number) => (
                <div key={i} className="bg-white p-7 rounded-2xl shadow-sm border border-gray-100/50 hover:shadow-md transition-shadow text-center">
                  <div className="flex justify-center mb-4">
                    {point.icon ? (
                      <div className="w-12 h-12 rounded-xl overflow-hidden">
                        <SafeImg src={point.icon} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg" style={{ backgroundColor: `${color}15`, color }}>!</div>
                    )}
                  </div>
                  <p className="text-gray-600 leading-relaxed">{point.text}</p>
                </div>
              ))}
            </div>
            {page.problem_title && (
              <div className="text-white p-8 rounded-3xl text-center shadow-lg max-w-2xl mx-auto" style={{ backgroundColor: color }}>
                <h3 className="text-xl md:text-2xl font-bold mb-2">সমাধান আছে!</h3>
                <p className="opacity-90 text-sm mb-5">আমাদের প্রোডাক্ট আপনার এই সমস্যাগুলো সমাধান করবে।</p>
                <a href="#checkout" className="inline-block px-8 py-3 bg-white font-bold rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all active:scale-95" style={{ color }}>
                  {page.hero_cta || "👉 এখনই অর্ডার করুন"}
                </a>
              </div>
            )}
          </div>
        </section>
      )}

      {/* ── PRODUCTS ── */}
      {show("products") && products.length > 0 && (
        <section style={{ order: ord("products") }} className="py-8 md:py-10" id="products">
          <div className="max-w-7xl mx-auto px-6 md:px-8">
            <div className="text-center mb-8">
              <LpText target="products_title" value={page.products_title || "আমাদের প্রোডাক্ট"} as="h2" className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-2" />
              <p className="text-lg text-gray-500 italic">{page.products_subtitle || page.products_sub || "ত্বক-বান্ধব ও প্রিমিয়াম মানের"}</p>
            </div>
            <div className={`mx-auto grid gap-3 sm:gap-6 md:gap-8 ${products.length === 1 ? "grid-cols-1 max-w-sm" : products.length === 2 ? "grid-cols-2 max-w-2xl" : "grid-cols-2 max-w-5xl lg:grid-cols-3"} justify-items-stretch`}>
              {products.map((p) => (
                <div key={p.id} className="bg-white rounded-2xl overflow-hidden group shadow-sm hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 w-full">
                  <a href="#checkout" className="block">
                    <div className="relative overflow-hidden aspect-square sm:aspect-[4/3] bg-gray-50">
                      <SafeNextImage src={p.image} alt={p.name} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-contain group-hover:scale-105 transition-transform duration-500" />
                      {p.original_price && p.original_price > p.price && (
                        <span className="absolute top-2 left-2 sm:top-3 sm:left-3 text-white text-[10px] sm:text-xs font-bold px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-full shadow-md" style={{ backgroundColor: "#e53e3e" }}>
                          -{Math.round(((p.original_price - p.price) / p.original_price) * 100)}%
                        </span>
                      )}
                      <div className="absolute inset-0 group-hover:bg-black/5 transition-colors duration-300" />
                    </div>
                  </a>
                  <div className="p-3 sm:p-4">
                    <a href="#checkout">
                      <h3 className="font-extrabold text-gray-800 text-sm sm:text-xl md:text-2xl leading-tight line-clamp-2 group-hover:text-[var(--lp)] transition-colors">
                        {p.name}
                      </h3>
                    </a>
                    {p.description && (
                      <p className="text-[11px] sm:text-xs text-gray-400 mt-1 line-clamp-1">{p.description.split("\n")[0]}</p>
                    )}
                    <div className="mt-2 sm:mt-3 flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-base sm:text-xl" style={{ color }}>৳{toBn(p.price)}</span>
                      {p.original_price && p.original_price > p.price && (
                        <span className="text-gray-400 line-through text-xs sm:text-sm">৳{toBn(p.original_price)}</span>
                      )}
                    </div>
                    <a href="#checkout"
                      className="mt-3 w-full py-2 sm:py-2.5 text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors flex items-center justify-center shadow-sm hover:opacity-90"
                      style={{ backgroundColor: color }}>
                      অর্ডার করুন
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── FEATURES/BENEFITS ── */}
      {show("features") && features.length > 0 && (
        <section className="py-8 md:py-10 text-white" id="benefits" style={{ backgroundColor: color, order: ord("features") }}>
          <div className="max-w-7xl mx-auto px-6 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="order-2 lg:order-1">
              <LpText target="features_title" value={page.features_title || "🔥 কেন এই প্রোডাক্ট ব্যবহার করবেন?"} as="h2" className="text-3xl md:text-4xl lg:text-5xl font-extrabold mb-10 text-center lg:text-left" />
              <div className="space-y-6">
                {features.map((f, i) => (
                  <div key={i} className="flex gap-4 items-start">
                    <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center shrink-0 text-xl">
                      {f.icon || <FiCheck className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="text-xl font-bold mb-1">{f.title}</h4>
                      <p className="text-white/80 text-sm leading-relaxed">{f.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {(page.features_image || page.hero_image) && (
              <div className="relative order-1 lg:order-2">
                <div className="bg-white/10 backdrop-blur-md p-2 rounded-[2rem] border border-white/20">
                  {(() => {
                    const src = page.features_image || page.hero_image;
                    if (!src) return null;
                    const auto = !!page.hero_video_autoplay;
                    if (isVideoFile(src) || isYouTube(src)) {
                      return <VideoPlayer src={src} autoPlay={auto} loop={auto} className="rounded-[1.8rem] max-w-none aspect-video" />;
                    }
                    return <SafeNextImage src={src} alt="Feature" width={600} height={600} sizes="(max-width: 768px) 100vw, 50vw" className="rounded-[1.8rem] w-full h-auto" />;
                  })()}
                </div>
                {page.hero_badge && (
                  <div className="absolute -top-3 -right-3 bg-green-100 text-green-800 px-3 py-2 rounded-xl shadow-lg text-center">
                    {page.hero_badge.split(/\\n|\n/).map((line: string, i: number) => (
                      <span key={i} className={i === 0 ? "text-lg font-black block leading-tight" : "text-[10px] uppercase tracking-wider font-bold"}>
                        {line}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ── HOW IT WORKS ── */}
      {show("how_it_works") && howItWorks.length > 0 && (
        <section style={{ order: ord("how_it_works") }} className="py-8 md:py-10" id="how-it-works">
          <div className="max-w-7xl mx-auto px-6 md:px-8">
            <div className="text-center mb-8">
              <LpText target="how_it_works_title" value={page.how_it_works_title || "কিভাবে ব্যবহার করবেন?"} as="h2" className="text-3xl md:text-4xl font-extrabold mb-3" />
              <p className="text-gray-500 text-lg">{page.how_it_works_subtitle || page.how_it_works_sub || `অত্যন্ত সহজ ${toBn(howItWorks.length)}টি ধাপ`}</p>
            </div>
            <div className={`grid grid-cols-1 gap-4 relative ${howItWorks.length === 1 ? "md:grid-cols-1" : howItWorks.length === 2 ? "md:grid-cols-2" : howItWorks.length === 3 ? "md:grid-cols-3" : "md:grid-cols-4"}`}>
              <div className="hidden md:block absolute top-12 left-[15%] right-[15%] h-0.5 border-t-2 border-dashed border-gray-200" />
              {howItWorks.map((step, i) => (
                <div key={i} className="text-center z-10 px-4">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-lg text-2xl font-bold" style={{ color }}>
                    {toBn(i + 1)}
                  </div>
                  <h4 className="font-bold text-lg mb-2">{step.title}</h4>
                  <p className="text-sm text-gray-500">{step.description}</p>
                </div>
              ))}
            </div>
            {/* CTA under How It Works */}
            <div className="text-center mt-10">
              <a href="#checkout" className="inline-block px-8 py-4 rounded-full text-white text-lg font-bold shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all active:scale-95" style={{ backgroundColor: color }}>
                {page.hero_cta || "👉 এখনই অর্ডার করুন"}
              </a>
            </div>
          </div>
        </section>
      )}

      {/* ── TESTIMONIALS CAROUSEL ── (lazy: Swiper kept out of first paint) */}
      {show("testimonials") && testimonials.length > 0 && (
        <div style={{ order: ord("testimonials") }}>
          <TestimonialsCarousel
            testimonials={testimonials}
            color={color}
            title={page.testimonials_title || "গ্রাহকদের মন্তব্য"}
          />
        </div>
      )}

      {/* ── FAQ ── */}
      {show("faq") && faqItems.length > 0 && (
        <section style={{ order: ord("faq") }} className="py-8 md:py-10" id="faq">
          <div className="max-w-3xl mx-auto px-6 md:px-8">
            <LpText target="faq_title" value={page.faq_title || "সাধারণ কিছু প্রশ্ন (FAQ)"} as="h2" className="text-3xl md:text-4xl font-extrabold text-center mb-12" />
            <div className="space-y-3">
              {faqItems.map((item, i) => (
                <div key={i} className="bg-gray-50 rounded-2xl overflow-hidden">
                  <button type="button" onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between px-6 py-5 text-left font-bold text-lg hover:bg-gray-100 transition-colors">
                    <span>{item.question}</span>
                    <FiChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${openFaq === i ? "rotate-180" : ""}`} />
                  </button>
                  {openFaq === i && (
                    <div className="px-6 pb-5 text-gray-600 leading-relaxed">{item.answer}</div>
                  )}
                </div>
              ))}
            </div>
            {/* CTA under FAQ */}
            <div className="text-center mt-10">
              <a href="#checkout" className="inline-block px-8 py-4 rounded-full text-white text-lg font-bold shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all active:scale-95" style={{ backgroundColor: color }}>
                {page.hero_cta || "👉 এখনই অর্ডার করুন"}
              </a>
            </div>
          </div>
        </section>
      )}

      </div>{/* ── end reorderable sections ── */}

      {/* ── CHECKOUT ── (pinned last — the #checkout conversion anchor) */}
      {products.length > 0 && (
        <section className="py-8 md:py-10 bg-gray-100 relative overflow-hidden" id="checkout">
          <div className="max-w-4xl mx-auto px-6 md:px-8">
            <div className="bg-white rounded-[2rem] md:rounded-[3rem] p-8 md:p-14 shadow-2xl relative z-10 border border-gray-100">
              <div className="text-center mb-10">
                <h2 className="text-3xl md:text-4xl font-extrabold mb-3" style={{ color }}>{page.checkout_title || "🛒 আপনার অর্ডার দিন এখনই"}</h2>
                <p className="text-gray-500">{page.checkout_subtitle || "নিচের ফরমটি পূরণ করে অর্ডারটি কনফার্ম করুন।"}</p>
              </div>

              <form onSubmit={handleOrder} className="space-y-6">
                {error && <div className="p-4 bg-red-50 text-red-700 rounded-xl text-sm">{error}</div>}

                <div className="flex flex-col md:flex-row gap-4 md:gap-6">
                  <div className="flex-1">
                    <label className="block font-bold text-sm mb-2 px-1">আপনার নাম *</label>
                    <input required name="name" autoComplete="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full bg-gray-50 border-none rounded-xl p-4 focus:ring-2 focus:outline-none text-sm" style={{ "--tw-ring-color": color } as React.CSSProperties}
                      placeholder="পুরো নাম লিখুন" />
                  </div>
                  <div className="flex-1">
                    <label className="block font-bold text-sm mb-2 px-1">মোবাইল নম্বর *</label>
                    <input required type="tel" name="tel" autoComplete="tel" value={form.phone}
                      onChange={(e) => {
                        const val = e.target.value.replace(/[^\d]/g, "");
                        setForm({ ...form, phone: val });
                        if (phoneError) setPhoneError(validatePhone(val));
                      }}
                      onBlur={(e) => setPhoneError(validatePhone(e.target.value.replace(/[^\d]/g, "")))}
                      ref={phoneRef}
                      maxLength={11}
                      inputMode="numeric"
                      className={`w-full border-2 rounded-xl p-4 focus:ring-2 focus:outline-none text-sm transition-colors ${phoneError ? "bg-red-50 border-red-400 focus:ring-red-300" : "bg-gray-50 border-transparent"}`}
                      style={!phoneError ? { "--tw-ring-color": color } as React.CSSProperties : {}}
                      placeholder="01700000000" />
                    {phoneError && (
                      <p className="mt-1.5 text-xs text-red-500 px-1 flex items-center gap-1">
                        <span>⚠</span> {phoneError}
                      </p>
                    )}
                  </div>
                </div>
                {page.show_email && (
                  <div>
                    <label className="block font-bold text-sm mb-2 px-1">ইমেইল (ঐচ্ছিক)</label>
                    <input type="email" name="email" autoComplete="email" value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full bg-gray-50 border-none rounded-xl p-4 focus:ring-2 focus:outline-none text-sm" style={{ "--tw-ring-color": color } as React.CSSProperties}
                      placeholder="your@email.com" />
                  </div>
                )}
                <div>
                  <label className="block font-bold text-sm mb-2 px-1">সম্পূর্ণ ঠিকানা *</label>
                  <textarea required name="street-address" autoComplete="street-address" rows={3} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })}
                    className="w-full bg-gray-50 border-none rounded-xl p-4 focus:ring-2 focus:outline-none text-sm resize-none" style={{ "--tw-ring-color": color } as React.CSSProperties}
                    placeholder="গ্রাম, থানা, জেলা উল্লেখ করুন" />
                </div>
                {(page.show_city !== false) && (
                  <div>
                    <label className="block font-bold text-sm mb-2 px-1">শহর/জেলা *</label>
                    <input required name="address-level2" autoComplete="address-level2" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })}
                      className="w-full bg-gray-50 border-none rounded-xl p-4 focus:ring-2 focus:outline-none text-sm" style={{ "--tw-ring-color": color } as React.CSSProperties}
                      placeholder="আপনার জেলা" />
                  </div>
                )}

                {/* Product quantity selector */}
                <div>
                  <label className="block font-bold text-sm mb-4 px-1">পণ্য / প্রোডাক্ট সিলেক্ট করুন</label>
                  <div className="space-y-3">
                    {products.map((p) => {
                      const hasVars = p.has_variations || p.hasVariations;
                      const vars = p.variants || [];
                      const selectedVar = hasVars && vars.length > 0 ? (vars.find(v => v.id === selectedVariants[p.id]) ?? null) : null;
                      const effectivePrice = selectedVar ? selectedVar.price : p.price;
                      const effectiveOrigPrice = selectedVar ? selectedVar.original_price : p.original_price;
                      const effectiveImage = (selectedVar?.image) || p.image;

                      return (
                      <div key={p.id}>
                        {/* Variant product: render each variant as a selectable radio row */}
                        {hasVars && vars.length > 0 ? (
                          <div className="space-y-2">
                            {vars.map(v => {
                              const isSelected = selectedVariants[p.id] === v.id;
                              const vImg = v.image || p.image;
                              const vKey = `${p.id}_${v.id}`;
                              const vQty = quantities[vKey as unknown as number] || 1;
                              const vMaxStock = (v as any).unlimited_stock ? 999 : (v.stock > 0 ? v.stock : 999);
                              const vAtMax = vQty >= vMaxStock && vMaxStock < 999;
                              return (
                                <div key={v.id}
                                  onClick={() => setSelectedVariants(prev => ({ ...prev, [p.id]: v.id }))}
                                  className={`p-3 rounded-xl border-2 cursor-pointer transition-all ${
                                    isSelected
                                      ? "border-[var(--lp)] bg-[var(--lp-light)]"
                                      : "border-gray-100 hover:border-gray-200"
                                  }`}>
                                  {/* Row: radio + image + name/price + [qty desktop] + price */}
                                  <div className="flex items-center gap-3">
                                    <input type="radio"
                                      name={`variant_${p.id}`}
                                      checked={isSelected}
                                      onChange={() => setSelectedVariants(prev => ({ ...prev, [p.id]: v.id }))}
                                      onClick={e => e.stopPropagation()}
                                      className="w-4 h-4 shrink-0"
                                      style={{ accentColor: color }} />
                                    {vImg && (
                                      <div className="w-10 h-10 rounded-lg overflow-hidden relative shrink-0">
                                        <SafeNextImage src={vImg} alt={v.label} fill sizes="40px" className="object-cover" />
                                      </div>
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <div className="font-semibold text-sm break-words">{p.name} — {v.label}</div>
                                      <div className="text-xs text-gray-400">৳{toBn(v.price)} / পিস</div>
                                    </div>
                                    {/* Desktop qty controls — inline */}
                                    {isSelected && (
                                      <div className="hidden md:flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                                        <button type="button"
                                          onClick={() => setQuantities(prev => ({ ...prev, [vKey as unknown as number]: Math.max(1, vQty - 1) }))}
                                          disabled={vQty <= 1}
                                          className="w-7 h-7 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                                          <FiMinus className="w-3.5 h-3.5" />
                                        </button>
                                        <span className="min-w-[2rem] text-center font-bold text-base">{toBn(vQty)}</span>
                                        <button type="button"
                                          onClick={() => setQuantities(prev => ({ ...prev, [vKey as unknown as number]: Math.min(vQty + 1, vMaxStock) }))}
                                          disabled={vAtMax}
                                          className="w-7 h-7 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                                          <FiPlus className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    )}
                                    <div className="font-bold text-sm shrink-0" style={{ color }}>৳{toBn(v.price * vQty)}</div>
                                  </div>
                                  {/* Mobile qty controls — stacked below */}
                                  {isSelected && (
                                    <div className="md:hidden flex items-center justify-center gap-3 mt-3 pt-3 border-t border-gray-100"
                                      onClick={e => e.stopPropagation()}>
                                      <button type="button"
                                        onClick={() => setQuantities(prev => ({ ...prev, [vKey as unknown as number]: Math.max(1, vQty - 1) }))}
                                        disabled={vQty <= 1}
                                        className="w-8 h-8 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                                        <FiMinus className="w-3.5 h-3.5" />
                                      </button>
                                      <span className="min-w-[2.5rem] text-center font-bold text-lg">{toBn(vQty)}</span>
                                      <button type="button"
                                        onClick={() => setQuantities(prev => ({ ...prev, [vKey as unknown as number]: Math.min(vQty + 1, vMaxStock) }))}
                                        disabled={vAtMax}
                                        className="w-8 h-8 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                                        <FiPlus className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                        <div className="p-3 md:p-4 rounded-xl border-2 border-gray-100 hover:border-gray-200 transition-colors">
                        {/* Desktop: grid layout for aligned columns */}
                        {(() => { const mxS = getMaxStock(p); const curQ = quantities[p.id] || 1; const atMax = curQ >= mxS && mxS < 999; return (
                        <div className="hidden md:grid md:grid-cols-[48px_1fr_130px_80px] items-center gap-3">
                          <div className="w-12 h-12 rounded-lg overflow-hidden relative shrink-0"><SafeNextImage src={effectiveImage} alt={p.name} fill sizes="48px" className="object-cover" /></div>
                          <div className="min-w-0">
                            <div className="font-bold text-sm truncate">{p.name}</div>
                            <div className="text-xs text-gray-400">৳{toBn(effectivePrice)} / পিস{mxS < 999 && <span className="ml-1 text-gray-300">· {toBn(mxS)}টি আছে</span>}</div>
                          </div>
                          <div className="flex items-center justify-center gap-2">
                            <button type="button" onClick={() => updateQty(p.id, curQ - 1)}
                              disabled={curQ <= 1}
                              className="w-8 h-8 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                              <FiMinus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-10 text-center font-bold">{toBn(curQ)}</span>
                            <button type="button" onClick={() => updateQty(p.id, curQ + 1)}
                              disabled={atMax}
                              className="w-8 h-8 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                              <FiPlus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="font-bold text-lg text-right" style={{ color }}>
                            ৳{toBn(effectivePrice * curQ)}
                          </div>
                        </div>
                        ); })()}
                        {/* Mobile: stacked layout */}
                        {(() => { const mxS = getMaxStock(p); const curQ = quantities[p.id] || 1; const atMax = curQ >= mxS && mxS < 999; return (
                        <div className="md:hidden">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg overflow-hidden relative shrink-0"><SafeNextImage src={effectiveImage} alt={p.name} fill sizes="40px" className="object-cover" /></div>
                            <div className="flex-1 min-w-0">
                              <div className="font-bold text-sm truncate">{p.name}</div>
                              <div className="text-xs text-gray-400">৳{toBn(effectivePrice)} / পিস{mxS < 999 && <span className="ml-1 text-gray-300">· {toBn(mxS)}টি</span>}</div>
                            </div>
                            <div className="font-bold text-base shrink-0" style={{ color }}>
                              ৳{toBn(effectivePrice * curQ)}
                            </div>
                          </div>
                          <div className="flex items-center justify-center gap-3 mt-3 pt-3 border-t border-gray-100">
                            <button type="button" onClick={() => updateQty(p.id, curQ - 1)}
                              disabled={curQ <= 1}
                              className="w-8 h-8 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                              <FiMinus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-10 text-center font-bold text-lg">{toBn(curQ)}</span>
                            <button type="button" onClick={() => updateQty(p.id, curQ + 1)}
                              disabled={atMax}
                              className="w-8 h-8 rounded-full border border-gray-200 bg-white flex items-center justify-center text-gray-600 hover:bg-gray-50 hover:border-gray-300 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                              <FiPlus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        ); })()}
                        </div>
                        )}
                      </div>
                      );
                    })}
                  </div>
                </div>

                {/* Shipping Zone Selector (only when custom shipping is OFF and no product custom shipping) */}
                {!page.custom_shipping && customShippingValues.length === 0 && shippingZones.length > 0 && (
                  <div>
                    <label className="block font-bold text-sm mb-3 px-1">ডেলিভারি এরিয়া সিলেক্ট করুন *</label>
                    <div className="space-y-2">
                      {shippingZones.map((zone) => (
                        <label key={zone.id}
                          className={`flex items-center justify-between p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                            selectedZone === zone.id
                              ? "border-[var(--lp)] bg-[var(--lp-light)]"
                              : "border-gray-100 hover:border-gray-200"
                          }`}>
                          <div className="flex items-center gap-3">
                            <input type="radio" name="shipping_zone" checked={selectedZone === zone.id}
                              onChange={() => setSelectedZone(zone.id)}
                              className="w-4 h-4" style={{ accentColor: color }} />
                            <div>
                              <div className="font-semibold text-sm">{zone.name}</div>
                              {zone.estimated_days && <div className="text-xs text-gray-400">{zone.estimated_days}</div>}
                            </div>
                          </div>
                          <span className="font-bold text-sm" style={{ color }}>৳{toBn(zone.rate)}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {/* Total */}
                <div className="bg-gray-50 rounded-xl p-5 space-y-2 text-sm">
                  <div className="flex justify-between text-gray-500"><span>সাবটোটাল</span><span>৳{toBn(subtotal)}</span></div>
                  <div className="flex justify-between text-gray-500">
                    <span>শিপিং {shippingReady && activeZone ? `(${activeZone.name})` : ""}</span>
                    <span className={shippingReady && shipping === 0 ? "text-green-600 font-semibold" : ""}>
                      {!shippingReady ? "…" : shipping === 0 ? "ফ্রি" : `৳${toBn(shipping)}`}
                    </span>
                  </div>
                  <div className="flex justify-between font-bold text-xl pt-2 border-t border-gray-200" style={{ color }}>
                    <span>মোট</span><span>{shippingReady ? `৳${toBn(total)}` : "…"}</span>
                  </div>
                </div>

                <button type="submit" disabled={submitting || !shippingReady}
                  className="w-full text-white font-black text-xl md:text-2xl py-5 md:py-6 rounded-2xl shadow-xl hover:shadow-2xl transition-all active:scale-[0.98] disabled:opacity-50"
                  style={{ backgroundColor: color }}>
                  {submitting ? "অর্ডার হচ্ছে..." : page.checkout_btn_text || "অর্ডার কনফার্ম করুন"}
                </button>

                {page.guarantee_text && (
                  <p className="text-center text-xs text-gray-400 flex items-center justify-center gap-1.5">
                    🛡️ {page.guarantee_text}
                  </p>
                )}
              </form>
            </div>
          </div>
          <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full blur-[100px]" style={{ backgroundColor: `${color}10` }} />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-green-100/20 rounded-full blur-[100px]" />
        </section>
      )}

      {/* ── FOOTER ── */}
      <footer className="bg-gray-100 py-10">
        <div className="max-w-7xl mx-auto px-6 md:px-8 text-center">
          <div className="text-lg font-bold mb-3" style={{ color }}>{page.title}</div>
          <div className="flex items-center justify-center gap-4 text-sm text-gray-500 mb-4">
            {sitePhone && (
              <a href={`tel:${sitePhone}`} className="flex items-center gap-1 hover:text-gray-700"><FiPhone className="w-3.5 h-3.5" /> {sitePhone}</a>
            )}
          </div>
          <p className="text-xs text-gray-400">সারা বাংলাদেশে হোম ডেলিভারি • ক্যাশ অন ডেলিভারি</p>
        </div>
      </footer>

      {/* Floating contact bubble — mode (whatsapp/phone/messenger/all)
          controlled by the LP's contact_mode (dashboard form). */}
      <LpContactBubble pageWhatsapp={page.whatsapp} pageContactMode={page.contact_mode} />
    </div>
  );
}
