"use client";

/**
 * Frontend inline editor for landing pages — the pencil-icon "edit in place"
 * experience, mirroring the storefront themes but scoped to a single LP row.
 *
 * Architecture
 * ------------
 *  - <LpEditProvider pageId={..}> wraps a template. It exposes edit state via
 *    context and is the ONLY place that talks to the save endpoint.
 *  - <LpText> / <LpImage> are the editable wrappers a template drops around
 *    its text / image nodes. They show a pencil affordance in edit mode and
 *    write changes into the provider's draft.
 *  - <LpEditBar> is a floating control (Edit ▸ Save / Discard), admin-only.
 *
 * Admin gating
 * ------------
 *  Edit mode only turns on for users whose role is in ADMIN_ROLES (same set
 *  the storefront editor uses). Shoppers never see a pencil and never load the
 *  save path. The provider renders children untouched when not editing, so
 *  there is zero DOM/handler overhead for normal visitors.
 *
 * Saving
 * ------
 *  Each field declares a target: a top-level column (e.g. "hero_headline") or
 *  a template_data key (prefix "td:"). On Save the draft is split into
 *  { columns, template_data } and PATCHed to
 *  /api/v1/admin/landing-pages/<id> — a partial update that never disturbs
 *  other fields. After a successful save the page is reloaded so the
 *  server-rendered template re-reads the persisted values.
 */

import {
  createContext, useContext, useState, useCallback, useMemo, useRef, type ReactNode,
} from "react";
import { useAuth } from "@/lib/AuthContext";
import dynamic from "next/dynamic";

// Same media/gallery modal the storefront theme editor uses. Code-split +
// ssr:false so shoppers never download it; only mounts when an admin opens it.
const MediaGallery = dynamic(() => import("@/components/MediaGallery"), { ssr: false });

const ADMIN_ROLES = new Set(["admin", "ADMIN", "owner", "OWNER", "staff", "STAFF"]);

interface LpEditCtx {
  isAdmin: boolean;
  editing: boolean;
  draft: Record<string, string>;
  dirty: boolean;
  saving: boolean;
  toggleEditing: () => void;
  setField: (target: string, value: string) => void;
  get: (target: string, fallback: string) => string;
  save: () => void;
  discard: () => void;
  /** Open the media gallery to pick an image for `target`. */
  openGallery: (target: string) => void;
}

const Ctx = createContext<LpEditCtx | null>(null);
export const useLpEdit = () => useContext(Ctx);

export function LpEditProvider({ pageId, children }: { pageId: number; children: ReactNode }) {
  const { user } = useAuth();
  const isAdmin = !!user && ADMIN_ROLES.has(user.role);

  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  // Which field the open media gallery should write to (null = closed).
  const [galleryTarget, setGalleryTarget] = useState<string | null>(null);

  const dirty = Object.keys(draft).length > 0;

  const setField = useCallback((target: string, value: string) => {
    setDraft((d) => ({ ...d, [target]: value }));
  }, []);

  const get = useCallback(
    (target: string, fallback: string) => (target in draft ? draft[target] : fallback),
    [draft],
  );

  const discard = useCallback(() => setDraft({}), []);

  const toggleEditing = useCallback(() => {
    setEditing((e) => {
      if (e) setDraft({}); // leaving edit mode drops unsaved changes
      return !e;
    });
  }, []);

  const save = useCallback(async () => {
    if (!dirty || saving) return;
    setSaving(true);
    // Split draft into columns vs template_data:
    //  - "td:" prefix → template_data (strip prefix)
    //  - "__w" suffix (image width markers) → ALWAYS template_data, since they
    //    aren't real columns (the PATCH allow-list would reject them).
    //  - everything else → a top-level column.
    const columns: Record<string, string> = {};
    const template_data: Record<string, string> = {};
    for (const [target, value] of Object.entries(draft)) {
      if (target.startsWith("td:")) {
        template_data[target.slice(3)] = value;
      } else if (target.endsWith("__w")) {
        template_data[target] = value; // e.g. "hero_image__w"
      } else {
        columns[target] = value;
      }
    }
    try {
      const res = await fetch(`/api/v1/admin/landing-pages/${pageId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ columns, template_data }),
      });
      if (!res.ok) throw new Error(`Save failed (${res.status})`);
      // Reload so the SSR template re-reads persisted values (and the LP data
      // cache, busted by revalidateAll on the server, serves fresh content).
      window.location.reload();
    } catch (err) {
      setSaving(false);
      alert(err instanceof Error ? err.message : "Save failed");
    }
  }, [draft, dirty, saving, pageId]);

  const openGallery = useCallback((target: string) => setGalleryTarget(target), []);

  const value = useMemo<LpEditCtx>(
    () => ({ isAdmin, editing, draft, dirty, saving, toggleEditing, setField, get, save, discard, openGallery }),
    [isAdmin, editing, draft, dirty, saving, toggleEditing, setField, get, save, discard, openGallery],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      {/* Editor chrome + CSS are admin-only, so shoppers download zero editor
          markup/styles and the page HTML stays byte-identical to before. */}
      {isAdmin && (
        <>
          <LpEditBar />
          <style dangerouslySetInnerHTML={{ __html: LP_EDIT_CSS }} />
          {/* Media gallery — same picker the theme editor uses. Portals to
              <body>; writes the chosen URL into the draft field that opened it. */}
          {galleryTarget && (
            <MediaGallery
              open={!!galleryTarget}
              onClose={() => setGalleryTarget(null)}
              mediaType="image"
              onSelect={(url) => {
                setField(galleryTarget, url);
                setGalleryTarget(null);
              }}
            />
          )}
        </>
      )}
    </Ctx.Provider>
  );
}

/* ── Editable text ────────────────────────────────────────────────────
 * `as` picks the tag (h1/h2/p/span/button…). In edit mode the element
 * becomes contentEditable and a pencil badge appears; on blur the text is
 * committed to the draft. Outside edit mode it renders exactly as a plain
 * element — no wrapper, no handlers.
 */
export function LpText({
  target, value, as = "span", className, style, multiline = false,
}: {
  target: string;
  value: string;
  as?: keyof React.JSX.IntrinsicElements;
  className?: string;
  style?: React.CSSProperties;
  multiline?: boolean;
}) {
  const ctx = useLpEdit();
  const Tag = as as React.ElementType;
  if (!ctx || !ctx.editing) {
    return <Tag className={className} style={style}>{value}</Tag>;
  }
  const current = ctx.get(target, value);
  return (
    <Tag
      className={`${className || ""} lpe lpe--text`}
      style={style}
      contentEditable
      suppressContentEditableWarning
      data-lpe-pencil
      onInput={(e: React.FormEvent<HTMLElement>) => {
        const text = multiline
          ? (e.currentTarget as HTMLElement).innerText
          : (e.currentTarget as HTMLElement).innerText.replace(/\n/g, " ");
        ctx.setField(target, text);
      }}
      onBlur={(e: React.FocusEvent<HTMLElement>) => {
        const text = (e.currentTarget as HTMLElement).innerText;
        ctx.setField(target, multiline ? text : text.replace(/\n/g, " "));
      }}
    >
      {current}
    </Tag>
  );
}

/* ── Editable image ───────────────────────────────────────────────────
 * Outside edit mode: renders children untouched (zero overhead).
 * In edit mode:
 *   - CLICK the image → opens the MediaGallery picker (browse/upload/pick).
 *   - DRAG the corner handle → resize width; the new width (%) is stored in a
 *     companion draft field "<target>__w" and applied as a live max-width on
 *     this wrapper. The template reads it on next render so the size persists
 *     after save.
 *
 * Width is stored as a percentage of the container so it stays responsive
 * across screen sizes (a fixed px width would overflow mobile).
 */
export function LpImage({
  target, value, width, children,
}: {
  target: string;
  value: string;
  /** Persisted width (e.g. "62%") the template read from template_data
   *  (key "<base>__w"). Used as the fallback so a saved size survives reload
   *  and renders for shoppers. */
  width?: string;
  children: ReactNode;
}) {
  const ctx = useLpEdit();
  const wrapRef = useRef<HTMLSpanElement>(null);
  // Companion field: "<target>__w" holds a width like "62%". Draft overrides
  // the persisted prop while editing.
  const widthField = `${target}__w`;
  const widthVal = ctx ? ctx.get(widthField, width || "") : (width || "");

  if (!ctx || !ctx.editing) {
    // Even outside edit mode we honor a saved width so it persists for shoppers.
    // block + margin:auto keeps a resized image CENTERED (inline-block left-
    // aligned inside a normal-flow container). The img fills the wrapper.
    return widthVal
      ? <span className="lpe-imgwrap" style={{ display: "block", width: widthVal, maxWidth: "100%", marginInline: "auto" }}>{children}</span>
      : <>{children}</>;
  }

  const startResize = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const wrap = wrapRef.current;
    const parent = wrap?.parentElement;
    if (!wrap || !parent) return;
    const parentW = parent.getBoundingClientRect().width || 1;
    const startX = e.clientX;
    const startW = wrap.getBoundingClientRect().width;
    const onMove = (ev: PointerEvent) => {
      const newPx = Math.max(60, startW + (ev.clientX - startX));
      const pct = Math.min(100, Math.round((newPx / parentW) * 100));
      wrap.style.width = pct + "%";
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      const finalPct = wrap.style.width || `${Math.round((startW / parentW) * 100)}%`;
      ctx.setField(widthField, finalPct);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  return (
    <span
      ref={wrapRef}
      className="lpe lpe--img"
      data-lpe-pencil
      style={{ display: "block", width: widthVal || undefined, maxWidth: "100%", marginInline: "auto" }}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); ctx.openGallery(target); }}
      role="button"
      tabIndex={0}
      title="Click to choose an image · drag the corner to resize"
    >
      {children}
      {/* Resize handle — drag to change width. */}
      <span
        className="lpe-resize"
        onPointerDown={startResize}
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
        title="Drag to resize"
      />
    </span>
  );
}

/* ── Floating edit bar (admin only) ─────────────────────────────────── */
function LpEditBar() {
  const ctx = useLpEdit()!;
  if (!ctx.isAdmin) return null;
  return (
    <div className="lpe-bar">
      {!ctx.editing ? (
        <button type="button" className="lpe-bar__btn lpe-bar__btn--primary" onClick={ctx.toggleEditing}>
          ✏️ Edit page
        </button>
      ) : (
        <>
          {/* Hint on its own row above the buttons — on mobile the inline
              layout squeezed the buttons. */}
          <span className="lpe-bar__hint">{ctx.dirty ? "● Unsaved changes" : "Click any text or image to edit"}</span>
          <div className="lpe-bar__btns">
            <button type="button" className="lpe-bar__btn" onClick={ctx.discard} disabled={!ctx.dirty || ctx.saving}>
              Discard
            </button>
            <button type="button" className="lpe-bar__btn" onClick={ctx.toggleEditing} disabled={ctx.saving}>
              Exit
            </button>
            <button type="button" className="lpe-bar__btn lpe-bar__btn--primary" onClick={ctx.save} disabled={!ctx.dirty || ctx.saving}>
              {ctx.saving ? "Saving…" : "Save"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

const LP_EDIT_CSS = `
.lpe { position:relative; outline:1.5px dashed rgba(37,99,235,.5); outline-offset:3px; border-radius:4px; transition:outline-color .15s; }
.lpe:hover { outline-color:#2563eb; }
.lpe--text { cursor:text; min-width:1ch; }
.lpe--text:focus { outline:2px solid #2563eb; background:rgba(37,99,235,.05); }
.lpe--img { display:inline-block; cursor:pointer; }
/* When the wrapper has an explicit width (resized), make the inner image fill
   it. Without a set width the image keeps its natural size. */
.lpe--img[style*="width"] img { width:100%; height:auto; display:block; }
.lpe-resize {
  position:absolute; right:-7px; bottom:-7px; z-index:6;
  width:18px; height:18px; border-radius:50%; background:#2563eb;
  border:2px solid #fff; box-shadow:0 1px 4px rgba(0,0,0,.3);
  cursor:nwse-resize; touch-action:none;
}
.lpe-resize::after {
  content:""; position:absolute; inset:4px; border-right:2px solid #fff;
  border-bottom:2px solid #fff;
}
[data-lpe-pencil]::after {
  content:"✏️"; position:absolute; top:-10px; right:-10px; z-index:5;
  font-size:11px; background:#2563eb; color:#fff; width:20px; height:20px;
  border-radius:50%; display:flex; align-items:center; justify-content:center;
  box-shadow:0 2px 6px rgba(0,0,0,.25); pointer-events:none;
}
.lpe-bar {
  position:fixed; bottom:16px; left:50%; transform:translateX(-50%); z-index:99999;
  display:flex; flex-direction:column; align-items:center; gap:8px; background:#0f172a; color:#fff;
  padding:10px 14px; border-radius:18px; box-shadow:0 8px 28px rgba(0,0,0,.35);
  font-family:system-ui,sans-serif; font-size:14px; max-width:calc(100vw - 24px);
}
.lpe-bar__hint { font-size:12px; opacity:.8; text-align:center; white-space:nowrap; }
.lpe-bar__btns { display:flex; align-items:center; gap:8px; }
.lpe-bar__btns .lpe-bar__btn { flex:1; white-space:nowrap; }
.lpe-bar__btn {
  border:0; border-radius:999px; padding:8px 16px; font-size:13px; font-weight:700;
  cursor:pointer; background:rgba(255,255,255,.12); color:#fff; font-family:inherit;
}
.lpe-bar__btn:hover:not(:disabled) { background:rgba(255,255,255,.22); }
.lpe-bar__btn--primary { background:#2563eb; }
.lpe-bar__btn--primary:hover:not(:disabled) { background:#1d4ed8; }
.lpe-bar__btn:disabled { opacity:.4; cursor:default; }
`;
