"use client";

import { useRouter } from "next/navigation";
import { useRealtime } from "@/lib/useRealtime";

/**
 * Live-refresh the public landing page when an admin saves it in the
 * dashboard. Mirrors StorefrontFeaturesWatcher: subscribes to the tenant's
 * public "landing_pages" channel (anonymous-subscribable — see the realtime
 * auth route's PUBLIC_RESOURCES) and calls router.refresh() so the server
 * component re-renders with the new content — including section visibility
 * toggles — without the visitor reloading.
 *
 * Scoped by slug: a broadcast carries the edited page's slug, so a visitor on
 * LP "A" ignores edits to LP "B". Missing slug → refresh anyway (safe default).
 */
export default function LpRealtimeRefresh({ slug }: { slug: string }) {
  const router = useRouter();
  useRealtime<{ slug?: string }>("landing_pages", "changed", (payload) => {
    if (!payload?.slug || payload.slug === slug) {
      router.refresh();
    }
  });
  return null;
}
