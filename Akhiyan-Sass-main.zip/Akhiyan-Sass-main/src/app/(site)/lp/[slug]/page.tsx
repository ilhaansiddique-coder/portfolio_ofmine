/**
 * /lp/[slug] route. Two cases, distinguished by the x-lp-clean header that
 * proxy.ts sets ONLY on its internal rewrite of a clean root URL:
 *
 *   - EXTERNAL hit (/lp/ayurex typed/linked): no x-lp-clean header → 308
 *     redirect to the canonical clean URL /ayurex (consolidates old links/SEO).
 *   - INTERNAL rewrite (/ayurex → /lp/ayurex): x-lp-clean=1 → render the LP.
 *
 * Shared loader/renderer lives in ./lp-shared.
 */
import type { Metadata } from "next";
import { headers } from "next/headers";
import { permanentRedirect } from "next/navigation";
import { landingPageMetadata, renderLandingPage } from "./lp-shared";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  return landingPageMetadata(slug);
}

export default async function LandingPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const h = await headers();
  // Direct /lp/<slug> hit (not the internal rewrite) → send to the clean URL.
  if (h.get("x-lp-clean") !== "1") {
    permanentRedirect(`/${slug}`);
  }
  return renderLandingPage(slug);
}
