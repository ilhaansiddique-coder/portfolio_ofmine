/**
 * Legacy /p/[slug] route. Puck CMS pages are now served at clean root URLs
 * (/about-us, like landing pages), so any old /p/<slug> link 308-redirects to
 * the canonical clean URL. The actual render happens in the root resolver
 * (lp-shared.renderLandingPage → CMS fallback), reached via the proxy rewrite
 * of /<slug> → /lp/<slug>.
 */
import { permanentRedirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function CmsPageRoute(
  { params }: { params: Promise<{ slug: string }> },
) {
  const { slug } = await params;
  permanentRedirect(`/${slug}`);
}
