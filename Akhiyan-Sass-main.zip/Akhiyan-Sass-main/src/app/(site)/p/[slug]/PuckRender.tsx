"use client";

/** Public read-only Puck renderer (production path — no editor code). */
import { Render, type Data } from "@puckeditor/core";
import { puckConfig } from "@/lib/puck/config";

export default function PuckRender({ data }: { data: Record<string, unknown> }) {
  return (
    <div style={{ minHeight: "60vh" }}>
      <Render config={puckConfig} data={data as Data} />
    </div>
  );
}
