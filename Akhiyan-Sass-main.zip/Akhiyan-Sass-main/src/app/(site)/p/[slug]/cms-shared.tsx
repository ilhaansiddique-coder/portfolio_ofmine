/**
 * Shared CMS-page loader + renderer, used by BOTH:
 *   - the clean root URL resolver (lp-shared.renderLandingPage falls back here)
 *   - the legacy /p/[slug] route (now a redirect, but kept for metadata reuse)
 *
 * CMS pages render as NORMAL storefront pages — WITH navbar/footer — unlike
 * landing pages which are chrome-less. The (site) layout keeps chrome because
 * a CMS page is not an active landing page (isLandingPageRoute stays false).
 */
import { cache } from "react";
import { unstable_cache } from "next/cache";
import type { Metadata } from "next";
import type { PrismaClient } from "@prisma/client";
import PuckRender from "./PuckRender";

async function loadCmsPage(prisma: PrismaClient, slug: string) {
  try {
    return await prisma.cmsPage.findFirst({
      where: { slug, status: "published" },
      select: {
        title: true, publishedData: true,
        metaTitle: true, metaDesc: true, excerpt: true, featuredImage: true, noIndex: true,
      },
    });
  } catch {
    return null;
  }
}

/** Cross-request cache, tag `t<id>:cms-pages` — flushed by the admin
 *  cms-pages PATCH/DELETE (revalidateAll). */
export const getCmsPage = cache(
  (prisma: PrismaClient, tenantId: number, slug: string) =>
    unstable_cache(
      () => loadCmsPage(prisma, slug),
      ["cms", String(tenantId), slug],
      { tags: [`t${tenantId}:cms-pages`], revalidate: 300 },
    )(),
);

export function cmsPageMetadataFrom(
  page: Awaited<ReturnType<typeof loadCmsPage>>,
): Metadata {
  if (!page) return {};
  return {
    title: page.metaTitle || page.title,
    description: page.metaDesc || page.excerpt || undefined,
    openGraph: page.featuredImage ? { images: [page.featuredImage] } : undefined,
    robots: page.noIndex ? { index: false, follow: false } : undefined,
  };
}

/** Render the published Puck tree for a CMS page (read-only). */
export function renderCmsContent(data: unknown): React.ReactElement {
  return <PuckRender data={data as Record<string, unknown>} />;
}
