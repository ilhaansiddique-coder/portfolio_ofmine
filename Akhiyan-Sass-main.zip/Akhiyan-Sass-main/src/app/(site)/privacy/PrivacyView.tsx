"use client";

/**
 * Client-rendered view for the legacy default-theme privacy layout.
 * Extracted from `page.tsx` so the inline `<Editable>` function children
 * stay on the client side of the server/client boundary.
 */

import { FiShield } from "react-icons/fi";
import { TText } from "@/components/ProductDetailClient";
import type { Bilingual } from "@/lib/bilingual";
import { Editable } from "@/storefront-engine/editor/Editable";

interface PolicySection { title: Bilingual; content: Bilingual }
interface PolicyContent {
  title: Bilingual;
  lastUpdated: Bilingual;
  intro: Bilingual;
  sections: PolicySection[];
}

export default function PrivacyView({ content }: { content: PolicyContent }) {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="bg-linear-to-br from-primary via-primary-light to-primary-dark py-14 md:py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-white/15 rounded-2xl mb-4">
            <FiShield className="w-7 h-7 text-white" />
          </div>
          <Editable section="privacy" field="title" defaultValue={content.title.en || content.title.bn} label="Privacy title">
            {(v, ep) => (
              <h1 {...ep} className={`text-4xl md:text-5xl font-bold text-white mb-3 ${ep.className ?? ""}`}>
                {v || <TText en={content.title.en} bn={content.title.bn} />}
              </h1>
            )}
          </Editable>
          <p className="text-white/75 text-base max-w-lg mx-auto">
            <Editable section="privacy" field="lastUpdatedLabel" defaultValue="Last updated: " label="“Last updated” label">
              {(v, ep) => <span {...ep}>{v || <TText en="Last updated: " bn="সর্বশেষ আপডেট: " />}</span>}
            </Editable>
            <Editable section="privacy" field="lastUpdated" defaultValue={content.lastUpdated.en || content.lastUpdated.bn} label="Last updated date">
              {(v, ep) => <span {...ep}>{v || <TText en={content.lastUpdated.en} bn={content.lastUpdated.bn} />}</span>}
            </Editable>
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-14 md:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="bg-primary/5 border border-primary/15 rounded-2xl p-5 mb-10">
              <Editable section="privacy" field="intro" defaultValue={content.intro.en || content.intro.bn} label="Privacy intro">
                {(v, ep) => (
                  <p {...ep} className={`text-text-body text-sm leading-relaxed ${ep.className ?? ""}`}>
                    {v || <TText en={content.intro.en} bn={content.intro.bn} />}
                  </p>
                )}
              </Editable>
            </div>

            <div className="space-y-10">
              {content.sections.map((section, idx) => {
                const n = idx + 1;
                return (
                  <div key={idx}>
                    <h2 className="text-2xl font-bold text-foreground mb-4 flex items-center gap-3">
                      <span className="w-8 h-8 bg-primary text-white rounded-lg flex items-center justify-center text-sm font-bold shrink-0">
                        {n}
                      </span>
                      <Editable
                        section="privacy"
                        field={`section${n}Title`}
                        defaultValue={section.title.en || section.title.bn}
                        label={`Section ${n} title`}
                      >
                        {(v, ep) => <span {...ep}>{v || <TText en={section.title.en} bn={section.title.bn} />}</span>}
                      </Editable>
                    </h2>
                    <Editable
                      section="privacy"
                      field={`section${n}Content`}
                      defaultValue={section.content.en || section.content.bn}
                      label={`Section ${n} body`}
                    >
                      {(v, ep) => (
                        <div {...ep} className={`pl-11 text-text-body text-sm leading-relaxed whitespace-pre-line ${ep.className ?? ""}`}>
                          {v || <TText en={section.content.en} bn={section.content.bn} />}
                        </div>
                      )}
                    </Editable>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
