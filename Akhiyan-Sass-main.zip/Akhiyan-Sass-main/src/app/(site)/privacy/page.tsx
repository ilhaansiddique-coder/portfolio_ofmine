/**
 * /privacy — thin shell.
 *
 * Loads the tenant's saved policy content (or falls back to defaults),
 * resolves the active storefront theme, and renders the theme's
 * PrivacyPage when one is registered. When the active theme has no
 * privacy page override (e.g. the default theme), renders the legacy
 * inline layout via `<PrivacyView>` (client-only so its `<Editable>`
 * wrappers don't trip the server/client boundary).
 */

import type { ComponentType } from "react";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSetting } from "@/lib/settingsCache";
import type { PrismaClient } from "@prisma/client";
import { toBilingual, type Bilingual } from "@/lib/bilingual";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { PolicyContent, PrivacyPageProps } from "@/storefront-engine/types/pages";
import PrivacyView from "./PrivacyView";

export const dynamic = "force-dynamic";

interface PolicySection { title: Bilingual; content: Bilingual }

const DEFAULT_PRIVACY: PolicyContent = {
  title: { en: "Privacy Policy", bn: "গোপনীয়তা নীতি" },
  lastUpdated: { en: "January 1, 2025", bn: "১ জানুয়ারি ২০২৫" },
  intro: {
    en: "We take your privacy very seriously. This privacy policy describes how we collect, use and protect your information when you use our website.",
    bn: "আমরা আপনার গোপনীয়তাকে সর্বোচ্চ গুরুত্ব দিই।",
  },
  sections: [
    {
      title: { en: "Information Collection", bn: "তথ্য সংগ্রহ" },
      content: {
        en: "We may collect the following information to provide our services:\n- Personal information: name, email address, phone number, delivery address.\n- Order information: products you purchased, payment information (securely processed).\n- Browsing information: which products you viewed, how much time you spent.\n- Device information: browser type, IP address, operating system.",
        bn: "আমরা আমাদের পরিষেবা প্রদান করার জন্য নিম্নলিখিত তথ্য সংগ্রহ করতে পারি।",
      },
    },
  ],
};

function normalizePolicy(raw: unknown, fallback: PolicyContent): PolicyContent {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const sections = Array.isArray(r.sections) ? r.sections : fallback.sections;
  return {
    title: toBilingual(r.title ?? fallback.title),
    lastUpdated: toBilingual(r.lastUpdated ?? fallback.lastUpdated),
    intro: toBilingual(r.intro ?? fallback.intro),
    sections: sections.map((s) => {
      const o = (s && typeof s === "object" ? s : {}) as Record<string, unknown>;
      return { title: toBilingual(o.title), content: toBilingual(o.content) } as PolicySection;
    }),
  };
}

async function getContent(prisma: PrismaClient, tenantId: number): Promise<PolicyContent> {
  try {
    const value = await getSetting(prisma, tenantId, "page_privacy");
    if (value) return normalizePolicy(JSON.parse(value), DEFAULT_PRIVACY);
  } catch { /* */ }
  return DEFAULT_PRIVACY;
}

async function resolveLang(prisma: PrismaClient, tenantId: number): Promise<"en" | "bn"> {
  try {
    const value = await getSetting(prisma, tenantId, "site_language");
    if (value === "bn" || value === "en") return value;
  } catch { /* */ }
  return "en";
}

export async function generateMetadata(): Promise<Metadata> {
  const { prisma, tenant } = await getPrismaForRequest();
  const content = await getContent(prisma, tenant.id);
  return {
    title: content.title.bn || content.title.en || "Privacy Policy",
    description: content.intro.bn || content.intro.en,
  };
}

export default async function PrivacyRoute() {
  const { prisma, tenant } = await getPrismaForRequest();
  const [content, lang] = await Promise.all([
    getContent(prisma, tenant.id),
    resolveLang(prisma, tenant.id),
  ]);
  await headers();

  let ActivePage: ComponentType<PrivacyPageProps> | null = null;
  let activeThemeId = "default";
  try {
    const theme = await getActiveTheme();
    activeThemeId = theme.id;
    if (theme.pages.loadPrivacyPage) {
      ActivePage = await theme.pages.loadPrivacyPage().catch(() => null);
    }
  } catch { /* fall through to legacy view */ }

  if (ActivePage) {
    return (
      <div className={`theme-${activeThemeId}`}>
        <ThemeErrorBoundary themeId={activeThemeId} fallback={<PrivacyView content={content} />}>
          <ActivePage content={content} lang={lang} />
        </ThemeErrorBoundary>
      </div>
    );
  }

  return <PrivacyView content={content} />;
}
