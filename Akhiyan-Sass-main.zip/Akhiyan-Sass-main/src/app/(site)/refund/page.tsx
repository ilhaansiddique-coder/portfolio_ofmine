/**
 * /refund — thin shell.
 *
 * Loads the tenant's saved refund policy content, resolves the active
 * storefront theme, and renders the theme's RefundPage when one is
 * registered. Falls back to the legacy default-theme RefundView when
 * the active theme has no override.
 */

import type { ComponentType } from "react";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSetting } from "@/lib/settingsCache";
import type { PrismaClient } from "@prisma/client";
import { toBilingual, type Bilingual } from "@/lib/bilingual";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { PolicyContent, RefundPageProps } from "@/storefront-engine/types/pages";
import RefundView from "./RefundView";

export const dynamic = "force-dynamic";

interface PolicySection { title: Bilingual; content: Bilingual }

const DEFAULT_REFUND: PolicyContent = {
  title: { en: "Refund Policy", bn: "রিফান্ড পলিসি" },
  lastUpdated: { en: "January 1, 2025", bn: "১ জানুয়ারি ২০২৫" },
  intro: {
    en: "We give your satisfaction the highest priority. Our refund policy is completely transparent and simple.",
    bn: "আমরা আপনার সন্তুষ্টিকে সর্বোচ্চ অগ্রাধিকার দেই।",
  },
  sections: [],
};

function normalizePolicy(raw: unknown, fallback: PolicyContent): PolicyContent {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const sections = Array.isArray(r.sections) ? r.sections : fallback.sections;
  return {
    title: toBilingual(r.title ?? fallback.title),
    lastUpdated: toBilingual(r.lastUpdated ?? fallback.lastUpdated),
    intro: toBilingual(r.intro ?? fallback.intro),
    sections: sections.map((s) => {
      const o = (s && typeof s === "object" ? s : {}) as Record<string, unknown>;
      return { title: toBilingual(o.title), content: toBilingual(o.content) } as PolicySection;
    }),
  };
}

async function getContent(prisma: PrismaClient, tenantId: number): Promise<PolicyContent> {
  try {
    const value = await getSetting(prisma, tenantId, "page_refund");
    if (value) return normalizePolicy(JSON.parse(value), DEFAULT_REFUND);
  } catch { /* */ }
  return DEFAULT_REFUND;
}

async function resolveLang(prisma: PrismaClient, tenantId: number): Promise<"en" | "bn"> {
  try {
    const value = await getSetting(prisma, tenantId, "site_language");
    if (value === "bn" || value === "en") return value;
  } catch { /* */ }
  return "en";
}

export async function generateMetadata(): Promise<Metadata> {
  const { prisma, tenant } = await getPrismaForRequest();
  const content = await getContent(prisma, tenant.id);
  return {
    title: content.title.bn || content.title.en || "Refund Policy",
    description: content.intro.bn || content.intro.en,
  };
}

export default async function RefundRoute() {
  const { prisma, tenant } = await getPrismaForRequest();
  const [content, lang] = await Promise.all([
    getContent(prisma, tenant.id),
    resolveLang(prisma, tenant.id),
  ]);
  await headers();

  let ActivePage: ComponentType<RefundPageProps> | null = null;
  let activeThemeId = "default";
  try {
    const theme = await getActiveTheme();
    activeThemeId = theme.id;
    if (theme.pages.loadRefundPage) {
      ActivePage = await theme.pages.loadRefundPage().catch(() => null);
    }
  } catch { /* fall through to legacy view */ }

  if (ActivePage) {
    return (
      <div className={`theme-${activeThemeId}`}>
        <ThemeErrorBoundary themeId={activeThemeId} fallback={<RefundView content={content} />}>
          <ActivePage content={content} lang={lang} />
        </ThemeErrorBoundary>
      </div>
    );
  }

  return <RefundView content={content} />;
}
