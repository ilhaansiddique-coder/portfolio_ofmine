/**
 * Homepage route — THIN SHELL.
 *
 * Responsibilities (and ONLY these):
 *   1. Fetch typed data via `@/storefront-engine/data/home`.
 *   2. Resolve the tenant's active theme via `@/storefront-engine/loader`.
 *   3. Dynamically import that theme's HomePage component.
 *   4. Render it inside `ThemeErrorBoundary` with the default theme as
 *      fallback so a broken theme never white-screens the storefront.
 *
 * All rendering, layout, and styling decisions live in the theme bundle
 * under `src/themes/<id>/pages/HomePage.tsx`. This file should never grow.
 */

import type { ComponentType } from "react";
import { getActiveTheme } from "@/storefront-engine/loader";
import { loadHomeData } from "@/storefront-engine/data/home";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import DefaultHomePage from "@/themes/default/pages/HomePage";
import type { HomePageProps } from "@/storefront-engine/types/pages";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSetting } from "@/lib/settingsCache";
import { getCmsPage, renderCmsContent } from "./p/[slug]/cms-shared";

// Multi-tenant: must be dynamic — getPrismaForRequest reads the host header.
export const dynamic = "force-dynamic";

export default async function HomeRoute() {
  // WordPress-style "front page": when the admin designates a CMS page as the
  // home page (Site Settings → home_page_slug), render it at "/" instead of
  // the theme homepage. Renders WITH storefront chrome (navbar/footer) like a
  // normal page. Falls through to the theme home if unset or unpublished.
  {
    const { prisma, tenant } = await getPrismaForRequest();
    const homeSlug = (await getSetting(prisma, tenant.id, "home_page_slug").catch(() => null))?.trim();
    if (homeSlug) {
      const cms = await getCmsPage(prisma, tenant.id, homeSlug);
      if (cms?.publishedData) return renderCmsContent(cms.publishedData);
    }
  }

  const data = await loadHomeData();
  const theme = await getActiveTheme();

  // Resolve the active theme's HomePage. If it's missing (theme hasn't
  // ported this route yet) or the dynamic import fails, fall back to the
  // default theme's HomePage so the route always renders something.
  let ActivePage: ComponentType<HomePageProps> = DefaultHomePage;
  if (theme.pages.loadHomePage) {
    try {
      ActivePage = await theme.pages.loadHomePage();
    } catch {
      ActivePage = DefaultHomePage;
    }
  }

  return (
    <div className={`theme-${theme.id}`}>
      <ThemeErrorBoundary themeId={theme.id} fallback={<DefaultHomePage {...data} />}>
        <ActivePage {...data} />
      </ThemeErrorBoundary>
    </div>
  );
}
