import { Suspense } from "react";
import { unstable_cache } from "next/cache";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { mapApiProduct } from "@/data/products";
import type { Product } from "@/data/products";
import { inStockWhere } from "@/lib/productFilters";
import { toBilingual, type Bilingual } from "@/lib/bilingual";
import ShopClient from "./ShopClient";
import type { PrismaClient } from "@prisma/client";
import type { ComponentType } from "react";
import { getActiveTheme } from "@/storefront-engine/loader";
import { ThemeErrorBoundary } from "@/storefront-engine/ThemeErrorBoundary";
import type { ShopPageProps } from "@/storefront-engine/types/pages";

// Multi-tenant: must be dynamic — getPrismaForRequest reads the host header.
export const dynamic = "force-dynamic";

interface ShopContent {
  heroBadge: Bilingual;
  heroTitle: Bilingual;
  heroSubtitle: Bilingual;
  filtersTitle: Bilingual;
  categoryLabel: Bilingual;
  brandLabel: Bilingual;
  priceLabel: Bilingual;
  sortLabel: Bilingual;
  emptyTitle: Bilingual;
  emptyDescription: Bilingual;
  loadMoreText: Bilingual;
}

const DEFAULT_SHOP: ShopContent = {
  heroBadge: { en: "Browse Products", bn: "পণ্য ব্রাউজ করুন" },
  heroTitle: { en: "Shop", bn: "শপ" },
  heroSubtitle: { en: "Discover quality products at great prices", bn: "চমৎকার মূল্যে মানসম্পন্ন পণ্য আবিষ্কার করুন" },
  filtersTitle: { en: "Filters", bn: "ফিল্টার" },
  categoryLabel: { en: "Category", bn: "ক্যাটাগরি" },
  brandLabel: { en: "Brand", bn: "ব্র্যান্ড" },
  priceLabel: { en: "Price Range", bn: "মূল্য সীমা" },
  sortLabel: { en: "Sort by", bn: "সাজান" },
  emptyTitle: { en: "No products found", bn: "কোনো পণ্য পাওয়া যায়নি" },
  emptyDescription: { en: "Try adjusting your filters or search criteria", bn: "আপনার ফিল্টার বা সার্চ পরিবর্তন করে দেখুন" },
  loadMoreText: { en: "Load More", bn: "আরও দেখুন" },
};

function normalizeShop(raw: unknown): ShopContent {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return {
    heroBadge: toBilingual(r.heroBadge ?? DEFAULT_SHOP.heroBadge),
    heroTitle: toBilingual(r.heroTitle ?? DEFAULT_SHOP.heroTitle),
    heroSubtitle: toBilingual(r.heroSubtitle ?? DEFAULT_SHOP.heroSubtitle),
    filtersTitle: toBilingual(r.filtersTitle ?? DEFAULT_SHOP.filtersTitle),
    categoryLabel: toBilingual(r.categoryLabel ?? DEFAULT_SHOP.categoryLabel),
    brandLabel: toBilingual(r.brandLabel ?? DEFAULT_SHOP.brandLabel),
    priceLabel: toBilingual(r.priceLabel ?? DEFAULT_SHOP.priceLabel),
    sortLabel: toBilingual(r.sortLabel ?? DEFAULT_SHOP.sortLabel),
    emptyTitle: toBilingual(r.emptyTitle ?? DEFAULT_SHOP.emptyTitle),
    emptyDescription: toBilingual(r.emptyDescription ?? DEFAULT_SHOP.emptyDescription),
    loadMoreText: toBilingual(r.loadMoreText ?? DEFAULT_SHOP.loadMoreText),
  };
}

async function getShopContent(prisma: PrismaClient): Promise<ShopContent> {
  try {
    const setting = await prisma.siteSetting.findUnique({ where: { key: "page_shop" } });
    if (setting?.value) return normalizeShop(JSON.parse(setting.value));
  } catch { /* */ }
  return DEFAULT_SHOP;
}

export async function generateMetadata() {
  const { prisma } = await getPrismaForRequest();
  const c = await getShopContent(prisma);
  return {
    title: c.heroTitle.bn || c.heroTitle.en,
    description: c.heroSubtitle.bn || c.heroSubtitle.en,
  };
}

const PAGE_SIZE = 24;

// Tenant-keyed unstable_cache wrapper for initial product list.
function makeGetInitialProducts(prisma: PrismaClient, tenantId: number) {
  return unstable_cache(
    async (): Promise<{ products: Product[]; total: number }> => {
      const where = { isActive: true, deletedAt: null, AND: [inStockWhere] };
      const [rows, total] = await Promise.all([
        prisma.product.findMany({
          where,
          select: {
            id: true, name: true, slug: true, price: true, originalPrice: true,
            image: true, images: true, badge: true, badgeColor: true, weight: true,
            stock: true, unlimitedStock: true, soldCount: true, isActive: true,
            isFeatured: true, hasVariations: true, variationType: true,
            customShipping: true, shippingCost: true, sortOrder: true, createdAt: true,
            category: { select: { id: true, name: true, slug: true } },
            brand: { select: { id: true, name: true, slug: true } },
            variants: {
              where: { isActive: true },
              orderBy: { sortOrder: "asc" },
              select: { id: true, label: true, price: true, originalPrice: true, stock: true, unlimitedStock: true, image: true, sortOrder: true },
            },
          },
          orderBy: [{ sortOrder: "asc" }, { id: "desc" }],
          take: PAGE_SIZE,
        }),
        prisma.product.count({ where }),
      ]);
      return { products: rows.map((p) => mapApiProduct(serialize(p))), total };
    },
    [`t${tenantId}:shop-products-initial`],
    { tags: [`t${tenantId}:products`], revalidate: 60 }
  );
}

function makeGetCategories(prisma: PrismaClient, tenantId: number) {
  return unstable_cache(
    async (): Promise<{ id: number; name: string; slug: string }[]> =>
      prisma.category.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: "asc" },
        select: { id: true, name: true, slug: true },
      }),
    [`t${tenantId}:shop-categories`],
    { tags: [`t${tenantId}:categories`], revalidate: 300 }
  );
}

function makeGetBrands(prisma: PrismaClient, tenantId: number) {
  return unstable_cache(
    async (): Promise<{ id: number; name: string; slug: string }[]> =>
      prisma.brand.findMany({
        where: { isActive: true },
        orderBy: { name: "asc" },
        select: { id: true, name: true, slug: true },
      }),
    [`t${tenantId}:shop-brands`],
    { tags: [`t${tenantId}:brands`], revalidate: 300 }
  );
}

export default async function ShopPage() {
  const { prisma, tenant } = await getPrismaForRequest();
  let products: Product[] = [];
  let total = 0;
  let categories: { id: number; name: string; slug: string }[] = [];
  let brands: { id: number; name: string; slug: string }[] = [];

  try {
    const [productsResult, cats, brandRows] = await Promise.all([
      makeGetInitialProducts(prisma, tenant.id)(),
      makeGetCategories(prisma, tenant.id)(),
      makeGetBrands(prisma, tenant.id)(),
    ]);
    products = productsResult.products;
    total = productsResult.total;
    categories = cats;
    brands = brandRows;
  } catch {
    // DB unavailable at build time — revalidated on first request
  }

  const content = await getShopContent(prisma);
  const pageProps: ShopPageProps = {
    initialProducts: products,
    initialTotal: total,
    pageSize: PAGE_SIZE,
    apiCategories: categories,
    apiBrands: brands,
    content,
  };

  const theme = await getActiveTheme();
  if (theme.pages.loadShopPage) {
    let ActivePage: ComponentType<ShopPageProps> | null = null;
    try {
      ActivePage = await theme.pages.loadShopPage();
    } catch {
      ActivePage = null;
    }
    if (ActivePage) {
      return (
        <div className={`theme-${theme.id}`}>
          <ThemeErrorBoundary
            themeId={theme.id}
            fallback={(
              <ShopClient
                initialProducts={products}
                initialTotal={total}
                pageSize={PAGE_SIZE}
                apiCategories={categories}
                apiBrands={brands}
                content={content}
              />
            )}
          >
            <ActivePage {...pageProps} />
          </ThemeErrorBoundary>
        </div>
      );
    }
  }

  return (
    <Suspense fallback={null}>
      <ShopClient
        initialProducts={products}
        initialTotal={total}
        pageSize={PAGE_SIZE}
        apiCategories={categories}
        apiBrands={brands}
        content={content}
      />
    </Suspense>
  );
}
