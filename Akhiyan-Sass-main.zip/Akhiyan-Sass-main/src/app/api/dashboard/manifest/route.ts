import { NextResponse } from "next/server";

/**
 * GET /api/dashboard/manifest
 *
 * Returns the dashboard PWA manifest.
 *
 * IMPORTANT: served WITHOUT an auth gate. Browsers fetch <link rel="manifest">
 * with credentials OMITTED unless the link carries crossorigin="use-credentials"
 * — and Next's metadata `manifest` field can't set that attribute. So an
 * auth-gated endpoint always 404'd, even for logged-in staff (the manifest
 * request never carried the session cookie). The manifest content is
 * non-sensitive (app name + icons), and the <link> is only emitted for
 * staff/admin sessions in the dashboard layout, so customers never request it.
 */
export async function GET() {
  const manifest = {
    name: "CD Ecom Dashboard",
    short_name: "CD Ecom Admin",
    description: "Manage your CD Ecom store — orders, products, customers.",
    start_url: "/dashboard",
    scope: "/dashboard",
    display: "standalone",
    orientation: "any",
    background_color: "#ffffff",
    theme_color: "#000000",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "maskable" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    categories: ["business", "productivity"],
  };

  return NextResponse.json(manifest, {
    headers: {
      "Content-Type": "application/manifest+json",
      // Manifest can change per-user (role) — never let a CDN cache it
      "Cache-Control": "private, no-store",
    },
  });
}
