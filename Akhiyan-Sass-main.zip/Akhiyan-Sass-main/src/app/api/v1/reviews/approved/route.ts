import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse } from "@/lib/api-response";

export async function GET(req: Request) {
  const { prisma } = await getPrismaForRequest(req);
  const reviews = await prisma.review.findMany({
    where: { isApproved: true },
    orderBy: { createdAt: "desc" },
    take: 10,
    include: {
      product: { select: { name: true } },
    },
  });

  const result = reviews.map((r) => ({
    ...serialize(r),
    product_name: r.product?.name || "",
  }));

  return jsonResponse(result);
}
