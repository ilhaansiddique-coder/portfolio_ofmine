import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse } from "@/lib/api-response";

export async function GET(req: Request) {
  const { prisma } = await getPrismaForRequest(req);
  const posts = await prisma.blogPost.findMany({
    where: { isPublished: true },
    orderBy: { publishedAt: "desc" },
    include: { author: { select: { id: true, name: true } } },
  });

  return jsonResponse(posts.map(serialize));
}
