import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse, notFound } from "@/lib/api-response";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { prisma } = await getPrismaForRequest(request);
  const { slug } = await params;

  const post = await prisma.blogPost.findFirst({
    where: { slug, isPublished: true },
    include: { author: { select: { id: true, name: true } } },
  });

  if (!post) return notFound("Blog post not found");

  return jsonResponse(serialize(post));
}
