import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { jsonResponse, errorResponse, notFound } from "@/lib/api-response";
import { requireAdmin } from "@/lib/auth-helpers";
import { broadcastToTenant } from "@/lib/realtime";

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  // Admin-only: staff lost real captures by accidentally clicking the trash
  // icon. Locking deletion to admin keeps the abandonment data intact.
  try { await requireAdmin(); } catch (e) { return e as Response; }
  try {
    const { id } = await params;
    const idNum = Number(id);
    if (!idNum) return notFound("Invalid id");
    await prisma.incompleteOrder.delete({ where: { id: idNum } }).catch(() => null);
    broadcastToTenant(tenant.id, "incomplete_orders", "deleted", { id: idNum });
    return jsonResponse({ ok: true });
  } catch (e) {
    console.error("[IncompleteOrder] delete error:", e);
    return errorResponse("Failed", 500);
  }
}
