import { NextRequest } from "next/server";
import { revalidateAll } from "@/lib/revalidate";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { broadcastToTenant } from "@/lib/realtime";
import { serialize } from "@/lib/serialize";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { requireAdmin } from "@/lib/auth-helpers";
import { revalidateSettings } from "@/lib/settingsCache";
import { clearSmtpCache, clearEmailBrandCache } from "@/lib/email";
import { clearEmailTemplatesCache } from "@/lib/email-templates";

export async function GET(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const settings = await prisma.siteSetting.findMany();

  // Sensitive keys — mask in API response (write-only)
  const SENSITIVE_KEYS = new Set([
    "smtp_pass",
    "steadfast_api_key",
    "steadfast_secret_key",
    "fb_capi_access_token",
    "pathao_client_secret",
    "pathao_password",
    "pathao_access_token",
    "pathao_refresh_token",
    "pathao_web_token",
  ]);

  // Convert to key-value object, masking sensitive values
  const result: Record<string, string | null> = {};
  for (const setting of settings) {
    if (SENSITIVE_KEYS.has(setting.key) && setting.value) {
      // Mask with bullets matching the REAL value length so the admin can
      // see a long secret (e.g. a ~200-char FB CAPI token) is actually
      // stored, instead of a misleading fixed 8-dot stub. Value is still
      // write-only (never the plaintext). Capped so a pathological length
      // can't bloat the response.
      result[setting.key] = "•".repeat(Math.min(setting.value.length, 512));
    } else {
      result[setting.key] = setting.value;
    }
  }

  return jsonResponse(result);
}

export async function PUT(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  try {
    const body = await request.json();

    // Skip untouched masked secrets — the GET above returns the secret as a
    // bullet string whose LENGTH equals the real value, so the skip test
    // must match ANY all-bullets string, not just a fixed 8-dot one. If the
    // admin actually typed a new secret it won't be all bullets → saved.
    const incoming = Object.entries(body).filter(
      ([_, v]) => !(typeof v === "string" && v.length > 0 && /^•+$/.test(v)),
    );
    // BUG WAS HERE: the early-return below used to be unbraced — JS parsed it
    // as `if(...) broadcast(); return ...;` so the function ALWAYS bailed
    // out before doing the upsert. Every settings save (logo, theme, SMTP,
    // courier creds, everything) silently dropped on the floor. Braces now.
    if (incoming.length === 0) {
      return jsonResponse({ message: "Nothing to update" });
    }

    // Only upsert keys whose value actually changed — saves N round trips per save.
    const keys = incoming.map(([k]) => k);
    const existing = await prisma.siteSetting.findMany({
      where: { key: { in: keys } },
      select: { key: true, value: true },
    });
    const existingMap = new Map(existing.map((r) => [r.key, r.value]));

    const changed = incoming.filter(([k, v]) => existingMap.get(k) !== (v as string));
    if (changed.length === 0) {
      void broadcastToTenant(tenant.id, "settings", "changed", {}); /* @broadcast */ return jsonResponse({ message: "No changes" });
    }

    // Run upserts in parallel (no transaction needed — independent rows, idempotent).
    await Promise.all(
      changed.map(([key, value]) =>
        prisma.siteSetting.upsert({
          where: { key },
          update: { value: value as string },
          create: { key, value: value as string },
        })
      )
    );

    revalidateAll("settings");
    // Bust THIS tenant's settings cache. revalidateAll only busts the
    // generic "settings" tag; the settings cache is tagged per-tenant
    // (t<id>:settings), so without this the storefront serves stale
    // content (privacy/terms/refund/about/contact, theme tokens) until
    // the 60s fallback expires.
    revalidateSettings(tenant.id);
    clearSmtpCache(tenant.id);
    // Bust email brand cache so next email picks up new theme/lang/site_name.
    clearEmailBrandCache(tenant.id);
    // Bust email templates cache if the customizer was saved.
    if (changed.some(([k]) => k === "email_templates")) {
      clearEmailTemplatesCache(tenant.id);
    }
    void broadcastToTenant(tenant.id, "settings", "changed", {}); /* @broadcast */ return jsonResponse({ message: "Settings updated", changed: changed.length });
  } catch (error) {
    console.error("Settings PUT error:", error);
    return errorResponse("Failed to update settings", 500);
  }
}
