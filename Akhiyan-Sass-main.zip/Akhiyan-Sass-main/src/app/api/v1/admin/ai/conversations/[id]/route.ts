/**
 * GET    /api/v1/admin/ai/conversations/[id]   — conversation + all messages
 * DELETE /api/v1/admin/ai/conversations/[id]   — delete a session (cascade)
 *
 * Powers both the in-builder thread replay and the dashboard history
 * viewer. Returns every message in order, including the `appliedData`
 * (what the AI actually built) so the UI can show actions, not just text.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse, notFound } from "@/lib/api-response";
import { serialize } from "@/lib/serialize";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;

  const convo = await prisma.aiConversation.findUnique({
    where: { id: Number(id) },
    include: {
      messages: {
        orderBy: { createdAt: "asc" },
        select: {
          id: true, role: true, content: true, mode: true,
          appliedData: true, inputTokens: true, outputTokens: true, createdAt: true,
        },
      },
    },
  });
  if (!convo) return notFound("Conversation not found");
  return jsonResponse(serialize(convo));
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  try {
    await prisma.aiConversation.delete({ where: { id: Number(id) } });
    return jsonResponse({ success: true });
  } catch {
    return errorResponse("Failed to delete conversation", 500);
  }
}
