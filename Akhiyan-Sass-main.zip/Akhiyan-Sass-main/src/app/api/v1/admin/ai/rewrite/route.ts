/**
 * POST /api/v1/admin/ai/rewrite — stream a rewrite/improve/translate/etc.
 *
 * Body:
 *   {
 *     task: "improve" | "shorten" | "expand" | "translate" | "fix-grammar" | "generate",
 *     currentValue: string,
 *     fieldKey?: string,       // e.g. "site_name" — drives auto field-hint
 *     fieldHint?: string,      // override the auto hint
 *     targetLanguage?: string, // for translate
 *   }
 *
 * Response: text/plain stream of the rewrite. The client appends chunks
 * to the UI in real time.
 *
 * Auth: admin only, tenant resolved from host header.
 * Budget gate: refuses if the tenant has exceeded their monthly budget.
 * Usage logged AFTER the stream completes (in onFinish callback).
 */
import { NextRequest } from "next/server";
import { streamText } from "ai";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { errorResponse } from "@/lib/api-response";
import { getAiConfigInternal } from "@/lib/ai/config";
import { getBrief } from "@/lib/ai/brief";
import { resolveModel, computeCostUsd } from "@/lib/ai/provider";
import { isOverBudget, recordUsage } from "@/lib/ai/usage";
import { buildRewritePrompt, maxTokensForTask, type RewriteTask } from "@/lib/ai/prompt";

export const runtime = "nodejs";
export const maxDuration = 60; // streamText can run long for big rewrites

const VALID_TASKS: RewriteTask[] = [
  "improve", "shorten", "expand", "translate", "fix-grammar", "generate",
];

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));
  const task = body.task as RewriteTask;
  const currentValue = typeof body.currentValue === "string" ? body.currentValue : "";
  const fieldKey = typeof body.fieldKey === "string" ? body.fieldKey : undefined;
  const fieldHint = typeof body.fieldHint === "string" ? body.fieldHint : undefined;
  const targetLanguage = typeof body.targetLanguage === "string" ? body.targetLanguage : undefined;

  if (!VALID_TASKS.includes(task)) {
    return errorResponse(`task must be one of: ${VALID_TASKS.join(", ")}`, 400);
  }
  if (task !== "generate" && currentValue.trim().length === 0) {
    return errorResponse("currentValue is required for this task", 400);
  }
  if (currentValue.length > 20_000) {
    return errorResponse("currentValue too long (max 20,000 chars)", 413);
  }

  // Config + budget gate
  const cfg = await getAiConfigInternal(prisma);
  if (!cfg.active) {
    return errorResponse("AI is disabled for this tenant", 403);
  }
  if (await isOverBudget(prisma, cfg.monthlyBudgetUsd)) {
    return errorResponse(
      `Monthly AI budget reached ($${cfg.monthlyBudgetUsd}). Adjust in dashboard → AI Settings.`,
      429,
    );
  }

  // Resolve the provider/model (this throws if key is missing — surface as 400)
  let resolved;
  try {
    resolved = resolveModel({ provider: cfg.provider, apiKey: cfg.apiKey, model: cfg.model });
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "AI provider not configured", 400);
  }

  // Build prompt from brief + task
  const brief = await getBrief(prisma);
  const { system, user } = buildRewritePrompt({
    brief, task, currentValue, fieldKey, fieldHint, targetLanguage,
  });

  const started = Date.now();
  const result = streamText({
    model: resolved.model,
    system,
    prompt: user,
    temperature: task === "fix-grammar" ? 0.1 : 0.7,
    maxOutputTokens: maxTokensForTask(task, currentValue),
    onFinish: async ({ usage }) => {
      // Telemetry is best-effort. recordUsage swallows its own errors.
      const inputTokens = usage?.inputTokens ?? 0;
      const outputTokens = usage?.outputTokens ?? 0;
      const costUsd = computeCostUsd(resolved.modelId, inputTokens, outputTokens);
      await recordUsage(prisma, {
        surface: "rewrite",
        field: fieldKey ?? null,
        provider: resolved.provider,
        model: resolved.modelId,
        inputTokens,
        outputTokens,
        costUsd,
        durationMs: Date.now() - started,
        success: true,
      });
    },
  });

  // Return as a plain text stream — simplest for the client to consume.
  return result.toTextStreamResponse();
}
