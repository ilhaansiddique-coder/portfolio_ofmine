/**
 * GET    /api/v1/admin/ai/config — return current AI config (key MASKED)
 * PUT    /api/v1/admin/ai/config — update provider / key / model / budget
 *
 * Auth: requires admin on the calling tenant. Tenant context comes from the
 * resolved host header (never from request body), so tenant A admin can't
 * mutate tenant B's config.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { getAiConfigPublic, saveAiConfig, type AiProvider } from "@/lib/ai/config";
import { isEncryptionConfigured } from "@/lib/encryption";

export const runtime = "nodejs";

const VALID_PROVIDERS: AiProvider[] = ["platform", "openai", "anthropic", "google", "groq", "openrouter"];

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const cfg = await getAiConfigPublic(prisma);
  return jsonResponse(cfg);
}

export async function PUT(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  if (!isEncryptionConfigured()) {
    return errorResponse(
      "Server is missing AI_KEY_ENCRYPTION_SECRET env var. Ask the platform owner to configure it.",
      503,
    );
  }

  const body = await request.json().catch(() => ({}));

  // Validate provider
  const provider = body.provider as string | undefined;
  if (provider !== undefined && !VALID_PROVIDERS.includes(provider as AiProvider)) {
    return errorResponse(`provider must be one of: ${VALID_PROVIDERS.join(", ")}`, 400);
  }

  // Sanity-check model — must be a reasonable string. We don't enforce
  // against the MODEL_OPTIONS list because providers add new models often
  // and we don't want to require code changes for each one.
  const model = body.model as string | undefined;
  if (model !== undefined) {
    if (typeof model !== "string" || model.length === 0 || model.length > 100) {
      return errorResponse("model must be a non-empty string under 100 chars", 400);
    }
  }

  // Budget — optional number ≥ 0
  let monthlyBudgetUsd: number | null | undefined;
  if (body.monthlyBudgetUsd !== undefined) {
    if (body.monthlyBudgetUsd === null || body.monthlyBudgetUsd === "") {
      monthlyBudgetUsd = null;
    } else {
      const n = Number(body.monthlyBudgetUsd);
      if (!Number.isFinite(n) || n < 0) {
        return errorResponse("monthlyBudgetUsd must be a non-negative number or null", 400);
      }
      monthlyBudgetUsd = n;
    }
  }

  try {
    const updated = await saveAiConfig(prisma, {
      provider: provider as AiProvider | undefined,
      apiKey: typeof body.apiKey === "string" ? body.apiKey : undefined,
      model,
      imageModel: typeof body.imageModel === "string" ? body.imageModel : (body.imageModel === null ? null : undefined),
      monthlyBudgetUsd,
      active: typeof body.active === "boolean" ? body.active : undefined,
    });
    return jsonResponse(updated);
  } catch (err) {
    console.error("[ai-config] save failed:", err);
    const message = err instanceof Error ? err.message : "Failed to save AI config";
    return errorResponse(message, 500);
  }
}
