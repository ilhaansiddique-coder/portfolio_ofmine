/**
 * AI Site-Setup — generate / review / publish a tenant's draft site content.
 *
 *   POST   → generate selected artifacts from the Site Brief, stage as DRAFT.
 *            body: { include?: string[], facts?: SiteFacts }
 *            (writes NOTHING live — returns + stages the draft)
 *   GET    → read the current staged draft (for the review wizard).
 *   PUT    → publish approved draft keys.  body: { keys?: string[] }
 *   DELETE → discard the staged draft.
 *
 * Accuracy: AI output is schema-validated (runSiteSetup), facts are
 * pass-through, drafts are plain-text-sanitized at staging, and NOTHING goes
 * live without an explicit PUT (the human-approval gate).
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { revalidateAll } from "@/lib/revalidate";
import { getAiConfigInternal } from "@/lib/ai/config";
import { getBrief } from "@/lib/ai/brief";
import { resolveModel, computeCostUsd } from "@/lib/ai/provider";
import { isOverBudget, recordUsage } from "@/lib/ai/usage";
import { runSiteSetup, type SiteSetupArtifact, type SiteFacts } from "@/lib/ai/site-setup";
import {
  stageSiteSetupDraft,
  getSiteSetupDraft,
  updateSiteSetupDraft,
  publishSiteSetup,
  discardSiteSetupDraft,
} from "@/lib/ai/site-setup-store";
import type { PolicyContent } from "@/lib/ai/site-setup";

export const runtime = "nodejs";
export const maxDuration = 300; // several structured calls; can take minutes

const VALID_ARTIFACTS: SiteSetupArtifact[] = [
  "branding",
  "homepage",
  "page_about",
  "page_contact",
  "page_terms",
  "page_privacy",
  "page_refund",
];

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function pickFacts(raw: any): SiteFacts {
  const f: SiteFacts = {};
  for (const k of [
    "site_name", "phone", "whatsapp", "email", "address",
    "facebook", "instagram", "youtube",
  ] as const) {
    if (raw && typeof raw[k] === "string" && raw[k].trim()) f[k] = raw[k].trim();
  }
  return f;
}

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));
  const include: SiteSetupArtifact[] = Array.isArray(body.include)
    ? body.include.filter((x: unknown): x is SiteSetupArtifact =>
        typeof x === "string" && (VALID_ARTIFACTS as string[]).includes(x))
    : VALID_ARTIFACTS;
  if (include.length === 0) return errorResponse("no valid artifacts in `include`", 400);
  const facts = pickFacts(body.facts);

  const cfg = await getAiConfigInternal(prisma);
  if (!cfg.active) return errorResponse("AI is disabled for this tenant", 403);
  if (await isOverBudget(prisma, cfg.monthlyBudgetUsd)) {
    return errorResponse(`Monthly AI budget reached ($${cfg.monthlyBudgetUsd}).`, 429);
  }

  let resolved;
  try {
    resolved = resolveModel({ provider: cfg.provider, apiKey: cfg.apiKey, model: cfg.model });
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "AI provider not configured", 400);
  }

  const brief = await getBrief(prisma);
  const started = Date.now();
  let result;
  try {
    result = await runSiteSetup({ model: resolved.model, brief, facts, include });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    await recordUsage(prisma, {
      surface: "site_setup", field: null,
      provider: resolved.provider, model: resolved.modelId,
      inputTokens: 0, outputTokens: 0, costUsd: 0,
      durationMs: Date.now() - started, success: false,
      errorMessage: message.slice(0, 500),
    });
    return errorResponse(`Site-setup generation failed: ${message}`, 500);
  }

  const durationMs = Date.now() - started;
  const costUsd = computeCostUsd(
    resolved.modelId,
    result.usage.inputTokens,
    result.usage.outputTokens,
  );
  await recordUsage(prisma, {
    surface: "site_setup", field: null,
    provider: resolved.provider, model: resolved.modelId,
    inputTokens: result.usage.inputTokens,
    outputTokens: result.usage.outputTokens,
    costUsd, durationMs, success: true,
  });

  const manifest = await stageSiteSetupDraft(prisma, result);

  return jsonResponse({
    staged: true,
    manifest,
    settings: result.settings,
    pages: result.pages,
    warnings: result.warnings,
    costUsd,
    inputTokens: result.usage.inputTokens,
    outputTokens: result.usage.outputTokens,
  }, 201);
}

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }
  const draft = await getSiteSetupDraft(prisma);
  return jsonResponse(draft);
}

export async function PATCH(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));
  const settings: Record<string, string> | undefined =
    body.settings && typeof body.settings === "object" ? body.settings : undefined;
  const pages: Record<string, PolicyContent> | undefined =
    body.pages && typeof body.pages === "object" ? body.pages : undefined;
  const homepage =
    body.homepage && typeof body.homepage === "object" ? body.homepage : undefined;
  if (!settings && !pages && !homepage) return errorResponse("nothing to update", 400);

  const { updated } = await updateSiteSetupDraft(prisma, { settings, pages, homepage });
  if (updated.length === 0) {
    return errorResponse("no matching draft keys to update", 400);
  }
  return jsonResponse({ updated });
}

export async function PUT(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));
  const keys: string[] | undefined = Array.isArray(body.keys)
    ? body.keys.filter((k: unknown): k is string => typeof k === "string")
    : undefined;

  const { published } = await publishSiteSetup(prisma, { keys });
  if (published.length === 0) {
    return errorResponse("nothing to publish (no matching draft keys)", 400);
  }

  // Public pages read these via the tenant-scoped settings cache.
  revalidateAll(`t${tenant.id}:settings`);

  return jsonResponse({ published });
}

export async function DELETE(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }
  await discardSiteSetupDraft(prisma);
  return jsonResponse({ discarded: true });
}
