/**
 * POST /api/v1/admin/ai/test — fire a tiny "say hi" call to validate the
 * stored API key + model. Returns { ok, output, durationMs, error? }.
 *
 * Costs almost nothing (~10 tokens). Counts toward usage so the tenant can
 * see test calls in their usage history.
 *
 * If the request body includes `{ apiKey, provider, model }` we use those
 * EPHEMERALLY without persisting — lets the UI "Test" button validate a
 * key BEFORE the user clicks Save.
 */
import { NextRequest } from "next/server";
import { generateText } from "ai";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { getAiConfigInternal, type AiProvider } from "@/lib/ai/config";
import { resolveModel, computeCostUsd } from "@/lib/ai/provider";
import { recordUsage } from "@/lib/ai/usage";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  // Either use override creds from the request body (UI "Test before save"
  // flow) or load the persisted config.
  const body = await request.json().catch(() => ({}));

  let provider: AiProvider;
  let apiKey: string | null;
  let model: string;

  // Load stored config as baseline
  let cfg;
  try {
    cfg = await getAiConfigInternal(prisma);
  } catch (e) {
    console.error("[ai-test] failed to load config:", e);
    cfg = { provider: "openai" as AiProvider, apiKey: null, model: "gpt-4o-mini" };
  }

  // Body overrides take precedence over stored values
  provider = (typeof body?.provider === "string" && body.provider) ? (body.provider as AiProvider) : cfg.provider;
  model = (typeof body?.model === "string" && body.model.length > 0) ? body.model : cfg.model;
  // For apiKey: explicit body key > stored key
  apiKey = (typeof body?.apiKey === "string" && body.apiKey.length > 0) ? body.apiKey : cfg.apiKey;

  if (!apiKey) {
    return jsonResponse(
      {
        ok: false,
        error: "No API key available. Either save your key first (the stored key may have failed to decrypt — try re-entering it), or add a platform key in the server environment.",
        provider,
        model,
      },
      400,
    );
  }

  let resolved;
  try {
    resolved = resolveModel({ provider, apiKey, model });
  } catch (e) {
    return jsonResponse(
      { ok: false, error: e instanceof Error ? e.message : "Provider setup failed", provider, model },
      400,
    );
  }

  const started = Date.now();
  try {
    // Tiny prompt — should round-trip in < 1s on most providers.
    const result = await generateText({
      model: resolved.model,
      prompt: "Reply with the single word: ready",
      // Cap aggressively — we just want a heartbeat
      maxOutputTokens: 10,
      temperature: 0,
    });

    const durationMs = Date.now() - started;
    const inputTokens = result.usage?.inputTokens ?? 0;
    const outputTokens = result.usage?.outputTokens ?? 0;
    const costUsd = computeCostUsd(resolved.modelId, inputTokens, outputTokens);

    // Record usage. For ephemeral test (override) we still log — useful audit trail.
    await recordUsage(prisma, {
      surface: "test",
      field: null,
      provider: resolved.provider,
      model: resolved.modelId,
      inputTokens,
      outputTokens,
      costUsd,
      durationMs,
      success: true,
    });

    return jsonResponse({
      ok: true,
      provider: resolved.provider,
      model: resolved.modelId,
      output: result.text,
      durationMs,
      inputTokens,
      outputTokens,
      costUsd,
      isPlatformKey: resolved.isPlatformKey,
    });
  } catch (err) {
    const durationMs = Date.now() - started;
    const message = err instanceof Error ? err.message : String(err);

    await recordUsage(prisma, {
      surface: "test",
      field: null,
      provider: resolved.provider,
      model: resolved.modelId,
      inputTokens: 0,
      outputTokens: 0,
      costUsd: 0,
      durationMs,
      success: false,
      errorMessage: message.slice(0, 500),
    });

    return jsonResponse(
      { ok: false, provider: resolved.provider, model: resolved.modelId, error: message, durationMs },
      400,
    );
  }
}
