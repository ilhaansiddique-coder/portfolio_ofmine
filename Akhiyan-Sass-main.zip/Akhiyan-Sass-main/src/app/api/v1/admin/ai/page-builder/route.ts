/**
 * POST /api/v1/admin/ai/page-builder — AI page-builder assistant.
 *
 * Body:
 *   {
 *     mode: "generate" | "section" | "edit",
 *     prompt: string,
 *     // edit mode only — the currently-selected element:
 *     selectedType?: string,
 *     selectedProps?: Record<string, unknown>,
 *   }
 *
 * Returns (JSON):
 *   generate → { mode:"generate", data: PuckData }       // full page tree
 *   section  → { mode:"section",  item: PuckItem }        // one Container
 *   edit     → { mode:"edit",     props: Record<…> }      // prop patch
 *
 * Reuses the existing AI infra: tenant config, budget gate, provider
 * resolution, structured generation with graceful fallback, usage log.
 * Auth: admin only, tenant from host header.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { getAiConfigInternal } from "@/lib/ai/config";
import { getBrief, briefToSystemPrompt } from "@/lib/ai/brief";
import { resolveModel, computeCostUsd } from "@/lib/ai/provider";
import { isOverBudget, recordUsage } from "@/lib/ai/usage";
import { generateStructured } from "@/lib/ai/structured";
import {
  AiPageSchema, AiSectionSchema, AiEditSchema,
  hydratePage, hydrateContainer,
} from "@/lib/ai/page-builder";

export const runtime = "nodejs";
export const maxDuration = 300;

type Mode = "generate" | "section" | "edit";
const VALID: Mode[] = ["generate", "section", "edit"];

const WIDGET_GUIDE = `
You build pages out of these blocks ONLY:
- Container: a section/row. props: direction ("row"|"column"), bgColor (hex), and "children".
  A Container's children may be leaf widgets OR nested Containers (use nested
  row-Containers as COLUMNS to place items side by side).
- Heading: { text, level (h1..h6), align }
- Paragraph: { text, align }   (single plain paragraph)
- RichText: { html }   (formatted multi-paragraph content: <p>, <ul>/<li>, <strong>, <em>, <a>. Use for body copy with structure.)
- Button: { label, href, variant ("solid"|"outline"), align }
- Image: { src, alt }   (leave src empty if no real URL)
- Spacer: { height (px number) }
- Divider: {}

Rules:
- A page is an ordered list of top-level Containers (sections).
- For multi-column layouts: a row-Container whose children are column-Containers.
- Keep copy realistic and on-brand. Never invent image URLs — leave src empty.
- Do NOT output ids, styling beyond what's listed, or any other block types.
`.trim();

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));
  const mode = body.mode as Mode;
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";

  if (!VALID.includes(mode)) {
    return errorResponse(`mode must be one of: ${VALID.join(", ")}`, 400);
  }
  if (!prompt) return errorResponse("prompt is required", 400);
  if (prompt.length > 4000) return errorResponse("prompt too long (max 4000 chars)", 413);

  // Config + budget gate
  const cfg = await getAiConfigInternal(prisma);
  if (!cfg.active) return errorResponse("AI is disabled for this tenant", 403);
  if (await isOverBudget(prisma, cfg.monthlyBudgetUsd)) {
    return errorResponse(
      `Monthly AI budget reached. Adjust in dashboard → AI Settings.`,
      429,
    );
  }

  // Optional per-request model override from the builder's model picker.
  // Provider/key stay as configured; only the model id changes. This lets the
  // user switch models (e.g. dodge an overloaded one) without touching settings.
  const overrideModel =
    typeof body.model === "string" && body.model.trim()
      ? body.model.trim().slice(0, 100)
      : null;

  let resolved;
  try {
    resolved = resolveModel({ provider: cfg.provider, apiKey: cfg.apiKey, model: overrideModel || cfg.model });
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "AI provider not configured", 400);
  }

  const brief = await getBrief(prisma);
  const brandSystem = briefToSystemPrompt(brief);
  const system = [brandSystem, WIDGET_GUIDE].filter(Boolean).join("\n\n");

  // Optional conversation context for history. If no id is given we
  // lazily create a session titled from the first prompt.
  const incomingConvoId = Number.isFinite(Number(body.conversationId)) ? Number(body.conversationId) : null;
  const pageId = Number.isFinite(Number(body.pageId)) ? Number(body.pageId) : null;

  const started = Date.now();
  try {
    // payload = what we return to the client; applied = what gets stored
    // as the assistant's "what was built" in history.
    let payload: Record<string, unknown>;
    let applied: unknown;
    let summary: string;
    let usage: { inputTokens: number; outputTokens: number };

    if (mode === "generate") {
      const r = await generateStructured({
        model: resolved.model, schema: AiPageSchema, system,
        prompt: `Build a full page. User request:\n${prompt}`, temperature: 0.6,
        maxOutputTokens: 4000,
      });
      usage = r.usage;
      const data = hydratePage(r.object);
      payload = { mode, data };
      applied = data;
      summary = `Generated a page with ${r.object.sections?.length ?? 0} section(s).`;
    } else if (mode === "section") {
      const r = await generateStructured({
        model: resolved.model, schema: AiSectionSchema, system,
        prompt: `Build ONE section (a single Container). User request:\n${prompt}`, temperature: 0.6,
        maxOutputTokens: 1800,
      });
      usage = r.usage;
      const item = hydrateContainer(r.object);
      payload = { mode, item };
      applied = item;
      summary = `Added a section.`;
    } else {
      const selType = typeof body.selectedType === "string" ? body.selectedType : "";
      const selProps = (body.selectedProps && typeof body.selectedProps === "object") ? body.selectedProps : {};
      if (!selType) return errorResponse("edit mode requires a selected element", 400);
      // Edit just patches one element's props — the full widget catalogue and
      // brand brief are irrelevant here, so use a minimal system prompt to save
      // input tokens, and cap output small (a patch is tiny).
      const editSystem =
        "You edit the props of a single page-builder element. " +
        "Return ONLY the props that should change as JSON — never the whole element.";
      const r = await generateStructured({
        model: resolved.model, schema: AiEditSchema, system: editSystem,
        prompt:
          `Edit the props of the selected "${selType}" element.\n` +
          `Current props:\n${JSON.stringify(selProps)}\n\n` +
          `User request:\n${prompt}\n\n` +
          `Return ONLY the props that should change (a partial patch). ` +
          `Use the same prop keys/value types as the current props.`,
        temperature: 0.3,
        maxOutputTokens: 600,
      });
      usage = r.usage;
      payload = { mode, props: r.object.props };
      applied = r.object.props;
      summary = `Updated the selected ${selType}.`;
    }

    await logOk(prisma, resolved, usage, started, mode);
    const conversationId = await logConversation(prisma, {
      conversationId: incomingConvoId, pageId, mode, prompt, summary, applied, usage,
    });

    return jsonResponse({ ...payload, conversationId });
  } catch (e) {
    await recordUsage(prisma, {
      surface: "page_builder",
      field: mode,
      provider: resolved.provider,
      model: resolved.modelId,
      inputTokens: 0,
      outputTokens: 0,
      costUsd: 0,
      durationMs: Date.now() - started,
      success: false,
    }).catch(() => {});
    console.error("[ai/page-builder] error:", e);
    return errorResponse(e instanceof Error ? e.message : "AI generation failed", 500);
  }
}

/** Persist the user prompt + assistant result as conversation messages.
 * Creates the conversation on first message. Best-effort — never throws
 * into the request path. Returns the conversation id (or null on failure). */
async function logConversation(
  prisma: Awaited<ReturnType<typeof getPrismaForRequest>>["prisma"],
  args: {
    conversationId: number | null;
    pageId: number | null;
    mode: Mode;
    prompt: string;
    summary: string;
    applied: unknown;
    usage: { inputTokens: number; outputTokens: number };
  },
): Promise<number | null> {
  try {
    let convoId = args.conversationId;
    if (!convoId) {
      const created = await prisma.aiConversation.create({
        data: {
          title: args.prompt.slice(0, 80) || "New conversation",
          pageId: args.pageId,
        },
        select: { id: true },
      });
      convoId = created.id;
    } else {
      await prisma.aiConversation.update({ where: { id: convoId }, data: { updatedAt: new Date() } });
    }
    await prisma.aiMessage.createMany({
      data: [
        { conversationId: convoId, role: "user", content: args.prompt, mode: args.mode },
        {
          conversationId: convoId, role: "assistant", content: args.summary, mode: args.mode,
          appliedData: args.applied as object,
          inputTokens: args.usage.inputTokens, outputTokens: args.usage.outputTokens,
        },
      ],
    });
    return convoId;
  } catch (e) {
    console.error("[ai/page-builder] conversation log failed:", e);
    return args.conversationId;
  }
}

async function logOk(
  prisma: Parameters<typeof recordUsage>[0],
  resolved: { provider: string; modelId: string },
  usage: { inputTokens: number; outputTokens: number },
  started: number,
  field: string,
) {
  await recordUsage(prisma, {
    surface: "page_builder",
    field,
    provider: resolved.provider,
    model: resolved.modelId,
    inputTokens: usage.inputTokens,
    outputTokens: usage.outputTokens,
    costUsd: computeCostUsd(resolved.modelId, usage.inputTokens, usage.outputTokens),
    durationMs: Date.now() - started,
    success: true,
  }).catch(() => {});
}
