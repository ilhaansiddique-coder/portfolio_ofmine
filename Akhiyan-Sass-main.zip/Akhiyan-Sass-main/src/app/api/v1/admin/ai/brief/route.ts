/**
 * GET /api/v1/admin/ai/brief — return current Site Brief (or defaults)
 * PUT /api/v1/admin/ai/brief — upsert. Partial updates allowed.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { getBrief, saveBrief, type SiteBriefData } from "@/lib/ai/brief";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  return jsonResponse(await getBrief(prisma));
}

export async function PUT(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));

  // Normalise array fields — accept either string[] or comma-separated string
  const arr = (v: unknown): string[] | undefined => {
    if (v === undefined) return undefined;
    if (Array.isArray(v)) return v.map((s) => String(s).trim()).filter(Boolean);
    if (typeof v === "string") return v.split(",").map((s) => s.trim()).filter(Boolean);
    return [];
  };

  const update: Partial<SiteBriefData> = {
    businessName:      typeof body.businessName === "string" ? body.businessName : undefined,
    oneLiner:          typeof body.oneLiner === "string" ? body.oneLiner : undefined,
    longDescription:   typeof body.longDescription === "string" ? body.longDescription : undefined,
    targetAudience:    typeof body.targetAudience === "string" ? body.targetAudience : undefined,
    tone:              typeof body.tone === "string" ? body.tone : undefined,
    productCategories: arr(body.productCategories),
    locations:         arr(body.locations),
    uniqueSelling:     arr(body.uniqueSelling),
    doNotUse:          arr(body.doNotUse),
    exampleParagraph:  typeof body.exampleParagraph === "string" ? body.exampleParagraph : undefined,
    languages:         arr(body.languages),
    primaryLanguage:   typeof body.primaryLanguage === "string" ? body.primaryLanguage : undefined,
    competitors:       arr(body.competitors),
  };

  // Strip undefined so the merge in saveBrief() honors them as "no change"
  for (const k of Object.keys(update) as Array<keyof typeof update>) {
    if (update[k] === undefined) delete update[k];
  }

  try {
    const saved = await saveBrief(prisma, update);
    return jsonResponse(saved);
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "Save failed", 400);
  }
}
