/**
 * GET  /api/v1/admin/ai/conversations            — list sessions (newest first)
 * POST /api/v1/admin/ai/conversations            — create a new session
 *
 * Backs the AI page-builder chat history. Each conversation groups the
 * back-and-forth messages so the admin can reopen any session later and
 * see what was discussed + built.
 *
 * Auth: admin only, tenant DB resolved from host header.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { serialize } from "@/lib/serialize";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const url = new URL(request.url);
  const pageId = url.searchParams.get("pageId");

  const rows = await prisma.aiConversation.findMany({
    where: pageId ? { pageId: Number(pageId) } : undefined,
    orderBy: { updatedAt: "desc" },
    take: 100,
    select: {
      id: true,
      title: true,
      pageId: true,
      createdAt: true,
      updatedAt: true,
      _count: { select: { messages: true } },
    },
  });
  return jsonResponse(serialize(rows.map((r) => ({
    id: r.id,
    title: r.title,
    pageId: r.pageId,
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
    messageCount: r._count.messages,
  }))));
}

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const body = await request.json().catch(() => ({}));
  const title = typeof body.title === "string" && body.title.trim() ? body.title.trim().slice(0, 120) : "New conversation";
  const pageId = Number.isFinite(Number(body.pageId)) ? Number(body.pageId) : null;

  const convo = await prisma.aiConversation.create({
    data: { title, pageId },
    select: { id: true, title: true, pageId: true, createdAt: true, updatedAt: true },
  });
  return jsonResponse(serialize({ ...convo, messageCount: 0 }));
}
