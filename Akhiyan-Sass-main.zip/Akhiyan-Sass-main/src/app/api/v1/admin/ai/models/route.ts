/**
 * GET /api/v1/admin/ai/models?provider=openai&apiKey=sk-...
 *
 * Fetches available models from the provider's API dynamically.
 * If an apiKey is provided in the query, uses it ephemerally (never stored).
 * Otherwise falls back to:
 *   1. The tenant's saved key (decrypted)
 *   2. The platform key from env
 *
 * Returns { models: [{ id, label, vision }] } — same shape as MODEL_OPTIONS.
 * On failure (bad key, network), falls back to the hardcoded MODEL_OPTIONS.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse } from "@/lib/api-response";
import { getAiConfigInternal, type AiProvider } from "@/lib/ai/config";
import { MODEL_OPTIONS } from "@/lib/ai/provider";

export const runtime = "nodejs";
export const maxDuration = 15;

const VALID_PROVIDERS = new Set(["openai", "anthropic", "google", "groq", "openrouter"]);

interface ModelEntry {
  id: string;
  label: string;
  vision: boolean;
}

// ── Provider-specific model fetchers ─────────────────────────────────────────

async function fetchOpenAiModels(apiKey: string): Promise<ModelEntry[]> {
  const res = await fetch("https://api.openai.com/v1/models", {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) throw new Error(`OpenAI API ${res.status}`);
  const data = await res.json();
  const models: Array<{ id: string; owned_by?: string }> = data.data ?? [];

  // Filter to chat models (gpt-*) and sort
  const chat = models
    .filter((m) => /^(gpt-|o[1-9]|chatgpt)/.test(m.id))
    .filter((m) => !m.id.includes("instruct") && !m.id.includes("realtime") && !m.id.includes("audio"))
    .sort((a, b) => a.id.localeCompare(b.id));

  return chat.map((m) => ({
    id: m.id,
    label: m.id,
    vision: /4o|4\.1|4\.5|o[1-9]/.test(m.id),
  }));
}

async function fetchAnthropicModels(apiKey: string): Promise<ModelEntry[]> {
  const res = await fetch("https://api.anthropic.com/v1/models", {
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
  });
  if (!res.ok) throw new Error(`Anthropic API ${res.status}`);
  const data = await res.json();
  const models: Array<{ id: string; display_name?: string }> = data.data ?? [];

  return models
    .sort((a, b) => a.id.localeCompare(b.id))
    .map((m) => ({
      id: m.id,
      label: m.display_name || m.id,
      vision: true, // all Claude 3+ support vision
    }));
}

async function fetchGoogleModels(apiKey: string): Promise<ModelEntry[]> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`,
  );
  if (!res.ok) throw new Error(`Google API ${res.status}`);
  const data = await res.json();
  const models: Array<{ name: string; displayName?: string; supportedGenerationMethods?: string[] }> =
    data.models ?? [];

  // Filter to models that support generateContent (chat)
  const chat = models.filter((m) =>
    m.supportedGenerationMethods?.includes("generateContent"),
  );

  return chat
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((m) => {
      const id = m.name.replace(/^models\//, "");
      return {
        id,
        label: m.displayName || id,
        vision: /gemini/.test(id), // all Gemini models support vision
      };
    });
}

async function fetchGroqModels(apiKey: string): Promise<ModelEntry[]> {
  const res = await fetch("https://api.groq.com/openai/v1/models", {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) throw new Error(`Groq API ${res.status}`);
  const data = await res.json();
  const models: Array<{ id: string; owned_by?: string }> = data.data ?? [];

  return models
    .filter((m) => !m.id.includes("whisper") && !m.id.includes("tts") && !m.id.includes("guard"))
    .sort((a, b) => a.id.localeCompare(b.id))
    .map((m) => ({
      id: m.id,
      label: m.id,
      vision: /vision|llava/.test(m.id),
    }));
}

async function fetchOpenRouterModels(apiKey: string): Promise<ModelEntry[]> {
  // OpenRouter's model catalog is public; the key is optional here but we send
  // it when present so per-account model access is reflected.
  const res = await fetch("https://openrouter.ai/api/v1/models", {
    headers: apiKey ? { Authorization: `Bearer ${apiKey}` } : {},
  });
  if (!res.ok) throw new Error(`OpenRouter API ${res.status}`);
  const data = await res.json();
  const models: Array<{
    id: string;
    name?: string;
    architecture?: { input_modalities?: string[]; modality?: string };
  }> = data.data ?? [];

  return models
    .sort((a, b) => a.id.localeCompare(b.id))
    .map((m) => {
      const mods = m.architecture?.input_modalities ?? [];
      const vision = mods.includes("image") || /vision|vl|gpt-4o|gemini|claude/i.test(m.id);
      return { id: m.id, label: m.name || m.id, vision };
    });
}

// ── Route handler ────────────────────────────────────────────────────────────

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const url = new URL(request.url);
  const provider = (url.searchParams.get("provider") || "openai") as AiProvider;
  const ephemeralKey = url.searchParams.get("apiKey") || null;

  if (provider === "platform" || !VALID_PROVIDERS.has(provider)) {
    return jsonResponse({ models: [], fallback: true });
  }

  // Resolve key: ephemeral > saved > platform env
  let apiKey = ephemeralKey;
  if (!apiKey) {
    try {
      const cfg = await getAiConfigInternal(prisma);
      if (cfg.provider === provider && cfg.apiKey) {
        apiKey = cfg.apiKey;
      }
    } catch { /* ignore */ }
  }
  if (!apiKey) {
    // Try platform key
    const envMap: Record<string, string | undefined> = {
      openai: process.env.OPENAI_API_KEY,
      anthropic: process.env.ANTHROPIC_API_KEY,
      google: process.env.GOOGLE_GENERATIVE_AI_API_KEY,
      groq: process.env.GROQ_API_KEY,
      openrouter: process.env.OPENROUTER_API_KEY,
    };
    apiKey = envMap[provider] || null;
  }

  // OpenRouter's catalog is public, so we can list models even without a key.
  if (!apiKey && provider !== "openrouter") {
    // No key at all — return hardcoded fallback
    return jsonResponse({
      models: MODEL_OPTIONS[provider] ?? [],
      fallback: true,
      reason: "no_key",
    });
  }

  // Fetch dynamically
  try {
    const fetchers: Record<string, (k: string) => Promise<ModelEntry[]>> = {
      openai: fetchOpenAiModels,
      anthropic: fetchAnthropicModels,
      google: fetchGoogleModels,
      groq: fetchGroqModels,
      openrouter: fetchOpenRouterModels,
    };
    const models = await fetchers[provider](apiKey ?? "");
    return jsonResponse({ models, fallback: false });
  } catch (err) {
    // On API failure, fall back to hardcoded
    return jsonResponse({
      models: MODEL_OPTIONS[provider] ?? [],
      fallback: true,
      reason: err instanceof Error ? err.message : "fetch_failed",
    });
  }
}
