/**
 * GET /api/v1/admin/ai/usage — aggregated AI spend + recent calls.
 *
 * Query params:
 *   from — ISO date, inclusive (default: start of this UTC month)
 *   to   — ISO date, inclusive (default: now)
 *   limit — max recent rows to return (default 50, max 200)
 *
 * Returns:
 *   {
 *     summary: { totalCalls, successfulCalls, failedCalls, inputTokens,
 *                outputTokens, totalCostUsd, bySurface: [...] },
 *     budgetUsd: number | null,
 *     spentThisMonth: number,   // separate from `from..to` so the budget
 *                               // bar is always month-to-date
 *     recent: AiUsage[]         // most recent N rows
 *   }
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { usageSummary, currentMonthSpend } from "@/lib/ai/usage";
import { getAiConfigInternal } from "@/lib/ai/config";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const url = new URL(request.url);
  const fromParam = url.searchParams.get("from");
  const toParam = url.searchParams.get("to");
  const limit = Math.min(200, Math.max(1, Number(url.searchParams.get("limit") || "50")));

  let from: Date | undefined;
  let to: Date | undefined;
  if (fromParam) {
    const d = new Date(fromParam);
    if (Number.isNaN(d.getTime())) return errorResponse("invalid 'from' date", 400);
    from = d;
  }
  if (toParam) {
    const d = new Date(toParam);
    if (Number.isNaN(d.getTime())) return errorResponse("invalid 'to' date", 400);
    to = d;
  }

  const [summary, spentThisMonth, cfg, recent] = await Promise.all([
    usageSummary(prisma, { from, to }),
    currentMonthSpend(prisma),
    getAiConfigInternal(prisma),
    prisma.aiUsage.findMany({
      orderBy: { createdAt: "desc" },
      take: limit,
      select: {
        id: true,
        surface: true,
        field: true,
        provider: true,
        model: true,
        inputTokens: true,
        outputTokens: true,
        costUsd: true,
        durationMs: true,
        success: true,
        errorMessage: true,
        createdAt: true,
      },
    }),
  ]);

  return jsonResponse({
    summary,
    budgetUsd: cfg.monthlyBudgetUsd,
    spentThisMonth,
    recent: recent.map((r) => ({ ...r, costUsd: Number(r.costUsd) })),
  });
}
