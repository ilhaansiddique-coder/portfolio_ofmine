import { NextRequest } from "next/server";
import { readdir, stat, unlink } from "fs/promises";
import path from "path";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { getUploadDir } from "@/lib/uploads";
import { isR2Configured, r2List, r2Delete, r2PublicUrl, r2ListFromBucket, r2DeleteFromBucket, tenantPrefix, assertTenantKey } from "@/lib/r2";
import { getPrismaForRequest } from "@/lib/prisma-tenant";

const IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".avif", ".bmp", ".ico"];
const VIDEO_EXTS = [".mp4", ".webm", ".mov", ".avi", ".mkv", ".m4v"];
const AUDIO_EXTS = [".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac", ".opus", ".weba"];

type MediaType = "image" | "video" | "audio" | "file";

function classify(key: string): MediaType {
  const ext = path.extname(key).toLowerCase();
  if (IMAGE_EXTS.includes(ext)) return "image";
  if (VIDEO_EXTS.includes(ext)) return "video";
  if (AUDIO_EXTS.includes(ext)) return "audio";
  return "file";
}

/**
 * Build a media item. `includeAll` controls scope:
 *   - false (default): only image/video (back-compat — the page-builder picker
 *     MediaGallery expects this shape and renders only those two types).
 *   - true (?scope=library): every file, typed image | video | audio | file —
 *     used by the dashboard Media library page.
 */
function toMediaItem(key: string, publicBase: string, size: number, modified: string, includeAll: boolean) {
  const type = classify(key);
  if (!includeAll && type !== "image" && type !== "video") return null;
  return {
    filename: key,
    url: `${publicBase.replace(/\/$/, "")}/${key}`,
    size,
    type,
    modified,
  };
}

/**
 * GET /api/v1/admin/media — List all uploaded files.
 * Priority: dedicated R2 bucket → shared R2 bucket → local disk.
 */
export async function GET(request: NextRequest) {
  const { tenant } = await getPrismaForRequest(request);
  try { await requireStaff(); } catch (e) { return e as Response; }

  // ?scope=library → full media library (all file types). Default → image/video
  // only, preserving the shape the page-builder picker (MediaGallery) expects.
  const includeAll = new URL(request.url).searchParams.get("scope") === "library";

  try {
    // 1. Dedicated per-tenant R2 bucket
    if (tenant.r2Bucket && tenant.r2PublicUrl) {
      const objects = await r2ListFromBucket(tenant.r2Bucket);
      const media = objects
        .map((o) => toMediaItem(o.key, tenant.r2PublicUrl!, o.size, o.modified, includeAll))
        .filter(Boolean)
        .sort((a, b) => new Date(b!.modified).getTime() - new Date(a!.modified).getTime());
      return jsonResponse(media);
    }

    // 2. Shared R2 bucket with tenant prefix (legacy)
    if (isR2Configured()) {
      const objects = await r2List(tenantPrefix(tenant.id));
      const media = objects
        .map((o) => {
          const type = classify(o.key);
          if (!includeAll && type !== "image" && type !== "video") return null;
          return { filename: o.key, url: r2PublicUrl(o.key), size: o.size, type, modified: o.modified };
        })
        .filter(Boolean)
        .sort((a, b) => new Date(b!.modified).getTime() - new Date(a!.modified).getTime());
      return jsonResponse(media);
    }

    // 3. Local disk fallback
    const tenantDir = `tenant_${tenant.id}`;
    const uploadsDir = path.join(getUploadDir(), tenantDir);
    const files = await readdir(uploadsDir).catch(() => []);

    const media = await Promise.all(
      files
        .filter((f) => !f.startsWith("."))
        .map(async (filename) => {
          try {
            const filePath = path.join(uploadsDir, filename);
            const stats = await stat(filePath);
            const type = classify(filename);
            if (!includeAll && type !== "image" && type !== "video") return null;
            return {
              filename,
              url: `/uploads/${tenantDir}/${filename}`,
              size: stats.size,
              type,
              modified: stats.mtime.toISOString(),
            };
          } catch {
            return null;
          }
        })
    );

    const sorted = media
      .filter(Boolean)
      .sort((a, b) => new Date(b!.modified).getTime() - new Date(a!.modified).getTime());

    return jsonResponse(sorted);
  } catch (err) {
    console.error("[media GET] error:", err);
    return errorResponse("Failed to list media", 500);
  }
}

/**
 * DELETE /api/v1/admin/media — Delete an uploaded file.
 * Priority: dedicated R2 bucket → shared R2 bucket → local disk.
 */
export async function DELETE(request: NextRequest) {
  const { tenant } = await getPrismaForRequest(request);
  try { await requireStaff(); } catch (e) { return e as Response; }

  try {
    const { filename } = await request.json();
    if (!filename || typeof filename !== "string") {
      return errorResponse("Filename required", 400);
    }

    // 1. Dedicated bucket — key is bare (no tenant prefix)
    if (tenant.r2Bucket && tenant.r2PublicUrl) {
      const key = path.basename(filename);
      const ok = await r2DeleteFromBucket(tenant.r2Bucket, key);
      if (!ok) return errorResponse("Failed to delete file", 500);
      return jsonResponse({ message: "File deleted" });
    }

    // 2. Shared bucket — enforce tenant prefix
    if (isR2Configured()) {
      const raw = filename.replace(/^\/+/, "").replace(/^uploads\//, "");
      let key: string;
      try {
        key = assertTenantKey(tenant.id, raw);
      } catch {
        return errorResponse("Forbidden", 403);
      }
      const ok = await r2Delete(key);
      if (!ok) return errorResponse("Failed to delete file", 500);
      return jsonResponse({ message: "File deleted" });
    }

    // 3. Local fallback
    const safeName = path.basename(filename);
    const filePath = path.join(getUploadDir(), `tenant_${tenant.id}`, safeName);
    await unlink(filePath);
    return jsonResponse({ message: "File deleted" });
  } catch {
    return errorResponse("Failed to delete file", 500);
  }
}
