import { NextRequest } from "next/server";
import { revalidateAll } from "@/lib/revalidate";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { broadcastToTenant } from "@/lib/realtime";
import { serialize } from "@/lib/serialize";
import { jsonResponse, validationError, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { landingPageSchema } from "@/lib/validation";
import { uniqueSlug } from "@/lib/unique-slug";
import { bumpVersion } from "@/lib/sync";
import { setRootRedirectSlug, clearRootRedirectIfSlug } from "@/lib/lp-root-redirect";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  const pages = await prisma.landingPage.findMany({
    orderBy: { createdAt: "desc" },
  });

  // Defense-in-depth against a stale Prisma client cached in the dev server
  // memory before the `template` / `template_data` columns existed:
  // re-fetch those two columns via raw SQL keyed by id, then merge into the
  // serialized rows. Costs one extra query, runs on every list call.
  let extras: { id: number; template: string | null; template_data: unknown }[] = [];
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    extras = await prisma.$queryRawUnsafe<{ id: number; template: string | null; template_data: unknown }[]>(
      `SELECT id, template, template_data FROM "landing_pages" ORDER BY id`,
    );
  } catch { /* column may not exist yet on this tenant — fall through */ }
  const byId = new Map(extras.map((e) => [Number(e.id), e]));

  const serialized = pages.map((p) => {
    const base = serialize(p) as Record<string, unknown>;
    const extra = byId.get(p.id);
    if (extra) {
      base.template = extra.template || "default";
      base.template_data = extra.template_data;
    }
    return base;
  });

  return jsonResponse(serialized);
}

export async function POST(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  try {
    const body = await request.json();
    const parsed = landingPageSchema.safeParse(body);
    if (!parsed.success) {
      return validationError(parsed.error.flatten().fieldErrors as Record<string, string[]>);
    }

    const data = parsed.data;
    const slug = await uniqueSlug(prisma, data.title, "landingPage", data.slug);

    const page = await prisma.landingPage.create({
      data: {
        slug,
        title: data.title,
        isActive: data.is_active ?? true,
        heroHeadline: data.hero_headline || null,
        heroSubheadline: data.hero_subheadline || null,
        heroImage: data.hero_image || null,
        heroVideoAutoplay: data.hero_video_autoplay ?? false,
        heroCta: data.hero_cta || null,
        heroTrustText: data.hero_trust_text || null,
        heroBadge: data.hero_badge || null,
        problemTitle: data.problem_title || null,
        problemPoints: data.problem_points || null,
        productsTitle: data.products_title || null,
        productsSub: data.products_subtitle || null,
        featuresTitle: data.features_title || null,
        featuresImage: data.features_image || null,
        features: data.features || null,
        testimonialsTitle: data.testimonials_title || null,
        testimonialsMode: data.testimonials_mode || "custom",
        testimonials: data.testimonials || null,
        howItWorksTitle: data.how_it_works_title || null,
        howItWorksSub: data.how_it_works_subtitle || null,
        howItWorks: data.how_it_works || null,
        faqTitle: data.faq_title || null,
        faq: data.faq || null,
        products: data.products || null,
        checkoutTitle: data.checkout_title || null,
        checkoutSubtitle: data.checkout_subtitle || null,
        checkoutBtnText: data.checkout_btn_text || null,
        customShipping: data.custom_shipping ?? false,
        shippingCost: data.shipping_cost != null ? Number(data.shipping_cost) : 60,
        showEmail: data.show_email ?? false,
        showCity: data.show_city ?? true,
        guaranteeText: data.guarantee_text || null,
        successMessage: data.success_message || null,
        metaTitle: data.meta_title || null,
        metaDescription: data.meta_description || null,
        whatsapp: data.whatsapp || null,
        contactMode: data.contact_mode || "inherit",
        sectionVisibility: data.section_visibility || null,
        sectionOrder: Array.isArray(data.section_order) ? data.section_order : undefined,
        primaryColor: data.primary_color || "#0f5931",
        // Per-page visual template + its data payload. Default "default" matches
        // every existing row's column default so legacy pages keep their old look.
        template: data.template || "default",
        templateData: data.template_data
          ? (typeof data.template_data === "string"
              ? (() => { try { return JSON.parse(data.template_data); } catch { return null; } })()
              : data.template_data)
          : null,
      },
    });

    // Base-URL redirect designation (stored as a single site-setting slug).
    if (data.root_redirect) await setRootRedirectSlug(prisma, page.slug);
    else await clearRootRedirectIfSlug(prisma, page.slug);

    revalidateAll("landing-pages");
    bumpVersion("landing-pages");
    void broadcastToTenant(tenant.id, "landing_pages", "changed", { slug: page.slug }); /* @broadcast */ return jsonResponse(serialize(page), 201);
  } catch (error) {
    console.error("Landing page create error:", error);
    return errorResponse("Failed to create landing page", 500);
  }
}
