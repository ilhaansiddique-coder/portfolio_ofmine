import { NextRequest } from "next/server";
import { revalidateAll } from "@/lib/revalidate";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { broadcastToTenant } from "@/lib/realtime";
import { serialize } from "@/lib/serialize";
import { jsonResponse, validationError, notFound, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { landingPageSchema } from "@/lib/validation";
import { uniqueSlug } from "@/lib/unique-slug";
import { bumpVersion } from "@/lib/sync";
import { getRootRedirectSlug, setRootRedirectSlug, clearRootRedirectIfSlug } from "@/lib/lp-root-redirect";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  const { id } = await params;
  const page = await prisma.landingPage.findUnique({ where: { id: Number(id) } });
  if (!page) return notFound("Landing page not found");

  // Defense-in-depth: refetch template + template_data via raw SQL in case
  // the Prisma client cached in this dev process is older than the
  // template/template_data columns were added.
  const base = serialize(page) as Record<string, unknown>;
  try {
    const extras = await prisma.$queryRawUnsafe<{ template: string | null; template_data: unknown }[]>(
      `SELECT template, template_data FROM "landing_pages" WHERE id = $1`,
      Number(id),
    );
    if (extras[0]) {
      base.template = extras[0].template || "default";
      base.template_data = extras[0].template_data;
    }
  } catch { /* columns may not exist yet — leave base as is */ }

  // Surface whether THIS page is the current base-URL redirect target so the
  // editor checkbox reflects the saved state.
  base.root_redirect = (await getRootRedirectSlug(prisma)) === page.slug;

  return jsonResponse(base);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  const { id } = await params;
  const existing = await prisma.landingPage.findUnique({ where: { id: Number(id) } });
  if (!existing) return notFound("Landing page not found");

  try {
    const body = await request.json();
    const parsed = landingPageSchema.safeParse(body);
    if (!parsed.success) {
      return validationError(parsed.error.flatten().fieldErrors as Record<string, string[]>);
    }

    const data = parsed.data;
    const slug = await uniqueSlug(prisma, data.title, "landingPage", data.slug, Number(id));

    const page = await prisma.landingPage.update({
      where: { id: Number(id) },
      data: {
        slug,
        title: data.title,
        isActive: data.is_active ?? true,
        heroHeadline: data.hero_headline || null,
        heroSubheadline: data.hero_subheadline || null,
        heroImage: data.hero_image || null,
        heroVideoAutoplay: data.hero_video_autoplay ?? false,
        heroCta: data.hero_cta || null,
        heroTrustText: data.hero_trust_text || null,
        heroBadge: data.hero_badge || null,
        problemTitle: data.problem_title || null,
        problemPoints: data.problem_points || null,
        productsTitle: data.products_title || null,
        productsSub: data.products_subtitle || null,
        featuresTitle: data.features_title || null,
        featuresImage: data.features_image || null,
        features: data.features || null,
        testimonialsTitle: data.testimonials_title || null,
        testimonialsMode: data.testimonials_mode || "custom",
        testimonials: data.testimonials || null,
        howItWorksTitle: data.how_it_works_title || null,
        howItWorksSub: data.how_it_works_subtitle || null,
        howItWorks: data.how_it_works || null,
        faqTitle: data.faq_title || null,
        faq: data.faq || null,
        products: data.products || null,
        checkoutTitle: data.checkout_title || null,
        checkoutSubtitle: data.checkout_subtitle || null,
        checkoutBtnText: data.checkout_btn_text || null,
        customShipping: data.custom_shipping ?? false,
        shippingCost: data.shipping_cost != null ? Number(data.shipping_cost) : 60,
        showEmail: data.show_email ?? false,
        showCity: data.show_city ?? true,
        guaranteeText: data.guarantee_text || null,
        successMessage: data.success_message || null,
        metaTitle: data.meta_title || null,
        metaDescription: data.meta_description || null,
        whatsapp: data.whatsapp || null,
        contactMode: data.contact_mode || "inherit",
        sectionVisibility: data.section_visibility || null,
        sectionOrder: Array.isArray(data.section_order) ? data.section_order : undefined,
        primaryColor: data.primary_color || "#0f5931",
        template: data.template || "default",
        templateData: data.template_data
          ? (typeof data.template_data === "string"
              ? (() => { try { return JSON.parse(data.template_data); } catch { return null; } })()
              : data.template_data)
          : null,
      },
    });

    // Base-URL redirect designation. On enable → point at the (possibly
    // renamed) slug. On disable → clear if it pointed at this page (check both
    // the old and new slug in case the slug changed in this same save).
    if (data.root_redirect) {
      await setRootRedirectSlug(prisma, page.slug);
    } else {
      await clearRootRedirectIfSlug(prisma, existing.slug);
      await clearRootRedirectIfSlug(prisma, page.slug);
    }

    revalidateAll("landing-pages");
    bumpVersion("landing-pages");
    void broadcastToTenant(tenant.id, "landing_pages", "changed", { slug: page.slug }); /* @broadcast */ return jsonResponse(serialize(page));
  } catch (error) {
    console.error("Landing page update error:", error);
    return errorResponse("Failed to update landing page", 500);
  }
}

/**
 * PATCH — partial update for the FRONTEND inline editor (pencil-icon edits).
 *
 * Unlike PUT (which validates + replaces the WHOLE row from the dashboard
 * form), PATCH applies a small set of changes without touching anything else:
 *
 *   Body: {
 *     columns?: { hero_headline?, hero_image?, whatsapp?, ... },  // allow-listed
 *     template_data?: { ...keys to merge into the existing JSON }  // shallow merge
 *   }
 *
 * Only an explicit allow-list of columns can be written, so a compromised
 * client can't flip isActive, change the slug, or hijack the root redirect.
 * template_data is shallow-merged so editing one block never drops the others.
 */
const PATCH_COLUMN_MAP: Record<string, string> = {
  title: "title",
  hero_headline: "heroHeadline",
  hero_subheadline: "heroSubheadline",
  hero_image: "heroImage",
  hero_cta: "heroCta",
  hero_badge: "heroBadge",
  hero_trust_text: "heroTrustText",
  problem_title: "problemTitle",
  products_title: "productsTitle",
  features_title: "featuresTitle",
  features_image: "featuresImage",
  testimonials_title: "testimonialsTitle",
  how_it_works_title: "howItWorksTitle",
  faq_title: "faqTitle",
  checkout_title: "checkoutTitle",
  checkout_subtitle: "checkoutSubtitle",
  checkout_btn_text: "checkoutBtnText",
  guarantee_text: "guaranteeText",
  success_message: "successMessage",
  whatsapp: "whatsapp",
  primary_color: "primaryColor",
};

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  try { await requireStaff(); } catch (e) { return e as Response; }

  const { id } = await params;
  const existing = await prisma.landingPage.findUnique({ where: { id: Number(id) } });
  if (!existing) return notFound("Landing page not found");

  try {
    const body = await request.json().catch(() => ({}));
    const columns = (body?.columns ?? {}) as Record<string, unknown>;
    const tdPatch = (body?.template_data ?? null) as Record<string, unknown> | null;

    const update: Record<string, unknown> = {};

    // Allow-listed columns only.
    for (const [snake, value] of Object.entries(columns)) {
      const field = PATCH_COLUMN_MAP[snake];
      if (!field) continue;
      update[field] = typeof value === "string" ? (value || null) : value;
    }

    // Shallow-merge template_data so a single-field edit keeps the rest.
    if (tdPatch && typeof tdPatch === "object") {
      const raw = (existing as { templateData?: unknown }).templateData;
      const current: Record<string, unknown> =
        typeof raw === "string"
          ? (() => { try { return JSON.parse(raw); } catch { return {}; } })()
          : (raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {});
      update.templateData = JSON.stringify({ ...current, ...tdPatch });
    }

    if (Object.keys(update).length === 0) {
      return jsonResponse(serialize(existing));
    }

    const page = await prisma.landingPage.update({
      where: { id: Number(id) },
      data: update,
    });

    revalidateAll("landing-pages");
    bumpVersion("landing-pages");
    void broadcastToTenant(tenant.id, "landing_pages", "changed", { slug: page.slug }); /* @broadcast */
    return jsonResponse(serialize(page));
  } catch (error) {
    console.error("Landing page PATCH error:", error);
    return errorResponse("Failed to update landing page", 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  const { id } = await params;
  const existing = await prisma.landingPage.findUnique({ where: { id: Number(id) } });
  if (!existing) return notFound("Landing page not found");

  await prisma.landingPage.delete({ where: { id: Number(id) } });
  // Drop the base-URL redirect setting if it pointed at the deleted page.
  await clearRootRedirectIfSlug(prisma, existing.slug);
  revalidateAll("landing-pages");
  bumpVersion("landing-pages");
  void broadcastToTenant(tenant.id, "landing_pages", "changed", { slug: existing.slug }); /* @broadcast */ return jsonResponse({ message: "Landing page deleted" });
}
