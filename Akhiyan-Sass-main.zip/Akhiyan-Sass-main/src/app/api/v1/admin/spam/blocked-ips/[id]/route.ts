import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { broadcastToTenant } from "@/lib/realtime";
import { jsonResponse, notFound, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  try { await requireStaff(); } catch (e) { return e as Response; }

  const { id } = await params;
  const existing = await prisma.blockedIp.findUnique({ where: { id: Number(id) } });
  if (!existing) return notFound("Blocked IP not found");

  try {
    await prisma.blockedIp.delete({ where: { id: Number(id) } });
    void broadcastToTenant(tenant.id, "spam", "changed", {}); /* @broadcast */ return jsonResponse({ success: true });
  } catch {
    return errorResponse("Failed to unblock IP", 500);
  }
}
