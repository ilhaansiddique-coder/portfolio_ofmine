import { NextRequest } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { getUploadDir } from "@/lib/uploads";
import { isR2Configured, r2Upload, r2UploadToBucket, tenantKey } from "@/lib/r2";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import sharp from "sharp";

const IMAGE_EXTS = new Set([".jpg", ".jpeg", ".png", ".webp", ".avif", ".tiff"]);
const ALLOWED_EXTS = new Set([
  ".jpg", ".jpeg", ".png", ".webp", ".avif", ".tiff", ".gif",
  ".mp4", ".webm", ".mov", ".mkv", ".avi", ".m4v",
  ".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac", ".opus",
  ".pdf",
]);
const MAX_WIDTH = 1920;
const QUALITY = 80;
// Hard cap matching the UI hint ("max 50MB" in MediaGallery). Rejected early
// via file.size before we ever call arrayBuffer(), so a 5 GB upload can't
// OOM the server by landing the whole body in RAM.
const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;

const MIME: Record<string, string> = {
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
  ".webp": "image/webp", ".avif": "image/avif", ".gif": "image/gif",
  ".tiff": "image/tiff", ".svg": "image/svg+xml",
  ".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime",
  ".mkv": "video/x-matroska", ".avi": "video/x-msvideo", ".m4v": "video/x-m4v",
  ".mp3": "audio/mpeg", ".wav": "audio/wav", ".ogg": "audio/ogg",
  ".m4a": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac", ".opus": "audio/opus",
  ".pdf": "application/pdf",
};

/**
 * Sniff first bytes of a buffer to verify it matches the claimed extension.
 * Returns true if the magic bytes are consistent with the extension; false if
 * the file appears to be a different type (i.e. a polyglot or renamed file).
 *
 * This is defense-in-depth on top of the extension allowlist — an attacker
 * can't smuggle an HTML/JS file in by naming it `.png`.
 */
function magicBytesMatchExt(buf: Buffer, ext: string): boolean {
  const b = buf;
  if (b.length < 4) return false;

  const startsWith = (sig: number[], offset = 0) =>
    sig.every((byte, i) => b[offset + i] === byte);

  switch (ext) {
    case ".jpg":
    case ".jpeg":
      return startsWith([0xff, 0xd8, 0xff]);
    case ".png":
      return startsWith([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    case ".gif":
      return startsWith([0x47, 0x49, 0x46, 0x38]); // "GIF8"
    case ".webp":
      // "RIFF....WEBP"
      return startsWith([0x52, 0x49, 0x46, 0x46]) && startsWith([0x57, 0x45, 0x42, 0x50], 8);
    case ".avif":
    case ".tiff":
      // Both have varied signatures; allow extension match here and rely on
      // sharp's metadata() call which throws on malformed images.
      return true;
    case ".pdf":
      return startsWith([0x25, 0x50, 0x44, 0x46]); // "%PDF"
    case ".mp4":
    case ".mov":
      // ISO base media: bytes 4-7 are "ftyp"
      return b.length >= 8 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70;
    case ".webm":
    case ".mkv":
      // Matroska/EBML header
      return startsWith([0x1a, 0x45, 0xdf, 0xa3]);
    case ".m4v":
      // ISO base media (ftyp at bytes 4-7), same family as mp4/mov
      return b.length >= 8 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70;
    case ".avi":
      // "RIFF"...."AVI "
      return startsWith([0x52, 0x49, 0x46, 0x46]) && startsWith([0x41, 0x56, 0x49, 0x20], 8);
    case ".mp3":
      // "ID3" tag, or an MPEG audio frame sync (0xFFEx).
      return startsWith([0x49, 0x44, 0x33]) || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0);
    case ".wav":
      // "RIFF"...."WAVE"
      return startsWith([0x52, 0x49, 0x46, 0x46]) && startsWith([0x57, 0x41, 0x56, 0x45], 8);
    case ".ogg":
    case ".opus":
      return startsWith([0x4f, 0x67, 0x67, 0x53]); // "OggS"
    case ".flac":
      return startsWith([0x66, 0x4c, 0x61, 0x43]); // "fLaC"
    case ".m4a":
      // ISO base media (ftyp), like mp4
      return b.length >= 8 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70;
    case ".aac":
      // ADTS frame sync 0xFFFx
      return b[0] === 0xff && (b[1] & 0xf6) === 0xf0;
    default:
      return false;
  }
}

export async function POST(request: NextRequest) {
  const { tenant } = await getPrismaForRequest(request);
  try { await requireStaff(); } catch (e) { return e as Response; }

  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return errorResponse("No file provided", 422);
    }

    // Size check BEFORE loading the body — File.size is metadata, no read.
    if (file.size > MAX_UPLOAD_BYTES) {
      return errorResponse(`File too large. Maximum size is ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)} MB.`, 413);
    }

    const ext = path.extname(file.name).toLowerCase();

    if (!ALLOWED_EXTS.has(ext)) {
      return errorResponse(`File type ${ext} is not allowed. Allowed: ${[...ALLOWED_EXTS].join(", ")}`, 422);
    }

    const bytes = await file.arrayBuffer();
    let buffer: Buffer<ArrayBuffer> = Buffer.from(bytes);

    // Magic-byte sniff — refuse a file whose contents do not match its
    // claimed extension. Stops a renamed .html/.js (or polyglot) from being
    // stored as an "image".
    if (!magicBytesMatchExt(buffer, ext)) {
      return errorResponse(`File contents do not match the ${ext} extension.`, 422);
    }

    const basename = path.basename(file.name, path.extname(file.name))
      .replace(/[^a-zA-Z0-9_\-\u0980-\u09FF]/g, "-")
      .replace(/-+/g, "-");

    let finalExt = ext;

    // Compress images with sharp
    if (IMAGE_EXTS.has(ext)) {
      try {
        const img = sharp(buffer);
        const metadata = await img.metadata();

        if (metadata.width && metadata.width > MAX_WIDTH) {
          img.resize(MAX_WIDTH, undefined, { withoutEnlargement: true });
        }

        if (ext !== ".webp" && ext !== ".avif") {
          buffer = await img.webp({ quality: QUALITY }).toBuffer() as Buffer<ArrayBuffer>;
          finalExt = ".webp";
        } else if (ext === ".webp") {
          buffer = await img.webp({ quality: QUALITY }).toBuffer() as Buffer<ArrayBuffer>;
        } else {
          buffer = await img.avif({ quality: QUALITY }).toBuffer() as Buffer<ArrayBuffer>;
        }
      } catch {
        // If sharp fails, save original
      }
    }

    const uniqueName = `${basename}-${Date.now()}${finalExt}`;
    const contentType = MIME[finalExt] || "application/octet-stream";

    // Priority:
    // 1. Tenant has a dedicated R2 bucket → use it (bucket is already isolated)
    // 2. Global R2 configured → shared bucket with tenant-prefix (legacy)
    // 3. Neither → local disk fallback
    if (tenant.r2Bucket && tenant.r2PublicUrl) {
      const url = await r2UploadToBucket(
        tenant.r2Bucket,
        uniqueName,
        buffer,
        contentType,
        tenant.r2PublicUrl,
      );
      return jsonResponse({ url, path: url, key: uniqueName }, 201);
    }

    if (isR2Configured()) {
      // Tenant prefix every R2 key so two tenants never share file paths.
      const key = tenantKey(tenant.id, uniqueName);
      const url = await r2Upload(key, buffer, contentType);
      return jsonResponse({ url, path: url, key }, 201);
    }

    // Local fallback also tenant-prefixes its directory layout.
    const tenantDir = `tenant_${tenant.id}`;
    const uploadDir = path.join(getUploadDir(), tenantDir);
    await mkdir(uploadDir, { recursive: true });
    const filePath = path.join(uploadDir, uniqueName);
    await writeFile(filePath, buffer);
    const url = `/uploads/${tenantDir}/${uniqueName}`;
    return jsonResponse({ url, path: url }, 201);
  } catch {
    return errorResponse("Failed to upload file", 500);
  }
}
