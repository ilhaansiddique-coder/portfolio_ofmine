/**
 * Tenant self-service custom-domain management.
 *
 *   GET    /api/v1/admin/domain — current domain + verification status + DNS instructions
 *   POST   /api/v1/admin/domain — claim a new domain (validates + DNS-verifies + saves)
 *   DELETE /api/v1/admin/domain — remove the current custom domain
 *
 * Auth: requires staff session (admin / manager) on the calling tenant. Each
 * tenant can only mutate their OWN row — tenantId comes from the resolved
 * host header, not from any body parameter, so an admin on tenant A can't
 * touch tenant B's domain.
 *
 * Cache: every mutation calls `clearTenantCache()` so the new (or removed)
 * domain takes effect within the 60s host-resolution cache window — usually
 * faster because the entry gets invalidated immediately.
 */
import { NextRequest } from "next/server";
import { controlPrisma } from "@/lib/prisma-control";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAdmin } from "@/lib/auth-helpers";
import { clearTenantCache } from "@/lib/tenant";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import {
  cnameTarget,
  verifyDomainDNS,
  claimDomainForTenant,
} from "@/lib/domain-verify";
import {
  ensureCustomHostname,
  removeCustomHostnameByDomain,
} from "@/lib/cloudflare-custom-hostnames";

export const runtime = "nodejs";

/** Returns the current domain + a live DNS check + setup instructions. */
export async function GET(request: NextRequest) {
  try {
  const { tenant } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const expectedCname = cnameTarget();
  const apexA = process.env.APP_PUBLIC_IP || null;

  // If a domain is set, re-check its DNS so the UI can show "verified" vs
  // "DNS missing now" (e.g. after the tenant rotated their nameservers).
  let verification = null;
  if (tenant.primaryDomain) {
    try {
      verification = await verifyDomainDNS(tenant.primaryDomain);
    } catch {
      verification = null;
    }
  }

  const hasCfSaaS = !!(process.env.CLOUDFLARE_ZONE_ID && process.env.CLOUDFLARE_API_TOKEN);
  const baseDomain = process.env.BASE_DOMAIN || "contradigital.agency";

  // SELF-HEAL: ensure the domain is registered as a Cloudflare-for-SaaS custom
  // hostname. Idempotent — registers it if missing (fixes the "Error 1014
  // CNAME cross-user banned" case where a domain was saved but never
  // registered). Runs whenever the admin opens the Domain page, so it's
  // fully automatic. Best-effort: never break the page if CF is down.
  let cfHostname: { status: string; ssl: string } | null = null;
  if (hasCfSaaS && tenant.primaryDomain) {
    try {
      const ch = await ensureCustomHostname(tenant.primaryDomain);
      if (ch) cfHostname = { status: ch.status, ssl: ch.ssl?.status || "unknown" };
    } catch { /* leave null — surfaced as not-yet-registered in the UI */ }
  }

  return jsonResponse({
    domain: tenant.primaryDomain,
    verification,
    cloudflareManaged: hasCfSaaS,
    cfHostname,
    instructions: {
      cnameTarget: expectedCname,
      apexA: apexA,
      explainer: hasCfSaaS
        ? `Point your domain's CNAME or A record to ${baseDomain}. ` +
          `SSL is provisioned automatically — just add the domain and save.`
        : `Add a CNAME record on your domain pointing to ${expectedCname}. ` +
          `For apex domains (e.g. example.com without "www") that can't CNAME, ` +
          `add an A record to ${apexA ?? "the app server IP (ask support)"} instead.`,
    },
    storefrontFallback: `${tenant.slug}.${baseDomain}`,
  });
  } catch (e) {
    console.error("[domain GET] unexpected error:", e);
    return errorResponse(
      e instanceof Error ? `${e.name}: ${e.message}` : "Internal server error",
      500,
    );
  }
}

/** Claim a new custom domain — validates format, uniqueness, and DNS. */
export async function POST(request: NextRequest) {
  try {
    const { tenant } = await getPrismaForRequest(request);
    try { await requireAdmin(); } catch (e) { return e as Response; }

    const body = await request.json().catch(() => ({}));
    const raw: string = String(body.domain || "").trim();
    if (!raw) return errorResponse("Domain is required.", 400);

    const hasCfSaaS = !!(process.env.CLOUDFLARE_ZONE_ID && process.env.CLOUDFLARE_API_TOKEN);

    // SAVE-FIRST UX (the standard add-then-verify flow). We validate FORMAT +
    // UNIQUENESS here (uniqueness still blocks squatting another tenant's bound
    // domain) but do NOT block the save on DNS — most tenants add the domain in
    // our UI and configure DNS afterward, so a hard DNS gate left the domain
    // unsaved and the tenant stuck with no record + no instructions on screen.
    // DNS ownership is now surfaced as a live "pending / verified" STATUS plus a
    // Re-verify button. An unverified domain serves no traffic until its DNS
    // actually points at us, and the super-admin can audit/remove via the
    // tenant detail page.
    let normalized: string;
    try {
      normalized = await claimDomainForTenant(raw, tenant.id, { skipDnsCheck: true });
    } catch (e) {
      return errorResponse(e instanceof Error ? e.message : "Invalid domain", 400);
    }

    // 1. Persist immediately so it shows on screen with DNS instructions.
    await controlPrisma.tenant.update({
      where: { id: tenant.id },
      data: { primaryDomain: normalized },
    });
    await controlPrisma.auditLog.create({
      data: {
        tenantId: tenant.id,
        action: "tenant.domain.added",
        details: { domain: normalized, cloudflare: hasCfSaaS },
      },
    }).catch(() => {});
    clearTenantCache();

    // 2. Best-effort Cloudflare-for-SaaS hostname (kicks off SSL provisioning).
    //    Never blocks the save — DNS may not be ready yet, which is expected.
    let cfWarning: string | null = null;
    if (hasCfSaaS) {
      try {
        await ensureCustomHostname(normalized);
      } catch (e) {
        cfWarning = e instanceof Error ? e.message : String(e);
        console.warn("[domain POST] Cloudflare addCustomHostname (non-fatal):", cfWarning);
      }
    }

    // 3. Live DNS check for an immediate verified/pending badge (non-fatal).
    let verification = null;
    try {
      verification = await verifyDomainDNS(normalized);
    } catch { /* leave null — UI shows "pending", Re-verify will retry */ }

    const verified = !!verification?.ok;
    return jsonResponse({
      domain: normalized,
      verification,
      message: verified
        ? "Custom domain saved and verified."
        : "Custom domain saved. Add the DNS record shown above, then click Re-verify.",
      ...(cfWarning ? { cfWarning } : {}),
    });
  } catch (e) {
    console.error("[domain POST] unexpected error:", e);
    return errorResponse(
      e instanceof Error ? `${e.name}: ${e.message}` : "Internal server error",
      500,
    );
  }
}

/** Remove the current custom domain (revert to slug-based subdomain only). */
export async function DELETE(request: NextRequest) {
  const { tenant } = await getPrismaForRequest(request);
  try { await requireAdmin(); } catch (e) { return e as Response; }

  if (!tenant.primaryDomain) {
    return errorResponse("No custom domain is currently set.", 400);
  }

  const removed = tenant.primaryDomain;

  // Remove from Cloudflare for SaaS (best-effort — don't block DB cleanup).
  try {
    await removeCustomHostnameByDomain(removed);
  } catch { /* logged by CF lib; DB cleanup is more important */ }

  await controlPrisma.tenant.update({
    where: { id: tenant.id },
    data: { primaryDomain: null },
  });

  await controlPrisma.auditLog.create({
    data: {
      tenantId: tenant.id,
      action: "tenant.domain.removed",
      details: { domain: removed },
    },
  }).catch(() => {});

  clearTenantCache();
  return jsonResponse({ domain: null, message: "Custom domain removed." });
}
