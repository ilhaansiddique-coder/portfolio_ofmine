import { NextRequest } from "next/server";
import { revalidateAll } from "@/lib/revalidate";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { broadcastToTenant } from "@/lib/realtime";
import { serialize } from "@/lib/serialize";
import { jsonResponse, validationError, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { brandSchema } from "@/lib/validation";
import { uniqueSlug } from "@/lib/unique-slug";
import { bumpVersion } from "@/lib/sync";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  const brands = await prisma.brand.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { name: "asc" },
  });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const result = brands.map((b: any) => ({
    ...serialize(b),
    products_count: b._count?.products ?? 0,
  }));

  return jsonResponse(result);
}

export async function POST(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireStaff(); } catch (e) { return e as Response; }

  try {
    const body = await request.json();
    const parsed = brandSchema.safeParse(body);
    if (!parsed.success) {
      return validationError(parsed.error.flatten().fieldErrors as Record<string, string[]>);
    }

    const data = parsed.data;
    const slug = await uniqueSlug(prisma, data.name, "brand", data.slug);

    const brand = await prisma.brand.create({
      data: {
        name: data.name,
        slug,
        logo: data.logo ?? null,
        isActive: data.is_active ?? true,
      },
    });

    revalidateAll("brands");
    bumpVersion("brands");
    void broadcastToTenant(tenant.id, "brands", "changed", {}); /* @broadcast */ return jsonResponse(serialize(brand), 201);
  } catch (error) {
    return errorResponse("Failed to create brand", 500);
  }
}
