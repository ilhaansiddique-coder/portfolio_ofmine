/**
 * CMS Pages collection — GET (list) + POST (create).
 * Puck-built pages served at clean root URLs (/<slug>). Draft/Publish on [id].
 */
import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireStaff } from "@/lib/auth-helpers";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { serialize } from "@/lib/serialize";
import { normalizePageSlug } from "@/lib/page-slug";
import { ROOT_RESERVED } from "@/lib/reservedSlugs";

export async function GET(request: NextRequest) {
  try { await requireStaff(); } catch (e) { return e as Response; }
  const { prisma } = await getPrismaForRequest(request);
  const url = new URL(request.url);
  const type = url.searchParams.get("type") || undefined;
  const status = url.searchParams.get("status") || undefined;
  try {
    const pages = await prisma.cmsPage.findMany({
      where: { ...(type ? { type } : {}), ...(status ? { status } : {}) },
      orderBy: { updatedAt: "desc" },
      select: { id: true, title: true, slug: true, status: true, type: true, pageType: true, updatedAt: true, version: true },
    });
    return jsonResponse(serialize(pages));
  } catch (e) {
    console.error("[cms-pages] list error:", e);
    return errorResponse("Failed to list pages", 500);
  }
}

export async function POST(request: NextRequest) {
  try { await requireStaff(); } catch (e) { return e as Response; }
  const { prisma } = await getPrismaForRequest(request);
  try {
    const body = await request.json().catch(() => ({}));
    const title = String(body.title || "Untitled Page").trim();
    let rawSlug = normalizePageSlug(body.slug || title) || `page-${Date.now()}`;
    // A reserved root word (shop, blog, p…) can't be a clean-URL slug — the
    // proxy won't rewrite it. Prefix so the new page is still reachable; the
    // admin can rename it later (PATCH validates strictly).
    if (ROOT_RESERVED.has(rawSlug)) rawSlug = `page-${rawSlug}`;
    // Ensure unique slug within this tenant DB.
    let slug = rawSlug;
    for (let i = 2; await prisma.cmsPage.findFirst({ where: { slug } }); i++) slug = `${rawSlug}-${i}`;
    const page = await prisma.cmsPage.create({
      data: {
        title, slug,
        type: body.type || "page",
        pageType: body.pageType || "landing",
        status: "draft",
        version: 0,
        draftData: (body.draftData ?? { root: { props: {} }, content: [], zones: {} }) as unknown as Prisma.InputJsonValue,
      },
      select: { id: true, slug: true, title: true },
    });
    return jsonResponse(serialize(page), 201);
  } catch (e) {
    console.error("[cms-pages] create error:", e);
    return errorResponse("Failed to create page", 500);
  }
}
