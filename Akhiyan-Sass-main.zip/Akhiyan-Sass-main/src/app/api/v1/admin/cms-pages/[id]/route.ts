/**
 * CMS Page single — GET, PATCH (save draft / publish / unpublish), DELETE.
 *
 * Publish: copies draftData → publishedData, bumps version, status=published.
 * Unpublish: status=draft, clears publishedData.
 * Every mutation flushes the tenant-scoped public cache tag.
 */
import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireStaff } from "@/lib/auth-helpers";
import { jsonResponse, notFound, errorResponse } from "@/lib/api-response";
import { serialize } from "@/lib/serialize";
import { revalidateAll } from "@/lib/revalidate";
import { validatePageSlug } from "@/lib/page-slug";

const J = (v: unknown) => v as unknown as Prisma.InputJsonValue;

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try { await requireStaff(); } catch (e) { return e as Response; }
  const { prisma } = await getPrismaForRequest(request);
  const { id } = await params;
  const page = await prisma.cmsPage.findUnique({ where: { id: Number(id) } });
  if (!page) return notFound("Page not found");
  return jsonResponse(serialize(page));
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try { await requireStaff(); } catch (e) { return e as Response; }
  const { prisma, tenant } = await getPrismaForRequest(request);
  const { id } = await params;
  try {
    const body = await request.json();
    const existing = await prisma.cmsPage.findUnique({ where: { id: Number(id) } });
    if (!existing) return notFound("Page not found");

    const data: Record<string, unknown> = {};
    if (body.title !== undefined) data.title = body.title;
    if (body.slug !== undefined) {
      // CMS pages live at clean root URLs now, so the slug must be valid +
      // unreserved + not collide with a landing page / shortlink / other page.
      const check = await validatePageSlug(prisma, body.slug, Number(id));
      if (!check.ok) return errorResponse(check.message, 400);
      data.slug = check.slug;
    }
    if (body.metaTitle !== undefined) data.metaTitle = body.metaTitle;
    if (body.metaDesc !== undefined) data.metaDesc = body.metaDesc;
    if (body.excerpt !== undefined) data.excerpt = body.excerpt;
    if (body.featuredImage !== undefined) data.featuredImage = body.featuredImage;
    if (body.noIndex !== undefined) data.noIndex = !!body.noIndex;
    if (body.draftData !== undefined) data.draftData = J(body.draftData);

    if (body.status === "published") {
      const finalDraft = body.draftData ?? existing.draftData;
      data.status = "published";
      data.publishedData = J(finalDraft);
      data.publishedAt = new Date();
      data.version = (existing.version || 0) + 1;
    } else if (body.status === "draft") {
      data.status = "draft";
      data.publishedData = Prisma.JsonNull;
    }

    const page = await prisma.cmsPage.update({
      where: { id: Number(id) },
      data,
      select: { id: true, slug: true, title: true, status: true, version: true },
    });
    revalidateAll(`t${tenant.id}:cms-pages`);
    return jsonResponse(serialize(page));
  } catch (e) {
    console.error("[cms-pages] update error:", e);
    return errorResponse("Failed to update page", 500);
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try { await requireStaff(); } catch (e) { return e as Response; }
  const { prisma, tenant } = await getPrismaForRequest(request);
  const { id } = await params;
  await prisma.cmsPage.delete({ where: { id: Number(id) } });
  revalidateAll(`t${tenant.id}:cms-pages`);
  return jsonResponse({ success: true });
}
