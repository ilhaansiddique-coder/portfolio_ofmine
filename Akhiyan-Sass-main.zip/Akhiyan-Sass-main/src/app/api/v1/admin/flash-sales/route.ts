import { NextRequest } from "next/server";
import { revalidateAll } from "@/lib/revalidate";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { broadcastToTenant } from "@/lib/realtime";
import { serialize } from "@/lib/serialize";
import { jsonResponse, validationError, errorResponse } from "@/lib/api-response";
import { requireAdmin } from "@/lib/auth-helpers";
import { flashSaleSchema } from "@/lib/validation";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireAdmin(); } catch (e) { return e as Response; }

  const flashSales = await prisma.flashSale.findMany({
    include: { products: { include: { product: true } } },
    orderBy: { createdAt: "desc" },
  });

  return jsonResponse(flashSales.map(serialize));
}

export async function POST(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireAdmin(); } catch (e) { return e as Response; }

  try {
    const body = await request.json();
    const parsed = flashSaleSchema.safeParse(body);
    if (!parsed.success) {
      return validationError(parsed.error.flatten().fieldErrors as Record<string, string[]>);
    }

    const data = parsed.data;

    const flashSale = await prisma.flashSale.create({
      data: {
        title: data.title,
        startsAt: new Date(data.starts_at),
        endsAt: new Date(data.ends_at),
        isActive: data.is_active ?? true,
        products: data.products?.length
          ? {
              create: data.products.map((p) => ({
                productId: p.id,
                salePrice: p.sale_price,
              })),
            }
          : undefined,
      },
      include: { products: { include: { product: true } } },
    });

    revalidateAll("flash-sales");
    void broadcastToTenant(tenant.id, "flash_sales", "changed", {}); /* @broadcast */ return jsonResponse(serialize(flashSale), 201);
  } catch (error) {
    return errorResponse("Failed to create flash sale", 500);
  }
}
