import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { jsonResponse, errorResponse, notFound } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { isSteadfastConfigured, checkCourierScore as steadfastScore, formatPhone, clearKeyCache } from "@/lib/steadfast";
import { hasPathaoAuth, clearPathaoCache } from "@/lib/pathao";
import { getMerchantPanelToken, clearMerchantPanelTokenCache } from "@/lib/pathaoMerchantAuth";
import type { PrismaClient } from "@prisma/client";

/**
 * Unified courier fraud-score check.
 *
 * POST /api/v1/admin/courier/score  { order_id } | { phone }
 *
 * Calls every enabled courier in parallel and returns per-courier breakdown
 * plus a combined aggregate (sum of parcels/delivered, weighted ratio).
 * Steadfast → /fraud_check, Pathao → merchant panel /user/success.
 *
 * Each courier degrades independently — one failing won't kill the others.
 * Combined success_ratio is what we persist on the order.
 */

interface ProviderResult {
  provider: "steadfast" | "pathao";
  ok: boolean;
  total_parcels: number;
  total_delivered: number;
  total_cancelled: number;
  success_ratio: string;
  rating?: string;
  error?: string;
}

async function scoreSteadfast(prisma: PrismaClient, tenantId: number, phone: string): Promise<ProviderResult> {
  try {
    const r = await steadfastScore(prisma, tenantId, phone);
    const total = Number(r.total_parcels || 0);
    const delivered = Number(r.total_delivered || 0);
    return {
      provider: "steadfast",
      ok: true,
      total_parcels: total,
      total_delivered: delivered,
      total_cancelled: Math.max(0, total - delivered),
      success_ratio: r.success_ratio || (total > 0 ? `${((delivered / total) * 100).toFixed(1)}%` : "0.0%"),
    };
  } catch (e) {
    return { provider: "steadfast", ok: false, total_parcels: 0, total_delivered: 0, total_cancelled: 0, success_ratio: "0.0%", error: e instanceof Error ? e.message : "Steadfast failed" };
  }
}

async function scorePathao(prisma: PrismaClient, tenantId: number, phone: string): Promise<ProviderResult> {
  const token = await getMerchantPanelToken(prisma, tenantId);
  if (!token) {
    return { provider: "pathao", ok: false, total_parcels: 0, total_delivered: 0, total_cancelled: 0, success_ratio: "0.0%", error: "Pathao auto-login failed" };
  }
  const callOnce = (jwt: string) =>
    fetch("https://merchant.pathao.com/api/v1/user/success", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${jwt}`,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Origin": "https://merchant.pathao.com",
        "Referer": "https://merchant.pathao.com/courier/orders/create",
      },
      body: JSON.stringify({ phone: formatPhone(phone) }),
      signal: AbortSignal.timeout(15000),
    });
  try {
    let upstream = await callOnce(token);
    // Stale-token recovery — same pattern as parse + customer-history.
    if (upstream.status === 401 || upstream.status === 403) {
      clearMerchantPanelTokenCache(tenantId);
      try {
        await prisma.siteSetting.deleteMany({
          where: { key: { in: ["pathao_web_token_auto", "pathao_web_token_auto_exp"] } },
        });
      } catch {}
      const fresh = await getMerchantPanelToken(prisma, tenantId);
      if (!fresh) {
        return { provider: "pathao", ok: false, total_parcels: 0, total_delivered: 0, total_cancelled: 0, success_ratio: "0.0%", error: "Pathao auto-login failed" };
      }
      upstream = await callOnce(fresh);
    }
    const json = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      return { provider: "pathao", ok: false, total_parcels: 0, total_delivered: 0, total_cancelled: 0, success_ratio: "0.0%", error: (json as { message?: string })?.message || `HTTP ${upstream.status}` };
    }
    const c = (json as { data?: { customer?: { total_delivery?: number; successful_delivery?: number }; customer_rating?: string } }).data;
    const total = Number(c?.customer?.total_delivery || 0);
    const delivered = Number(c?.customer?.successful_delivery || 0);
    return {
      provider: "pathao",
      ok: true,
      total_parcels: total,
      total_delivered: delivered,
      total_cancelled: Math.max(0, total - delivered),
      success_ratio: total > 0 ? `${((delivered / total) * 100).toFixed(1)}%` : "0.0%",
      rating: c?.customer_rating,
    };
  } catch (e) {
    return { provider: "pathao", ok: false, total_parcels: 0, total_delivered: 0, total_cancelled: 0, success_ratio: "0.0%", error: e instanceof Error ? e.message : "Pathao failed" };
  }
}

export async function POST(req: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(req);
  try { await requireStaff(); } catch (e) { return e as Response; }

  const body = await req.json().catch(() => ({}));
  let phone: string | undefined = body.phone;
  let order: { id: number; customerPhone: string } | null = null;

  if (body.order_id) {
    order = await prisma.order.findUnique({ where: { id: Number(body.order_id) }, select: { id: true, customerPhone: true } });
    if (!order) return notFound("Order not found");
    phone = order.customerPhone;
  }

  if (!phone) return errorResponse("phone or order_id required", 400);

  // Fraud-score check intentionally ignores the per-courier Active checkmark.
  // Merchants often disable a courier for dispatch while still wanting its
  // historical fraud data — e.g. Steadfast has years of rider feedback even
  // if the shop has switched to Pathao. Use configured/hasAuth (keys present)
  // instead of enabled (keys + active checkbox).
  // Bust 5-min cache so freshly-saved keys register immediately.
  clearKeyCache();
  clearPathaoCache();
  const [stReady, pxReady] = await Promise.all([isSteadfastConfigured(prisma, tenant.id), hasPathaoAuth(prisma, tenant.id)]);
  if (!stReady && !pxReady) {
    return errorResponse("No courier configured. Go to Settings → Courier.", 400);
  }

  const tasks: Promise<ProviderResult>[] = [];
  if (stReady) tasks.push(scoreSteadfast(prisma, tenant.id, phone));
  if (pxReady) tasks.push(scorePathao(prisma, tenant.id, phone));
  const providers = await Promise.all(tasks);

  // Combined aggregate (sum across successful providers)
  const okProviders = providers.filter(p => p.ok && p.total_parcels > 0);
  const total = okProviders.reduce((s, p) => s + p.total_parcels, 0);
  const delivered = okProviders.reduce((s, p) => s + p.total_delivered, 0);
  const cancelled = Math.max(0, total - delivered);
  const ratio = total > 0 ? `${((delivered / total) * 100).toFixed(1)}%` : "0.0%";

  // Persist combined ratio on the order (when order_id given and any provider succeeded)
  if (order && total > 0) {
    await prisma.order.update({ where: { id: order.id }, data: { courierScore: ratio } });
  }

  // Surface a useful error if every provider failed
  const allFailed = providers.length > 0 && providers.every(p => !p.ok);
  const message = allFailed ? providers.map(p => `${p.provider}: ${p.error}`).join(" · ") : undefined;

  return jsonResponse({
    success: !allFailed,
    message,
    total_parcels: total,
    total_delivered: delivered,
    total_cancelled: cancelled,
    success_ratio: ratio,
    providers,
  });
}

