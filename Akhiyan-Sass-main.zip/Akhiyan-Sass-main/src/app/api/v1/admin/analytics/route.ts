/**
 * GET /api/v1/admin/analytics?from=YYYY-MM-DD&to=YYYY-MM-DD
 * Tenant storefront analytics for a date range (orders/products derived).
 * Dates are interpreted as Bangladesh-local (UTC+6) day boundaries so buckets
 * line up with the tenant's calendar. Defaults to today.
 */
import { NextRequest } from "next/server";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { requireStaff } from "@/lib/auth-helpers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { computeAnalytics, type CompareMode } from "@/lib/store-analytics";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try { await requireStaff(); } catch (e) { return e as Response; }

  const sp = new URL(request.url).searchParams;
  const fromStr = sp.get("from");
  const toStr = sp.get("to");
  const now = new Date();
  const bdToday = new Date(now.getTime() + 6 * 3600 * 1000).toISOString().slice(0, 10);

  const from = new Date(`${fromStr || bdToday}T00:00:00+06:00`);
  const to = toStr ? new Date(`${toStr}T23:59:59+06:00`) : now;
  if (isNaN(from.getTime()) || isNaN(to.getTime()) || from > to) {
    return errorResponse("Invalid date range", 400);
  }

  const raw = sp.get("compare");
  const compareMode: CompareMode = raw === "none" || raw === "year" ? raw : "previous";

  try {
    const data = await computeAnalytics(prisma, from, to, compareMode);
    return jsonResponse(data);
  } catch (e) {
    console.error("[analytics] compute failed:", e);
    return errorResponse("Failed to compute analytics", 500);
  }
}
