import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse, errorResponse } from "@/lib/api-response";
import { requireAdmin } from "@/lib/auth-helpers";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireAdmin(); } catch (e) { return e as Response; }

  try {
    const submissions = await prisma.formSubmission.findMany({
      orderBy: { createdAt: "desc" },
    });
    return jsonResponse(submissions.map(serialize));
  } catch {
    return errorResponse("Failed to fetch submissions", 500);
  }
}
