import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse, errorResponse, notFound } from "@/lib/api-response";
import { requireAdmin } from "@/lib/auth-helpers";
import { broadcastToTenant } from "@/lib/realtime";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireAdmin(); } catch (e) { return e as Response; }

  const { id } = await params;
  const data = await request.json();

  try {
    const submission = await prisma.formSubmission.update({
      where: { id: Number(id) },
      data: {
        status: data.status || undefined,
        notes: data.notes !== undefined ? data.notes : undefined,
      },
    });
    broadcastToTenant(tenant.id, "form_submissions", "changed", { id: submission.id });
    return jsonResponse(serialize(submission));
  } catch {
    return notFound("Submission not found");
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  let admin;
  try { admin = await requireAdmin(); } catch (e) { return e as Response; }

  const { id } = await params;

  try {
    await prisma.formSubmission.delete({ where: { id: Number(id) } });
    broadcastToTenant(tenant.id, "form_submissions", "deleted", { id: Number(id) });
    return jsonResponse({ message: "Deleted" });
  } catch {
    return notFound("Submission not found");
  }
}
