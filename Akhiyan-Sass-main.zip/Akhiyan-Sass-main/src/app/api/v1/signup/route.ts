/**
 * POST /api/v1/signup — public self-serve store signup.
 *
 * Creates a SignupOrder (status=pending). NO Neon project is provisioned here —
 * a super admin reviews + provisions from the superadmin console. The affiliate
 * code is read from the httpOnly `aff` cookie so the visitor can't spoof it,
 * and carried onto the order for commission attribution at provision time.
 */

import { NextRequest } from "next/server";
import { controlPrisma } from "@/lib/prisma-control";
import { AFFILIATE_COOKIE } from "@/lib/affiliate";

export const runtime = "nodejs";

const SLUG_RE = /^[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?$/;
const BD_PHONE_RE = /^01[3-9]\d{8}$/;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const storeName = String(body.storeName || "").trim();
  const slug = String(body.slug || "").trim().toLowerCase();
  const ownerName = String(body.ownerName || "").trim();
  const ownerEmail = String(body.ownerEmail || "").trim().toLowerCase();
  const phone = String(body.phone || "").trim();
  const plan = String(body.plan || "starter").trim();

  if (!storeName) return Response.json({ message: "Store name is required." }, { status: 400 });
  if (!SLUG_RE.test(slug))
    return Response.json({ message: "Store address must be lowercase a–z, 0–9, hyphens (2–32 chars)." }, { status: 400 });
  if (!ownerEmail.includes("@")) return Response.json({ message: "Enter a valid email." }, { status: 400 });
  if (phone && !BD_PHONE_RE.test(phone))
    return Response.json({ message: "Enter a valid 11-digit phone (01XXXXXXXXX)." }, { status: 400 });

  // Slug must be free among live tenants…
  const tenantClash = await controlPrisma.tenant.findUnique({ where: { slug }, select: { id: true } });
  if (tenantClash)
    return Response.json({ message: `"${slug}" is already taken — choose another store address.` }, { status: 409 });

  // …and not already requested in a still-open order.
  const openOrder = await controlPrisma.signupOrder.findFirst({
    where: { slug, status: { in: ["pending", "paid"] } },
    select: { id: true },
  });
  if (openOrder)
    return Response.json({ message: `"${slug}" is already being set up — choose another store address.` }, { status: 409 });

  // Validate the plan exists (fall back to first active if unknown).
  const planRow = await controlPrisma.plan.findUnique({ where: { slug: plan }, select: { slug: true } });
  const planSlug = planRow?.slug ?? "starter";

  // Affiliate attribution: trust ONLY the httpOnly cookie, never the request body.
  const affCookie = req.cookies.get(AFFILIATE_COOKIE)?.value || null;
  let affCode: string | null = null;
  if (affCookie) {
    const aff = await controlPrisma.affiliate.findUnique({
      where: { code: affCookie.toUpperCase() },
      select: { code: true, status: true },
    });
    if (aff && aff.status === "active") affCode = aff.code;
  }

  const order = await controlPrisma.signupOrder.create({
    data: {
      storeName,
      slug,
      ownerName: ownerName || null,
      ownerEmail,
      phone: phone || null,
      plan: planSlug,
      affCode,
      status: "pending",
    },
  });

  return Response.json({ ok: true, orderId: order.id, slug: order.slug }, { status: 201 });
}
