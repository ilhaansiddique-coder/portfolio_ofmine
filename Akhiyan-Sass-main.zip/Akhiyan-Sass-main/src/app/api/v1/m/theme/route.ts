/**
 * GET /api/v1/m/theme
 *
 * Returns the tenant's active theme tokens shaped for the Flutter admin app's
 * `LiveTheme.fromJson` contract:
 *
 *   {
 *     colors:  { primary, primary_light, primary_dark, ..., badge_green }  // hex strings
 *     fonts:   { body, heading, size_base, line_height }                    // mixed string/num
 *     radius:  { sm, md, lg, xl }                                           // numbers (dp)
 *     spacing: { container_max_width, section_y }                           // numbers (dp/px)
 *     branding:{ site_logo, favicon, site_name }                            // string | null
 *   }
 *
 * Public-shaped — no admin auth required (only version bumps are emitted
 * over SSE; the colour palette itself is never sensitive). The Flutter app
 * still sends Bearer tokens on every request via AkhiyanApi, but this
 * endpoint does NOT enforce auth so first-launch theming works before login.
 */

import { NextRequest, NextResponse } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { TOKENS } from "@/lib/theme-tokens";

const BRANDING_KEYS = ["site_logo", "favicon", "site_name"];

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);

  // Load all theme.* tokens plus branding keys in one query.
  const themeKeys = TOKENS.map((t) => t.key);
  const rows = await prisma.siteSetting.findMany({
    where: { key: { in: [...themeKeys, ...BRANDING_KEYS] } },
    select: { key: true, value: true },
  });

  const db: Record<string, string | null> = {};
  for (const { key, value } of rows) db[key] = value;

  // Helper — effective value = DB row ?? token default ?? null
  const eff = (tokenKey: string, def?: string): string =>
    (db[tokenKey] ?? "").trim() || (def ?? "");

  // ─── Colors ────────────────────────────────────────────────────────────────
  const colors: Record<string, string> = {};
  for (const t of TOKENS.filter((t) => t.type === "color")) {
    // "theme.color.primary" → "primary"
    const shortKey = t.key.replace(/^theme\.color\./, "");
    colors[shortKey] = eff(t.key, t.default);
  }

  // ─── Fonts ─────────────────────────────────────────────────────────────────
  const fonts: Record<string, string | number> = {};
  for (const t of TOKENS.filter((t) => t.group.startsWith("typography."))) {
    // "theme.font.body" → "body", "theme.font.size_base" → "size_base"
    const shortKey = t.key.replace(/^theme\.font\./, "");
    const raw = eff(t.key, t.default);
    if (t.type === "size") {
      fonts[shortKey] = parseFloat(raw) || parseFloat(t.default);
    } else {
      fonts[shortKey] = raw;
    }
  }

  // ─── Radius ────────────────────────────────────────────────────────────────
  const radius: Record<string, number> = {};
  for (const t of TOKENS.filter((t) => t.group === "layout.radius")) {
    // "theme.radius.sm" → "sm"
    const shortKey = t.key.replace(/^theme\.radius\./, "");
    radius[shortKey] = parseFloat(eff(t.key, t.default)) || parseFloat(t.default);
  }

  // ─── Spacing ───────────────────────────────────────────────────────────────
  const spacing: Record<string, number> = {};
  for (const t of TOKENS.filter((t) => t.group === "layout.spacing")) {
    // "theme.spacing.section_y" → "section_y"
    // "theme.container.max_width" → "container_max_width" (flatten dot → underscore)
    const shortKey = t.key
      .replace(/^theme\.(spacing|container)\./, "")
      .replace(/\./g, "_");
    spacing[shortKey] = parseFloat(eff(t.key, t.default)) || parseFloat(t.default);
  }

  // ─── Branding ──────────────────────────────────────────────────────────────
  const branding: Record<string, string | null> = {
    site_logo: db["site_logo"] ?? null,
    favicon: db["favicon"] ?? null,
    site_name: db["site_name"] ?? null,
  };

  return NextResponse.json({ colors, fonts, radius, spacing, branding });
}
