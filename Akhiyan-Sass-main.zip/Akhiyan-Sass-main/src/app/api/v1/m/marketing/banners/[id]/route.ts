export { DELETE, PUT } from "@/app/api/v1/admin/banners/[id]/route";
export { PUT as PATCH } from "@/app/api/v1/admin/banners/[id]/route";

