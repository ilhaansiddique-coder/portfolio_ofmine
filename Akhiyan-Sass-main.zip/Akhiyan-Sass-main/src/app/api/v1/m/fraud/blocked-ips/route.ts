import { NextRequest } from "next/server";
import { requireStaff } from "@/lib/auth-helpers";
import { jsonResponse, validationError } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";

export { GET } from "@/app/api/v1/admin/spam/blocked-ips/route";

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const body = await request.json();
  const ip = String(body.ipAddress || body.ip_address || "").trim();
  if (!ip) return validationError({ ipAddress: ["IP address is required"] });

  const blocked = await prisma.blockedIp.upsert({
    where: { ipAddress: ip },
    update: { reason: body.reason ? String(body.reason) : "manual_block" },
    create: { ipAddress: ip, reason: body.reason ? String(body.reason) : "manual_block" },
  });
  return jsonResponse({ data: serialize(blocked) }, 201);
}

export async function DELETE(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const ip = request.nextUrl.searchParams.get("ip")?.trim();
  if (!ip) return validationError({ ip: ["IP address is required"] });
  await prisma.blockedIp.deleteMany({ where: { ipAddress: ip } });
  return jsonResponse({ success: true });
}

