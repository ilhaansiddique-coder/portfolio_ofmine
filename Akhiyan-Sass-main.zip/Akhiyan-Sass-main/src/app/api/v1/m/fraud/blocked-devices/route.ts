import { NextRequest } from "next/server";
import { requireStaff } from "@/lib/auth-helpers";
import { jsonResponse, validationError } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";

export { GET } from "@/app/api/v1/admin/spam/devices/route";

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const body = await request.json();
  const fpHash = String(body.fpHash || body.fp_hash || "").trim();
  if (!fpHash) return validationError({ fpHash: ["Device fingerprint is required"] });

  const device = await prisma.deviceFingerprint.upsert({
    where: { fpHash },
    update: {
      status: "blocked",
      blockReason: body.reason ? String(body.reason) : "manual_block",
      blockedAt: new Date(),
    },
    create: {
      fpHash,
      status: "blocked",
      blockReason: body.reason ? String(body.reason) : "manual_block",
      blockedAt: new Date(),
    },
  });
  return jsonResponse({ data: serialize(device) }, 201);
}

export async function DELETE(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const fpHash = request.nextUrl.searchParams.get("fpHash")?.trim();
  if (!fpHash) return validationError({ fpHash: ["Device fingerprint is required"] });
  await prisma.deviceFingerprint.updateMany({
    where: { fpHash },
    data: { status: "active", blockReason: null, blockedAt: null },
  });
  return jsonResponse({ success: true });
}

