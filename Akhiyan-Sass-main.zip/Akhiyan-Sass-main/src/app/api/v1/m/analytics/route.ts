export { GET } from "@/app/api/v1/admin/dashboard/route";

