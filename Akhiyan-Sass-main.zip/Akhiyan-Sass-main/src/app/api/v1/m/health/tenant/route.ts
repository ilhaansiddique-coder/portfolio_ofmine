import { requireStaff } from "@/lib/auth-helpers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";

export async function GET(req: Request) {
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const { prisma, tenant } = await getPrismaForRequest(req);
  const productCount = await prisma.product.count();

  return Response.json({
    data: {
      ok: true,
      tenant: {
        id: tenant.id,
        slug: tenant.slug,
        name: tenant.name,
        primaryDomain: tenant.primaryDomain,
        status: tenant.status,
      },
      productCount,
      hostHeader: req.headers.get("host"),
    },
  });
}

