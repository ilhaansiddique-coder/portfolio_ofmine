import { NextRequest } from "next/server";
import { requireStaff } from "@/lib/auth-helpers";
import { errorResponse, notFound, validationError } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const { id } = await params;
  const body = await request.json();
  const existing = await prisma.product.findUnique({ where: { id: Number(id) } });
  if (!existing) return notFound("Product not found");

  const hasStock = body.stock !== undefined && body.stock !== null;
  const hasDelta = body.delta !== undefined && body.delta !== null;
  if (!hasStock && !hasDelta) return validationError({ stock: ["Stock or delta is required"] });

  const nextStock = hasStock ? Number(body.stock) : existing.stock + Number(body.delta);
  if (!Number.isFinite(nextStock)) return validationError({ stock: ["Stock must be a number"] });

  try {
    const product = await prisma.product.update({
      where: { id: Number(id) },
      data: { stock: Math.max(0, Math.trunc(nextStock)) },
    });
    return mobileData(product);
  } catch {
    return errorResponse("Failed to update stock", 500);
  }
}

