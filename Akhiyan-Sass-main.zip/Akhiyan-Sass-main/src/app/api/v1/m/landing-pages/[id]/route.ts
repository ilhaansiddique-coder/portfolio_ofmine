export { DELETE, GET, PUT } from "@/app/api/v1/admin/landing-pages/[id]/route";

