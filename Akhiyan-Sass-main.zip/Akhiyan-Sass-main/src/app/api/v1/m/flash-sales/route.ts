export { GET, POST } from "@/app/api/v1/admin/flash-sales/route";

