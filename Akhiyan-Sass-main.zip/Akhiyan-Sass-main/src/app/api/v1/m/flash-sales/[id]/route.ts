import { requireAdmin } from "@/lib/auth-helpers";
import { notFound } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";

export { DELETE, PUT } from "@/app/api/v1/admin/flash-sales/[id]/route";
export { PUT as PATCH } from "@/app/api/v1/admin/flash-sales/[id]/route";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { prisma } = await getPrismaForRequest(req);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }
  const { id } = await params;
  const flashSale = await prisma.flashSale.findUnique({
    where: { id: Number(id) },
    include: { products: true },
  });
  if (!flashSale) return notFound("Flash sale not found");
  return mobileData(flashSale);
}

