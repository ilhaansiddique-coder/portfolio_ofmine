import { requireAdmin } from "@/lib/auth-helpers";
import { notFound } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";
import { findMobileUser } from "@/lib/mobile-app/users";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { prisma } = await getPrismaForRequest(req);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  const { id } = await params;
  const user = await findMobileUser(prisma, id);
  if (!user || user.role !== "customer") return notFound("Customer not found");
  return mobileData(user);
}

