import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/auth-helpers";
import { jsonResponse } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { paginatedResponse } from "@/lib/paginate";
import { mobileUserSelect } from "@/lib/mobile-app/users";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  const { searchParams } = request.nextUrl;
  const page = Math.max(1, Number(searchParams.get("page")) || 1);
  const perPage = Math.min(100, Math.max(1, Number(searchParams.get("pageSize")) || 20));
  const search = searchParams.get("q") || searchParams.get("search");

  const where = {
    role: "customer",
    ...(search
      ? {
          OR: [
            { name: { contains: search, mode: "insensitive" as const } },
            { email: { contains: search, mode: "insensitive" as const } },
            { phone: { contains: search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };

  const [customers, total] = await Promise.all([
    prisma.user.findMany({
      where,
      select: mobileUserSelect(),
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    prisma.user.count({ where }),
  ]);

  return jsonResponse(paginatedResponse(customers, { page, perPage, total }));
}

