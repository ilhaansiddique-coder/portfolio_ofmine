export { GET, PUT } from "@/app/api/v1/admin/feeds/route";

