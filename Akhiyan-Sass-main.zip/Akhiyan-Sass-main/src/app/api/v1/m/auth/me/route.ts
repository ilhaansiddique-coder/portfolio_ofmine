import { getSessionUser } from "@/lib/auth";
import { unauthorized } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";

export async function GET(req: Request) {
  const sessionUser = await getSessionUser();
  if (!sessionUser) return unauthorized();
  const { prisma, tenant } = await getPrismaForRequest(req);

  // Mobile app reads  to build per-tenant Soketi channel names
  // ( etc). Resolved server-side from the request
  // host — never trusted from the client. Slug is included for human
  // display only.
  const tenantBlock = { id: tenant.id, slug: tenant.slug };

  if (sessionUser.id < 0) {
    return mobileData({
      id: sessionUser.id,
      name: sessionUser.name,
      email: sessionUser.email,
      phone: sessionUser.phone,
      role: sessionUser.role,
      avatar: null,
      createdAt: null,
      tenant: tenantBlock,
    });
  }

  const user = await prisma.user.findUnique({
    where: { id: sessionUser.id },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      role: true,
      avatar: true,
      createdAt: true,
    },
  });

  if (!user) return unauthorized();
  return mobileData({ ...user, tenant: tenantBlock });
}
