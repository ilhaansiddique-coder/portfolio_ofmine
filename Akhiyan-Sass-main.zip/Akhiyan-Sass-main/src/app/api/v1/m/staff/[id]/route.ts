import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/auth-helpers";
import { errorResponse, notFound } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData, mobileOk } from "@/lib/mobile-app/response";
import { findMobileUser, mobileUserSelect } from "@/lib/mobile-app/users";

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  const { id } = await params;
  const existing = await findMobileUser(prisma, id);
  if (!existing || !["admin", "staff"].includes(existing.role)) return notFound("Staff member not found");

  const body = await request.json();
  try {
    const user = await prisma.user.update({
      where: { id: Number(id) },
      data: {
        ...(body.name ? { name: String(body.name) } : {}),
        ...(body.phone !== undefined ? { phone: body.phone ? String(body.phone) : null } : {}),
        ...(body.role ? { role: body.role === "admin" ? "admin" : "staff" } : {}),
      },
      select: mobileUserSelect(),
    });
    return mobileData(user);
  } catch {
    return errorResponse("Failed to update staff member", 500);
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { prisma } = await getPrismaForRequest(req);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  const { id } = await params;
  const existing = await findMobileUser(prisma, id);
  if (!existing || !["admin", "staff"].includes(existing.role)) return notFound("Staff member not found");
  await prisma.user.delete({ where: { id: Number(id) } });
  return mobileOk({ success: true });
}

