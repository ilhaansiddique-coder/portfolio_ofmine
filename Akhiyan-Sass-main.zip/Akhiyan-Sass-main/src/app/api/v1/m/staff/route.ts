import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { requireAdmin } from "@/lib/auth-helpers";
import { errorResponse, jsonResponse, validationError } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";
import { mobileUserSelect } from "@/lib/mobile-app/users";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  const users = await prisma.user.findMany({
    where: { role: { in: ["admin", "staff"] } },
    select: mobileUserSelect(),
    orderBy: { createdAt: "desc" },
  });
  return mobileData(users);
}

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  const body = await request.json();
  if (!body.name || !body.email || !body.password) {
    return validationError({ email: ["Name, email, and password are required."] });
  }

  try {
    const user = await prisma.user.create({
      data: {
        name: String(body.name),
        email: String(body.email),
        password: await bcrypt.hash(String(body.password), 10),
        phone: body.phone ? String(body.phone) : null,
        role: body.role === "admin" ? "admin" : "staff",
      },
      select: mobileUserSelect(),
    });
    return mobileData(user, 201);
  } catch {
    return errorResponse("Failed to create staff member", 500);
  }
}

