import { requireAdmin } from "@/lib/auth-helpers";
import { notFound } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";

export { DELETE, PUT } from "@/app/api/v1/admin/coupons/[id]/route";
export { PUT as PATCH } from "@/app/api/v1/admin/coupons/[id]/route";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { prisma } = await getPrismaForRequest(req);
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }
  const { id } = await params;
  const coupon = await prisma.coupon.findUnique({ where: { id: Number(id) } });
  if (!coupon) return notFound("Coupon not found");
  return mobileData(coupon);
}

