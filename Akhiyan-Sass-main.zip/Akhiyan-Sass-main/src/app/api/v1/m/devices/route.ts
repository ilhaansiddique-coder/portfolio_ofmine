/**
 * Mobile device token registry for FCM push notifications.
 *
 * POST   /api/v1/m/devices  { token, platform? }  — upsert
 * DELETE /api/v1/m/devices  { token }             — drop on logout
 *
 * Per-tenant DB resolved from the request host means each tenant's
 * device_tokens table is naturally isolated — no tenantId column
 * needed, no cross-tenant leak risk. Auth: any logged-in admin/staff.
 */
import { getSessionUser } from "@/lib/auth";
import { unauthorized, jsonResponse } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { prisma } = await getPrismaForRequest(req);
  const body = (await req.json().catch(() => ({}))) as {
    token?: string;
    platform?: string;
  };
  const token = (body.token || "").trim();
  if (!token) return jsonResponse({ message: "token required" }, 400);
  const platform = body.platform === "ios" ? "ios" : "android";

  // Synthetic super-admin sessions (impersonation) carry negative ids;
  // skip the device-register so we don't pollute the tenant's token list
  // with the super-admin's phone.
  if (user.id < 0) return jsonResponse({ ok: true, skipped: true });

  await prisma.deviceToken.upsert({
    where: { token },
    create: { token, platform, userId: user.id },
    update: { userId: user.id, platform },
  });
  return jsonResponse({ ok: true });
}

export async function DELETE(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const { prisma } = await getPrismaForRequest(req);
  const body = (await req.json().catch(() => ({}))) as { token?: string };
  const token = (body.token || "").trim();
  if (!token) return jsonResponse({ message: "token required" }, 400);
  // Scope delete to the requesting user so one user's logout can't drop
  // another user's tokens (would-be enumeration attack).
  await prisma.deviceToken.deleteMany({
    where: { token, userId: user.id },
  });
  return jsonResponse({ ok: true });
}
