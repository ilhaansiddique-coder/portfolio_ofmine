import { pushToTokens, isFcmConfigured } from "@/lib/fcm";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { jsonResponse } from "@/lib/api-response";

export const runtime = "nodejs";

export async function POST(req: Request) {
  if (!isFcmConfigured()) {
    return jsonResponse({ ok: false, reason: "fcm not configured" }, 500);
  }
  const { prisma } = await getPrismaForRequest(req);
  const rows = await prisma.deviceToken.findMany({ select: { token: true } });
  if (rows.length === 0) {
    return jsonResponse({ ok: false, reason: "no tokens" });
  }
  const tokens = rows.map((r: { token: string }) => r.token);
  const result = await pushToTokens(tokens, {
    kind: "order.created",
    title: "Debug push",
    body: "If you see this, FCM works",
  });
  return jsonResponse({
    ok: true,
    tokenCount: tokens.length,
    tokenSample: tokens[0].slice(0, 12) + "...",
    result,
  });
}
