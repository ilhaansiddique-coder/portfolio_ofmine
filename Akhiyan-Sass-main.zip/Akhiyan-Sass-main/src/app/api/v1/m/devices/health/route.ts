/**
 * Diagnostic endpoint for the mobile push + live-sync pipeline.
 * Returns FCM + Soketi configured-flags + the PUBLIC Soketi values
 * the Flutter client needs (key/host/port/tls). Never exposes the
 * secret. No-auth so quick local probing works.
 */
import { isFcmConfigured } from "@/lib/fcm";
import { isRealtimeConfigured } from "@/lib/realtime";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { jsonResponse } from "@/lib/api-response";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const { prisma, tenant } = await getPrismaForRequest(req);
  const count = await prisma.deviceToken.count();
  return jsonResponse({
    fcm_configured: isFcmConfigured(),
    soketi: {
      configured: isRealtimeConfigured(),
      // Public values the Flutter client needs in dart_define.json.
      // App secret is intentionally omitted.
      key: process.env.SOKETI_APP_KEY || process.env.SOKETI_KEY || null,
      host: process.env.SOKETI_HOST || null,
      port: process.env.SOKETI_PORT || process.env.NEXT_PUBLIC_SOKETI_PORT || null,
      tls: process.env.SOKETI_TLS || null,
    },
    tenant_id: tenant.id,
    tenant_slug: tenant.slug,
    device_token_count: count,
  });
}
