/**
 * GET /api/v1/m/admin/settings
 * PUT /api/v1/m/admin/settings
 *
 * Mobile re-export of the admin settings endpoint. The Flutter legacy client
 * calls `/admin/settings` relative to its base URL (`/api/v1/m`) which
 * resolves to this path.
 *
 * Requires admin authentication (enforced by the upstream handler).
 */
export { GET, PUT } from "@/app/api/v1/admin/settings/route";
