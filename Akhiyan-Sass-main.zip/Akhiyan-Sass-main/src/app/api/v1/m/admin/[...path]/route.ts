import { NextRequest } from "next/server";

async function forwardToAdmin(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const { path } = await params;
  const incomingUrl = new URL(request.url);
  const host = request.headers.get("host") || incomingUrl.host;
  const proto = request.headers.get("x-forwarded-proto") || incomingUrl.protocol.replace(":", "");
  const url = new URL(`${proto}://${host}/api/v1/admin/${path.join("/")}`);
  url.search = incomingUrl.search;

  const init: RequestInit = {
    method: request.method,
    headers: request.headers,
    redirect: "manual",
  };

  if (request.method !== "GET" && request.method !== "HEAD") {
    init.body = await request.text();
  }

  const upstream = await fetch(url, init);
  const headers = new Headers(upstream.headers);
  headers.delete("content-encoding");
  headers.delete("content-length");

  return new Response(upstream.body, {
    status: upstream.status,
    statusText: upstream.statusText,
    headers,
  });
}

export const GET = forwardToAdmin;
export const POST = forwardToAdmin;
export const PUT = forwardToAdmin;
export const PATCH = forwardToAdmin;
export const DELETE = forwardToAdmin;
