/**
 * GET /api/v1/m/sync/stream
 *
 * Mobile re-export of the SSE version-sync feed (`/api/v1/sync/stream`).
 * Served under the /m namespace so the Flutter app shares the same base URL
 * + CORS handling (the proxy applies mobile CORS headers to /api/v1/m/*).
 *
 * Same wire format: `data: {"channel":"orders","version":N}\n\n` plus a
 * `: ping` heartbeat every 25s. The stream is unauthenticated (it only emits
 * version bumps, never data); the app reacts by refetching over the
 * authenticated /m HTTP endpoints, which ARE tenant-scoped.
 */
export { GET } from "@/app/api/v1/sync/stream/route";

// Re-declare the route segment config explicitly — Next reads these as named
// exports of THIS module, so they can't be relied on to flow through the
// `export { GET } from` re-export above.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
