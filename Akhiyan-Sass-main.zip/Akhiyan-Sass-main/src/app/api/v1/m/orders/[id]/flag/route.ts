import { NextRequest } from "next/server";
import { requireStaff } from "@/lib/auth-helpers";
import { errorResponse, notFound } from "@/lib/api-response";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { mobileData } from "@/lib/mobile-app/response";

async function setRisk(req: Request, id: string, riskScore: number | null) {
  const { prisma } = await getPrismaForRequest(req);
  try {
    await requireStaff();
  } catch (e) {
    return e as Response;
  }

  const existing = await prisma.order.findUnique({ where: { id: Number(id) } });
  if (!existing) return notFound("Order not found");

  try {
    const order = await prisma.order.update({
      where: { id: Number(id) },
      data: { riskScore },
      include: { items: true },
    });
    return mobileData(order);
  } catch {
    return errorResponse("Failed to update order flag", 500);
  }
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return setRisk(request, id, 100);
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return setRisk(request, id, null);
}

