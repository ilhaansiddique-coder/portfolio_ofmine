import { NextRequest } from "next/server";
import { POST as pathaoPost } from "@/app/api/v1/admin/courier/pathao/route";
import { POST as steadfastPost } from "@/app/api/v1/admin/courier/route";

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await request.json().catch(() => ({}));
  const courier = String(body.courier || "steadfast").toLowerCase();

  const forwarded = new Request(request.url, {
    method: "POST",
    headers: request.headers,
    body: JSON.stringify({
      order_id: Number(id),
      ...(body.payload ? { payload: body.payload } : {}),
    }),
  }) as NextRequest;

  const response = courier === "pathao"
    ? await pathaoPost(forwarded)
    : await steadfastPost(forwarded);

  const json = await response.json().catch(() => null);
  if (!response.ok) {
    return Response.json(json ?? { message: "Courier dispatch failed" }, { status: response.status });
  }

  return Response.json({
    data: json?.order ?? json,
    courier: courier === "pathao" ? "pathao" : "steadfast",
    consignment_id: json?.consignment_id,
    message: json?.message,
  }, { status: response.status });
}

