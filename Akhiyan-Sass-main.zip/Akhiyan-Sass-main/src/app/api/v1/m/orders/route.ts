export { GET } from "@/app/api/v1/admin/orders/route";
import { NextRequest } from "next/server";
import { POST as createOrder } from "@/app/api/v1/orders/route";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));

  // Normalise items: camelCase → snake_case product_id / variant_id
  const rawItems: Record<string, unknown>[] = Array.isArray(body.items)
    ? body.items.map((item: Record<string, unknown>) => ({
        ...item,
        product_id: item.product_id ?? item.productId,
        variant_id: item.variant_id ?? item.variantId,
      }))
    : [];

  // Flutter client doesn't send subtotal / total (server recalculates them
  // anyway, but the Zod schema requires them). Derive from items so
  // validation passes — server-side values win after schema parse.
  const shippingCost =
    Number(body.shipping_cost ?? body.shippingCost ?? 0) || 0;
  const discount = Number(body.discount ?? 0) || 0;
  const subtotal = rawItems.reduce((sum, item) => {
    const price = Number(item.price ?? 0) || 0;
    const qty = Number(item.quantity ?? 1) || 1;
    return sum + price * qty;
  }, 0);
  const total = Math.max(0, subtotal + shippingCost - discount);

  // Must be NextRequest (not plain Request) — the orders handler accesses
  // request.cookies for spam/fingerprint detection. A plain `new Request()`
  // cast to NextRequest has no real .cookies getter → TypeError → 500.
  const forwarded = new NextRequest(request.url, {
    method: "POST",
    headers: request.headers,
    body: JSON.stringify({
      ...body,
      customer_name: body.customer_name ?? body.customerName,
      customer_phone: body.customer_phone ?? body.customerPhone,
      customer_email: body.customer_email ?? body.customerEmail,
      customer_address: body.customer_address ?? body.customerAddress,
      zip_code: body.zip_code ?? body.zipCode,
      shipping_cost: shippingCost,
      payment_method: body.payment_method ?? body.paymentMethod,
      discount,
      subtotal,
      total,
      items: rawItems,
    }),
  });

  return createOrder(forwarded);
}
