import { mobileData } from "@/lib/mobile-app/response";

// Order-status filter options for the mobile app's "All Status" dropdown.
// MUST stay in sync with the web dashboard's `useStatusOptions()` in
// src/app/(site)/dashboard/orders/OrdersClient.tsx — same keys, same
// order — so the mobile filter matches the website exactly. The "All
// Status" (empty value) row is added by the client UI, not listed here.
export async function GET() {
  return mobileData([
    { key: "pending", label: "Pending" },
    { key: "processing", label: "Processing" },
    { key: "on_hold", label: "On Hold" },
    { key: "confirmed", label: "Confirmed" },
    { key: "shipped", label: "Shipped" },
    { key: "delivered", label: "Delivered" },
    { key: "exchange", label: "Exchange" },
    { key: "partial", label: "Partial" },
    { key: "cancelled", label: "Cancelled" },
    { key: "trashed", label: "Trash" },
  ]);
}
