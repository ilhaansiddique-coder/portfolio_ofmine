export { POST } from "@/app/api/v1/orders/[id]/cancel/route";

