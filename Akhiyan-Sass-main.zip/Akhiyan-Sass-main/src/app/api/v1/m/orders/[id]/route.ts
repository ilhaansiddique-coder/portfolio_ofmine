export { DELETE, GET, PUT } from "@/app/api/v1/admin/orders/[id]/route";
export { PUT as PATCH } from "@/app/api/v1/admin/orders/[id]/route";

