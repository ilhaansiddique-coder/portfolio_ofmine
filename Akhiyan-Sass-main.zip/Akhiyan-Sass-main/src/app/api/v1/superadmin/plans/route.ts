/**
 * GET  /api/v1/superadmin/plans  — list plans (sortOrder asc, then name)
 * POST /api/v1/superadmin/plans  — create a new plan
 *
 * Body for POST:
 *   { slug, name, description?, features?, priceMonthly?, priceYearly?,
 *     isActive?, sortOrder? }
 */
import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { sanitizeFeatures } from "@/lib/tenant-features";
import { errorResponse, jsonResponse } from "@/lib/api-response";

export const runtime = "nodejs";

const SLUG_RE = /^[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?$/;

export async function GET() {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const plans = await controlPrisma.plan.findMany({
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });
  return jsonResponse({ plans });
}

export async function POST(req: Request) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return errorResponse("Please send a valid request body.", 400); }

  const slug = String(body.slug || "").trim().toLowerCase();
  const name = String(body.name || "").trim();
  if (!SLUG_RE.test(slug)) {
    return errorResponse("Slug must be 1–32 lowercase letters, numbers, or dashes.", 422, { code: "invalid_slug" });
  }
  if (!name || name.length < 2) {
    return errorResponse("Plan name is required.", 422, { code: "invalid_name" });
  }

  const exists = await controlPrisma.plan.findUnique({ where: { slug } });
  if (exists) return errorResponse(`A plan with slug "${slug}" already exists.`, 409, { code: "duplicate_slug" });

  const plan = await controlPrisma.plan.create({
    data: {
      slug,
      name,
      description: typeof body.description === "string" ? body.description.trim() : null,
      features: sanitizeFeatures(body.features),
      priceMonthly: typeof body.priceMonthly === "number" ? body.priceMonthly : null,
      priceYearly: typeof body.priceYearly === "number" ? body.priceYearly : null,
      isActive: body.isActive === false ? false : true,
      sortOrder: typeof body.sortOrder === "number" ? body.sortOrder : 0,
    },
  });

  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      action: "plan.create",
      details: { planId: plan.id, slug: plan.slug, name: plan.name },
    },
  });

  return jsonResponse({ plan });
}
