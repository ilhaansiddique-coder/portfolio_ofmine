/**
 * GET    /api/v1/superadmin/plans/:id — read one
 * PATCH  /api/v1/superadmin/plans/:id — update fields
 * DELETE /api/v1/superadmin/plans/:id — delete (only if no tenants are on it)
 *
 * PATCH body accepts any subset of:
 *   { name, description, features, priceMonthly, priceYearly, isActive, sortOrder }
 *
 * Slug is immutable — changing it would break tenant.plan references
 * stored as the slug string.
 */
import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { sanitizeFeatures } from "@/lib/tenant-features";
import { errorResponse, jsonResponse, notFound } from "@/lib/api-response";

export const runtime = "nodejs";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const plan = await controlPrisma.plan.findUnique({ where: { id: Number(id) } });
  if (!plan) return notFound("Plan not found.");

  // Count of tenants currently using this plan (by slug match).
  const tenantCount = await controlPrisma.tenant.count({ where: { plan: plan.slug } });
  return jsonResponse({ plan, tenantCount });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const plan = await controlPrisma.plan.findUnique({ where: { id: Number(id) } });
  if (!plan) return notFound("Plan not found.");

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return errorResponse("Please send a valid request body.", 400); }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const data: any = {};
  if (typeof body.name === "string" && body.name.trim()) data.name = body.name.trim();
  if (typeof body.description === "string") data.description = body.description.trim() || null;
  if ("features" in body) data.features = sanitizeFeatures(body.features);
  if (typeof body.priceMonthly === "number") data.priceMonthly = body.priceMonthly;
  else if (body.priceMonthly === null) data.priceMonthly = null;
  if (typeof body.priceYearly === "number") data.priceYearly = body.priceYearly;
  else if (body.priceYearly === null) data.priceYearly = null;
  if (typeof body.isActive === "boolean") data.isActive = body.isActive;
  if (typeof body.sortOrder === "number") data.sortOrder = body.sortOrder;

  if (Object.keys(data).length === 0) {
    return errorResponse("No changes to save.", 400);
  }

  const updated = await controlPrisma.plan.update({ where: { id: plan.id }, data });

  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      action: "plan.update",
      details: { planId: plan.id, slug: plan.slug, changes: data },
    },
  });

  return jsonResponse({ plan: updated });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const plan = await controlPrisma.plan.findUnique({ where: { id: Number(id) } });
  if (!plan) return notFound("Plan not found.");

  const tenantCount = await controlPrisma.tenant.count({ where: { plan: plan.slug } });
  if (tenantCount > 0) {
    return errorResponse(
      `Can't delete this plan — ${tenantCount} tenant${tenantCount === 1 ? " is" : "s are"} still using it.`,
      409,
      { hint: "Move those tenants to another plan first.", code: "plan_in_use" },
    );
  }

  await controlPrisma.plan.delete({ where: { id: plan.id } });
  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      action: "plan.delete",
      details: { planId: plan.id, slug: plan.slug, name: plan.name },
    },
  });

  return jsonResponse({ ok: true });
}
