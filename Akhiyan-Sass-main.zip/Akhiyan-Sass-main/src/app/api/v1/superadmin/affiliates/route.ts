/**
 * GET  /api/v1/superadmin/affiliates        — list all affiliates
 * POST /api/v1/superadmin/affiliates        — create affiliate manually
 */

import { NextRequest } from "next/server";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { controlPrisma } from "@/lib/prisma-control";
import { generateAffiliateCode, generateDashboardToken } from "@/lib/affiliate";
import { hashPassword } from "@/lib/affiliate-auth";
import { randomBytes } from "crypto";

export const runtime = "nodejs";

export async function GET() {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }

  const affiliates = await controlPrisma.affiliate.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      email: true,
      name: true,
      code: true,
      commissionRate: true,
      status: true,
      totalEarned: true,
      totalPaid: true,
      bkashPhone: true,
      paypalEmail: true,
      createdAt: true,
      tenantId: true,
      _count: { select: { referrals: true } },
    },
  });

  return Response.json({ affiliates });
}

export async function POST(req: NextRequest) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }

  const body = await req.json().catch(() => ({}));
  const email: string = String(body.email || "").trim().toLowerCase();
  const name: string = String(body.name || "").trim();
  const commissionRate: number = Number(body.commissionRate ?? 0.20);
  const code: string = (body.code || generateAffiliateCode()).trim().toUpperCase();
  const bkashPhone: string | null = body.bkashPhone || null;
  const paypalEmail: string | null = body.paypalEmail || null;
  // Optional login password. Blank → auto-generate one and return it once.
  const providedPassword: string = String(body.password || "");
  // Super-admin-created affiliates are active immediately (not pending).
  const status: string = body.status === "pending" ? "pending" : "active";

  if (!email.includes("@")) return Response.json({ message: "valid email required" }, { status: 400 });
  if (!name) return Response.json({ message: "name required" }, { status: 400 });
  if (commissionRate <= 0 || commissionRate > 1) return Response.json({ message: "commissionRate must be 0.01–1.00" }, { status: 400 });
  if (providedPassword && providedPassword.length < 8)
    return Response.json({ message: "password must be at least 8 characters" }, { status: 400 });

  const existing = await controlPrisma.affiliate.findUnique({ where: { code } });
  if (existing) return Response.json({ message: `code "${code}" already in use` }, { status: 409 });
  const emailClash = await controlPrisma.affiliate.findUnique({ where: { email } });
  if (emailClash) return Response.json({ message: `email "${email}" already in use` }, { status: 409 });

  // Generate a temporary password if none supplied, so the affiliate can log in.
  const plainPassword = providedPassword || randomBytes(6).toString("base64url");

  const affiliate = await controlPrisma.affiliate.create({
    data: {
      email,
      name,
      code,
      status,
      commissionRate,
      bkashPhone,
      paypalEmail,
      password: await hashPassword(plainPassword),
      dashboardToken: generateDashboardToken(),
    },
  });

  // Return the plaintext password ONCE so the super admin can hand it off.
  return Response.json({ affiliate, tempPassword: plainPassword }, { status: 201 });
}
