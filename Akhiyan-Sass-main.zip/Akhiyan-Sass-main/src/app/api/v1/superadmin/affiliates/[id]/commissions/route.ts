/**
 * PATCH /api/v1/superadmin/affiliates/[id]/commissions
 *
 * Bulk-update commission status for an affiliate.
 * Body: { ids: number[], status: "approved" | "paid" | "rejected" }
 *
 * On "paid": stamps paid_at, deducts from totalEarned, increments totalPaid.
 * On "rejected": deducts from totalEarned.
 */

import { NextRequest } from "next/server";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { controlPrisma } from "@/lib/prisma-control";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const ids: number[] = Array.isArray(body.ids) ? body.ids.map(Number) : [];
  const status: string = body.status;

  if (!ids.length) return Response.json({ message: "ids required" }, { status: 400 });
  if (!["approved", "paid", "rejected"].includes(status))
    return Response.json({ message: "status must be approved | paid | rejected" }, { status: 400 });

  // Fetch matching commissions (scoped to this affiliate for safety)
  const commissions = await controlPrisma.affiliateCommission.findMany({
    where: { id: { in: ids }, affiliateId },
  });

  const totalAmount = commissions.reduce((s, c) => s + c.amount, 0);

  await controlPrisma.$transaction([
    controlPrisma.affiliateCommission.updateMany({
      where: { id: { in: ids }, affiliateId },
      data: {
        status,
        ...(status === "approved" ? { approvedAt: new Date() } : {}),
        ...(status === "paid" ? { paidAt: new Date(), approvedAt: new Date() } : {}),
      },
    }),
    ...(status === "paid"
      ? [controlPrisma.affiliate.update({
          where: { id: affiliateId },
          data: { totalPaid: { increment: totalAmount } },
        })]
      : []),
    ...(status === "rejected"
      ? [controlPrisma.affiliate.update({
          where: { id: affiliateId },
          data: { totalEarned: { decrement: totalAmount } },
        })]
      : []),
  ]);

  return Response.json({ updated: commissions.length });
}
