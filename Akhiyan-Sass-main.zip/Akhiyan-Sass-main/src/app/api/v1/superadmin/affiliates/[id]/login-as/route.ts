/**
 * POST /api/v1/superadmin/affiliates/[id]/login-as
 *
 * One-click login into an affiliate's dashboard — no password needed.
 * The affiliate dashboard is same-origin (control plane), so we just issue
 * the affiliate session cookie directly and tell the client where to go.
 *
 * The super admin's own `superadmin_token` cookie is separate and untouched,
 * so they stay logged into the admin console in their original tab.
 */

import { NextRequest } from "next/server";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { controlPrisma } from "@/lib/prisma-control";
import { setAffiliateSession } from "@/lib/affiliate-auth";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, { params }: Ctx) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }

  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  const affiliate = await controlPrisma.affiliate.findUnique({
    where: { id: affiliateId },
    select: { id: true, email: true, name: true, status: true },
  });
  if (!affiliate) return Response.json({ message: "not found" }, { status: 404 });
  if (affiliate.status === "banned")
    return Response.json({ message: "affiliate is banned" }, { status: 409 });

  await setAffiliateSession(affiliate);

  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      action: "affiliate.login_as",
      details: { affiliateId: affiliate.id, email: affiliate.email },
    },
  });

  return Response.json({ redirectTo: "/affiliate/dashboard" });
}
