/**
 * GET    /api/v1/superadmin/affiliates/[id]  — detail + stats
 * PATCH  /api/v1/superadmin/affiliates/[id]  — update (status, rate, payout info)
 * DELETE /api/v1/superadmin/affiliates/[id]  — soft-ban (status=banned)
 */

import { NextRequest } from "next/server";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { controlPrisma } from "@/lib/prisma-control";
import { getAffiliateStats, getAffiliateMetrics } from "@/lib/affiliate";
import { hashPassword } from "@/lib/affiliate-auth";
import { randomBytes } from "crypto";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  const affiliate = await controlPrisma.affiliate.findUnique({
    where: { id: affiliateId },
    include: {
      referrals: {
        orderBy: { createdAt: "desc" },
        take: 50,
      },
      commissions: {
        orderBy: { createdAt: "desc" },
        take: 50,
      },
      payouts: {
        orderBy: { createdAt: "desc" },
        take: 20,
      },
    },
  });

  if (!affiliate) return Response.json({ message: "not found" }, { status: 404 });

  const [stats, metrics] = await Promise.all([
    getAffiliateStats(affiliateId),
    getAffiliateMetrics(affiliateId),
  ]);

  return Response.json({ affiliate, stats, metrics });
}

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  // Allowed fields only
  const data: Record<string, unknown> = {};
  if (body.status !== undefined) data.status = body.status;
  if (body.commissionRate !== undefined) data.commissionRate = Number(body.commissionRate);
  if (body.bkashPhone !== undefined) data.bkashPhone = body.bkashPhone || null;
  if (body.paypalEmail !== undefined) data.paypalEmail = body.paypalEmail || null;
  if (body.name !== undefined) data.name = String(body.name).trim();

  // Password reset: { resetPassword: true } → generate a temp password and
  // return it once. Or { newPassword: "..." } to set a specific one.
  let tempPassword: string | undefined;
  if (body.resetPassword || body.newPassword) {
    const plain = body.newPassword ? String(body.newPassword) : randomBytes(6).toString("base64url");
    if (plain.length < 8) return Response.json({ message: "password must be at least 8 characters" }, { status: 400 });
    data.password = await hashPassword(plain);
    tempPassword = plain;
  }

  const affiliate = await controlPrisma.affiliate.update({
    where: { id: affiliateId },
    data,
  }).catch(() => null);

  if (!affiliate) return Response.json({ message: "not found" }, { status: 404 });
  return Response.json({ affiliate, ...(tempPassword ? { tempPassword } : {}) });
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  await controlPrisma.affiliate.update({
    where: { id: affiliateId },
    data: { status: "banned" },
  }).catch(() => null);

  return new Response(null, { status: 204 });
}
