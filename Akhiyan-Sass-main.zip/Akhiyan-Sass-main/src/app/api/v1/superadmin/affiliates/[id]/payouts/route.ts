/**
 * POST  /api/v1/superadmin/affiliates/[id]/payouts  — create payout request
 * PATCH /api/v1/superadmin/affiliates/[id]/payouts  — update payout status
 *
 * Body (POST): { amount, method, destination }
 * Body (PATCH): { payoutId, status, txRef?, note? }
 */

import { NextRequest } from "next/server";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { controlPrisma } from "@/lib/prisma-control";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const amount = Number(body.amount);
  const method: string = body.method;
  const destination: string = body.destination || "";

  if (!amount || amount <= 0) return Response.json({ message: "amount required" }, { status: 400 });
  if (!["bkash", "paypal", "bank"].includes(method))
    return Response.json({ message: "method must be bkash | paypal | bank" }, { status: 400 });
  if (!destination) return Response.json({ message: "destination required" }, { status: 400 });

  const payout = await controlPrisma.affiliatePayout.create({
    data: { affiliateId, amount, method, destination },
  });

  return Response.json({ payout }, { status: 201 });
}

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;
  const affiliateId = Number(id);
  if (!affiliateId) return Response.json({ message: "invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const payoutId = Number(body.payoutId);
  const status: string = body.status;

  if (!payoutId) return Response.json({ message: "payoutId required" }, { status: 400 });
  if (!["processing", "completed", "failed"].includes(status))
    return Response.json({ message: "status must be processing | completed | failed" }, { status: 400 });

  const payout = await controlPrisma.affiliatePayout.updateMany({
    where: { id: payoutId, affiliateId },
    data: {
      status,
      txRef: body.txRef || undefined,
      note: body.note || undefined,
      ...(status === "completed" ? { processedAt: new Date() } : {}),
    },
  });

  return Response.json({ updated: payout.count });
}
