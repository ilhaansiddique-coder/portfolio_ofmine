import { getSuperAdminSession } from "@/lib/super-admin-auth";

export const runtime = "nodejs";

export async function GET() {
  const session = await getSuperAdminSession();
  if (!session) return Response.json({ message: "not authenticated" }, { status: 401 });
  return Response.json({ session });
}
