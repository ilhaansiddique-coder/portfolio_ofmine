import { logoutSuperAdmin } from "@/lib/super-admin-auth";

export const runtime = "nodejs";

export async function POST() {
  await logoutSuperAdmin();
  return Response.json({ ok: true });
}
