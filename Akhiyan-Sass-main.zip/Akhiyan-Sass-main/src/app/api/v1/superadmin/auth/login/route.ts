/**
 * POST /api/v1/superadmin/auth/login
 * Body: { email, password }
 * Sets httpOnly cookie on success.
 *
 * Rate-limited to deter online brute-force against the control-plane account
 * that owns every tenant in the system. 5 attempts per IP per minute matches
 * the tenant-login policy.
 */
import { loginSuperAdmin } from "@/lib/super-admin-auth";
import { rateLimit, getClientIp } from "@/lib/rate-limit";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const ip = getClientIp(req);
  if (rateLimit(`sa-login:${ip}`, 5, 60_000)) {
    return Response.json({ message: "Too many requests. Please try again later." }, { status: 429 });
  }

  const { email, password } = await req.json().catch(() => ({}));
  if (!email || !password) {
    return Response.json({ message: "email + password required" }, { status: 400 });
  }

  // Per-email cap as well — stops password-spraying across IPs against a
  // known super-admin email. Looser window than IP cap (10 / 15 min).
  if (typeof email === "string" && rateLimit(`sa-login-email:${email.toLowerCase()}`, 10, 15 * 60_000)) {
    return Response.json({ message: "Too many requests. Please try again later." }, { status: 429 });
  }

  const session = await loginSuperAdmin(email, password);
  if (!session) {
    return Response.json({ message: "Invalid credentials" }, { status: 401 });
  }
  return Response.json({ session });
}
