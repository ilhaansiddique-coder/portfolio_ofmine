import { NextResponse } from "next/server";
import { controlPrisma } from "@/lib/prisma-control";
import { getImpersonation } from "@/lib/impersonation";
import { cookieParentDomain } from "@/lib/tenant";
import { broadcastToSuperAdmin } from "@/lib/realtime";

export const runtime = "nodejs";

const COOKIE_NAME = "superadmin_impersonate";
const BASE_DOMAIN = (process.env.BASE_DOMAIN || "contradigital.agency").toLowerCase();

/**
 * Compute the absolute URL the client should navigate to after exit.
 * Always points at the super-admin host (cdeadmin.<base>) — never the
 * tenant host the user is currently on, because the host-gate in
 * src/proxy.ts blocks /superadmin/* there. We honor the request's
 * protocol so dev (http) and prod (https) both work.
 */
function buildPostExitUrl(req: Request): string {
  const proto = (req.headers.get("x-forwarded-proto") || "https").split(",")[0].trim();
  const host = (req.headers.get("host") || "").split(":")[0].toLowerCase();

  // Dev shortcut: if we're on a dev wildcard host, keep the dev base.
  if (host.endsWith(".localtest.me") || host === "localtest.me") {
    return `${proto}://cdeadmin.localtest.me/superadmin/tenants`;
  }
  if (host.endsWith(".lvh.me") || host === "lvh.me") {
    return `${proto}://cdeadmin.lvh.me/superadmin/tenants`;
  }
  if (host === "localhost" || host === "127.0.0.1") {
    return `${proto}://localhost/superadmin/tenants`;
  }

  // Production: always cdeadmin.<BASE_DOMAIN> regardless of which tenant
  // host the request came from (could be a slug subdomain OR a tenant's
  // custom domain — neither knows the platform's admin URL on its own).
  return `https://cdeadmin.${BASE_DOMAIN}/superadmin/tenants`;
}

export async function POST(req: Request) {
  const imp = await getImpersonation();
  if (imp) {
    await controlPrisma.auditLog.create({
      data: {
        superAdminId: imp.superAdminId,
        tenantId: imp.tenantId,
        action: "tenant.impersonate.exit",
      },
    });
    void broadcastToSuperAdmin("impersonation.exit", {
      tenantId: imp.tenantId,
      tenantSlug: imp.tenantSlug,
    });
  }
  const redirectTo = buildPostExitUrl(req);
  const res = NextResponse.json({ ok: true, redirectTo });
  // Clear on both bare host and parent domain so browsers don't keep a stale
  // cookie around on cross-subdomain navigation.
  const parent = cookieParentDomain(req.headers.get("host"));
  res.cookies.set(COOKIE_NAME, "", { path: "/", maxAge: 0 });
  if (parent) {
    res.cookies.set(COOKIE_NAME, "", { path: "/", maxAge: 0, domain: parent });
  }
  return res;
}
