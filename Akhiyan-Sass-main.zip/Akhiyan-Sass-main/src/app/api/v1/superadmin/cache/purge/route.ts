/**
 * POST /api/v1/superadmin/cache/purge — flush the whole Cloudflare zone cache.
 * Super-admin only. Use after a deploy (Next chunk hashes change) or whenever
 * stale storefront HTML needs clearing. Requires the CF token to have
 * "Zone · Cache Purge · Purge" permission.
 */
import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { purgeZoneCache } from "@/lib/cloudflare-custom-hostnames";

export const runtime = "nodejs";

export async function POST() {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }

  const result = await purgeZoneCache();

  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      tenantId: null,
      action: result.ok ? "platform.cache.purged" : "platform.cache.purge_failed",
      details: result.ok ? {} : { error: result.error },
    },
  }).catch(() => {});

  if (!result.ok) {
    return Response.json(
      { ok: false, message: `Cloudflare purge failed: ${result.error}` },
      { status: 502 },
    );
  }
  return Response.json({ ok: true, message: "Cloudflare cache purged." });
}
