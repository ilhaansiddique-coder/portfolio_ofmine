import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import {
  defaultApiBaseUrl,
  defaultPackageId,
  defaultTenantAppName,
  normalizeHexColor,
  normalizePackageId,
} from "@/lib/mobile-app/tenant-app";

export const runtime = "nodejs";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireSuperAdmin();
  } catch (e) {
    return e as Response;
  }

  const { id } = await params;
  const tenant = await controlPrisma.tenant.findUnique({
    where: { id: Number(id) },
    include: { app: true },
  });
  if (!tenant) return Response.json({ message: "tenant not found" }, { status: 404 });

  return Response.json({
    tenant: {
      id: tenant.id,
      slug: tenant.slug,
      name: tenant.name,
      primaryDomain: tenant.primaryDomain,
      status: tenant.status,
    },
    app: tenant.app ?? {
      tenantId: tenant.id,
      appName: defaultTenantAppName(tenant),
      packageId: defaultPackageId(tenant),
      logoUrl: tenant.r2PublicUrl ?? null,
      primaryColor: null,
      apiBaseUrl: defaultApiBaseUrl(tenant),
      buildStatus: "not_started",
      latestBuildUrl: null,
      lastBuildError: null,
    },
  });
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireSuperAdmin();
  } catch (e) {
    return e as Response;
  }

  const { id } = await params;
  const tenant = await controlPrisma.tenant.findUnique({ where: { id: Number(id) } });
  if (!tenant) return Response.json({ message: "tenant not found" }, { status: 404 });

  const body = await req.json().catch(() => ({}));
  let packageId: string;
  let primaryColor: string | null;
  try {
    packageId = normalizePackageId(body.packageId, tenant);
    primaryColor = normalizeHexColor(body.primaryColor);
  } catch (e) {
    return Response.json({ message: e instanceof Error ? e.message : "Invalid app config" }, { status: 400 });
  }

  const app = await controlPrisma.tenantApp.upsert({
    where: { tenantId: tenant.id },
    update: {
      appName: typeof body.appName === "string" && body.appName.trim()
        ? body.appName.trim()
        : defaultTenantAppName(tenant),
      packageId,
      logoUrl: typeof body.logoUrl === "string" && body.logoUrl.trim() ? body.logoUrl.trim() : null,
      primaryColor,
      apiBaseUrl: typeof body.apiBaseUrl === "string" && body.apiBaseUrl.trim()
        ? body.apiBaseUrl.trim()
        : defaultApiBaseUrl(tenant),
    },
    create: {
      tenantId: tenant.id,
      appName: typeof body.appName === "string" && body.appName.trim()
        ? body.appName.trim()
        : defaultTenantAppName(tenant),
      packageId,
      logoUrl: typeof body.logoUrl === "string" && body.logoUrl.trim() ? body.logoUrl.trim() : null,
      primaryColor,
      apiBaseUrl: typeof body.apiBaseUrl === "string" && body.apiBaseUrl.trim()
        ? body.apiBaseUrl.trim()
        : defaultApiBaseUrl(tenant),
    },
  });

  return Response.json({ app });
}

