/**
 * POST /api/v1/superadmin/tenants/:id/reset-admin-password
 *
 * Generates a new random 12-char password, updates the tenant DB user row
 * (bcrypt-hashed) AND saves the plaintext on the control-plane Tenant row
 * so the super admin can re-read it from the dashboard.
 *
 * Targets the user identified by `tenant.initialAdminEmail`. Falls back to
 * `tenant.ownerEmail` when initialAdminEmail is missing (legacy tenants).
 *
 * Audited.
 */
import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { broadcastToSuperAdmin } from "@/lib/realtime";

export const runtime = "nodejs";

function generatePassword(): string {
  return randomBytes(9).toString("base64").replace(/[+/=]/g, "").slice(0, 12);
}

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;

  const tenant = await controlPrisma.tenant.findUnique({ where: { id: Number(id) } });
  if (!tenant) return NextResponse.json({ message: "not found" }, { status: 404 });
  if (!tenant.dbUrl) return NextResponse.json({ message: "tenant has no dbUrl" }, { status: 400 });

  const adminEmail = tenant.initialAdminEmail || tenant.ownerEmail;
  const newPassword = generatePassword();

  // Update the tenant DB user row.
  const tenantPrisma = new PrismaClient({ datasourceUrl: tenant.dbUrl });
  try {
    const user = await tenantPrisma.user.findUnique({ where: { email: adminEmail } });
    if (!user) {
      return NextResponse.json({
        message: `No user found in tenant DB for ${adminEmail}. Provision the admin user first.`,
      }, { status: 404 });
    }
    await tenantPrisma.user.update({
      where: { id: user.id },
      data: { password: await bcrypt.hash(newPassword, 12), role: "admin" },
    });
  } finally {
    await tenantPrisma.$disconnect();
  }

  // Save plaintext on control plane.
  await controlPrisma.tenant.update({
    where: { id: tenant.id },
    data: {
      initialAdminEmail: adminEmail,
      initialAdminPassword: newPassword,
    },
  });

  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      tenantId: tenant.id,
      action: "tenant.admin_password.reset",
      details: { adminEmail },
    },
  });

  void broadcastToSuperAdmin("tenant.admin_password.reset", { tenantId: tenant.id, slug: tenant.slug, adminEmail });
  return NextResponse.json({ ok: true, adminEmail, adminPassword: newPassword });
}
