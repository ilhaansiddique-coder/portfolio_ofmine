import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { clearTenantCache } from "@/lib/tenant";
import { broadcastToSuperAdmin } from "@/lib/realtime";

export const runtime = "nodejs";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;

  const tenant = await controlPrisma.tenant.findUnique({ where: { id: Number(id) } });
  if (!tenant) return Response.json({ message: "not found" }, { status: 404 });
  if (tenant.status === "active") return Response.json({ message: "already active" }, { status: 409 });

  const updated = await controlPrisma.tenant.update({
    where: { id: tenant.id },
    data: { status: "active", suspendedAt: null },
  });
  await controlPrisma.auditLog.create({
    data: { superAdminId: session.id, tenantId: tenant.id, action: "tenant.resume" },
  });
  clearTenantCache();
  void broadcastToSuperAdmin("tenant.resumed", { id: tenant.id, slug: tenant.slug });
  return Response.json({ tenant: { id: updated.id, status: updated.status } });
}
