/**
 * POST /api/v1/superadmin/tenants/:id/impersonate
 *
 * Mints an impersonation cookie pinning the current browser to act as admin
 * of the target tenant. Cookie is set on the parent domain (`.lvh.me` in
 * dev, `.contradigital.agency` in prod) so it travels from `cdeadmin.<base>` to
 * `<slug>.<base>` and is honored by the storefront / dashboard. Audited.
 */
import { NextResponse } from "next/server";
import { SignJWT, type JWTPayload } from "jose";
import { controlPrisma } from "@/lib/prisma-control";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { cookieParentDomain } from "@/lib/tenant";
import { broadcastToSuperAdmin } from "@/lib/realtime";

export const runtime = "nodejs";

const COOKIE_NAME = "superadmin_impersonate";
const TOKEN_EXP_SECS = 60 * 60;

function getSecret(): Uint8Array {
  const s = process.env.SUPER_ADMIN_JWT_SECRET;
  if (!s) throw new Error("SUPER_ADMIN_JWT_SECRET missing in env");
  return new TextEncoder().encode(s);
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }
  const { id } = await params;

  const tenant = await controlPrisma.tenant.findUnique({ where: { id: Number(id) } });
  if (!tenant) return NextResponse.json({ message: "not found" }, { status: 404 });
  if (tenant.status !== "active") {
    return NextResponse.json({ message: `Cannot impersonate ${tenant.status} tenant. Resume it first.` }, { status: 400 });
  }

  const token = await new SignJWT({
    email: session.email,
    name: session.name,
    tenantId: tenant.id,
    tenantSlug: tenant.slug,
    tenantName: tenant.name,
  } as JWTPayload)
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(session.id))
    .setIssuedAt()
    .setExpirationTime(`${TOKEN_EXP_SECS}s`)
    .sign(getSecret());

  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      tenantId: tenant.id,
      action: "tenant.impersonate.start",
      details: { tenantSlug: tenant.slug },
    },
  });
  void broadcastToSuperAdmin("impersonation.start", {
    tenantId: tenant.id,
    tenantSlug: tenant.slug,
    superAdminEmail: session.email,
  });

  // Compute the storefront URL so the client can hard-redirect to the
  // tenant's actual subdomain (where they'll be able to act as admin).
  const host = req.headers.get("host") || "";
  const parentDomain = cookieParentDomain(host);
  const portMatch = host.match(/:(\d+)$/);
  const port = portMatch ? `:${portMatch[1]}` : "";
  const proto = process.env.NODE_ENV === "production" ? "https" : "http";

  // Pick the tenant's storefront origin:
  //  - custom domain wins,
  //  - else `<slug>.<parent>` (parent = lvh.me in dev, contradigital.agency in prod),
  //  - else fall back to current host so impersonation still works on raw localhost.
  const parentBare = (parentDomain ?? "").replace(/^\./, "");
  const storefrontOrigin = tenant.primaryDomain
    ? `https://${tenant.primaryDomain}`
    : parentBare
      ? `${proto}://${tenant.slug}.${parentBare}${port}`
      : `${proto}://${host}`;

  const res = NextResponse.json({
    ok: true,
    redirect: `${storefrontOrigin}/dashboard`,
    tenant: { id: tenant.id, slug: tenant.slug, name: tenant.name },
  });
  res.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: TOKEN_EXP_SECS,
    // Parent-domain so cdeadmin.<base> + <slug>.<base> share the cookie.
    // On bare `localhost` we omit `domain` (browsers reject `.localhost`).
    ...(parentDomain ? { domain: parentDomain } : {}),
  });
  return res;
}
