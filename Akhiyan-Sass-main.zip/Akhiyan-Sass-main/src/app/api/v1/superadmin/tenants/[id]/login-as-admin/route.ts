/**
 * POST /api/v1/superadmin/tenants/:id/login-as-admin
 *
 * Issues a short-lived (5 min) signed JWT that, when consumed at the
 * tenant-host callback below, creates a REAL tenant-admin session on
 * that host. Unlike `/impersonate` (which scopes a cookie to the
 * parent domain and overlays the superadmin identity), this is a
 * clean login as the actual tenant-admin user. The superadmin's
 * cdeadmin.* session stays intact in parallel — fully separate.
 *
 * Flow:
 *   1. POST here from cdeadmin.* (requires requireSuperAdmin)
 *   2. We look up the admin User in the tenant's DB
 *   3. We sign a JWT { tenantId, userId, kind: "admin-auto-login" }
 *   4. Return { redirectTo: "https://<tenant-host>/api/v1/auth/admin-login-callback?token=<jwt>" }
 *   5. Browser navigates to that URL on the tenant host
 *   6. Callback verifies the token, sets the cd_ecom_session cookie
 *      (correctly scoped to the tenant host), redirects to /dashboard
 *
 * Auditing: the issue step is audited under the superadmin id; the
 * callback step is audited as well so we can trace cross-host. The
 * resulting session is a normal tenant admin session — admin actions
 * are logged as the actual user (not "[SuperAdmin] X" the way
 * impersonate does).
 */
import { NextResponse } from "next/server";
import { SignJWT, type JWTPayload } from "jose";
import { controlPrisma } from "@/lib/prisma-control";
import { getPrismaForDbUrl } from "@/lib/prisma-tenant";
import { requireSuperAdmin } from "@/lib/super-admin-auth";

export const runtime = "nodejs";

// Fail CLOSED — never sign auth tokens with a hardcoded default key.
// Mirrors src/lib/impersonation.ts / super-admin-auth.ts. Evaluated per
// request (not at module load) so a misconfigured env can't silently fall
// back to a public constant.
function getSecret(): Uint8Array {
  const s = process.env.SUPER_ADMIN_JWT_SECRET;
  if (!s) throw new Error("SUPER_ADMIN_JWT_SECRET missing in env");
  return new TextEncoder().encode(s);
}
const TTL_SECONDS = 5 * 60; // 5 minutes
const BASE_DOMAIN = (process.env.BASE_DOMAIN || "contradigital.agency").toLowerCase();

/**
 * Resolve the public URL of a tenant. Order:
 *   1. tenant.primaryDomain (custom domain) — e.g. https://shop.acme.com
 *   2. <slug>.<BASE_DOMAIN>                — e.g. https://acme.contradigital.agency
 *   3. host of THIS request (fallback for local/dev)
 */
function tenantOrigin(
  tenant: { slug: string; primaryDomain: string | null },
  fallbackHost: string | null,
  fallbackProto: string,
): string {
  if (tenant.primaryDomain) {
    return tenant.primaryDomain.startsWith("http")
      ? tenant.primaryDomain.replace(/\/+$/, "")
      : `https://${tenant.primaryDomain}`;
  }
  // Dev shortcuts: mirror the caller's wildcard host family so the cookie
  // lands on the same parent. Always preserve the port.
  if (fallbackHost) {
    const [hostOnly, portPart] = fallbackHost.split(":");
    const h = hostOnly.toLowerCase();
    const port = portPart ? `:${portPart}` : "";
    if (h.endsWith(".localtest.me") || h === "localtest.me") {
      return `${fallbackProto}://${tenant.slug}.localtest.me${port}`;
    }
    if (h.endsWith(".lvh.me") || h === "lvh.me") {
      return `${fallbackProto}://${tenant.slug}.lvh.me${port}`;
    }
    // Bare localhost / 127.0.0.1 in dev — lvh.me resolves to 127.0.0.1 so
    // we can use it to get a real subdomain that the proxy can route on.
    if (h === "localhost" || h === "127.0.0.1") {
      return `${fallbackProto}://${tenant.slug}.lvh.me${port}`;
    }
  }
  return `https://${tenant.slug}.${BASE_DOMAIN}`;
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  let session;
  try { session = await requireSuperAdmin(); } catch (e) { return e as Response; }

  const { id } = await params;
  const tenantId = Number(id);
  if (!Number.isFinite(tenantId)) {
    return NextResponse.json({ message: "invalid tenant id" }, { status: 400 });
  }

  const tenant = await controlPrisma.tenant.findUnique({
    where: { id: tenantId },
    select: {
      id: true,
      slug: true,
      name: true,
      status: true,
      dbUrl: true,
      primaryDomain: true,
      initialAdminEmail: true,
    },
  });
  if (!tenant) {
    return NextResponse.json({ message: "tenant not found" }, { status: 404 });
  }
  if (tenant.status !== "active") {
    return NextResponse.json({ message: `tenant is ${tenant.status}, not active` }, { status: 400 });
  }
  if (!tenant.dbUrl) {
    return NextResponse.json({ message: "tenant has no dbUrl yet" }, { status: 400 });
  }

  // Find the admin user in the tenant DB. Prefer the row matching
  // initialAdminEmail; fall back to any role=admin if that email changed.
  const tenantPrisma = getPrismaForDbUrl(tenant.dbUrl);
  let adminUser = tenant.initialAdminEmail
    ? await tenantPrisma.user.findFirst({
        where: { email: tenant.initialAdminEmail.toLowerCase(), role: "admin" },
        select: { id: true, name: true, email: true, phone: true, role: true },
      })
    : null;
  if (!adminUser) {
    adminUser = await tenantPrisma.user.findFirst({
      where: { role: "admin" },
      orderBy: { id: "asc" },
      select: { id: true, name: true, email: true, phone: true, role: true },
    });
  }
  if (!adminUser) {
    return NextResponse.json(
      { message: "No admin user exists in this tenant's DB — provision may have failed." },
      { status: 404 },
    );
  }

  // Mint the one-time JWT
  const payload: JWTPayload = {
    tenantId: tenant.id,
    userId: adminUser.id,
    name: adminUser.name,
    email: adminUser.email ?? null,
    phone: adminUser.phone ?? null,
    role: adminUser.role,
    kind: "admin-auto-login",
  };
  const token = await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${TTL_SECONDS}s`)
    .setIssuer("superadmin")
    .setAudience("tenant-admin")
    .sign(getSecret());

  // Audit on the issuer side
  await controlPrisma.auditLog.create({
    data: {
      superAdminId: session.id,
      tenantId: tenant.id,
      action: "tenant.login_as_admin.issued",
      details: { adminUserId: adminUser.id, adminEmail: adminUser.email },
    },
  });

  const fallbackProto = (req.headers.get("x-forwarded-proto") || "").split(",")[0].trim()
    || (req.url.startsWith("https://") ? "https" : "http");
  // Prefer x-forwarded-host (set by Traefik/Cloudflare to the original
  // public hostname) over Host (which can be rewritten by some proxy
  // chains to the upstream service name or container bind address).
  // Reject obviously-internal values like 0.0.0.0, localhost when we're
  // in production — those would build broken redirect URLs.
  const xfHost = (req.headers.get("x-forwarded-host") || "").split(",")[0].trim();
  const rawHost = xfHost || req.headers.get("host") || "";
  const hostOnly = rawHost.split(":")[0].toLowerCase();
  const isInternalBind = hostOnly === "0.0.0.0" || hostOnly === "::" || hostOnly === "";
  const callerHost = isInternalBind ? null : rawHost;
  const origin = tenantOrigin(
    { slug: tenant.slug, primaryDomain: tenant.primaryDomain },
    callerHost,
    fallbackProto,
  );
  const redirectTo = `${origin}/api/v1/auth/admin-login-callback?token=${encodeURIComponent(token)}`;

  return NextResponse.json({ ok: true, redirectTo });
}
