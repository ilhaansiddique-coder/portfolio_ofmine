/**
 * PATCH  /api/v1/superadmin/signups/[id] — update a signup order status.
 *   Body: { status: "paid" | "pending" | "rejected" }
 *
 * "provisioned" is set automatically by the tenant-creation flow, not here.
 */

import { NextRequest } from "next/server";
import { requireSuperAdmin } from "@/lib/super-admin-auth";
import { controlPrisma } from "@/lib/prisma-control";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, { params }: Ctx) {
  try { await requireSuperAdmin(); } catch (e) { return e as Response; }

  const { id } = await params;
  const orderId = Number(id);
  if (!orderId) return Response.json({ message: "invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const status: string = body.status;
  if (!["pending", "paid", "rejected"].includes(status))
    return Response.json({ message: "status must be pending | paid | rejected" }, { status: 400 });

  const order = await controlPrisma.signupOrder
    .update({
      where: { id: orderId },
      data: { status, ...(body.note !== undefined ? { note: String(body.note).slice(0, 500) } : {}) },
    })
    .catch(() => null);

  if (!order) return Response.json({ message: "not found" }, { status: 404 });
  return Response.json({ ok: true, order });
}
