/**
 * GET /api/v1/cron/tenant-expiry
 *
 * Hourly cron. Two responsibilities:
 *   1. Auto-suspend tenants whose `expiresAt` has passed.
 *   2. Email tenant owners 7 days before expiry, once.
 *
 * Auth: header `X-Cron-Secret` must match env `CRON_SECRET`. Vercel Cron and
 * cron-job.org both support custom headers. Failing the check returns 401 so
 * accidental probes don't leak that this endpoint exists.
 *
 * Idempotency:
 *   - Suspension is naturally idempotent (status filter excludes already-
 *     suspended rows).
 *   - Warning emails are deduped via `warningSentAt`; cleared whenever
 *     expiresAt moves forward (renew / extend / plan change).
 *
 * Schedule (vercel.json):
 *   { "crons": [{ "path": "/api/v1/cron/tenant-expiry", "schedule": "0 * * * *" }] }
 */
import { controlPrisma } from "@/lib/prisma-control";
import { sendExpiryWarning, sendSuspensionNotice } from "@/lib/control-mailer";
import { broadcastToSuperAdmin, broadcastToTenant } from "@/lib/realtime";
import { clearTenantCache } from "@/lib/tenant";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const DAY_MS = 86_400_000;

export async function GET(req: Request) {
  // Secret gate. Vercel Cron sends `Authorization: Bearer $CRON_SECRET` by
  // default; we accept either form so the same endpoint works with cron-job.org.
  const secret = process.env.CRON_SECRET || "";
  if (!secret) return Response.json({ message: "CRON_SECRET not set" }, { status: 500 });
  const headerSecret = req.headers.get("x-cron-secret") || "";
  const auth = req.headers.get("authorization") || "";
  const bearer = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (headerSecret !== secret && bearer !== secret) {
    return Response.json({ message: "unauthorized" }, { status: 401 });
  }

  const now = new Date();
  const in7d = new Date(now.getTime() + 7 * DAY_MS);

  const result = {
    suspended: [] as Array<{ id: number; slug: string }>,
    warned:    [] as Array<{ id: number; slug: string; daysLeft: number }>,
    errors:    [] as Array<{ id: number; stage: string; error: string }>,
  };

  // --- 1. Suspend lapsed tenants -------------------------------------------
  // We pull rows first so we can broadcast + email per tenant. updateMany
  // would be one query but loses the per-row details we need.
  const lapsed = await controlPrisma.tenant.findMany({
    where: {
      status: "active",
      expiresAt: { not: null, lte: now },
    },
    select: { id: true, slug: true, name: true, ownerEmail: true },
  });

  for (const t of lapsed) {
    try {
      await controlPrisma.tenant.update({
        where: { id: t.id },
        data: { status: "suspended", suspendedAt: now },
      });
      await controlPrisma.auditLog.create({
        data: {
          tenantId: t.id,
          action: "tenant.auto_suspend.expiry",
          details: { suspendedAt: now.toISOString() },
        },
      });
      // Best-effort email — don't let SMTP outage block the suspension.
      if (t.ownerEmail) {
        const mail = await sendSuspensionNotice({
          to: t.ownerEmail,
          tenantName: t.name,
          tenantSlug: t.slug,
        });
        if (!mail.ok) {
          result.errors.push({ id: t.id, stage: "suspend.mail", error: mail.error || "unknown" });
        }
      }
      // Tenant browser sees the suspension immediately.
      void broadcastToTenant(t.id, "platform", "suspended", { reason: "expiry" });
      result.suspended.push({ id: t.id, slug: t.slug });
    } catch (e) {
      result.errors.push({ id: t.id, stage: "suspend", error: e instanceof Error ? e.message : String(e) });
    }
  }

  // --- 2. 7-day warning -----------------------------------------------------
  const soon = await controlPrisma.tenant.findMany({
    where: {
      status: "active",
      warningSentAt: null,
      expiresAt: { gt: now, lte: in7d },
    },
    select: { id: true, slug: true, name: true, ownerEmail: true, expiresAt: true },
  });

  for (const t of soon) {
    if (!t.ownerEmail || !t.expiresAt) continue;
    const daysLeft = Math.max(1, Math.ceil((t.expiresAt.getTime() - now.getTime()) / DAY_MS));
    try {
      const mail = await sendExpiryWarning({
        to: t.ownerEmail,
        tenantName: t.name,
        tenantSlug: t.slug,
        expiresAt: t.expiresAt,
        daysLeft,
      });
      if (!mail.ok) {
        result.errors.push({ id: t.id, stage: "warn.mail", error: mail.error || "unknown" });
        continue; // don't mark as sent if SMTP failed — retry next hour
      }
      await controlPrisma.tenant.update({
        where: { id: t.id },
        data: { warningSentAt: now },
      });
      await controlPrisma.auditLog.create({
        data: {
          tenantId: t.id,
          action: "tenant.expiry_warning_sent",
          details: { daysLeft, expiresAt: t.expiresAt.toISOString() },
        },
      });
      result.warned.push({ id: t.id, slug: t.slug, daysLeft });
    } catch (e) {
      result.errors.push({ id: t.id, stage: "warn", error: e instanceof Error ? e.message : String(e) });
    }
  }

  // Bust resolver cache + ping super-admin tabs if anything moved.
  if (result.suspended.length > 0) {
    clearTenantCache();
    void broadcastToSuperAdmin("tenant.expired", { count: result.suspended.length, ids: result.suspended.map((t) => t.id) });
  }
  if (result.warned.length > 0) {
    void broadcastToSuperAdmin("tenant.expiry_warning", { count: result.warned.length });
  }

  return Response.json({ ok: true, ranAt: now.toISOString(), ...result });
}
