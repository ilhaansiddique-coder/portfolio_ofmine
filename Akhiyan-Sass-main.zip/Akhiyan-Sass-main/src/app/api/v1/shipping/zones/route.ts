import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serializeZone } from "@/lib/shipping-zone";
import { jsonResponse } from "@/lib/api-response";

export async function GET(req: Request) {
  const { prisma } = await getPrismaForRequest(req);
  const zones = await prisma.shippingZone.findMany({
    where: { isActive: true },
  });

  return jsonResponse(zones.map(serializeZone));
}
