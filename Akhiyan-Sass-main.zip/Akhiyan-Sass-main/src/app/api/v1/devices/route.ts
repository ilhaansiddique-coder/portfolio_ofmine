import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireAuth } from "@/lib/auth-helpers";
import { jsonResponse } from "@/lib/api-response";

/**
 * POST /api/v1/devices — Register a device token for push notifications.
 */
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const { prisma } = await getPrismaForRequest(request);
    const body = await request.json();

    const { token, platform } = body;
    if (!token || !platform || !["android", "ios"].includes(platform)) {
      return jsonResponse(
        { message: "token and platform (android|ios) are required." },
        422,
      );
    }

    // Upsert: if token exists, update the user (device may change hands)
    await prisma.deviceToken.upsert({
      where: { token },
      create: { userId: user.id, token, platform },
      update: { userId: user.id, platform },
    });

    return jsonResponse({ success: true });
  } catch (e) {
    return e as Response;
  }
}

/**
 * DELETE /api/v1/devices — Unregister a device token (logout / uninstall).
 */
export async function DELETE(request: NextRequest) {
  try {
    await requireAuth();
    const { prisma } = await getPrismaForRequest(request);
    const { token } = await request.json();

    if (token) {
      await prisma.deviceToken.deleteMany({ where: { token } });
    }

    return jsonResponse({ success: true });
  } catch (e) {
    return e as Response;
  }
}
