/**
 * POST /api/v1/affiliate/apply — public affiliate application.
 *
 * Creates an affiliate row with status="pending". The applicant cannot earn
 * until a super admin approves (sets status="active"): both /ref/[code] and
 * recordAffiliateReferral() gate on status === "active".
 *
 * Returns { dashboardToken } so the applicant can bookmark their status page.
 */

import { NextRequest } from "next/server";
import { controlPrisma } from "@/lib/prisma-control";
import { generateUniqueCode, generateDashboardToken } from "@/lib/affiliate";
import { hashPassword, setAffiliateSession } from "@/lib/affiliate-auth";

export const runtime = "nodejs";

// BD phone: 01[3-9] + 8 digits. Optional field, only validated when present.
const BD_PHONE_RE = /^01[3-9]\d{8}$/;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const name: string = String(body.name || "").trim();
  const email: string = String(body.email || "").trim().toLowerCase();
  const password: string = String(body.password || "");
  const bkashPhone: string = String(body.bkashPhone || "").trim();
  const paypalEmail: string = String(body.paypalEmail || "").trim().toLowerCase();
  const promo: string = String(body.promo || "").trim(); // how they'll promote (stored in note)

  if (!name || name.length < 2) return Response.json({ message: "Please enter your full name." }, { status: 400 });
  if (!email.includes("@")) return Response.json({ message: "Please enter a valid email." }, { status: 400 });
  if (password.length < 8) return Response.json({ message: "Password must be at least 8 characters." }, { status: 400 });
  if (bkashPhone && !BD_PHONE_RE.test(bkashPhone))
    return Response.json({ message: "bKash number must be a valid 11-digit BD number (01XXXXXXXXX)." }, { status: 400 });
  if (paypalEmail && !paypalEmail.includes("@"))
    return Response.json({ message: "Please enter a valid PayPal email." }, { status: 400 });
  if (!bkashPhone && !paypalEmail)
    return Response.json({ message: "Add at least one payout method (bKash or PayPal)." }, { status: 400 });

  // Duplicate email guard
  const existing = await controlPrisma.affiliate.findUnique({ where: { email }, select: { id: true, status: true } });
  if (existing) {
    return Response.json(
      { message: "An affiliate application already exists for this email. Contact support if you need help." },
      { status: 409 },
    );
  }

  const code = await generateUniqueCode(name);
  const dashboardToken = generateDashboardToken();

  const affiliate = await controlPrisma.affiliate.create({
    data: {
      name,
      email,
      code,
      password: await hashPassword(password),
      status: "pending",
      bkashPhone: bkashPhone || null,
      paypalEmail: paypalEmail || null,
      dashboardToken,
    },
  });

  if (promo) console.log(`[affiliate.apply] #${affiliate.id} ${email} promo plan: ${promo.slice(0, 500)}`);

  // Auto-login so they land straight on their dashboard (status: pending).
  await setAffiliateSession(affiliate);

  return Response.json({ ok: true, code }, { status: 201 });
}
