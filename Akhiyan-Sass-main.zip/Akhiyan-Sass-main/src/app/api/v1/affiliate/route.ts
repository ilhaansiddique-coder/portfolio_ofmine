/**
 * GET /api/v1/affiliate?token=<dashboardToken>
 *
 * Public no-login endpoint for the affiliate dashboard page.
 * Returns affiliate profile + stats. Token is a UUID — treated as a password.
 */

import { NextRequest } from "next/server";
import { controlPrisma } from "@/lib/prisma-control";
import { getAffiliateStats } from "@/lib/affiliate";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("token")?.trim();
  if (!token) return Response.json({ message: "token required" }, { status: 401 });

  const affiliate = await controlPrisma.affiliate.findUnique({
    where: { dashboardToken: token },
    include: {
      referrals: { orderBy: { createdAt: "desc" }, take: 50 },
      commissions: { orderBy: { createdAt: "desc" }, take: 50 },
      payouts: { orderBy: { createdAt: "desc" }, take: 20 },
    },
  });

  if (!affiliate) return Response.json({ message: "invalid token" }, { status: 401 });

  const stats = await getAffiliateStats(affiliate.id);

  // Strip dashboardToken from response — it's already authed
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { dashboardToken: _, ...safe } = affiliate;

  return Response.json({ affiliate: safe, stats });
}
