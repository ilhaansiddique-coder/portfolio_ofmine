/**
 * POST /api/v1/affiliate/logout — clear the affiliate session cookie.
 */

import { logoutAffiliate } from "@/lib/affiliate-auth";

export const runtime = "nodejs";

export async function POST() {
  await logoutAffiliate();
  return Response.json({ ok: true });
}
