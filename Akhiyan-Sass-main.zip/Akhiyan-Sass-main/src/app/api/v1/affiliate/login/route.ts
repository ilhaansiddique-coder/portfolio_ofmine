/**
 * POST /api/v1/affiliate/login — affiliate login.
 * Body: { email, password }. Sets httpOnly session cookie on success.
 */

import { NextRequest } from "next/server";
import { loginAffiliate } from "@/lib/affiliate-auth";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");

  if (!email || !password) {
    return Response.json({ message: "Email and password are required." }, { status: 400 });
  }

  const session = await loginAffiliate(email, password);
  if (!session) {
    return Response.json({ message: "Invalid email or password." }, { status: 401 });
  }

  return Response.json({ ok: true, name: session.name });
}
