/**
 * PATCH /api/v1/affiliate/me — authenticated affiliate self-service.
 *
 * Update name, payout methods, and (optionally) password. Requires a valid
 * affiliate session cookie. Affiliates can never change their own commission
 * rate, status, or code — those are super-admin controlled.
 */

import { NextRequest } from "next/server";
import { requireAffiliate, hashPassword } from "@/lib/affiliate-auth";
import { controlPrisma } from "@/lib/prisma-control";
import bcrypt from "bcryptjs";

export const runtime = "nodejs";

const BD_PHONE_RE = /^01[3-9]\d{8}$/;

export async function PATCH(req: NextRequest) {
  let session;
  try { session = await requireAffiliate(); } catch (e) { return e as Response; }

  const body = await req.json().catch(() => ({}));
  const data: Record<string, unknown> = {};

  if (body.name !== undefined) {
    const name = String(body.name).trim();
    if (name.length < 2) return Response.json({ message: "Name is too short." }, { status: 400 });
    data.name = name;
  }

  if (body.bkashPhone !== undefined) {
    const v = String(body.bkashPhone).trim();
    if (v && !BD_PHONE_RE.test(v))
      return Response.json({ message: "bKash number must be 11 digits (01XXXXXXXXX)." }, { status: 400 });
    data.bkashPhone = v || null;
  }

  if (body.paypalEmail !== undefined) {
    const v = String(body.paypalEmail).trim().toLowerCase();
    if (v && !v.includes("@"))
      return Response.json({ message: "Enter a valid PayPal email." }, { status: 400 });
    data.paypalEmail = v || null;
  }

  // Password change requires the current password.
  if (body.newPassword) {
    const newPassword = String(body.newPassword);
    if (newPassword.length < 8)
      return Response.json({ message: "New password must be at least 8 characters." }, { status: 400 });
    const current = await controlPrisma.affiliate.findUnique({
      where: { id: session.id },
      select: { password: true },
    });
    const ok = current?.password && (await bcrypt.compare(String(body.currentPassword || ""), current.password));
    if (!ok) return Response.json({ message: "Current password is incorrect." }, { status: 400 });
    data.password = await hashPassword(newPassword);
  }

  // Reject "at least one payout method" only if the update would leave both empty.
  if ("bkashPhone" in data || "paypalEmail" in data) {
    const cur = await controlPrisma.affiliate.findUnique({
      where: { id: session.id },
      select: { bkashPhone: true, paypalEmail: true },
    });
    const nextBkash = "bkashPhone" in data ? (data.bkashPhone as string | null) : cur?.bkashPhone;
    const nextPaypal = "paypalEmail" in data ? (data.paypalEmail as string | null) : cur?.paypalEmail;
    if (!nextBkash && !nextPaypal)
      return Response.json({ message: "Keep at least one payout method (bKash or PayPal)." }, { status: 400 });
  }

  if (Object.keys(data).length === 0) {
    return Response.json({ message: "Nothing to update." }, { status: 400 });
  }

  const updated = await controlPrisma.affiliate.update({
    where: { id: session.id },
    data,
    select: { name: true, bkashPhone: true, paypalEmail: true },
  });

  return Response.json({ ok: true, affiliate: updated });
}
