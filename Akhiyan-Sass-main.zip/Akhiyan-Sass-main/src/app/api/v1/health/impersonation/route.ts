/**
 * Debug: surface current impersonation + session state.
 * GET /api/v1/health/impersonation
 *
 * Requires an active superadmin session — not accessible to tenants or
 * unauthenticated callers.
 */
import { getImpersonation } from "@/lib/impersonation";
import { getSessionUser } from "@/lib/auth";
import { getSuperAdminSession, requireSuperAdmin } from "@/lib/super-admin-auth";

export const runtime = "nodejs";

export async function GET(req: Request) {
  // Must be a signed-in super-admin
  try {
    await requireSuperAdmin();
  } catch (e) {
    return e as Response;
  }

  const cookieHeader = req.headers.get("cookie") || "";
  const cookieNames = cookieHeader.split(/;\s*/).map((c) => c.split("=")[0]).filter(Boolean);

  const imp = await getImpersonation();
  const tenantUser = await getSessionUser();
  const superAdmin = await getSuperAdminSession();

  return Response.json({
    cookieNames,
    impersonationCookiePresent: cookieNames.includes("superadmin_impersonate"),
    impersonation: imp,
    tenantSessionUser: tenantUser,
    superAdminSession: superAdmin,
    env: {
      hasSecret: !!process.env.SUPER_ADMIN_JWT_SECRET,
      // intentionally NOT exposing secretLen — reduces brute-force attack surface
    },
  });
}
