/**
 * GET /api/v1/health/domain-verify
 *
 * Lightweight probe used by the domain verification flow. Does NOT require
 * tenant resolution or auth — it just confirms that this app instance is
 * reachable on the given host. The domain-verify logic in `domain-verify.ts`
 * hits this endpoint over HTTPS on the candidate custom domain; a 200 with
 * the correct JSON body proves the domain routes to our app.
 */
export const runtime = "nodejs";

const APP_ID = "cd-ecom";

export function GET() {
  return Response.json({ app: APP_ID, ts: Date.now() });
}
