/**
 * Tenant resolution health check — staff-only diagnostic.
 *
 * GET /api/v1/health/tenant
 *
 * Returns the resolved tenant slug + product count for the current host.
 * Gated behind staff auth to prevent tenant enumeration by anonymous clients.
 */
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { requireStaff } from "@/lib/auth-helpers";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try { await requireStaff(); } catch (e) { return e as Response; }

  try {
    const { prisma, tenant } = await getPrismaForRequest(req);
    const productCount = await prisma.product.count();

    return Response.json({
      ok: true,
      tenant: {
        id: tenant.id,
        slug: tenant.slug,
        name: tenant.name,
        primaryDomain: tenant.primaryDomain,
        status: tenant.status,
      },
      productCount,
      hostHeader: req.headers.get("host"),
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : String(err) },
      { status: 500 }
    );
  }
}
