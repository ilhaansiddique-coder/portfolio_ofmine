import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { resetPasswordSchema } from "@/lib/validation";
import { setSessionCookie } from "@/lib/auth";
import { jsonResponse, validationError } from "@/lib/api-response";
import { rateLimit, getClientIp } from "@/lib/rate-limit";

// Token TTL — the reset code from the email is only valid for 15 minutes.
const RESET_TOKEN_TTL_MS = 15 * 60 * 1000;
// Generic "wrong / expired" message used for both invalid code and missing
// user — prevents email enumeration via the reset endpoint.
const INVALID_CODE_MSG = "রিসেট কোড সঠিক নয় বা মেয়াদ শেষ হয়েছে।";

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  const ip = getClientIp(request);
  if (rateLimit(`reset:${ip}`, 5, 60000)) {
    return jsonResponse({ message: "Too many requests." }, 429);
  }

  const body = await request.json();
  const parsed = resetPasswordSchema.safeParse(body);
  if (!parsed.success) {
    const errors: Record<string, string[]> = {};
    for (const issue of parsed.error.issues) errors[issue.path.join(".")] = [issue.message];
    return validationError(errors);
  }

  const { email, code, password } = parsed.data;

  // Per-email attempt cap: 5 wrong codes per 15 min, then the token row is
  // burned regardless. Stops online brute-force across rotating IPs.
  if (rateLimit(`reset-email:${email}`, 5, 15 * 60 * 1000)) {
    // Invalidate any active token so the attacker can't keep trying once
    // they hit the cap. Silent — same generic response.
    await prisma.passwordResetToken.deleteMany({ where: { email } }).catch(() => {});
    return validationError({ code: [INVALID_CODE_MSG] });
  }

  const record = await prisma.passwordResetToken.findUnique({ where: { email } });

  // Enforce TTL: a token older than RESET_TOKEN_TTL_MS is treated as expired
  // and deleted. Without this check, a leaked code from an old email is
  // valid forever (this was the audit finding).
  if (record?.createdAt) {
    const age = Date.now() - new Date(record.createdAt).getTime();
    if (age > RESET_TOKEN_TTL_MS) {
      await prisma.passwordResetToken.delete({ where: { email } }).catch(() => {});
      return validationError({ code: [INVALID_CODE_MSG] });
    }
  }

  if (!record || !(await bcrypt.compare(code, record.token))) {
    return validationError({ code: [INVALID_CODE_MSG] });
  }

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    // Token matched but user is gone — clear the stale token and return
    // the same generic error (no "user not found" leak).
    await prisma.passwordResetToken.delete({ where: { email } }).catch(() => {});
    return validationError({ code: [INVALID_CODE_MSG] });
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { password: await bcrypt.hash(password, 12) },
  });

  await prisma.passwordResetToken.delete({ where: { email } });

  const sessionUser = { id: user.id, name: user.name, email: user.email ?? "", phone: user.phone, role: user.role };
  await setSessionCookie(sessionUser);

  return jsonResponse({
    message: "পাসওয়ার্ড রিসেট সফল হয়েছে।",
    user: sessionUser,
    token: "session",
  });
}
