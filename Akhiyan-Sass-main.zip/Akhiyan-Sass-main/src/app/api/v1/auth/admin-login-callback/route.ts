/**
 * GET /api/v1/auth/admin-login-callback?token=<jwt>
 *
 * The receiving side of the "Login as admin" superadmin action. Runs on
 * the TENANT host (so the session cookie gets scoped correctly). Verifies
 * the short-lived JWT minted by /api/v1/superadmin/tenants/:id/login-as-admin,
 * verifies the embedded tenantId matches THIS host's tenant (no
 * cross-tenant token replay), then sets the tenant's session cookie and
 * redirects to /dashboard.
 *
 * Security:
 *   - Token is signed with SUPER_ADMIN_JWT_SECRET (same secret used by
 *     impersonation; can't be forged without that key).
 *   - Token has a 5-minute TTL; replayed after that → rejected.
 *   - kind === "admin-auto-login" check prevents reusing other JWTs.
 *   - aud === "tenant-admin" and iss === "superadmin" claim checks.
 *   - The host resolved by getPrismaForRequest MUST equal the tenantId
 *     in the token; otherwise we refuse (defense against passing a
 *     token meant for tenant A to tenant B's callback).
 */
import { NextRequest, NextResponse } from "next/server";
import { jwtVerify, type JWTPayload } from "jose";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { setSessionCookie, type SessionUser } from "@/lib/auth";
import { controlPrisma } from "@/lib/prisma-control";

export const runtime = "nodejs";

// Fail CLOSED — never verify auth tokens against a hardcoded default key.
// A missing env var must reject the token, not accept attacker-forged JWTs
// signed with a public constant. Mirrors impersonation.ts/super-admin-auth.ts.
function getSecret(): Uint8Array {
  const s = process.env.SUPER_ADMIN_JWT_SECRET;
  if (!s) throw new Error("SUPER_ADMIN_JWT_SECRET missing in env");
  return new TextEncoder().encode(s);
}

function htmlError(message: string, status = 400): NextResponse {
  // Keep the body very short — these errors should be visible but not
  // helpful to attackers.
  const body = `<!DOCTYPE html><html><head><title>${status}</title>
<style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;color:#666}p{font-size:14px;max-width:480px;text-align:center}a{color:#000}</style>
</head><body><p>${message}<br><br><a href="/">← Back to site</a></p></body></html>`;
  return new NextResponse(body, {
    status,
    headers: { "Content-Type": "text/html" },
  });
}

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const token = url.searchParams.get("token") || "";
  if (!token) return htmlError("Missing login token.", 400);

  // Resolve the tenant for THIS host. If we can't, the request is
  // hitting a host that doesn't belong to any tenant — refuse.
  let tenant;
  try {
    ({ tenant } = await getPrismaForRequest(request));
  } catch {
    return htmlError("This host is not assigned to any tenant.", 404);
  }

  // Verify the JWT — signature, exp, iss, aud, kind.
  let payload: JWTPayload;
  try {
    const result = await jwtVerify(token, getSecret(), {
      issuer: "superadmin",
      audience: "tenant-admin",
    });
    payload = result.payload;
  } catch {
    return htmlError("Login link is invalid or expired. Ask the super-admin to re-issue it.", 401);
  }
  if (payload.kind !== "admin-auto-login") {
    return htmlError("Wrong token type.", 401);
  }

  // Critical safety: the token's tenantId MUST match the host's tenantId.
  // Otherwise an attacker could mint a token for tenant A and try to use
  // it on tenant B's callback to elevate.
  if (typeof payload.tenantId !== "number" || payload.tenantId !== tenant.id) {
    return htmlError("This login link is not valid for this tenant.", 401);
  }

  const userId = Number(payload.userId);
  if (!Number.isFinite(userId) || userId <= 0) {
    return htmlError("Malformed login token (missing user).", 401);
  }

  // Build the session user record. We have everything in the payload,
  // but we double-check by reading the user row from the tenant DB so
  // a stale token (after the user was deleted) doesn't grant access.
  // Use the prisma client already bound to this tenant by getPrismaForRequest.
  const { prisma } = await getPrismaForRequest(request);
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, name: true, email: true, phone: true, role: true },
  });
  if (!user || user.role !== "admin") {
    return htmlError("That user is no longer an admin of this tenant.", 401);
  }

  const sessionUser: SessionUser = {
    id: user.id,
    name: user.name,
    email: user.email ?? "",
    phone: user.phone,
    role: user.role,
  };

  // Audit the consumption — separate row from the issuance row so we
  // can see both sides in the audit log.
  await controlPrisma.auditLog.create({
    data: {
      tenantId: tenant.id,
      action: "tenant.login_as_admin.consumed",
      details: { adminUserId: user.id, adminEmail: user.email },
    },
  }).catch(() => {});

  // Set the tenant-scoped session cookie + redirect into the dashboard.
  await setSessionCookie(sessionUser);

  // CRITICAL: use a RELATIVE redirect. We're already on the correct tenant
  // host (the issuer redirected the browser here), so just stay here.
  //
  // We can't use `new URL("/dashboard", request.url)` because in Docker
  // behind Traefik/Cloudflare, `request.url` often resolves to the
  // container's internal bind address (e.g. http://0.0.0.0:3000) — which
  // would dump the browser onto an unreachable host. We also can't trust
  // `request.headers.get("host")` because some proxy chains rewrite or
  // drop it.
  //
  // `NextResponse.redirect()` requires an absolute URL, so we build a raw
  // Response with a relative Location header — browsers resolve that
  // against the current URL, which is exactly the tenant host we want.
  return new NextResponse(null, {
    status: 302,
    headers: { Location: "/dashboard" },
  });
}
