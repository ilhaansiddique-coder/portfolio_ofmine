import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { loginSchema } from "@/lib/validation";
import { jsonResponse, validationError } from "@/lib/api-response";
import { rateLimit, getClientIp } from "@/lib/rate-limit";
import { setSessionCookie, createToken } from "@/lib/auth";

// Pre-computed bcrypt hash of a fixed nonsense password. Used when the
// submitted email has no matching user so we still spend the ~80 ms of CPU
// time that a real compare costs — otherwise the "user not found" path
// returns in ~5 ms and an attacker can enumerate emails via response timing.
// The hash is for "not-a-real-password" at cost 10 — it can never match any
// real user-supplied password because we never store this value.
const DUMMY_BCRYPT_HASH = "$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy";

export async function POST(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  const ip = getClientIp(request);
  if (rateLimit(`login:${ip}`, 5, 60000)) {
    return jsonResponse({ message: "Too many requests. Please try again later." }, 429);
  }

  const body = await request.json();
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return validationError({ email: ["ইমেইল এবং পাসওয়ার্ড দিন।"] });
  }

  const { email, password } = parsed.data;
  const user = await prisma.user.findUnique({ where: { email } });

  // Always run bcrypt.compare — even when the user doesn't exist — so the
  // response time doesn't reveal whether the email is registered. The dummy
  // hash will never match anything a user could submit.
  const passwordOk = user
    ? await bcrypt.compare(password, user.password)
    : (await bcrypt.compare(password, DUMMY_BCRYPT_HASH), false);

  if (!user || !passwordOk) {
    return validationError({ email: ["ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।"] });
  }

  const sessionUser = {
    id: user.id,
    name: user.name,
    email: user.email ?? "",
    phone: user.phone,
    role: user.role,
  };

  // Set httpOnly JWT cookie (for web)
  await setSessionCookie(sessionUser);

  // Also return the raw JWT so mobile apps can use Bearer auth
  const jwt = await createToken(sessionUser);

  return jsonResponse({
    user: sessionUser,
    token: jwt,
  });
}
