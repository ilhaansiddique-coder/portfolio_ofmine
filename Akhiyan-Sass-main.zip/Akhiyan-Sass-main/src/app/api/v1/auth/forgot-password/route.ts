import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { forgotPasswordSchema } from "@/lib/validation";
import { jsonResponse, validationError } from "@/lib/api-response";
import { rateLimit, getClientIp } from "@/lib/rate-limit";
import { sendResetCodeEmail } from "@/lib/email";

// Generic response so the endpoint cannot be used to enumerate registered emails.
const GENERIC_OK = { message: "আপনার ইমেইল আমাদের সিস্টেমে থাকলে একটি রিসেট কোড পাঠানো হয়েছে।" };

export async function POST(request: NextRequest) {
  const { prisma, tenant } = await getPrismaForRequest(request);
  const ip = getClientIp(request);
  if (rateLimit(`forgot:${ip}`, 5, 60000)) {
    return jsonResponse({ message: "Too many requests." }, 429);
  }

  const body = await request.json();
  const parsed = forgotPasswordSchema.safeParse(body);
  if (!parsed.success) return validationError({ email: ["ইমেইল দিন।"] });

  const { email } = parsed.data;
  const user = await prisma.user.findUnique({ where: { email } });

  // Always respond with the same payload regardless of whether the email
  // exists — prevents account enumeration via this endpoint. Only do the
  // token write + email send when a real user is found.
  if (user) {
    // Per-email rate limit: cap reset-code issuance to 3 per 15 min so an
    // attacker who knows the email cannot exhaust the user's inbox or roll
    // the OTP slot to a value they want.
    if (!rateLimit(`forgot-email:${email}`, 3, 15 * 60 * 1000)) {
      const code = crypto.randomBytes(4).toString("hex"); // 8 hex chars = 32 bits
      const hashedCode = await bcrypt.hash(code, 10);

      await prisma.passwordResetToken.upsert({
        where: { email },
        update: { token: hashedCode, createdAt: new Date() },
        create: { email, token: hashedCode, createdAt: new Date() },
      });

      // Non-blocking — failures here must not leak via timing
      sendResetCodeEmail(prisma, tenant.id, email, code);
    }
  }

  return jsonResponse(GENERIC_OK);
}
