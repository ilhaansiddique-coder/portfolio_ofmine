import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { updateProfileSchema } from "@/lib/validation";
import { jsonResponse, validationError } from "@/lib/api-response";
import { requireAuth } from "@/lib/auth-helpers";

export async function PUT(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  let user;
  try { user = await requireAuth(); } catch (e) { return e as Response; }

  // Impersonation users (negative id) don't exist in the tenant DB — refuse
  // mutations. Read endpoints return the synthetic record so the dashboard
  // still works.
  if (user.id < 0) {
    return jsonResponse({ message: "Cannot edit profile while impersonating. Exit impersonation first." }, 403);
  }

  const body = await request.json();
  const parsed = updateProfileSchema.safeParse(body);
  if (!parsed.success) {
    const errors: Record<string, string[]> = {};
    for (const issue of parsed.error.issues) errors[issue.path.join(".")] = [issue.message];
    return validationError(errors);
  }

  const data = parsed.data;

  // Check email uniqueness if changing
  if (data.email && data.email !== user.email) {
    const existing = await prisma.user.findUnique({ where: { email: data.email } });
    if (existing) return validationError({ email: ["এই ইমেইল ইতিমধ্যে ব্যবহৃত হচ্ছে।"] });
  }

  const updated = await prisma.user.update({
    where: { id: user.id },
    data: {
      ...(data.name !== undefined && { name: data.name }),
      ...(data.email !== undefined && { email: data.email }),
      ...(data.phone !== undefined && { phone: data.phone }),
    },
  });

  return jsonResponse(serialize(updated));
}
