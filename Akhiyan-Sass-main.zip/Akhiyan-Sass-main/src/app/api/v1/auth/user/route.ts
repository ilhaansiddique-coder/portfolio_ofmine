import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { jsonResponse, unauthorized } from "@/lib/api-response";
import { getSessionUser } from "@/lib/auth";

export async function GET(req: Request) {
  const { prisma } = await getPrismaForRequest(req);
  const sessionUser = await getSessionUser();
  if (!sessionUser) return unauthorized();

  // Impersonation users have negative ids and don't exist in the tenant DB —
  // return the synthetic record directly. AuthContext caches this and renders
  // the dashboard normally.
  if (sessionUser.id < 0) {
    return jsonResponse({
      id: sessionUser.id,
      name: sessionUser.name,
      email: sessionUser.email,
      phone: sessionUser.phone,
      role: sessionUser.role,
      avatar: null,
      createdAt: null,
    });
  }

  const user = await prisma.user.findUnique({
    where: { id: sessionUser.id },
    select: { id: true, name: true, email: true, phone: true, role: true, avatar: true, createdAt: true },
  });

  if (!user) return unauthorized();

  return jsonResponse(user);
}
