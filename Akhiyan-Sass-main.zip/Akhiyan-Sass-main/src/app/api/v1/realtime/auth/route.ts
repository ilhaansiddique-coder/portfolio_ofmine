/**
 * POST /api/v1/realtime/auth
 *
 * Pusher-compatible private-channel auth endpoint. Soketi calls this on the
 * client's behalf with `socket_id` + `channel_name` form fields.
 *
 * Authorization rules:
 *   • `private-t<id>-*`           → user must be admin/staff of tenant <id>
 *   • `private-customer-t<id>-<u>` → user must be id=<u> of tenant <id>
 *   • super-admin impersonation cookie also opens private-t<id>-* of the
 *     impersonated tenant
 *
 * Anything else → 403.
 */
import { NextResponse } from "next/server";
import { pusher, SUPERADMIN_CHANNEL } from "@/lib/realtime";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { getSessionUser } from "@/lib/auth";
import { getSuperAdminSession } from "@/lib/super-admin-auth";

export const runtime = "nodejs";

export async function POST(req: Request) {
  // pusher-js sends application/x-www-form-urlencoded
  const form = await req.formData();
  const socketId = form.get("socket_id");
  const channel = form.get("channel_name");
  if (typeof socketId !== "string" || typeof channel !== "string") {
    return NextResponse.json({ message: "missing socket_id / channel_name" }, { status: 400 });
  }

  // Super-admin feed: gate on super-admin session, not tenant context.
  if (channel === SUPERADMIN_CHANNEL) {
    const superAdmin = await getSuperAdminSession();
    if (!superAdmin) {
      return NextResponse.json({ message: "super admin required" }, { status: 401 });
    }
    const auth = pusher().authorizeChannel(socketId, channel);
    return NextResponse.json(auth);
  }

  // Resolve current tenant for this request.
  let tenantId: number | null = null;
  try {
    const ctx = await getPrismaForRequest(req);
    tenantId = ctx.tenant.id;
  } catch {
    return NextResponse.json({ message: "no tenant for host" }, { status: 403 });
  }

  // Match channel patterns.
  // private-t<id>-<resource>          (note: does NOT match private-customer-*)
  const tenantMatch = channel.match(/^private-t(\d+)-(.+)$/);
  // private-customer-t<id>-<userId>
  const customerMatch = channel.match(/^private-customer-t(\d+)-(\d+)$/);

  if (tenantMatch) {
    const channelTenantId = Number(tenantMatch[1]);
    const resource = tenantMatch[2];
    if (channelTenantId !== tenantId) {
      return NextResponse.json({ message: "tenant mismatch" }, { status: 403 });
    }
    // PUBLIC, non-sensitive resources: the storefront's feature-flag / settings
    // sync (StorefrontFeaturesWatcher, TenantFeaturesProvider) and landing-page
    // content updates (LpRealtimeRefresh). Payloads are only {} / { features } /
    // { slug } — already visible in the rendered storefront HTML — so ANY visitor
    // on this tenant may subscribe with no session. This stops a 401-per-page-
    // load for every anonymous shopper. All other resources (orders, couriers,
    // …) still require an admin/staff session below.
    const PUBLIC_RESOURCES = new Set(["settings", "landing_pages"]);
    if (!PUBLIC_RESOURCES.has(resource)) {
      const user = await getSessionUser();
      if (!user) {
        return NextResponse.json({ message: "not authenticated" }, { status: 401 });
      }
      // Synthetic admin (impersonation) has role=admin already → passes.
      if (user.role !== "admin" && user.role !== "staff") {
        return NextResponse.json({ message: "admin/staff role required" }, { status: 403 });
      }
    }
  } else if (customerMatch) {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ message: "not authenticated" }, { status: 401 });
    }
    const channelTenantId = Number(customerMatch[1]);
    const channelUserId = Number(customerMatch[2]);
    if (channelTenantId !== tenantId) {
      return NextResponse.json({ message: "tenant mismatch" }, { status: 403 });
    }
    if (user.id !== channelUserId) {
      return NextResponse.json({ message: "user mismatch" }, { status: 403 });
    }
  } else {
    return NextResponse.json({ message: "unrecognized private channel" }, { status: 403 });
  }

  // Sign + return Pusher's expected auth payload.
  const auth = pusher().authorizeChannel(socketId, channel);
  return NextResponse.json(auth);
}
