/**
 * POST /api/v1/presence — storefront heartbeat. Records a live visitor for the
 * tenant resolved from the request host. Body: { sid: string } (a random
 * per-tab id the client keeps in sessionStorage). No DB, no auth — cheap.
 * Returns 204.
 */
import { maybeGetPrismaForRequest } from "@/lib/prisma-tenant";
import { recordPresence, getPresenceSnapshot, shouldBroadcastPresence } from "@/lib/presence";
import { broadcastToSuperAdmin } from "@/lib/realtime";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const ctx = await maybeGetPrismaForRequest(req);
    if (ctx) {
      const body = await req.json().catch(() => ({}));
      const sid = String(body?.sid || "").slice(0, 64);
      if (sid) {
        recordPresence(ctx.tenant.id, sid);
        // Push the live snapshot to the super-admin monitor over Soketi.
        // Throttled + fire-and-forget so the heartbeat stays cheap (no await,
        // no DB — the snapshot is read straight from the in-memory store).
        if (shouldBroadcastPresence()) {
          void broadcastToSuperAdmin("presence", getPresenceSnapshot());
        }
      }
    }
  } catch {
    /* unknown host / bad body — ignore, presence is best-effort */
  }
  return new Response(null, { status: 204 });
}
