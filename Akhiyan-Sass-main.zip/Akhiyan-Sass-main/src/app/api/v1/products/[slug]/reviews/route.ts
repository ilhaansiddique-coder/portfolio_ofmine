import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse } from "@/lib/api-response";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { prisma } = await getPrismaForRequest(request);
  const { slug } = await params;
  const decoded = decodeURIComponent(slug);

  // Find product by slug to get its ID
  const product = await prisma.product.findFirst({
    where: { OR: [{ slug }, { slug: decoded }] },
    select: { id: true },
  });

  if (!product) return jsonResponse([]);

  const reviews = await prisma.review.findMany({
    where: { productId: product.id, isApproved: true },
    orderBy: { createdAt: "desc" },
  });

  return jsonResponse(reviews.map(serialize));
}
