/**
 * GET   /api/v1/dashboard/refer-and-earn — tenant admin's refer-and-earn data.
 *   Auto-enrolls the current tenant as an Affiliate (linked via tenantId) on
 *   first call. Returns referral link, stats, metrics, commissions, payout info.
 *
 * PATCH /api/v1/dashboard/refer-and-earn — update payout method (bKash / PayPal).
 *
 * Auth: tenant admin (requireAdmin). The tenant itself is resolved from the
 * request host via getPrismaForRequest.
 */

import { NextRequest } from "next/server";
import { requireAdmin } from "@/lib/auth-helpers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { controlPrisma } from "@/lib/prisma-control";
import {
  generateUniqueCode,
  generateDashboardToken,
  getAffiliateStats,
  getAffiliateMetrics,
} from "@/lib/affiliate";

export const runtime = "nodejs";

const BD_PHONE_RE = /^01[3-9]\d{8}$/;

async function getOrCreateTenantAffiliate(tenant: { id: number; name: string; ownerEmail: string }) {
  // 1) Already linked to this tenant — done.
  const byTenant = await controlPrisma.affiliate.findUnique({ where: { tenantId: tenant.id } });
  if (byTenant) return byTenant;

  // 2) Affiliate row already exists for the owner's email (signed up
  //    standalone earlier). Link to this tenant instead of creating a dup —
  //    the email column is UNIQUE.
  const byEmail = await controlPrisma.affiliate.findUnique({ where: { email: tenant.ownerEmail } });
  if (byEmail) {
    return controlPrisma.affiliate.update({
      where: { id: byEmail.id },
      data: { tenantId: tenant.id },
    });
  }

  // 3) Fresh enrollment.
  return controlPrisma.affiliate.create({
    data: {
      tenantId: tenant.id,
      email: tenant.ownerEmail,
      name: tenant.name,
      code: await generateUniqueCode(tenant.name),
      status: "active",
      commissionRate: 0.20,
      dashboardToken: generateDashboardToken(),
      // No password set — the tenant admin accesses this via their dashboard
      // session, not via the /affiliate/login flow.
    },
  });
}

export async function GET(req: NextRequest) {
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const { tenant } = await getPrismaForRequest(req);
  const ctrlTenant = await controlPrisma.tenant.findUnique({
    where: { id: tenant.id },
    select: { id: true, name: true, ownerEmail: true },
  });
  if (!ctrlTenant) return Response.json({ message: "tenant not found" }, { status: 404 });

  const affiliate = await getOrCreateTenantAffiliate(ctrlTenant);
  const [stats, metrics, commissions] = await Promise.all([
    getAffiliateStats(affiliate.id),
    getAffiliateMetrics(affiliate.id),
    controlPrisma.affiliateCommission.findMany({
      where: { affiliateId: affiliate.id },
      orderBy: { createdAt: "desc" },
      take: 20,
    }),
  ]);

  const baseDomain = process.env.NEXT_PUBLIC_BASE_URL || `https://${process.env.BASE_DOMAIN || "example.com"}`;
  const refUrl = `${baseDomain}/ref/${affiliate.code}`;

  // Available balance = approved-but-not-yet-paid
  const available = Math.max(0, stats.approvedCommission);

  return Response.json({
    affiliate: {
      code: affiliate.code,
      commissionRate: affiliate.commissionRate,
      bkashPhone: affiliate.bkashPhone,
      paypalEmail: affiliate.paypalEmail,
      totalEarned: affiliate.totalEarned,
      totalPaid: affiliate.totalPaid,
    },
    refUrl,
    stats,
    metrics,
    available,
    commissions: commissions.map((c) => ({
      id: c.id,
      amount: c.amount,
      status: c.status,
      event: c.event,
      createdAt: c.createdAt.toISOString(),
    })),
    payoutThresholds: {
      bkash: 500,   // ৳500 minimum payout for bKash
      paypal: 10,   // $10 minimum payout for PayPal
    },
  });
}

export async function PATCH(req: NextRequest) {
  try { await requireAdmin(); } catch (e) { return e as Response; }

  const { tenant } = await getPrismaForRequest(req);
  const body = await req.json().catch(() => ({}));

  const data: Record<string, unknown> = {};
  if (body.bkashPhone !== undefined) {
    const v = String(body.bkashPhone).trim();
    if (v && !BD_PHONE_RE.test(v))
      return Response.json({ message: "bKash number must be 11 digits (01XXXXXXXXX)." }, { status: 400 });
    data.bkashPhone = v || null;
  }
  if (body.paypalEmail !== undefined) {
    const v = String(body.paypalEmail).trim().toLowerCase();
    if (v && !v.includes("@"))
      return Response.json({ message: "Enter a valid PayPal email." }, { status: 400 });
    data.paypalEmail = v || null;
  }

  if (Object.keys(data).length === 0)
    return Response.json({ message: "Nothing to update." }, { status: 400 });

  const updated = await controlPrisma.affiliate.update({
    where: { tenantId: tenant.id },
    data,
    select: { bkashPhone: true, paypalEmail: true },
  }).catch(() => null);

  if (!updated)
    return Response.json({ message: "No affiliate record — open Refer & earn page once to enroll." }, { status: 404 });

  return Response.json({ ok: true, affiliate: updated });
}
