/**
 * GET  /api/v1/dashboard/theme-content?theme=<id>&lang=<en|bn>
 *   Read the current tenant's saved overrides for the given theme.
 *   Resolves both the inline `theme_content:<themeId>` row AND any
 *   mapped values from `page_*` rows (form-managed content) into a
 *   single flat `{ "<section>.<field>": "value" }` map. Returns
 *   `{ overrides }`.
 *
 * PUT  /api/v1/dashboard/theme-content
 *   Body: `{ theme: "<id>", lang?: "en"|"bn", overrides: { ... } }`
 *   Splits the payload by mapping:
 *     - Fields in `CONTENT_MAPPINGS` → routed into the matching `page_*`
 *       JSON blob at the right nested path. Bilingual fields go under
 *       the current language slot, preserving the opposite language.
 *     - Unmapped fields → flat `theme_content:<themeId>` row.
 *   Both surfaces (inline editor + dashboard Content forms) end up
 *   reading and writing the same `page_*` rows, so there is no drift.
 *
 * Auth: tenant admin only (requireAdmin). Non-admin requests get 403.
 * The tenant is resolved from the request host via getPrismaForRequest —
 * admins can only edit their own tenant's content, never another tenant's.
 */

import { NextRequest, NextResponse } from "next/server";
import { revalidateTag } from "next/cache";
import { requireAdmin } from "@/lib/auth-helpers";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { THEME_CONTENT_SETTING_PREFIX } from "@/storefront-engine/editor/loadOverrides";
import {
  CONTENT_MAPPINGS,
  getPathValue,
  setPathValue,
  pickBilingual,
} from "@/storefront-engine/editor/contentMappings";

export const runtime = "nodejs";

const THEME_ID_RE = /^[a-z0-9-]{1,40}$/;
// Field ids are dot-separated namespaces. Original regex only accepted
// TWO segments (e.g. `hero.title`), but the default theme uses nested
// namespaces like `home.hero.title` to scope shared section components
// under the `home.*` page. The new regex accepts 2+ segments — each
// segment is `[a-z0-9_]+`, joined by literal dots.
const FIELD_ID_RE = /^[a-z0-9_]+(?:\.[a-z0-9_]+)+$/i;
const MAX_FIELD_VALUE_BYTES = 8 * 1024;
const MAX_FIELDS = 200;

type Lang = "en" | "bn";
function normLang(raw: unknown): Lang {
  return raw === "bn" ? "bn" : "en";
}

export async function GET(req: NextRequest) {
  await requireAdmin();
  const { prisma, tenant } = await getPrismaForRequest();
  const themeId = req.nextUrl.searchParams.get("theme");
  if (!themeId || !THEME_ID_RE.test(themeId)) {
    return NextResponse.json({ error: "invalid theme id" }, { status: 400 });
  }
  const lang = normLang(req.nextUrl.searchParams.get("lang"));
  const overrides = await resolveOverrides(prisma, themeId, lang);
  return NextResponse.json({ tenantId: tenant.id, theme: themeId, lang, overrides });
}

/** Read both layers (theme_content + mapped page_*) into a flat map.
 *  Same logic as `loadThemeOverrides` but doesn't go through the
 *  shared cache (admin reads should always be fresh). */
async function resolveOverrides(
  prisma: Awaited<ReturnType<typeof getPrismaForRequest>>["prisma"],
  themeId: string,
  lang: Lang,
): Promise<Record<string, string>> {
  const out: Record<string, string> = {};

  // theme_content layer
  const tcRow = await prisma.siteSetting.findUnique({
    where: { key: `${THEME_CONTENT_SETTING_PREFIX}${themeId}` },
  });
  if (tcRow?.value) {
    try {
      const parsed = JSON.parse(tcRow.value);
      if (parsed && typeof parsed === "object") {
        for (const [k, v] of Object.entries(parsed)) {
          if (typeof v === "string") out[k] = v;
        }
      }
    } catch { /* corrupt — skip */ }
  }

  // page_* layer
  const pageKeys = Array.from(new Set(Object.values(CONTENT_MAPPINGS).map((m) => m.settingKey)));
  const pageRows = await prisma.siteSetting.findMany({
    where: { key: { in: pageKeys } },
    select: { key: true, value: true },
  });
  const byKey: Record<string, unknown> = {};
  for (const r of pageRows) {
    if (!r.value) continue;
    try { byKey[r.key] = JSON.parse(r.value); } catch { /* skip */ }
  }
  for (const [fieldId, mapping] of Object.entries(CONTENT_MAPPINGS)) {
    const blob = byKey[mapping.settingKey];
    if (blob == null) continue;
    const cell = getPathValue(blob, mapping.path);
    if (cell == null) continue;
    const text = mapping.bilingual
      ? pickBilingual(cell, lang)
      : (typeof cell === "string" ? cell : "");
    if (text) out[fieldId] = text;
  }

  return out;
}

export async function PUT(req: NextRequest) {
  await requireAdmin();
  const { prisma, tenant } = await getPrismaForRequest();

  let body: unknown;
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "invalid json body" }, { status: 400 }); }
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "body must be object" }, { status: 400 });
  }
  const { theme, overrides, lang: langRaw } = body as { theme?: unknown; overrides?: unknown; lang?: unknown };

  if (typeof theme !== "string" || !THEME_ID_RE.test(theme)) {
    return NextResponse.json({ error: "invalid theme id" }, { status: 400 });
  }
  if (!overrides || typeof overrides !== "object") {
    return NextResponse.json({ error: "overrides must be object" }, { status: 400 });
  }
  const lang = normLang(langRaw);

  const entries = Object.entries(overrides as Record<string, unknown>);
  if (entries.length > MAX_FIELDS) {
    return NextResponse.json({ error: `too many fields (max ${MAX_FIELDS})` }, { status: 400 });
  }

  // Validate + bucket fields. Mapped fields go into `pageBuckets` keyed
  // by setting key (so we can write each row once with all its patches).
  // Unmapped fields go into the flat `theme_content` accumulator.
  const themeContentPatches: Record<string, string> = {};
  const pageBuckets: Record<string, { fieldId: string; value: string }[]> = {};
  for (const [k, v] of entries) {
    if (!FIELD_ID_RE.test(k)) continue;
    if (typeof v !== "string") continue;
    if (Buffer.byteLength(v, "utf8") > MAX_FIELD_VALUE_BYTES) {
      return NextResponse.json({ error: `field "${k}" exceeds size limit` }, { status: 400 });
    }
    const mapping = CONTENT_MAPPINGS[k];
    if (mapping) {
      (pageBuckets[mapping.settingKey] ||= []).push({ fieldId: k, value: v });
    } else {
      themeContentPatches[k] = v;
    }
  }

  // ── Layer 1: theme_content row (unmapped fields) ──────────────────
  const themeKey = `${THEME_CONTENT_SETTING_PREFIX}${theme}`;
  const themeRow = await prisma.siteSetting.findUnique({ where: { key: themeKey } });
  const existingThemeContent: Record<string, string> = {};
  if (themeRow?.value) {
    try {
      const parsed = JSON.parse(themeRow.value);
      if (parsed && typeof parsed === "object") {
        for (const [k, v] of Object.entries(parsed)) {
          if (typeof v === "string" && FIELD_ID_RE.test(k)) existingThemeContent[k] = v;
        }
      }
    } catch { /* corrupt — start clean */ }
  }
  const mergedThemeContent = { ...existingThemeContent, ...themeContentPatches };
  if (Object.keys(mergedThemeContent).length > MAX_FIELDS) {
    return NextResponse.json({ error: `too many fields (max ${MAX_FIELDS})` }, { status: 400 });
  }
  if (Object.keys(themeContentPatches).length > 0 || !themeRow) {
    await prisma.siteSetting.upsert({
      where: { key: themeKey },
      create: { key: themeKey, value: JSON.stringify(mergedThemeContent) },
      update: { value: JSON.stringify(mergedThemeContent) },
    });
  }

  // ── Layer 2: page_* rows (mapped fields) ──────────────────────────
  // For each touched page setting: load the existing JSON, apply every
  // patch via the mapping's nested path (preserving the opposite-lang
  // slot for bilingual cells), write back atomically.
  for (const [settingKey, patches] of Object.entries(pageBuckets)) {
    const row = await prisma.siteSetting.findUnique({ where: { key: settingKey } });
    let blob: Record<string, unknown> = {};
    if (row?.value) {
      try {
        const parsed = JSON.parse(row.value);
        if (parsed && typeof parsed === "object") blob = parsed as Record<string, unknown>;
      } catch { /* corrupt — start clean */ }
    }

    for (const { fieldId, value } of patches) {
      const mapping = CONTENT_MAPPINGS[fieldId];
      if (!mapping) continue;
      if (mapping.bilingual) {
        const existingCell = getPathValue(blob, mapping.path);
        const cur = existingCell && typeof existingCell === "object" && !Array.isArray(existingCell)
          ? (existingCell as Record<string, unknown>)
          : {};
        // Preserve the opposite language; write current lang slot.
        const next = { ...cur, [lang]: value };
        // If a string had been stored previously (legacy form data), put
        // its value into both lang slots that don't already have a value
        // — keeps the storefront from going blank on the unedited lang.
        if (typeof existingCell === "string") {
          if (!next.en) next.en = existingCell;
          if (!next.bn) next.bn = existingCell;
          next[lang] = value;
        }
        setPathValue(blob, mapping.path, next);
      } else {
        setPathValue(blob, mapping.path, value);
      }
    }

    await prisma.siteSetting.upsert({
      where: { key: settingKey },
      create: { key: settingKey, value: JSON.stringify(blob) },
      update: { value: JSON.stringify(blob) },
    });
  }

  // Bust caches so both the storefront engine cache AND any dashboard
  // form data caches refresh. `:settings` is the same tag dashboard
  // forms invalidate when admins save them, so both surfaces share the
  // refresh path.
  revalidateTag(`t${tenant.id}:theme-content`, "max");
  revalidateTag(`t${tenant.id}:settings`, "max");

  // Return the FULL resolved overrides map for the active language so
  // the client's local state mirrors what's actually persisted across
  // both layers — not just the incoming subset.
  const resolved = await resolveOverrides(prisma, theme, lang);
  return NextResponse.json({ ok: true, tenantId: tenant.id, theme, lang, overrides: resolved });
}
