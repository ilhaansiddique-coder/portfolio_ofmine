/**
 * GET /api/v1/lp-products?ids=1,2,3
 *
 * Public endpoint — fetches product data by comma-separated IDs.
 * Used by Puck landing-page widgets (LandingProducts, LandingCheckout)
 * to load live product data in both the editor and on published pages.
 */
import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse } from "@/lib/api-response";
import { inStockWhere } from "@/lib/productFilters";

export async function GET(request: NextRequest) {
  const { prisma } = await getPrismaForRequest(request);
  const idsParam = request.nextUrl.searchParams.get("ids") || "";

  const ids = idsParam
    .split(",")
    .map((s) => parseInt(s.trim(), 10))
    .filter((n) => !isNaN(n) && n > 0);

  if (ids.length === 0) return jsonResponse([]);

  const products = await prisma.product.findMany({
    where: { id: { in: ids }, AND: [inStockWhere] },
    include: {
      variants: { where: { isActive: true }, orderBy: { sortOrder: "asc" } },
    },
  });

  // Return in the same order the caller specified
  const ordered = ids
    .map((id) => products.find((p) => p.id === id))
    .filter(Boolean)
    .map((p) => serialize(p!));

  return jsonResponse(ordered);
}
