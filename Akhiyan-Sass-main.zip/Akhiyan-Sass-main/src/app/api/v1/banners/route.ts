import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse } from "@/lib/api-response";

export async function GET(req: Request) {
  const { prisma } = await getPrismaForRequest(req);
  const banners = await prisma.banner.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: "asc" },
  });

  return jsonResponse(banners.map(serialize));
}
