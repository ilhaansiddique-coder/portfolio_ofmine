import { NextRequest } from "next/server";
import { getPrismaForRequest } from "@/lib/prisma-tenant";
import { serialize } from "@/lib/serialize";
import { jsonResponse, notFound, unauthorized } from "@/lib/api-response";
import { getSessionUser } from "@/lib/auth-helpers";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { prisma } = await getPrismaForRequest(request);
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const { id } = await params;
  const order = await prisma.order.findFirst({
    where: { id: Number(id), userId: user.id },
    include: { items: true },
  });

  if (!order) return notFound("Order not found");

  return jsonResponse(serialize(order));
}
