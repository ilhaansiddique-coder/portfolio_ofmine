/**
 * Container healthcheck endpoint.
 *
 * Used by Docker HEALTHCHECK (Dockerfile) and Coolify's service health
 * probe. Intentionally minimal — just confirms the Node process is up,
 * the App Router is responding, and the container has finished booting.
 *
 * Deliberately does NOT touch Prisma or any tenant DB — a transient DB
 * blip should not flap the container. Liveness only, not readiness.
 *
 * `runtime: "nodejs"` forces the route off the edge runtime so it shares
 * the same Node worker as the rest of the app.
 * `dynamic: "force-dynamic"` disables ISR / static generation so the
 * probe always hits live code rather than a stale prerender.
 */

import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(
    {
      ok: true,
      ts: Date.now(),
      uptime: typeof process !== "undefined" ? process.uptime() : null,
    },
    { headers: { "Cache-Control": "no-store, no-cache, must-revalidate" } },
  );
}

export async function HEAD() {
  return new Response(null, {
    status: 200,
    headers: { "Cache-Control": "no-store" },
  });
}
