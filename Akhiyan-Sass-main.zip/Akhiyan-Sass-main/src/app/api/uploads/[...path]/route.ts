import { NextRequest } from "next/server";
import { stat, readFile } from "fs/promises";
import path from "path";
import { getUploadDir, mimeForExt } from "@/lib/uploads";

/**
 * GET /api/uploads/<filename>
 *
 * Streams files from `getUploadDir()` (env-configurable) so that runtime-added
 * uploads work even when Next's standalone build doesn't serve `public/`. The
 * legacy `/uploads/<filename>` URL is rewritten to here in `next.config.ts`,
 * so existing image URLs keep working without any DB migration.
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> },
) {
  try {
    const { path: parts } = await params;
    if (!parts || parts.length === 0) return new Response("Not found", { status: 404 });

    // Strip any traversal — basename each segment, rejoin.
    const safeRel = parts.map((p) => path.basename(p)).join("/");
    const abs = path.join(getUploadDir(), safeRel);

    // Confirm it's actually under the upload dir (defense-in-depth).
    const root = path.resolve(getUploadDir());
    if (!path.resolve(abs).startsWith(root + path.sep) && path.resolve(abs) !== root) {
      return new Response("Forbidden", { status: 403 });
    }

    const stats = await stat(abs).catch(() => null);
    if (!stats || !stats.isFile()) return new Response("Not found", { status: 404 });

    const data = await readFile(abs);
    const ext = path.extname(abs).toLowerCase();
    const mime = mimeForExt(ext);

    // Files that the browser would otherwise execute inline on our origin —
    // SVG can carry <script>, HTML obviously executes, PDF historically had
    // JS support. Force them to download instead, killing stored-XSS via
    // user-uploaded media.
    const INLINE_EXECUTES = new Set([".svg", ".html", ".htm", ".xml", ".xhtml"]);
    const baseHeaders: Record<string, string> = {
      "Content-Type": mime,
      "Content-Length": String(stats.size),
      "Cache-Control": "public, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
    };
    if (INLINE_EXECUTES.has(ext)) {
      baseHeaders["Content-Disposition"] = `attachment; filename="${path.basename(abs)}"`;
      // Belt-and-braces — any script inside an SVG/HTML attached here would
      // fail to fetch resources / hit the network.
      baseHeaders["Content-Security-Policy"] = "default-src 'none'; sandbox";
    }

    return new Response(new Uint8Array(data), {
      status: 200,
      headers: baseHeaders,
    });
  } catch {
    return new Response("Server error", { status: 500 });
  }
}
