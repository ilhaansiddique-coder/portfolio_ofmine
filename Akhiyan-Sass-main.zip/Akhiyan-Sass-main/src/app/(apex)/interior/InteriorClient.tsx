"use client";

/**
 * Atelier Verdant — interior design studio landing page.
 *
 * Fresh build using common landing-page sections (hero, projects,
 * stats, process, services, press, testimonials, about, insights,
 * CTA, footer). All copy + brand are original to this project and
 * unrelated to any reference site.
 */

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import {
  FiArrowRight,
  FiArrowUpRight,
  FiCompass,
  FiLayers,
  FiHome,
  FiSliders,
  FiSun,
  FiPenTool,
  FiCheck,
  FiInstagram,
  FiLinkedin,
  FiTwitter,
  FiMail,
  FiPhone,
  FiMapPin,
} from "react-icons/fi";

// ─── Data (all original) ────────────────────────────────────────────────────

const HERO_SLIDES = [
  {
    img: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=1920&q=80",
    eyebrow: "Residential",
    title: "Quiet rooms that hold light",
    sub: "Considered interiors for the way you actually live.",
  },
  {
    img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1920&q=80",
    eyebrow: "Hospitality",
    title: "Spaces guests remember",
    sub: "Boutique stays designed around story, texture, and warmth.",
  },
  {
    img: "https://images.unsplash.com/photo-1567016432779-094069958ea5?w=1920&q=80",
    eyebrow: "Workplace",
    title: "Offices that feel like air",
    sub: "Studios and HQs built for focused work and unforced collaboration.",
  },
];

const FEATURED_PROJECTS = [
  {
    img: "https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=900&q=80",
    cat: "Residence",
    name: "Ashfield Terrace",
    loc: "Dhanmondi",
  },
  {
    img: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80",
    cat: "Hotel",
    name: "House of Marin",
    loc: "Cox's Bazar",
  },
  {
    img: "https://images.unsplash.com/photo-1567016526105-22da7c13161a?w=900&q=80",
    cat: "Office",
    name: "Studio Northbridge",
    loc: "Gulshan",
  },
  {
    img: "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=900&q=80",
    cat: "Restaurant",
    name: "Apiary Café",
    loc: "Banani",
  },
];

const STATS = [
  { icon: FiHome, value: "142", label: "Projects delivered" },
  { icon: FiLayers, value: "11", label: "Years in practice" },
  { icon: FiSun, value: "38", label: "Awards & features" },
  { icon: FiCheck, value: "98%", label: "Repeat clients" },
];

const PROCESS = [
  { step: "01", title: "Discover", body: "First conversation. We listen to how you move through your day." },
  { step: "02", title: "Define", body: "Brief, budget, and mood — captured in one shared document." },
  { step: "03", title: "Design", body: "Floor plans, material boards, 3D walkthroughs you can rotate." },
  { step: "04", title: "Detail", body: "Joinery drawings, lighting plans, finishing schedules." },
  { step: "05", title: "Deliver", body: "On-site project management with weekly client reviews." },
  { step: "06", title: "Dwell", body: "Final styling, handover, and a year of post-move support." },
];

const SERVICES = [
  { icon: FiHome, title: "Residential", body: "Apartments, family homes, weekend retreats." },
  { icon: FiCompass, title: "Hospitality", body: "Hotels, restaurants, cafés, lounges, spas." },
  { icon: FiPenTool, title: "Workplace", body: "Co-working, headquarters, studios, agencies." },
  { icon: FiSliders, title: "Styling", body: "Furniture curation, art placement, photo prep." },
];

const PRESS_LOGOS = [
  "Archifield", "Detail Quarterly", "Frame Asia", "InsideOut", "Object & Form",
  "PLAN Mag", "Solid State", "Studio Notes", "Verge",
];

const CLIENT_LOGOS = [
  "Northwind", "Halcyon", "Foundry No. 6", "Marin & Co.", "Brackish",
  "Page Two", "Atlas Studio", "Glasshouse",
];

const TESTIMONIALS = [
  {
    quote:
      "They moved at our pace and pushed when we needed pushing. The flat feels twice the size now and nothing in it is accidental.",
    name: "Tahmida Rahman",
    role: "Homeowner, Gulshan",
  },
  {
    quote:
      "Our café re-opened to a queue down the block. Guests photograph the banquettes and the brass shelves more than the food.",
    name: "Ishan Choudhury",
    role: "Founder, Apiary Café",
  },
  {
    quote:
      "Our team retention numbers changed after the office redesign. People come in early. That has never been true for us.",
    name: "Nadia Hossain",
    role: "Head of People, Northbridge",
  },
];

const BLOG = [
  {
    img: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=600&q=80",
    cat: "Material",
    title: "On the patience of lime plaster",
    date: "May 22, 2026",
  },
  {
    img: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&q=80",
    cat: "Lighting",
    title: "Why we specify 2700K everywhere",
    date: "May 14, 2026",
  },
  {
    img: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=600&q=80",
    cat: "Practice",
    title: "Notes from our first decade",
    date: "Apr 30, 2026",
  },
];

// ─── Component ──────────────────────────────────────────────────────────────

export default function InteriorClient() {
  const [slide, setSlide] = useState(0);
  const [tIdx, setTIdx] = useState(0);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % HERO_SLIDES.length), 6000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => setTIdx((i) => (i + 1) % TESTIMONIALS.length), 7000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main className="bg-white text-stone-900 font-sans">
      {/* ── Sticky Nav ──────────────────────────────────────────────────── */}
      <nav
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          scrolled ? "bg-white/95 backdrop-blur shadow-sm" : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between">
          <Link href="/interior" className={`text-xl font-semibold tracking-tight ${scrolled ? "text-stone-900" : "text-white"}`}>
            Atelier <span className="font-light italic">Verdant</span>
          </Link>
          <div className={`hidden md:flex items-center gap-8 text-sm font-medium ${scrolled ? "text-stone-700" : "text-white/90"}`}>
            <a href="#projects" className="hover:opacity-70">Projects</a>
            <a href="#services" className="hover:opacity-70">Services</a>
            <a href="#process" className="hover:opacity-70">Process</a>
            <a href="#journal" className="hover:opacity-70">Journal</a>
            <a href="#contact" className="hover:opacity-70">Contact</a>
          </div>
          <a
            href="#contact"
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-colors ${
              scrolled
                ? "bg-emerald-700 text-white hover:bg-emerald-800"
                : "bg-white/15 text-white backdrop-blur hover:bg-white/25 border border-white/30"
            }`}
          >
            Book a consult
            <FiArrowRight className="w-4 h-4" />
          </a>
        </div>
      </nav>

      {/* ── Hero ───────────────────────────────────────────────────────── */}
      <section className="relative min-h-screen overflow-hidden">
        {HERO_SLIDES.map((s, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ${i === slide ? "opacity-100" : "opacity-0"}`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={s.img} alt="" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/35 to-black/65" />
          </div>
        ))}
        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 min-h-screen flex items-end pb-20 md:pb-28">
          <div className="max-w-3xl text-white">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-emerald-200 mb-5">
              {HERO_SLIDES[slide].eyebrow}
            </span>
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-light leading-[1.05] tracking-tight">
              {HERO_SLIDES[slide].title}
            </h1>
            <p className="mt-6 text-lg md:text-xl text-white/85 max-w-xl font-light leading-relaxed">
              {HERO_SLIDES[slide].sub}
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-white text-stone-900 rounded-full font-semibold hover:bg-stone-100 transition-colors"
              >
                See projects <FiArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-7 py-3.5 border border-white/40 text-white rounded-full font-semibold hover:bg-white/10 transition-colors backdrop-blur"
              >
                Start a project
              </a>
            </div>
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex gap-2">
          {HERO_SLIDES.map((_, i) => (
            <button
              key={i}
              onClick={() => setSlide(i)}
              aria-label={`Slide ${i + 1}`}
              className={`h-1.5 rounded-full transition-all ${i === slide ? "w-10 bg-white" : "w-6 bg-white/40"}`}
            />
          ))}
        </div>
      </section>

      {/* ── Featured Projects ──────────────────────────────────────────── */}
      <section id="projects" className="py-20 md:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div>
              <span className="text-xs uppercase tracking-[0.3em] text-emerald-700">Selected work</span>
              <h2 className="mt-3 text-3xl md:text-5xl font-light tracking-tight text-stone-900">
                Spaces from the last 12 months
              </h2>
            </div>
            <a href="#" className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 hover:gap-3 transition-all">
              View full archive <FiArrowUpRight className="w-4 h-4" />
            </a>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURED_PROJECTS.map((p) => (
              <a key={p.name} href="#" className="group block">
                <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-stone-100">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={p.img}
                    alt={p.name}
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="mt-4">
                  <span className="text-xs uppercase tracking-wider text-emerald-700">{p.cat}</span>
                  <h3 className="mt-1 text-lg font-medium text-stone-900 group-hover:text-emerald-700 transition-colors">
                    {p.name}
                  </h3>
                  <p className="text-sm text-stone-500">{p.loc}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ── Stats Strip ────────────────────────────────────────────────── */}
      <section className="bg-stone-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-10">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-emerald-700/20 text-emerald-300 mb-4">
                <s.icon className="w-6 h-6" />
              </div>
              <div className="text-4xl md:text-5xl font-light tracking-tight">{s.value}</div>
              <div className="mt-2 text-sm text-stone-400 uppercase tracking-wider">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Process ────────────────────────────────────────────────────── */}
      <section id="process" className="py-20 md:py-28 bg-stone-50">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="max-w-2xl mb-16">
            <span className="text-xs uppercase tracking-[0.3em] text-emerald-700">How we work</span>
            <h2 className="mt-3 text-3xl md:text-5xl font-light tracking-tight text-stone-900">
              Six steps from first call to handover
            </h2>
          </div>
          <div className="relative grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PROCESS.map((p) => (
              <div key={p.step} className="relative bg-white p-8 rounded-2xl border border-stone-200">
                <div className="text-5xl font-light text-emerald-700/30">{p.step}</div>
                <h3 className="mt-4 text-xl font-medium text-stone-900">{p.title}</h3>
                <p className="mt-3 text-stone-600 leading-relaxed">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Services ───────────────────────────────────────────────────── */}
      <section id="services" className="py-20 md:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="max-w-2xl mb-16">
            <span className="text-xs uppercase tracking-[0.3em] text-emerald-700">Practice</span>
            <h2 className="mt-3 text-3xl md:text-5xl font-light tracking-tight text-stone-900">
              What we design
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {SERVICES.map((s) => (
              <div
                key={s.title}
                className="group p-8 rounded-2xl bg-stone-50 hover:bg-emerald-50 hover:-translate-y-1 transition-all border border-transparent hover:border-emerald-200"
              >
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-emerald-700 text-white group-hover:rotate-6 transition-transform">
                  <s.icon className="w-6 h-6" />
                </div>
                <h3 className="mt-5 text-xl font-medium text-stone-900">{s.title}</h3>
                <p className="mt-2 text-stone-600 leading-relaxed">{s.body}</p>
                <a href="#contact" className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-emerald-700 group-hover:gap-2 transition-all">
                  Learn more <FiArrowRight className="w-4 h-4" />
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Press marquee ─────────────────────────────────────────────── */}
      <section className="py-12 border-y border-stone-200 bg-white overflow-hidden">
        <p className="text-center text-xs uppercase tracking-[0.3em] text-stone-500 mb-6">As featured in</p>
        <div className="relative overflow-hidden">
          <div className="flex gap-16 whitespace-nowrap animate-[marquee_30s_linear_infinite]">
            {[...PRESS_LOGOS, ...PRESS_LOGOS].map((n, i) => (
              <span key={i} className="text-2xl font-serif italic text-stone-400 hover:text-stone-900 transition-colors">
                {n}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Client logos ───────────────────────────────────────────────── */}
      <section className="py-12 bg-stone-50 overflow-hidden">
        <p className="text-center text-xs uppercase tracking-[0.3em] text-stone-500 mb-6">Trusted by</p>
        <div className="relative overflow-hidden">
          <div className="flex gap-20 whitespace-nowrap animate-[marquee_25s_linear_infinite_reverse]">
            {[...CLIENT_LOGOS, ...CLIENT_LOGOS].map((n, i) => (
              <span key={i} className="text-xl font-semibold tracking-tight text-stone-400 hover:text-stone-900 transition-colors">
                {n}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ───────────────────────────────────────────────── */}
      <section className="py-20 md:py-28 bg-white">
        <div className="max-w-4xl mx-auto px-4 md:px-8 text-center">
          <span className="text-xs uppercase tracking-[0.3em] text-emerald-700">Words from clients</span>
          <div className="mt-10 min-h-[200px]">
            <p className="text-2xl md:text-3xl font-light leading-relaxed text-stone-800 italic">
              &ldquo;{TESTIMONIALS[tIdx].quote}&rdquo;
            </p>
            <div className="mt-8">
              <p className="font-medium text-stone-900">{TESTIMONIALS[tIdx].name}</p>
              <p className="text-sm text-stone-500">{TESTIMONIALS[tIdx].role}</p>
            </div>
          </div>
          <div className="mt-8 flex justify-center gap-2">
            {TESTIMONIALS.map((_, i) => (
              <button
                key={i}
                onClick={() => setTIdx(i)}
                aria-label={`Testimonial ${i + 1}`}
                className={`h-2 rounded-full transition-all ${i === tIdx ? "w-8 bg-emerald-700" : "w-2 bg-stone-300"}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── About snippet ──────────────────────────────────────────────── */}
      <section className="py-20 md:py-28 bg-stone-50">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid md:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://images.unsplash.com/photo-1631679706909-1844bbd07221?w=1000&q=80"
              alt=""
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-emerald-700">About the studio</span>
            <h2 className="mt-3 text-3xl md:text-5xl font-light tracking-tight text-stone-900 leading-tight">
              A small team. A long list of finished rooms.
            </h2>
            <p className="mt-6 text-lg text-stone-600 leading-relaxed">
              We are nine people working from a converted warehouse in the city.
              We specify lime, brass, jute, and woods you can still find a tree for.
              We move slowly on purpose. Every project gets one principal designer
              from kickoff to keys.
            </p>
            <div className="mt-8 grid grid-cols-2 gap-6">
              {["Founded 2015", "Bangladesh + UAE", "Award shortlists 2022–24", "100% in-house drafting"].map((t) => (
                <div key={t} className="flex items-start gap-3">
                  <FiCheck className="w-5 h-5 text-emerald-700 mt-0.5 shrink-0" />
                  <span className="text-stone-700">{t}</span>
                </div>
              ))}
            </div>
            <a href="#contact" className="mt-10 inline-flex items-center gap-2 text-emerald-700 font-semibold hover:gap-3 transition-all">
              Read our manifesto <FiArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      {/* ── Journal ────────────────────────────────────────────────────── */}
      <section id="journal" className="py-20 md:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div>
              <span className="text-xs uppercase tracking-[0.3em] text-emerald-700">Journal</span>
              <h2 className="mt-3 text-3xl md:text-5xl font-light tracking-tight text-stone-900">
                Recent writing
              </h2>
            </div>
            <a href="#" className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 hover:gap-3 transition-all">
              All entries <FiArrowUpRight className="w-4 h-4" />
            </a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG.map((b) => (
              <a key={b.title} href="#" className="group block">
                <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-stone-100">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={b.img}
                    alt={b.title}
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="mt-5">
                  <div className="flex items-center gap-3 text-xs uppercase tracking-wider">
                    <span className="text-emerald-700 font-semibold">{b.cat}</span>
                    <span className="text-stone-400">{b.date}</span>
                  </div>
                  <h3 className="mt-2 text-xl font-medium text-stone-900 group-hover:text-emerald-700 transition-colors">
                    {b.title}
                  </h3>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA banner ─────────────────────────────────────────────────── */}
      <section id="contact" className="relative py-20 md:py-32 bg-emerald-900 text-white overflow-hidden">
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-emerald-700/40 blur-3xl" aria-hidden />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-emerald-700/30 blur-3xl" aria-hidden />
        <div className="relative max-w-4xl mx-auto px-4 md:px-8 text-center">
          <h2 className="text-3xl md:text-5xl font-light tracking-tight leading-tight">
            Have a project starting in the next few months?
          </h2>
          <p className="mt-5 text-lg text-emerald-100 max-w-2xl mx-auto">
            We take on a small number of new clients each quarter. Tell us about your space and we&apos;ll send a thoughtful response within two working days.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <a
              href="mailto:hello@atelierverdant.com"
              className="inline-flex items-center gap-2 px-7 py-3.5 bg-white text-stone-900 rounded-full font-semibold hover:bg-stone-100 transition-colors"
            >
              Send a project brief <FiArrowRight className="w-4 h-4" />
            </a>
            <a
              href="tel:+8801700000000"
              className="inline-flex items-center gap-2 px-7 py-3.5 border border-white/40 rounded-full font-semibold hover:bg-white/10 transition-colors"
            >
              Call the studio
            </a>
          </div>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────────────── */}
      <footer className="bg-stone-900 text-stone-300 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-10">
          <div className="col-span-2 md:col-span-1">
            <div className="text-2xl font-semibold tracking-tight text-white">
              Atelier <span className="font-light italic">Verdant</span>
            </div>
            <p className="mt-4 text-sm text-stone-400 leading-relaxed">
              An interior design practice based in Dhaka, working across residential, hospitality, and workplace projects.
            </p>
            <div className="mt-6 flex gap-3">
              {[FiInstagram, FiLinkedin, FiTwitter].map((Icon, i) => (
                <a key={i} href="#" className="w-9 h-9 inline-flex items-center justify-center rounded-full bg-white/5 hover:bg-emerald-700 transition-colors">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Studio</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white">About</a></li>
              <li><a href="#services" className="hover:text-white">Services</a></li>
              <li><a href="#process" className="hover:text-white">Process</a></li>
              <li><a href="#" className="hover:text-white">Careers</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Work</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#projects" className="hover:text-white">Projects</a></li>
              <li><a href="#journal" className="hover:text-white">Journal</a></li>
              <li><a href="#" className="hover:text-white">Press</a></li>
              <li><a href="#" className="hover:text-white">Awards</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-medium mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2"><FiMail className="w-4 h-4 text-emerald-400" /> hello@atelierverdant.com</li>
              <li className="flex items-center gap-2"><FiPhone className="w-4 h-4 text-emerald-400" /> +880 1700 000 000</li>
              <li className="flex items-start gap-2"><FiMapPin className="w-4 h-4 text-emerald-400 mt-0.5" /> 14 Rd 6, Dhanmondi, Dhaka</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 md:px-8 mt-12 pt-6 border-t border-white/10 flex flex-col md:flex-row justify-between gap-3 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} Atelier Verdant. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">Terms</a>
          </div>
        </div>
      </footer>

      {/* Marquee keyframes (scoped, no extra CSS file). */}
      <style jsx global>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
      `}</style>
    </main>
  );
}
