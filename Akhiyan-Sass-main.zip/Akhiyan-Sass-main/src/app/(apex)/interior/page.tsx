import type { Metadata } from "next";
import InteriorClient from "./InteriorClient";

export const metadata: Metadata = {
  title: "Atelier Verdant — Modern Interior Design Studio",
  description:
    "Atelier Verdant designs calm, considered interiors for homes, hospitality, and workplaces. Discover our process, projects, and design philosophy.",
};

export default function InteriorRoute() {
  return <InteriorClient />;
}
