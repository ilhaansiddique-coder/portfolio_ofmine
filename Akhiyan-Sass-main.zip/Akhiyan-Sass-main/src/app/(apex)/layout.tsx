/**
 * Apex (marketing portfolio) root layout.
 *
 * Owns its own <html>/<body> so the agency portfolio renders independent of
 * tenant storefront chrome. URLs under this group live at `/landing/...`; on
 * the bare base domain the proxy middleware rewrites `/about` → `/landing/about`
 * etc., so visitors see clean paths.
 */
import type { Metadata } from "next";
import { Bricolage_Grotesque, Playfair_Display } from "next/font/google";
import "./portfolio.css";

const bricolageGrotesque = Bricolage_Grotesque({
  variable: "--font-bricolage-grotesque",
  subsets: ["latin"],
  display: "swap",
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
});

export const metadata: Metadata = {
  title: "Contra Digital | Leading UI/UX Design Agency",
  description:
    "We design products that drive results. Full-service UI/UX design agency offering web design, app design, branding, Webflow & Framer development.",
  keywords: ["UI/UX Design", "Web Design", "App Design", "Branding", "Webflow", "Framer", "Design Agency"],
};

export default function ApexLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${bricolageGrotesque.variable} ${playfair.variable}`} suppressHydrationWarning>
      <body className="min-h-screen bg-background text-foreground antialiased">
        {children}
      </body>
    </html>
  );
}
