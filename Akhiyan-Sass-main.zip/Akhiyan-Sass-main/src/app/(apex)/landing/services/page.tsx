import type { Metadata } from "next";
import Services from "@/components/portfolio/Services";
import CTAForm from "@/components/portfolio/CTAForm";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Services | ContraDigital",
  description:
    "UI/UX Design, Web Development, Logo & Branding, Webflow & Framer — everything we offer, and the work behind each service.",
};

export default function ServicesPage() {
  return (
    <>
      <main>
        {/* Hero */}
        <section className="pt-16 pb-12 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-primary-light mb-3 block">
              What We Do
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-text-dark mb-6 leading-tight">
              Services We{" "}
              <span className="font-serif italic gradient-text">Deliver</span>
            </h1>
            <p className="text-text-muted text-lg leading-relaxed max-w-2xl mx-auto">
              Design, development, branding, and no-code. Scroll the sticky panel
              to see every service we offer — tap any one for the full story.
            </p>
          </div>
        </section>

        {/* Services section (same sticky-scroll layout as the home page) */}
        <Services />

        {/* CTA */}
        <CTAForm />
      </main>
      <Footer />
    </>
  );
}
