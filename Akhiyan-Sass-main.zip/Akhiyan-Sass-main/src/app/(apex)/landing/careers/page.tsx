import type { Metadata } from "next";
import Careers from "@/components/portfolio/Careers";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Careers | ContraDigital",
  description:
    "Join the ContraDigital team. We're looking for talented designers, developers, and strategists to help us build the future of digital products.",
};

export default function CareersPage() {
  return (
    <>
      <main>
        {/* Hero */}
        <section className="pt-16 pb-12 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-primary-light mb-3 block">
              Join Our Team
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-text-dark mb-6 leading-tight">
              Build Your Career{" "}
              <span className="font-serif italic gradient-text">With Us</span>
            </h1>
            <p className="text-text-muted text-lg leading-relaxed max-w-2xl mx-auto">
              We&apos;re always looking for talented people who are passionate about
              design and technology. Check out our open positions below.
            </p>
          </div>
        </section>

        {/* Careers */}
        <Careers />
      </main>
      <Footer />
    </>
  );
}
