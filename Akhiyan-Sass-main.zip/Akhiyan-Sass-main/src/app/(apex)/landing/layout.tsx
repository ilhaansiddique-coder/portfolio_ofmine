import BottomNav from "@/components/portfolio/BottomNav";
import SmoothScroll from "@/components/portfolio/SmoothScroll";

export default function PublicLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <SmoothScroll />
      {children}
      {/* Bottom blur overlay — sits above the bottom nav, desktop only */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-x-0 bottom-0 z-40 hidden lg:block"
        style={{
          height: "120px",
          backdropFilter: "blur(12px)",
          WebkitBackdropFilter: "blur(12px)",
          maskImage: "linear-gradient(to top, black 0%, black 40%, transparent 100%)",
          WebkitMaskImage: "linear-gradient(to top, black 0%, black 40%, transparent 100%)",
        }}
      />
      <BottomNav />
    </>
  );
}
