import Hero from "@/components/portfolio/Hero";
import ClientLogos from "@/components/portfolio/ClientLogos";
import Products from "@/components/portfolio/Products";
import Projects from "@/components/portfolio/Projects";
import Testimonials from "@/components/portfolio/Testimonials";
import Pricing from "@/components/portfolio/Pricing";
import ComparisonTable from "@/components/portfolio/ComparisonTable";
import Bonuses from "@/components/portfolio/Bonuses";
import FAQ from "@/components/portfolio/FAQ";
import CTAForm from "@/components/portfolio/CTAForm";
import Footer from "@/components/portfolio/Footer";

export default function Home() {
  return (
    <>
      <main>
        <Hero />
        <div className="-mt-20 relative z-10">
          <ClientLogos />
        </div>
        <Products />
        <Projects />
        <div style={{ background: "#09060f" }}>
          <div style={{ height: 50, background: "#ffffff", borderBottomLeftRadius: 20, borderBottomRightRadius: 20 }} />
        </div>
        <Testimonials />
        <div className="relative z-10 -mt-10 bg-white">
          <Pricing />
        </div>
        <Bonuses />
        <div className="relative z-10 -mt-10 bg-white">
          <ComparisonTable />
        </div>
        <div className="section-divider" />
        <FAQ />
        <CTAForm />
      </main>
      <Footer />
    </>
  );
}
