import type { Metadata } from "next";
import Pricing from "@/components/portfolio/Pricing";
import ComparisonTable from "@/components/portfolio/ComparisonTable";
import Bonuses from "@/components/portfolio/Bonuses";
import FAQ from "@/components/portfolio/FAQ";
import CTAForm from "@/components/portfolio/CTAForm";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Pricing | ContraDigital",
  description:
    "Transparent pricing for UI/UX design services. Choose the plan that fits your project — from one-time designs to monthly subscriptions.",
};

export default function PricingPage() {
  return (
    <>
      <main>
        {/* Hero */}
        <section className="pt-16 pb-12 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-primary-light mb-3 block">
              Pricing
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-text-dark mb-6 leading-tight">
              Simple,{" "}
              <span className="font-serif italic gradient-text">Transparent</span>{" "}
              Pricing
            </h1>
            <p className="text-text-muted text-lg leading-relaxed max-w-2xl mx-auto">
              No hidden fees. Pick the plan that works for your project and budget.
            </p>
          </div>
        </section>

        <Pricing />
        <Bonuses />
        <div className="relative z-10 -mt-10 bg-white">
          <ComparisonTable />
        </div>
        <div className="section-divider" />
        <FAQ />
        <CTAForm />
      </main>
      <Footer />
    </>
  );
}
