import Link from "next/link";
import Image from "next/image";
import { HiOutlineArrowRight } from "react-icons/hi2";
import Navbar from "@/components/portfolio/Navbar";
import Footer from "@/components/portfolio/Footer";
import { PRODUCTS } from "@/lib/portfolio/products";

export const metadata = {
  title: "Products | ContraDigital",
  description:
    "SaaS products built by Contra Digital. Launch your business with our flagship platforms.",
};

const STATUS_LABEL: Record<string, { label: string; cls: string }> = {
  live: { label: "Live", cls: "bg-emerald-100 text-emerald-700" },
  beta: { label: "Beta", cls: "bg-amber-100 text-amber-700" },
  coming_soon: { label: "Coming soon", cls: "bg-zinc-200 text-zinc-700" },
};

export default function ProductsPage() {
  return (
    <>
      <Navbar />
      <main className="pt-28 pb-24">
        <section className="mx-auto max-w-[1150px] px-6">
          {/* Header */}
          <div className="text-center max-w-2xl mx-auto">
            <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              Our Products
            </span>
            <h1 className="mt-4 text-4xl md:text-5xl font-bold tracking-tight text-text-dark">
              Software we built. <span className="italic font-playfair">You can use it.</span>
            </h1>
            <p className="mt-4 text-base md:text-lg text-text-muted">
              We don&apos;t just build for clients — we ship our own platforms.
              Sign up directly, no agency engagement needed.
            </p>
          </div>

          {/* Grid */}
          <div className="mt-12 grid gap-6 md:gap-8 sm:grid-cols-2">
            {PRODUCTS.map((p) => {
              const status = STATUS_LABEL[p.status] ?? STATUS_LABEL.live;
              return (
                <Link
                  key={p.slug}
                  href={`/products/${p.slug}`}
                  className="group block overflow-hidden rounded-3xl border border-black/8 bg-white shadow-sm hover:shadow-xl transition-all hover:-translate-y-1"
                >
                  {/* Image */}
                  <div
                    className="relative aspect-[16/10] overflow-hidden"
                    style={{ background: p.bgColor }}
                  >
                    <Image
                      src={p.image}
                      alt={p.name}
                      fill
                      sizes="(min-width:640px) 50vw, 100vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                    />
                    <span className={`absolute top-4 right-4 rounded-full px-2.5 py-1 text-xs font-medium ${status.cls}`}>
                      {status.label}
                    </span>
                  </div>

                  {/* Body */}
                  <div className="p-6">
                    <div className="flex items-center justify-between">
                      <span className="text-xs uppercase tracking-widest text-text-muted">{p.category}</span>
                      <span className="text-sm font-semibold" style={{ color: p.accentColor }}>{p.priceFrom}</span>
                    </div>
                    <h2 className="mt-2 text-2xl font-bold text-text-dark">{p.name}</h2>
                    <p className="mt-1 text-sm text-text-muted line-clamp-2">{p.tagline}</p>

                    <div className="mt-5 flex items-center gap-2 text-sm font-semibold text-text-dark group-hover:text-primary transition-colors">
                      View details
                      <HiOutlineArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </Link>
              );
            })}

            {/* "More coming" placeholder card */}
            <div className="rounded-3xl border-2 border-dashed border-black/10 p-8 flex flex-col items-center justify-center text-center min-h-[260px]">
              <span className="text-4xl">✨</span>
              <h3 className="mt-3 text-lg font-semibold text-text-dark">More launching soon</h3>
              <p className="mt-1 text-sm text-text-muted max-w-xs">
                Mobile-app builder, landing-page generator, and more. Stay tuned.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
