import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { HiOutlineArrowRight, HiOutlineCheckCircle } from "react-icons/hi2";
import Navbar from "@/components/portfolio/Navbar";
import Footer from "@/components/portfolio/Footer";
import { PRODUCTS, getProduct } from "@/lib/portfolio/products";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Ctx) {
  const { slug } = await params;
  const p = getProduct(slug);
  if (!p) return { title: "Product | ContraDigital" };
  return { title: `${p.name} | ContraDigital`, description: p.tagline };
}

export default async function ProductDetailPage({ params }: Ctx) {
  const { slug } = await params;
  const product = getProduct(slug);
  if (!product) notFound();

  return (
    <>
      <Navbar />
      <main className="pt-28 pb-24">
        {/* Hero */}
        <section className="mx-auto max-w-[1150px] px-6">
          <Link href="/products" className="text-xs text-text-muted hover:text-primary">
            ← All products
          </Link>

          <div className="mt-4 grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                {product.category}
              </span>
              <h1 className="mt-4 text-4xl md:text-5xl font-bold tracking-tight text-text-dark">
                {product.name}
              </h1>
              <p className="mt-3 text-lg md:text-xl text-text-muted">{product.tagline}</p>
              <p className="mt-4 text-base text-text-body leading-relaxed">{product.description}</p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href={product.ctaPrimary.href}
                  className="inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold text-white transition-all hover:shadow-lg"
                  style={{ background: product.accentColor }}
                >
                  {product.ctaPrimary.label}
                  <HiOutlineArrowRight className="w-4 h-4" />
                </Link>
                {product.ctaSecondary && (
                  <Link
                    href={product.ctaSecondary.href}
                    className="inline-flex items-center gap-2 rounded-xl border border-black/10 px-6 py-3 text-sm font-semibold text-text-dark hover:bg-black/[0.03] transition-colors"
                  >
                    {product.ctaSecondary.label}
                  </Link>
                )}
              </div>
              <p className="mt-3 text-sm text-text-muted">
                <span className="font-semibold" style={{ color: product.accentColor }}>{product.priceFrom}</span>
                {" · "}no setup fee · cancel anytime
              </p>
            </div>

            {/* Hero image */}
            <div
              className="relative aspect-[16/11] overflow-hidden rounded-3xl border border-black/8 shadow-xl"
              style={{ background: product.bgColor }}
            >
              <Image
                src={product.image}
                alt={product.name}
                fill
                sizes="(min-width:1024px) 50vw, 100vw"
                priority
                className="object-cover"
              />
            </div>
          </div>
        </section>

        {/* Features grid */}
        <section className="mx-auto max-w-[1150px] px-6 mt-20">
          <h2 className="text-2xl md:text-3xl font-bold text-text-dark">What&apos;s inside</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {product.features.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-black/8 bg-white p-5 hover:shadow-md transition-shadow"
              >
                <div
                  className="grid h-9 w-9 place-items-center rounded-xl text-white"
                  style={{ background: product.accentColor }}
                >
                  <HiOutlineCheckCircle className="w-5 h-5" />
                </div>
                <h3 className="mt-4 text-base font-semibold text-text-dark">{f.title}</h3>
                <p className="mt-1 text-sm text-text-muted">{f.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Highlights */}
        {product.highlights && product.highlights.length > 0 && (
          <section className="mx-auto max-w-[1150px] px-6 mt-20">
            <div className="rounded-3xl bg-zinc-50 p-8 md:p-12">
              <h2 className="text-2xl md:text-3xl font-bold text-text-dark">Why it&apos;s different</h2>
              <ul className="mt-6 space-y-4">
                {product.highlights.map((h, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="mt-1 text-xl" style={{ color: product.accentColor }}>•</span>
                    <span className="text-base text-text-body">{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        )}

        {/* Bottom CTA */}
        <section className="mx-auto max-w-[1150px] px-6 mt-20">
          <div className="rounded-3xl p-10 md:p-14 text-center" style={{ background: product.bgColor }}>
            <h2 className="text-3xl md:text-4xl font-bold text-text-dark">
              Ready to start?
            </h2>
            <p className="mt-3 text-base md:text-lg text-text-body max-w-xl mx-auto">
              {product.priceFrom}. No credit card needed to begin.
            </p>
            <Link
              href={product.ctaPrimary.href}
              className="mt-6 inline-flex items-center gap-2 rounded-xl px-8 py-4 text-base font-semibold text-white transition-all hover:shadow-lg"
              style={{ background: product.accentColor }}
            >
              {product.ctaPrimary.label}
              <HiOutlineArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export function generateStaticParams() {
  return PRODUCTS.map((p) => ({ slug: p.slug }));
}
