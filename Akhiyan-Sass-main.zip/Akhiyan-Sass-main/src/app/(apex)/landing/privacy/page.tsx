import type { Metadata } from "next";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Privacy Policy | ContraDigital",
  description: "Privacy Policy for ContraDigital design agency.",
};

export default function PrivacyPage() {
  return (
    <>
      <main className="pt-16 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-text-dark mb-8">Privacy Policy</h1>

          <div className="prose-custom space-y-6 text-text-muted text-sm leading-relaxed">
            <p>
              <strong className="text-text-dark">Last updated:</strong> April 19, 2026
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">1. Information We Collect</h2>
            <p>
              We collect information you provide directly, including your name, email address,
              phone number, and project details when you submit our contact form or engage our services.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">2. How We Use Your Information</h2>
            <p>
              We use the information we collect to respond to your inquiries, provide our design
              services, send project updates, and improve our website and services.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">3. Information Sharing</h2>
            <p>
              We do not sell, trade, or share your personal information with third parties, except
              as necessary to provide our services or as required by law.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">4. Data Security</h2>
            <p>
              We implement appropriate security measures to protect your personal information
              against unauthorized access, alteration, disclosure, or destruction.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">5. Cookies</h2>
            <p>
              Our website may use cookies to enhance your browsing experience. You can configure
              your browser to refuse cookies, though some features may not function properly.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">6. Third-Party Links</h2>
            <p>
              Our website may contain links to third-party sites. We are not responsible for
              the privacy practices or content of those sites.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">7. Your Rights</h2>
            <p>
              You have the right to access, correct, or delete your personal data. To exercise
              these rights, please contact us at the email address below.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">8. Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. Any changes will be posted
              on this page with an updated revision date.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">9. Contact</h2>
            <p>
              For questions about this policy, please contact us at{" "}
              <a href="mailto:elsiddique@gmail.com" className="text-primary-light hover:underline">
                elsiddique@gmail.com
              </a>
              .
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
