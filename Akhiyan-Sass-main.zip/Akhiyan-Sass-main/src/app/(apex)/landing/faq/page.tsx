import type { Metadata } from "next";
import FAQ from "@/components/portfolio/FAQ";
import CTAForm from "@/components/portfolio/CTAForm";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "FAQ | ContraDigital",
  description:
    "Frequently asked questions about ContraDigital's design services, process, pricing, and more.",
};

export default function FAQPage() {
  return (
    <>
      <main>
        {/* Hero */}
        <section className="pt-16 pb-12 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-primary-light mb-3 block">
              FAQ
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-text-dark mb-6 leading-tight">
              Got{" "}
              <span className="font-serif italic gradient-text">Questions?</span>
            </h1>
            <p className="text-text-muted text-lg leading-relaxed max-w-2xl mx-auto">
              Find answers to the most common questions about our services, process, and pricing.
            </p>
          </div>
        </section>

        <FAQ />
        <CTAForm />
      </main>
      <Footer />
    </>
  );
}
