import type { Metadata } from "next";
import SetApart from "@/components/portfolio/SetApart";
import Testimonials from "@/components/portfolio/Testimonials";
import CTAForm from "@/components/portfolio/CTAForm";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "About Us | ContraDigital",
  description:
    "Learn about ContraDigital — a full-service UI/UX design agency crafting digital products that drive real results. Trusted by 200+ brands worldwide.",
};

export default function AboutPage() {
  return (
    <>
      <main>
        {/* Hero */}
        <section className="pt-16 pb-20 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-primary-light mb-3 block">
              About Us
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-text-dark mb-6 leading-tight">
              We Design Products That{" "}
              <span className="font-serif italic gradient-text">Drive Results</span>
            </h1>
            <p className="text-text-muted text-lg leading-relaxed max-w-2xl mx-auto">
              ContraDigital is a full-service UI/UX design agency helping startups and
              enterprises build digital products that users love. From concept to launch,
              we craft every pixel with purpose.
            </p>
          </div>
        </section>

        {/* What Sets Us Apart */}
        <SetApart />

        {/* Testimonials */}
        <Testimonials />

        {/* CTA */}
        <CTAForm />
      </main>
      <Footer />
    </>
  );
}
