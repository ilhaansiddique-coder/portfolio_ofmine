import type { Metadata } from "next";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Blog | ContraDigital",
  description:
    "Insights, tutorials, and design thinking from the ContraDigital team. Stay updated with the latest in UI/UX design and digital product strategy.",
};

export default function BlogPage() {
  return (
    <>
      <main>
        <section className="pt-16 pb-24 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-primary-light mb-3 block">
              Our Blog
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold text-text-dark mb-6 leading-tight">
              Insights &{" "}
              <span className="font-serif italic gradient-text">Ideas</span>
            </h1>
            <p className="text-text-muted text-lg leading-relaxed max-w-2xl mx-auto mb-16">
              Design thinking, industry trends, and behind-the-scenes stories from our team.
            </p>

            <div className="card rounded-2xl p-12 text-center">
              <p className="text-text-muted text-lg">Coming soon — stay tuned!</p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
