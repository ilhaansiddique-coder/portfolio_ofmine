import { notFound } from "next/navigation";
import AkhiyanProject from "@/components/portfolio/projects/AkhiyanProject";
import Footer from "@/components/portfolio/Footer";

const PROJECT_SLUGS = ["akhiyan"];

export function generateStaticParams() {
  return PROJECT_SLUGS.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (slug === "akhiyan") {
    return {
      title: "Akhiyan BD — E-Commerce Case Study | Contra Digital",
      description:
        "How Contra Digital built a fully automated e-commerce store for Akhiyan BD, tripling conversions and eliminating manual WhatsApp orders.",
    };
  }
  return {};
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (slug === "akhiyan") {
    return (
      <>
        <main>
          <AkhiyanProject />
        </main>
        <Footer />
      </>
    );
  }
  notFound();
}
