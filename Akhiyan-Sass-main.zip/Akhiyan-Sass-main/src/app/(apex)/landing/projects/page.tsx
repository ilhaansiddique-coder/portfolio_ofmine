import type { Metadata } from "next";
import ProjectsHero from "@/components/portfolio/ProjectsHero";
import Projects from "@/components/portfolio/ProjectsGrid";
import CTAForm from "@/components/portfolio/CTAForm";
import Footer from "@/components/portfolio/Footer";
export const metadata: Metadata = {
  title: "Projects | Contra Digital",
  description:
    "Real projects, real results. Explore how Contra Digital has helped brands scale with web design, development, and performance marketing.",
};

export default function ProjectsPage() {
  return (
    <>
      <main>
        <ProjectsHero />
        <Projects />
        <CTAForm />
      </main>
      <Footer />
    </>
  );
}
