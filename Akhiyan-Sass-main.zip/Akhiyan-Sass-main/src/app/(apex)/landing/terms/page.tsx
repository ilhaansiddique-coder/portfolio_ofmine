import type { Metadata } from "next";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Terms of Service | ContraDigital",
  description: "Terms of Service for ContraDigital design agency.",
};

export default function TermsPage() {
  return (
    <>
      <main className="pt-16 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold text-text-dark mb-8">Terms of Service</h1>

          <div className="prose-custom space-y-6 text-text-muted text-sm leading-relaxed">
            <p>
              <strong className="text-text-dark">Last updated:</strong> April 19, 2026
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">1. Agreement to Terms</h2>
            <p>
              By accessing or using ContraDigital&apos;s services, you agree to be bound by these
              Terms of Service. If you do not agree to these terms, please do not use our services.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">2. Services</h2>
            <p>
              ContraDigital provides UI/UX design, web development, branding, and related digital
              design services. The scope of work for each project will be defined in a separate
              project agreement or proposal.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">3. Payment Terms</h2>
            <p>
              Payment terms will be outlined in individual project agreements. Unless otherwise
              specified, a deposit of 50% is required before work begins, with the remaining
              balance due upon project completion.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">4. Intellectual Property</h2>
            <p>
              Upon full payment, all deliverables and design assets created for the client become
              the client&apos;s property. ContraDigital retains the right to showcase completed
              projects in our portfolio unless otherwise agreed in writing.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">5. Revisions</h2>
            <p>
              The number of revision rounds included in a project will be specified in the project
              agreement. Additional revisions beyond the agreed scope may incur additional fees.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">6. Confidentiality</h2>
            <p>
              Both parties agree to keep all project-related information confidential. We are happy
              to sign a Non-Disclosure Agreement (NDA) upon request.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">7. Limitation of Liability</h2>
            <p>
              ContraDigital shall not be liable for any indirect, incidental, or consequential
              damages arising from the use of our services. Our total liability shall not exceed
              the total fees paid for the specific project in question.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">8. Changes to Terms</h2>
            <p>
              We reserve the right to modify these terms at any time. Changes will be effective
              upon posting to our website. Continued use of our services constitutes acceptance
              of the updated terms.
            </p>

            <h2 className="text-xl font-semibold text-text-dark mt-8">9. Contact</h2>
            <p>
              For questions about these terms, please contact us at{" "}
              <a href="mailto:elsiddique@gmail.com" className="text-primary-light hover:underline">
                elsiddique@gmail.com
              </a>
              .
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
