"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import dynamic from "next/dynamic";
import { WHATSAPP_URL_BD } from "@/lib/portfolio/contact";
import {
  HiOutlineExclamationCircle,
  HiOutlineCheckCircle,
  HiOutlineBolt,
  HiOutlineShoppingBag,
  HiOutlineCreditCard,
  HiOutlineTruck,
  HiOutlineChatBubbleLeftRight,
  HiOutlineChartBarSquare,
  HiOutlineDevicePhoneMobile,
  HiOutlineSparkles,
  HiCheck,
  HiOutlineArrowRight,
  HiOutlinePhone,
} from "react-icons/hi2";

const GLSLHills = dynamic(
  () => import("@/components/portfolio/ui/glsl-hills").then((m) => m.GLSLHills),
  { ssr: false }
);

const WHATSAPP = WHATSAPP_URL_BD;
const CALENDLY = WHATSAPP;

const fade = (delay = 0) => ({
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
});

// ─── Hero ─────────────────────────────────────────────────────────────────────

function Hero() {
  return (
    <section className="relative overflow-hidden bg-[#050310]">
      <GLSLHills cameraZ={125} planeSize={256} speed={0.5} />

      {/* Dark vignette overlay — matches homepage Hero */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          zIndex: 2,
          background:
            "radial-gradient(ellipse 80% 60% at 50% 40%, transparent 50%, rgb(57 174 50 / 55%) 100%)",
        }}
      />

      <div className="relative max-w-5xl mx-auto text-center px-6 pt-20 pb-24 sm:pt-28 sm:pb-32" style={{ zIndex: 10 }}>
        <motion.span {...fade(0)}
          className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1.5 mb-6"
          style={{
            border: "1px solid rgba(142,242,119,0.35)",
            color: "#8ef277",
            background: "rgba(142,242,119,0.08)",
          }}
        >
          🇧🇩 বাংলাদেশি ই-কমার্স ব্যবসার জন্য
        </motion.span>

        <motion.h1 {...fade(0.1)}
          className="font-bold text-white mb-6"
          style={{ fontSize: "clamp(2rem, 5.5vw, 4rem)", lineHeight: 1.15 }}
        >
          মাসে ১০ লক্ষ টাকা সেল করুন —
          <br />
          <span className="font-serif italic" style={{ color: "#8ef277" }}>ম্যানুয়াল কাজ ছাড়াই।</span>
        </motion.h1>

        <motion.p {...fade(0.2)}
          className="text-lg sm:text-xl max-w-2xl mx-auto mb-10"
          style={{ color: "rgba(255,255,255,0.7)", lineHeight: 1.6 }}
        >
          ফেসবুক থেকে ডেলিভারি পর্যন্ত — সম্পূর্ণ অটোমেটেড সিস্টেম। অর্ডার, পেমেন্ট, পাঠাও/স্টেডফাস্ট, bKash/Nagad — সব এক জায়গায়, ২৪/৭।
        </motion.p>

        {/* CTAs */}
        <motion.div {...fade(0.3)} className="flex flex-col sm:flex-row gap-3 justify-center items-center mb-12">
          <Link
            href={CALENDLY}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-[10px] font-bold transition-all hover:-translate-y-0.5"
            style={{
              background: "#8ef277",
              color: "#0a0a0a",
              boxShadow: "0 8px 32px rgba(142,242,119,0.4)",
            }}
          >
            <HiOutlineSparkles className="w-5 h-5" />
            <span>ফ্রি ডেমো বুক করুন</span>
          </Link>
          <Link
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-[10px] font-bold transition-all hover:-translate-y-0.5"
            style={{
              background: "rgba(255,255,255,0.06)",
              color: "#ffffff",
              border: "1px solid rgba(255,255,255,0.2)",
            }}
          >
            <HiOutlineChatBubbleLeftRight className="w-5 h-5" />
            <span>WhatsApp এ কথা বলুন</span>
          </Link>
        </motion.div>

        {/* Trust signals */}
        <motion.div {...fade(0.4)}
          className="flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm"
          style={{ color: "rgba(255,255,255,0.55)" }}
        >
          <span className="inline-flex items-center gap-2"><HiCheck className="w-4 h-4" style={{ color: "#8ef277" }} /> ২-৪ সপ্তাহে লাইভ</span>
          <span className="inline-flex items-center gap-2"><HiCheck className="w-4 h-4" style={{ color: "#8ef277" }} /> ১০০+ বাংলাদেশি ব্যবসা</span>
          <span className="inline-flex items-center gap-2"><HiCheck className="w-4 h-4" style={{ color: "#8ef277" }} /> ৬০ দিন ফ্রি সাপোর্ট</span>
        </motion.div>
      </div>
    </section>
  );
}

// ─── Pain Points ──────────────────────────────────────────────────────────────

const PAINS = [
  { title: "৫০টা ফেসবুক মেসেজ মিস হলো আজ?", desc: "মেসেঞ্জারে অর্ডার ট্র্যাক করা একটা দুঃস্বপ্ন। গ্রাহক চলে যায় — বিক্রি হারিয়ে যায়।" },
  { title: "কাস্টমার পেমেন্ট দিয়েছে কি না — যাচাই করতে ১০ মিনিট?", desc: "bKash/Nagad স্ক্রিনশট চেক করতে গিয়ে দিন শেষ। অটো-ভেরিফিকেশন ছাড়া স্কেল হবে না।" },
  { title: "Pathao/Steadfast এ আলাদা করে অর্ডার এন্ট্রি দেন?", desc: "ম্যানুয়ালি কপি-পেস্ট মানে ভুল হবেই। ভুল ঠিকানা = রিটার্ন = লস।" },
  { title: "ক্যাশ অন ডেলিভারিতে ৩০%+ রিটার্ন?", desc: "ফেক অর্ডার, কনফার্মেশন ছাড়াই শিপ — এটা আপনার প্রফিট খেয়ে ফেলছে।" },
];

function PainSection() {
  return (
    <section className="py-20 px-6" style={{ background: "#09060f" }}>
      <div className="max-w-5xl mx-auto">
        <motion.div {...fade(0)} className="text-center mb-12">
          <span
            className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1.5 mb-5"
            style={{
              border: "1px solid rgba(255,100,100,0.35)",
              color: "#ff8888",
              background: "rgba(255,100,100,0.06)",
            }}
          >
            চেনা সমস্যা?
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4" style={{ lineHeight: 1.2 }}>
            আপনি ব্যবসা করছেন,{" "}
            <span className="font-serif italic" style={{ color: "#ff8888" }}>না কাজ করছেন?</span>
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.55)" }}>
            বাংলাদেশের প্রায় সব ই-কমার্স ব্যবসায়ী এই কাজগুলো ম্যানুয়ালি করেন — এবং প্রতিদিন টাকা হারান।
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {PAINS.map((p, i) => (
            <motion.div
              key={p.title}
              {...fade(i * 0.05)}
              className="p-6 rounded-2xl flex items-start gap-4"
              style={{
                background: "#0d1a10",
                border: "1px solid rgba(255,100,100,0.15)",
              }}
            >
              <HiOutlineExclamationCircle className="w-7 h-7 shrink-0 mt-0.5" style={{ color: "#ff8888" }} />
              <div>
                <h3 className="text-lg font-bold text-white mb-2">{p.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.6)" }}>{p.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Solution ─────────────────────────────────────────────────────────────────

const FEATURES = [
  { icon: HiOutlineShoppingBag, title: "ফেসবুক/ইনস্টাগ্রাম থেকে ডিরেক্ট অর্ডার", desc: "মেসেঞ্জারের ঝামেলা শেষ। ক্যাটালগ থেকে এক ক্লিকে অর্ডার।" },
  { icon: HiOutlineCreditCard, title: "bKash + Nagad + Card একসাথে", desc: "অটো-ভেরিফিকেশন। স্ক্রিনশট চেক করার দিন শেষ।" },
  { icon: HiOutlineTruck, title: "Pathao, Steadfast, RedX অটো-পুশ", desc: "অর্ডার আসা মাত্রই ডেলিভারি কোম্পানিতে চলে যায়। কোনো ম্যানুয়াল এন্ট্রি নেই।" },
  { icon: HiOutlineChatBubbleLeftRight, title: "WhatsApp + SMS অটো নোটিফিকেশন", desc: "অর্ডার কনফার্মেশন, শিপিং আপডেট, ডেলিভারি — সব অটোমেটিক।" },
  { icon: HiOutlineChartBarSquare, title: "Facebook CAPI (iOS 17 ফিক্স)", desc: "iPhone ইউজারদের ডাটা ট্র্যাক করুন। আপনার Ads আবার কাজ করবে।" },
  { icon: HiOutlineBolt, title: "ফ্ল্যাশ সেল + কুপন সিস্টেম", desc: "টাইমার, ডিসকাউন্ট, কুপন কোড — সব রেডি। ক্যাম্পেইন চালান যখন ইচ্ছা।" },
];

function SolutionSection() {
  return (
    <section className="py-20 px-6" style={{ background: "#09060f" }}>
      <div className="max-w-6xl mx-auto">
        <motion.div {...fade(0)} className="text-center mb-14">
          <span
            className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1.5 mb-5"
            style={{
              border: "1px solid rgba(142,242,119,0.35)",
              color: "#8ef277",
              background: "rgba(142,242,119,0.05)",
            }}
          >
            সমাধান
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4" style={{ lineHeight: 1.2 }}>
            একটা সিস্টেম —{" "}
            <span className="font-serif italic" style={{ color: "#8ef277" }}>যেটা কখনো ঘুমায় না</span>
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.55)" }}>
            আপনি ফোকাস করুন ব্যবসা বড় করায়। বাকি সব আমরা সামলাই।
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => {
            const Icon = f.icon;
            return (
              <motion.div
                key={f.title}
                {...fade(i * 0.05)}
                className="p-6 rounded-2xl"
                style={{
                  background: "#0d1a10",
                  border: "1px solid rgba(142,242,119,0.15)",
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{
                    background: "rgba(142,242,119,0.1)",
                    border: "1px solid rgba(142,242,119,0.25)",
                  }}
                >
                  <Icon className="w-6 h-6" style={{ color: "#8ef277" }} />
                </div>
                <h3 className="text-base font-bold text-white mb-2">{f.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.6)" }}>{f.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ─── Case Study ───────────────────────────────────────────────────────────────

function CaseStudy() {
  return (
    <section className="py-20 px-6" style={{ background: "#09060f" }}>
      <div className="max-w-5xl mx-auto">
        <motion.div
          {...fade(0)}
          className="rounded-3xl p-8 sm:p-12 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, rgba(142,242,119,0.08), rgba(46,209,242,0.05))",
            border: "1px solid rgba(142,242,119,0.2)",
          }}
        >
          <span
            className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1.5 mb-6"
            style={{
              border: "1px solid rgba(142,242,119,0.35)",
              color: "#8ef277",
              background: "rgba(142,242,119,0.08)",
            }}
          >
            কেস স্টাডি — Akhiyan BD
          </span>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-6" style={{ lineHeight: 1.25 }}>
            একটা ব্রান্ড যেটা চলে{" "}
            <span className="font-serif italic" style={{ color: "#8ef277" }}>মালিকের ঘুমের সময়েও</span>
          </h2>

          <p className="text-base sm:text-lg mb-8 max-w-3xl" style={{ color: "rgba(255,255,255,0.7)", lineHeight: 1.7 }}>
            Akhiyan BD — ঢাকার একটা প্রিমিয়াম কিডস ফ্যাশন ব্রান্ড। ফাউন্ডার Masum প্রতিদিন ১০+ ঘন্টা ব্যয় করতেন অর্ডার ম্যানেজ করতে। আমরা তাঁর পুরো ব্যবসা অটোমেট করেছি — ফেসবুক অর্ডার থেকে Pathao ডেলিভারি পর্যন্ত।
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-8">
            {[
              { value: "১০x", label: "অর্ডার বৃদ্ধি" },
              { value: "৭৫%", label: "সময় সাশ্রয়" },
              { value: "৪x", label: "ROAS বৃদ্ধি" },
              { value: "৪.৮★", label: "কাস্টমার রেটিং" },
            ].map((s) => (
              <div key={s.label}>
                <div className="text-2xl sm:text-3xl font-bold mb-1" style={{ color: "#8ef277" }}>{s.value}</div>
                <div className="text-xs sm:text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>{s.label}</div>
              </div>
            ))}
          </div>

          <blockquote
            className="border-l-2 pl-5 italic text-base sm:text-lg"
            style={{ borderColor: "#8ef277", color: "rgba(255,255,255,0.85)" }}
          >
            &ldquo;Contra Digital আমার পুরো ব্যবসা পাল্টে দিয়েছে। আমি এখন প্রতিদিন ১০ ঘন্টা অর্ডার ম্যানেজ না করে ব্যবসা বড় করায় ফোকাস করি।&rdquo;
            <footer className="not-italic text-sm mt-3" style={{ color: "rgba(255,255,255,0.5)" }}>— Masum Billah, Founder, Akhiyan BD</footer>
          </blockquote>

          <Link
            href="/portfolio/projects/akhiyan"
            className="inline-flex items-center gap-2 mt-8 text-sm font-semibold transition-colors hover:opacity-80"
            style={{ color: "#8ef277" }}
          >
            পুরো কেস স্টাডি দেখুন <HiOutlineArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

// ─── Packages ─────────────────────────────────────────────────────────────────

const PACKAGES = [
  {
    name: "Basic",
    bestFor: "নতুন স্টোর",
    setup: "১৫,০০০",
    renewal: "৮,০০০",
    target: "নতুন ব্যবসা যারা প্রফেশনালভাবে অনলাইনে আসতে চান",
    featured: false,
    featureHeader: null as string | null,
    features: [
      "দ্রুত স্টোরফ্রন্ট — SEO ready, মোবাইল ফার্স্ট",
      "প্রোডাক্ট ও ক্যাটাগরি ম্যানেজমেন্ট",
      "অর্ডার ম্যানেজমেন্ট — ফুল লাইফসাইকেল",
      "bKash + Nagad + COD",
      "কুপন কোড",
      "PDF ইনভয়েস",
      "কাস্টমার অ্যাকাউন্ট + উইশলিস্ট",
      "ড্যাশবোর্ড (সেল, রেভিনিউ, লো স্টক)",
      "১টি অ্যাডমিন অ্যাকাউন্ট",
    ],
    cta: "শুরু করুন",
  },
  {
    name: "Regular",
    bestFor: "গ্রোয়িং ব্রান্ড",
    setup: "৩০,০০০",
    renewal: "১৪,০০০",
    target: "যে ব্যবসা সিরিয়াসলি অনলাইন সেল বাড়াতে চায়",
    featured: true,
    badge: "সবচেয়ে জনপ্রিয়",
    featureHeader: "Basic এ যা আছে +",
    features: [
      "ফেক অর্ডার ডিটেকশন (IP block, device fingerprint, spam filter)",
      "Facebook CAPI — সার্ভার-সাইড কনভার্সন ট্র্যাকিং",
      "শর্টলিংক + ক্লিক অ্যানালিটিক্স",
      "ইনকমপ্লিট অর্ডার রিকভারি",
      "ফ্ল্যাশ সেল + কাউন্টডাউন টাইমার",
      "ইমেইল নোটিফিকেশন",
      "প্রোডাক্ট ফিড (Google / Facebook)",
      "ল্যান্ডিং পেজ বিল্ডার",
      "ব্লগ",
      "৩টি অ্যাডমিন অ্যাকাউন্ট",
    ],
    cta: "এখনই শুরু করুন",
  },
  {
    name: "Advanced",
    bestFor: "হাই-ভলিউম + Ads",
    setup: "৫৫,০০০",
    renewal: "২২,০০০",
    target: "হাই-ভলিউম ব্রান্ড যারা ফেসবুক/গুগল Ads চালান",
    featured: false,
    featureHeader: "Regular এ যা আছে +",
    features: [
      "Pathao অটো কুরিয়ার এন্ট্রি",
      "ফুল ইনভেন্টরি ম্যানেজমেন্ট (স্টক, ভ্যারিয়েন্ট, SKU)",
      "কুরিয়ার পারফরম্যান্স ট্র্যাকিং",
      "বাংলা + ইংরেজি স্টোরফ্রন্ট",
      "ফুল SEO সুইট (JSON-LD, structured data)",
      "রিয়েল-টাইম অর্ডার আপডেট",
      "আনলিমিটেড অ্যাডমিন অ্যাকাউন্ট + রোলস",
      "প্রায়োরিটি WhatsApp সাপোর্ট",
    ],
    cta: "কথা বলুন",
  },
];

function Packages() {
  return (
    <section id="packages" className="py-24 px-6 rounded-t-[20px]" style={{ background: "#f4f4f0" }}>
      <div className="max-w-6xl mx-auto">
        <motion.div {...fade(0)} className="text-center mb-14">
          <span
            className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1 mb-5"
            style={{
              border: "1px solid rgba(20,206,113,0.4)",
              color: "#0a4500",
              background: "rgba(142,242,119,0.18)",
            }}
          >
            প্যাকেজ
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style={{ color: "#0a0a0a", lineHeight: 1.2 }}>
            আপনার ব্যবসার সাইজ অনুযায়ী{" "}
            <span className="font-serif italic" style={{ color: "#15a448" }}>প্যাকেজ বেছে নিন</span>
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: "rgba(0,0,0,0.55)" }}>
            ফিক্সড প্রাইস। কোনো লুকানো চার্জ নেই। ৫০% অগ্রিম, ৫০% লঞ্চের সময়।
          </p>
          <p className="text-xs max-w-xl mx-auto mt-3" style={{ color: "rgba(0,0,0,0.45)" }}>
            <strong style={{ color: "rgba(0,0,0,0.6)" }}>রিনিউয়ালে যা থাকে:</strong> hosting, server, updates, security patches, uptime monitoring।
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-5xl mx-auto items-start">
          {PACKAGES.map((pkg, i) => (
            <motion.div
              key={pkg.name}
              {...fade(i * 0.08)}
              className="rounded-2xl p-8 relative transition-all"
              style={{
                background: pkg.featured ? "#8ef277" : "#ffffff",
                border: pkg.featured ? "2px solid #8ef277" : "1px solid rgba(0,0,0,0.08)",
                transform: pkg.featured ? "scale(1.04)" : "scale(1)",
                boxShadow: pkg.featured
                  ? "0 12px 40px rgba(142,242,119,0.35), 0 0 0 1px rgba(142,242,119,0.5)"
                  : "0 2px 12px rgba(0,0,0,0.04)",
              }}
            >
              {pkg.featured && pkg.badge && (
                <div
                  className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-bold px-4 py-1.5 rounded-full whitespace-nowrap"
                  style={{
                    background: "#0a0a0a",
                    color: "#8ef277",
                    boxShadow: "0 6px 20px rgba(0,0,0,0.25)",
                  }}
                >
                  {pkg.badge}
                </div>
              )}

              <div className="mb-5">
                <div className="flex items-center justify-between mb-1.5">
                  <h3 className="text-xl font-bold" style={{ color: "#0a0a0a" }}>{pkg.name}</h3>
                  <span
                    className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full"
                    style={{
                      background: pkg.featured ? "rgba(0,0,0,0.12)" : "rgba(20,206,113,0.12)",
                      color: pkg.featured ? "rgba(0,0,0,0.7)" : "#0a6b35",
                    }}
                  >
                    {pkg.bestFor}
                  </span>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: pkg.featured ? "rgba(0,0,0,0.7)" : "rgba(0,0,0,0.55)" }}>{pkg.target}</p>
              </div>

              {/* Pricing — Setup + Renewal */}
              <div className="mb-6 pb-5" style={{ borderBottom: pkg.featured ? "1px solid rgba(0,0,0,0.1)" : "1px solid rgba(0,0,0,0.06)" }}>
                <div className="text-[11px] uppercase tracking-wider mb-1" style={{ color: pkg.featured ? "rgba(0,0,0,0.55)" : "rgba(0,0,0,0.45)" }}>
                  সেটআপ
                </div>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-xl font-semibold" style={{ color: "#0a0a0a" }}>৳</span>
                  <span className="text-3xl font-bold" style={{ color: "#0a0a0a" }}>{pkg.setup}</span>
                </div>
                <div className="text-xs" style={{ color: pkg.featured ? "rgba(0,0,0,0.65)" : "rgba(0,0,0,0.55)" }}>
                  + ৳{pkg.renewal}/বছর রিনিউয়াল
                </div>
              </div>

              {pkg.featureHeader && (
                <div
                  className="text-[11px] font-semibold uppercase tracking-wider mb-3"
                  style={{ color: pkg.featured ? "rgba(0,0,0,0.6)" : "#0a6b35" }}
                >
                  {pkg.featureHeader}
                </div>
              )}

              <ul className="space-y-2.5 mb-8">
                {pkg.features.map((feat) => (
                  <li key={feat} className="flex items-start gap-2.5 text-sm" style={{ color: pkg.featured ? "rgba(0,0,0,0.82)" : "rgba(0,0,0,0.7)" }}>
                    <HiCheck className="w-4 h-4 shrink-0 mt-0.5" style={{ color: pkg.featured ? "#0a4500" : "#14ce71" }} />
                    {feat}
                  </li>
                ))}
              </ul>

              <Link
                href={CALENDLY}
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center py-3 rounded-xl font-bold text-sm transition-all hover:-translate-y-0.5 w-full"
                style={
                  pkg.featured
                    ? { background: "#0a0a0a", color: "#ffffff" }
                    : { background: "#8ef277", color: "#0a0a0a" }
                }
              >
                {pkg.cta}
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Process ──────────────────────────────────────────────────────────────────

const STEPS = [
  { num: "০১", title: "ফ্রি কনসালটেশন", desc: "৩০ মিনিটের কল। আপনার ব্যবসা বুঝি, পেইন পয়েন্ট আইডেন্টিফাই করি।" },
  { num: "০২", title: "সিস্টেম ডিজাইন", desc: "৭ দিনের মধ্যে আপনি দেখবেন আপনার নতুন ওয়েবসাইটের ডিজাইন।" },
  { num: "০৩", title: "ডেভেলপমেন্ট + লঞ্চ", desc: "২-৪ সপ্তাহে সাইট লাইভ। সব ইন্টিগ্রেশন টেস্ট করা হয়।" },
  { num: "০৪", title: "গ্রোথ + সাপোর্ট", desc: "লঞ্চের পর ৩০-৬০ দিন সাপোর্ট। চাইলে মাসিক রিটেইনারে আমরা চলমান গ্রোথ পার্টনার।" },
];

function Process() {
  return (
    <section className="py-20 px-6" style={{ background: "#f4f4f0" }}>
      <div className="max-w-5xl mx-auto">
        <motion.div {...fade(0)} className="text-center mb-14">
          <span
            className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1 mb-5"
            style={{
              border: "1px solid rgba(20,206,113,0.4)",
              color: "#0a4500",
              background: "rgba(142,242,119,0.18)",
            }}
          >
            প্রসেস
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style={{ color: "#0a0a0a", lineHeight: 1.2 }}>
            লঞ্চ পর্যন্ত —{" "}
            <span className="font-serif italic" style={{ color: "#15a448" }}>৪টি ধাপ</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {STEPS.map((s, i) => (
            <motion.div
              key={s.num}
              {...fade(i * 0.08)}
              className="p-6 rounded-2xl"
              style={{
                background: "#ffffff",
                border: "1px solid rgba(0,0,0,0.08)",
              }}
            >
              <div className="text-3xl font-bold mb-4 font-serif italic" style={{ color: "#8ef277" }}>{s.num}</div>
              <h3 className="text-lg font-bold mb-2" style={{ color: "#0a0a0a" }}>{s.title}</h3>
              <p className="text-sm leading-relaxed" style={{ color: "rgba(0,0,0,0.6)" }}>{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── FAQ ──────────────────────────────────────────────────────────────────────

const FAQS = [
  { q: "কতদিনে আমার সাইট লাইভ হবে?", a: "প্যাকেজ অনুযায়ী ২-৪ সপ্তাহ। স্টার্টার ২ সপ্তাহ, গ্রোথ ৩-৪ সপ্তাহ, এন্টারপ্রাইজ ৬-৮ সপ্তাহ।" },
  { q: "আমার এক্সিস্টিং সাইট থাকলে কি হবে?", a: "কোনো সমস্যা নেই। আমরা আপনার পুরোনো সাইট থেকে সব ডাটা (প্রোডাক্ট, কাস্টমার, অর্ডার হিস্টরি) মাইগ্রেট করে দেব।" },
  { q: "পেমেন্ট কিভাবে করতে হবে?", a: "৫০% অগ্রিম প্রজেক্ট শুরুর সময়, বাকি ৫০% সাইট লঞ্চের আগে। bKash, ব্যাংক ট্রান্সফার — দুটোই সাপোর্টেড।" },
  { q: "টেকনিক্যাল জ্ঞান ছাড়া চালাতে পারব?", a: "অবশ্যই। আমাদের অ্যাডমিন প্যানেল বাংলায়, একদম সিম্পল। লঞ্চের পর আমরা ১ ঘন্টার ট্রেনিং সেশন দিব — রেকর্ডিং সহ।" },
  { q: "৬০ দিন সাপোর্টের পর কি হবে?", a: "আপনি চাইলে মাসিক AMC প্ল্যানে যেতে পারেন (৫,০০০-১৫,০০০ টাকা/মাস)। অথবা শুধু প্রয়োজন অনুযায়ী সাপোর্ট নিতে পারেন।" },
  { q: "Facebook Ads ও কি আপনারা চালান?", a: "হ্যাঁ — এন্টারপ্রাইজ প্যাকেজে। আমরা শুধু সাইট না, পুরো গ্রোথ পার্টনার। Meta + Google Ads ম্যানেজমেন্ট, কনভার্সন ট্র্যাকিং, রিপোর্টিং — সব।" },
];

function FAQ() {
  return (
    <section className="py-20 px-6" style={{ background: "#f4f4f0" }}>
      <div className="max-w-3xl mx-auto">
        <motion.div {...fade(0)} className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4" style={{ color: "#0a0a0a", lineHeight: 1.2 }}>
            সচরাচর{" "}
            <span className="font-serif italic" style={{ color: "#15a448" }}>প্রশ্নসমূহ</span>
          </h2>
        </motion.div>

        <div className="space-y-3">
          {FAQS.map((faq, i) => (
            <motion.details
              key={i}
              {...fade(i * 0.04)}
              className="group rounded-xl p-5 cursor-pointer"
              style={{
                background: "#ffffff",
                border: "1px solid rgba(0,0,0,0.08)",
              }}
            >
              <summary className="flex items-center justify-between font-semibold list-none" style={{ color: "#0a0a0a" }}>
                <span className="pr-4">{faq.q}</span>
                <span className="text-2xl shrink-0 transition-transform group-open:rotate-45" style={{ color: "#15a448" }}>+</span>
              </summary>
              <p className="mt-3 text-sm leading-relaxed" style={{ color: "rgba(0,0,0,0.65)" }}>{faq.a}</p>
            </motion.details>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Final CTA ────────────────────────────────────────────────────────────────

function FinalCTA() {
  return (
    <section className="py-24 px-6 rounded-t-[20px]" style={{ background: "#09060f" }}>
      <div className="max-w-4xl mx-auto text-center">
        <motion.div {...fade(0)}>
          <span
            className="inline-block text-xs font-semibold uppercase tracking-widest rounded-full px-4 py-1.5 mb-6"
            style={{
              border: "1px solid rgba(142,242,119,0.35)",
              color: "#8ef277",
              background: "rgba(142,242,119,0.05)",
            }}
          >
            সীমিত স্লট — মাসে মাত্র ৫টি প্রজেক্ট
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-5" style={{ lineHeight: 1.2 }}>
            এখনই শুরু করুন —{" "}
            <span className="font-serif italic" style={{ color: "#8ef277" }}>কম্পিটিটর এগিয়ে যাওয়ার আগে</span>
          </h2>
          <p className="text-lg mb-10 max-w-xl mx-auto" style={{ color: "rgba(255,255,255,0.65)" }}>
            ৩০ মিনিটের ফ্রি কনসালটেশন। কোনো কমিটমেন্ট নেই। শুধু আপনার ব্যবসার জন্য সঠিক সমাধান।
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
            <Link
              href={CALENDLY}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-[10px] font-bold text-base transition-all hover:-translate-y-0.5"
              style={{
                background: "#8ef277",
                color: "#0a0a0a",
                boxShadow: "0 8px 32px rgba(142,242,119,0.4)",
              }}
            >
              <HiOutlineSparkles className="w-5 h-5" />
              ফ্রি কনসালটেশন বুক করুন
            </Link>
            <Link
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-[10px] font-bold text-base transition-all hover:-translate-y-0.5"
              style={{
                background: "rgba(255,255,255,0.06)",
                color: "#ffffff",
                border: "1px solid rgba(255,255,255,0.2)",
              }}
            >
              <HiOutlinePhone className="w-5 h-5" />
              এখনই WhatsApp করুন
            </Link>
          </div>

          <p className="mt-6 text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
            ⚡ গড়ে ১ ঘন্টার মধ্যে রিপ্লাই · ৯টা সকাল – ১১টা রাত
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// ─── Sticky Mobile CTA ────────────────────────────────────────────────────────

function StickyMobileCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden p-3 backdrop-blur-md" style={{ background: "rgba(9,6,15,0.92)", borderTop: "1px solid rgba(142,242,119,0.2)" }}>
      <div className="flex gap-2 max-w-md mx-auto">
        <Link
          href={CALENDLY}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 inline-flex items-center justify-center gap-2 py-3 rounded-[10px] font-bold text-sm"
          style={{ background: "#8ef277", color: "#0a0a0a" }}
        >
          <HiOutlineSparkles className="w-4 h-4" />
          ডেমো বুক করুন
        </Link>
        <Link
          href={WHATSAPP}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="WhatsApp"
          className="inline-flex items-center justify-center w-12 rounded-[10px]"
          style={{ background: "rgba(255,255,255,0.08)", color: "#ffffff", border: "1px solid rgba(255,255,255,0.15)" }}
        >
          <HiOutlineChatBubbleLeftRight className="w-5 h-5" />
        </Link>
      </div>
    </div>
  );
}

// ─── Mini Header ──────────────────────────────────────────────────────────────

function MiniHeader() {
  return (
    <header className="absolute top-0 left-0 right-0 z-40 px-6 pt-6">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/portfolio/contra-logo.png" alt="Contra Digital" className="h-8 w-auto" style={{ filter: "brightness(0) invert(1)" }} />
        </Link>
        <Link
          href="/"
          className="text-xs font-medium hover:opacity-80 transition-opacity hidden sm:inline-block"
          style={{ color: "rgba(255,255,255,0.6)" }}
        >
          🌍 Global Site →
        </Link>
      </div>
    </header>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function BDLandingPage() {
  return (
    <main className="relative overflow-x-hidden pb-20 lg:pb-0">
      <MiniHeader />
      <Hero />
      <PainSection />
      <SolutionSection />
      <CaseStudy />
      <Packages />
      <Process />
      <FAQ />
      <FinalCTA />
      <StickyMobileCTA />
    </main>
  );
}
