import type { Metadata } from "next";
import { Hind_Siliguri } from "next/font/google";

const hindSiliguri = Hind_Siliguri({
  variable: "--font-bangla",
  subsets: ["bengali", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Contra Digital BD — বাংলাদেশি ই-কমার্স ব্যবসার পূর্ণাঙ্গ অটোমেশন",
  description:
    "ফেসবুক থেকে ডেলিভারি পর্যন্ত — সম্পূর্ণ অটোমেটেড ই-কমার্স সিস্টেম। bKash, Nagad, Pathao, Steadfast — সব একসাথে। ২-৪ সপ্তাহে লাইভ।",
  openGraph: {
    title: "Contra Digital BD — ই-কমার্স অটোমেশন",
    description: "মাসে ১০ লক্ষ টাকা সেল করুন — ম্যানুয়াল কাজ ছাড়াই",
  },
};

export default function BDLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return <div className={`${hindSiliguri.variable}`} style={{ fontFamily: "var(--font-bangla), system-ui, sans-serif" }}>{children}</div>;
}
