import type { Metadata } from "next";
import ContactForm from "@/components/portfolio/ContactForm";
import ContactInfoPanel from "@/components/portfolio/ContactInfoPanel";
import Footer from "@/components/portfolio/Footer";

export const metadata: Metadata = {
  title: "Contact Us | ContraDigital",
  description:
    "Start a project with ContraDigital. Share your project details and our team will get back to you with a tailored strategy within 24 hours.",
};

export default function ContactPage() {
  return (
    <>
      <main className="min-h-screen pt-16 pb-24 px-6 relative overflow-hidden">
        {/* Background Glows */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-primary/5 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-accent-green/5 blur-[100px] pointer-events-none" />

        <div className="max-w-[1150px] mx-auto relative z-10">
          <div className="grid lg:grid-cols-5 gap-12 items-stretch">
            {/* Left Column — Info */}
            <div className="lg:col-span-2 flex">
              <ContactInfoPanel />
            </div>

            {/* Right Column — Form */}
            <div className="lg:col-span-3 flex">
              <ContactForm />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
