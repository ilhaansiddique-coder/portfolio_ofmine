/**
 * Shortlink resolver root layout. Deliberately isolated from the storefront
 * `(site)` group: NO Navbar/Footer, NO tenant providers, NO storefront
 * feature-gate. This is what lets a root-level shortlink (`/<slug>`) resolve
 * even for landing-page-only tenants whose storefront master switch is OFF —
 * the `(site)` gate never runs for these routes.
 *
 * For a matching active shortlink the page server-redirects (308) before any
 * HTML renders, so this layout's markup is only ever shown for the not-found
 * (no/invalid shortlink) case.
 */
import type { Metadata } from "next";
import "../globals.css";

export const metadata: Metadata = {
  // Shortlink targets shouldn't be indexed under the slug URL.
  robots: { index: false, follow: false },
};

export default function LinksRootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen antialiased" style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' }}>
        {children}
      </body>
    </html>
  );
}
