/**
 * Root-level shortlink resolver — `/<slug>`.
 *
 * Lives in its own `(links)` route group (separate root layout) so it is NOT
 * subject to the storefront feature-gate in `(site)/layout.tsx`. Static
 * storefront segments (/shop, /blog, /dashboard, …) win over this dynamic
 * route in the Next router, and RESERVED_SLUGS guards the rest, so this only
 * fires for paths that don't match a real page.
 *
 * On a matching active shortlink: log one click (truncated IP + UA + utm) and
 * server-redirect (308) to the target. Otherwise notFound() → the bare 404
 * below. The empty-slug ("base URL") shortlink is handled separately in the
 * (site) layout — this route only matches a non-empty segment.
 *
 * force-dynamic: never try to statically pre-render arbitrary slugs at build.
 */
import { redirect, notFound } from "next/navigation";
import { headers } from "next/headers";
import { maybeGetPrismaForRequest } from "@/lib/prisma-tenant";
import { RESERVED_SLUGS } from "@/lib/reservedSlugs";
import { logShortlinkClick } from "@/lib/shortlink-click";

export const dynamic = "force-dynamic";

export default async function ShortlinkResolver({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { slug: rawSlug } = await params;
  const slug = String(rawSlug || "").toLowerCase();

  // Empty slug is the base-URL redirect (handled in the site layout); a
  // reserved slug should never have reached here (static routes win), but
  // double-check defensively.
  if (!slug || RESERVED_SLUGS.has(slug)) notFound();

  // Resolve OUTSIDE the redirect call: redirect() throws NEXT_REDIRECT, which
  // must propagate, so it can't sit inside the try/catch.
  let targetUrl: string | null = null;
  let incomingParams: Record<string, string | string[] | undefined> = {};
  try {
    const ctx = await maybeGetPrismaForRequest();
    if (ctx) {
      const link = await ctx.prisma.shortlink.findUnique({ where: { slug } });
      if (link && link.isActive && link.targetUrl) {
        const h = await headers();
        const sp = await searchParams;
        incomingParams = sp;
        await logShortlinkClick(ctx.prisma, link.id, h, sp);
        targetUrl = link.targetUrl;
      }
    }
  } catch {
    /* unknown host / DB error → fall through to 404 */
  }

  if (!targetUrl) notFound();
  redirect(mergeQuery(targetUrl, incomingParams));
}

/**
 * Forward query params from the SHORT url onto the target. So a link with
 * target `https://shop.com/p?ref=spring` hit as `/promo?utm_source=fb` ends
 * up at `https://shop.com/p?ref=spring&utm_source=fb`. The target's own params
 * win on key collision (they were set deliberately on the shortlink). Works
 * for both absolute targets and internal paths (/shop?x=1).
 */
function mergeQuery(target: string, params: Record<string, string | string[] | undefined>): string {
  const entries = Object.entries(params).filter(([, v]) => v != null);
  if (entries.length === 0) return target;
  const isAbsolute = /^https?:\/\//i.test(target);
  try {
    const u = new URL(target, isAbsolute ? undefined : "http://_local_");
    for (const [k, v] of entries) {
      if (u.searchParams.has(k)) continue; // target's own param wins
      if (Array.isArray(v)) v.forEach((vv) => u.searchParams.append(k, vv));
      else u.searchParams.set(k, String(v));
    }
    return isAbsolute ? u.toString() : u.pathname + u.search + u.hash;
  } catch {
    return target; // malformed target — redirect as-is
  }
}
