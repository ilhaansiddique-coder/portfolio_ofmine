/**
 * 404 for the shortlink resolver group. Self-contained (no LanguageContext /
 * site providers, since the (links) layout doesn't mount them) — renders a
 * clean bilingual not-found for an unknown/inactive slug.
 */
import Link from "next/link";

export default function LinksNotFound() {
  return (
    <main style={{ minHeight: "70vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "2rem", textAlign: "center" }}>
      <div style={{ maxWidth: 460 }}>
        <h1 style={{ fontSize: 72, fontWeight: 800, color: "#e5e7eb", margin: 0, lineHeight: 1 }}>404</h1>
        <h2 style={{ fontSize: 22, fontWeight: 700, margin: "12px 0 8px" }}>Link not found</h2>
        <p style={{ color: "#6b7280", fontSize: 15, lineHeight: 1.6 }}>
          This short link doesn&apos;t exist or has been disabled.
          <br />
          এই লিঙ্কটি নেই অথবা নিষ্ক্রিয় করা হয়েছে।
        </p>
        <Link
          href="/"
          style={{ display: "inline-block", marginTop: 20, padding: "10px 24px", borderRadius: 10, background: "#0f5931", color: "#fff", fontWeight: 600, textDecoration: "none" }}
        >
          Home / হোম
        </Link>
      </div>
    </main>
  );
}
