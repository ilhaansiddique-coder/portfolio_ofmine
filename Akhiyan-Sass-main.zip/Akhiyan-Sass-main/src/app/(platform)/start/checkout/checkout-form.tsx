"use client";

import { useState } from "react";
import { FiCheckCircle, FiArrowRight } from "react-icons/fi";

const SLUG_RE = /^[a-z0-9](?:[a-z0-9-]{0,30}[a-z0-9])?$/;

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32);
}

export function CheckoutForm({ plan, baseDomain }: { plan: string; baseDomain: string }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [slug, setSlug] = useState("");
  const [slugTouched, setSlugTouched] = useState(false);
  const [done, setDone] = useState<{ slug: string } | null>(null);

  // Auto-fill slug from store name until the user edits it directly.
  function onStoreName(v: string) {
    if (!slugTouched) setSlug(slugify(v));
  }

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr("");
    const fd = new FormData(e.currentTarget);
    const finalSlug = String(fd.get("slug") || "").trim().toLowerCase();
    if (!SLUG_RE.test(finalSlug)) {
      setErr("Store address must be lowercase letters, numbers, hyphens (2–32 chars).");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/v1/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          storeName: String(fd.get("storeName") || "").trim(),
          slug: finalSlug,
          ownerName: String(fd.get("ownerName") || "").trim(),
          ownerEmail: String(fd.get("ownerEmail") || "").trim().toLowerCase(),
          phone: String(fd.get("phone") || "").trim(),
          plan: String(fd.get("plan") || plan),
        }),
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || `HTTP ${res.status}`);
      setDone({ slug: finalSlug });
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="space-y-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-6 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-100 text-emerald-600">
          <FiCheckCircle className="h-7 w-7" />
        </div>
        <h2 className="text-xl font-bold text-emerald-900">Request received!</h2>
        <p className="text-sm text-emerald-700">
          We&apos;re setting up <strong>{done.slug}</strong>. Our team will email you shortly to confirm payment and hand over your store login.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
      {err && <div className="rounded-xl border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700">{err}</div>}

      <input type="hidden" name="plan" value={plan} />

      <Field label="Store name" required>
        <input name="storeName" required placeholder="Acme Store" onChange={(e) => onStoreName(e.target.value)}
          className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Store address" required hint="Your store will live at this address.">
        <div className="flex items-stretch overflow-hidden rounded-xl border border-zinc-300 focus-within:border-orange-500">
          <input
            name="slug" required value={slug}
            onChange={(e) => { setSlug(slugify(e.target.value)); setSlugTouched(true); }}
            placeholder="acme" autoCapitalize="off" autoComplete="off"
            className="min-w-0 flex-1 px-4 py-3 font-mono text-sm lowercase outline-none"
          />
          <span className="flex items-center bg-zinc-50 px-3 font-mono text-xs text-zinc-400">.{baseDomain}</span>
        </div>
      </Field>

      <hr className="border-zinc-200" />

      <Field label="Your name" required>
        <input name="ownerName" required placeholder="John Doe"
          className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Email" required hint="We'll send your store login here.">
        <input name="ownerEmail" type="email" required placeholder="you@example.com"
          autoCapitalize="off" autoComplete="email"
          className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <Field label="Phone (WhatsApp)" required>
        <input name="phone" type="tel" inputMode="numeric" required placeholder="01XXXXXXXXX"
          className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-orange-500" />
      </Field>

      <button type="submit" disabled={busy}
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 px-5 py-3 text-sm font-semibold text-white hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-40">
        {busy ? "Submitting…" : "Request my store"}
        {!busy && <FiArrowRight className="h-4 w-4" />}
      </button>

      <p className="text-center text-xs text-zinc-400">
        No charge now. We confirm payment with you before the store goes live.
      </p>
    </form>
  );
}

function Field({ label, hint, required, children }: {
  label: string; hint?: string; required?: boolean; children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1 text-sm font-medium">
        {label}{required && <span className="text-rose-500"> *</span>}
      </div>
      {children}
      {hint && <div className="mt-1 text-xs text-zinc-400">{hint}</div>}
    </label>
  );
}
