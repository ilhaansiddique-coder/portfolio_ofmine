import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";
import { CheckoutForm } from "./checkout-form";

export const dynamic = "force-dynamic";
export const metadata = { title: "Checkout — CD Ecom" };

type Ctx = { searchParams: Promise<{ plan?: string }> };

const taka = (paisa: number | null) =>
  paisa == null ? "Custom quote" : `৳${Math.round(paisa / 100).toLocaleString("en-US")}/mo`;

export default async function CheckoutPage({ searchParams }: Ctx) {
  const { plan: planSlug } = await searchParams;

  const plans = await controlPrisma.plan.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: "asc" },
    select: { slug: true, name: true, priceMonthly: true },
  });

  const selected = plans.find((p) => p.slug === planSlug) ?? plans[0];

  if (!selected) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <h1 className="text-2xl font-semibold">No plans available</h1>
        <p className="mt-2 text-sm text-zinc-500">Please check back soon.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg px-4 py-12">
      <header className="mb-6">
        <Link href="/start" className="text-xs text-zinc-400 hover:text-zinc-600">← Plans</Link>
        <h1 className="mt-2 text-3xl font-bold tracking-tight">Start your store</h1>
        <p className="mt-2 text-sm text-zinc-500">
          Tell us about your store. We&apos;ll set it up and email you to confirm — no payment taken online yet.
        </p>
      </header>

      {/* Plan summary */}
      <div className="mb-5 flex items-center justify-between rounded-2xl border border-zinc-200 bg-zinc-50 px-5 py-4">
        <div>
          <div className="text-xs uppercase tracking-wide text-zinc-400">Selected plan</div>
          <div className="text-lg font-semibold">{selected.name}</div>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold">{taka(selected.priceMonthly)}</div>
          <Link href="/start" className="text-xs text-orange-600 hover:underline">change</Link>
        </div>
      </div>

      <CheckoutForm
        plan={selected.slug}
        baseDomain={process.env.BASE_DOMAIN || "cdecom.store"}
      />
    </div>
  );
}
