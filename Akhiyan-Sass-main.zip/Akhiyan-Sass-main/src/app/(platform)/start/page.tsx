/**
 * /start — premium pricing page for CD Ecom SaaS.
 *
 * Section order matches a Hostinger-style funnel but every section has been
 * re-skinned to feel like a polished SaaS marketing page:
 *
 *   1. Sticky translucent header
 *   2. Hero — large headline, social-proof microbar, ambient gradient backdrop
 *   3. Plan cards (client, billing toggle)
 *   4. "Everything in every plan" — elevated icon cards
 *   5. Plan comparison table — striped rows, popular column tinted
 *   6. Use cases — full-bleed gradient tiles
 *   7. Integrations strip — branded chips
 *   8. Trust band — gradient, larger stats
 *   9. Testimonials — quote-card style
 *  10. FAQ — clean accordions
 *  11. Final CTA banner
 *
 * All copy is SaaS-relevant; no Hostinger language is reused.
 */

import type { Metadata } from "next";
import Link from "next/link";
import { controlPrisma } from "@/lib/prisma-control";
import {
  FiCheck, FiX, FiShoppingBag, FiTruck, FiCreditCard, FiBarChart2, FiUsers, FiTag,
  FiZap, FiShield, FiSmartphone, FiGlobe, FiHeadphones, FiClock, FiRefreshCw, FiAward,
  FiStar, FiArrowRight, FiTrendingUp,
} from "react-icons/fi";
import PricingCards, { type PlanCard } from "./PricingCards";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Pricing — CD Ecom",
  description: "Launch your online store today. bKash, Pathao, Steadfast, Facebook Pixel — built-in. Plans for every stage.",
};

const HIGHLIGHTS: Record<string, string[]> = {
  starter: [
    "Online storefront, mobile-first",
    "Up to 100 products",
    "bKash & COD checkout",
    "Order management + timeline",
    "Basic analytics dashboard",
    "Email support",
  ],
  pro: [
    "Everything in Starter",
    "Unlimited products",
    "Staff accounts (up to 5)",
    "Coupons, flash sales, upsells",
    "Custom domain + free SSL",
    "Pathao + Steadfast dispatch",
    "Facebook Pixel + Conversions API",
    "Priority email support",
  ],
  enterprise: [
    "Everything in Pro",
    "Unlimited staff seats",
    "Native mobile app (iOS + Android)",
    "Advanced analytics + cohorts",
    "AI product copy + descriptions",
    "Dedicated onboarding manager",
    "24/7 priority support",
    "Custom integrations & SLA",
  ],
};

export default async function PricingPage() {
  const planRows = await controlPrisma.plan.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: "asc" },
  });

  const plans: PlanCard[] = planRows.map((p, i) => ({
    id: p.id,
    slug: p.slug,
    name: p.name,
    description: p.description,
    priceMonthly: p.priceMonthly,
    features: HIGHLIGHTS[p.slug] ?? [],
    highlight: p.slug === "pro" || (planRows.length === 1 && i === 0),
  }));

  return (
    <>
      {/* ════════════════════════════ 1. Header ════════════════════════════ */}
      <header className="sticky top-0 z-30 border-b border-gray-200/60 bg-white/85 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center">
          {/* Brand mark — left */}
          <Link href="/" className="inline-flex items-center gap-2 shrink-0 mr-auto">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-[#0f5931] to-[#072b18] text-white font-bold text-xs">CD</span>
            <span className="text-base font-bold text-gray-900">Ecom</span>
          </Link>

          {/* Centered nav (hidden on small screens) */}
          <nav className="hidden md:flex items-center text-sm">
            <a href="#pricing"  className="px-4 py-2 text-gray-600 hover:text-gray-900 font-medium transition-colors">Pricing</a>
            <a href="#features" className="px-4 py-2 text-gray-600 hover:text-gray-900 font-medium transition-colors">Features</a>
            <a href="#compare"  className="px-4 py-2 text-gray-600 hover:text-gray-900 font-medium transition-colors">Compare</a>
            <a href="#faq"      className="px-4 py-2 text-gray-600 hover:text-gray-900 font-medium transition-colors">FAQ</a>
          </nav>

          {/* Right actions */}
          <div className="ml-auto flex items-center gap-3 shrink-0">
            <Link href="/cdlogin" className="hidden sm:inline text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
              Log in
            </Link>
            <Link
              href="#pricing"
              className="inline-flex items-center gap-1.5 h-9 px-4 rounded-full bg-[#0f5931] text-white text-sm font-semibold hover:bg-[#12693a] transition-colors shadow-sm whitespace-nowrap"
            >
              Start free
              <FiArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      </header>

      <main>
        {/* ══════════════════════════ 2. Hero (2-col split — text + visual) ══════════════════════════ */}
        <section className="relative overflow-hidden pt-16 sm:pt-20 pb-16 px-4 sm:px-6 lg:px-8">
          {/* Ambient gradient backdrop */}
          <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-b from-emerald-50/60 via-white to-white" />
          <div aria-hidden className="absolute -top-40 right-0 -z-10 w-[700px] h-[700px] rounded-full bg-emerald-300/15 blur-3xl" />

          <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* ── LEFT: copy + CTA ── */}
            <div>
              <span className="inline-flex items-center gap-2 text-xs font-semibold text-[#0f5931] bg-emerald-100/70 border border-emerald-200 px-3 py-1.5 rounded-full">
                <FiZap className="h-3 w-3" /> Up to <strong className="font-bold">20% off</strong> on annual plans
              </span>
              <h1 className="mt-5 text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-gray-900 leading-[1.1]">
                Launch your online store{" "}
                <span className="bg-gradient-to-r from-[#0f5931] to-[#12693a] bg-clip-text text-transparent">
                  in 10 minutes
                </span>
              </h1>
              <p className="mt-4 text-base sm:text-lg text-gray-600 leading-relaxed max-w-xl">
                Storefront, checkout, courier dispatch, real-time analytics — every tool a Bangladeshi merchant
                needs, in one platform. No plugins to wire, no scale tax.
              </p>

              {/* Feature ticks */}
              <ul className="mt-6 grid sm:grid-cols-2 gap-y-2 gap-x-6 text-sm text-gray-700 max-w-md">
                {[
                  "bKash, Nagad & COD",
                  "Pathao + Steadfast dispatch",
                  "Facebook Pixel + CAPI",
                  "Custom domain + free SSL",
                ].map((f) => (
                  <li key={f} className="flex items-center gap-2">
                    <span className="grid h-5 w-5 place-items-center rounded-full bg-emerald-100 text-[#0f5931] shrink-0">
                      <FiCheck className="h-3 w-3" />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link
                  href="#pricing"
                  className="inline-flex items-center gap-2 h-12 px-7 rounded-xl bg-[#0f5931] text-white font-semibold hover:bg-[#12693a] transition-colors shadow-lg shadow-emerald-700/20"
                >
                  Choose plan <FiArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  href="/start/checkout?plan=trial"
                  className="inline-flex items-center gap-2 h-12 px-6 rounded-xl bg-white border border-gray-200 text-gray-800 font-semibold hover:border-[#0f5931] hover:text-[#0f5931] transition-colors"
                >
                  Start free trial
                </Link>
              </div>

              <div className="mt-5 inline-flex items-center gap-2 text-sm text-gray-600">
                <FiShield className="h-4 w-4 text-[#0f5931]" />
                <span><strong className="font-semibold text-gray-900">14-day money-back guarantee</strong> · no card needed for trial</span>
              </div>
            </div>

            {/* ── RIGHT: visual mockup (pure CSS, no asset dependency) ── */}
            <div className="relative">
              {/* Floating "Bangla 🇧🇩" badge — top-right corner */}
              <div className="absolute -top-3 right-2 sm:right-6 z-20 bg-white border border-emerald-200 rounded-2xl shadow-xl px-4 py-3 flex items-center gap-2">
                <span className="text-lg leading-none">🇧🇩</span>
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-gray-500">Built for</div>
                  <div className="text-sm font-bold text-gray-900 leading-tight">Bangladesh</div>
                </div>
              </div>

              {/* Floating "PWA Ready" badge — right side mid */}
              <div aria-hidden className="hidden sm:flex absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-20 bg-gradient-to-br from-amber-400 to-amber-500 text-amber-950 rounded-xl shadow-xl w-14 h-14 items-center justify-center">
                <FiZap className="h-6 w-6" />
              </div>

              {/* Main dashboard card */}
              <div className="relative bg-white rounded-3xl border border-gray-200 shadow-2xl shadow-emerald-900/10 overflow-hidden">
                {/* Top bar — fake browser chrome */}
                <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-100 bg-gray-50">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                  <span className="ml-3 text-[11px] text-gray-400 font-mono">yourstore.com/dashboard</span>
                </div>

                {/* Order strip header */}
                <div className="px-5 pt-5">
                  <div className="flex items-center gap-3">
                    <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#0f5931] to-[#12693a] text-white text-xs font-bold">CD</div>
                    <div className="flex-1">
                      <div className="text-sm font-bold text-gray-900">Order #1042</div>
                      <div className="text-[11px] text-gray-500">Asif Khan · Dhaka</div>
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wide bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full">Confirmed</span>
                  </div>
                </div>

                {/* Stat tiles */}
                <div className="grid grid-cols-2 gap-3 px-5 py-5">
                  {[
                    { label: "Today's orders", value: "47", trend: "+12%" },
                    { label: "Today's revenue", value: "৳1.2L", trend: "+8%" },
                  ].map((s) => (
                    <div key={s.label} className="rounded-2xl bg-gradient-to-br from-emerald-50 to-white border border-emerald-100 p-4">
                      <div className="text-[10px] uppercase tracking-wide text-gray-500 font-bold">{s.label}</div>
                      <div className="mt-1 flex items-baseline gap-1.5">
                        <span className="text-2xl font-bold text-gray-900">{s.value}</span>
                        <span className="text-[11px] font-semibold text-emerald-600">{s.trend}</span>
                      </div>
                      {/* Mini sparkline */}
                      <svg viewBox="0 0 80 24" className="mt-2 w-full h-6 text-[#0f5931]">
                        <polyline fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                          points="0,18 10,14 20,16 30,10 40,12 50,6 60,8 70,4 80,6" />
                      </svg>
                    </div>
                  ))}
                </div>

                {/* Integrations strip */}
                <div className="px-5 pb-5">
                  <div className="rounded-2xl bg-gray-50 border border-gray-100 px-4 py-3 flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-wide text-gray-500 font-bold">Connected</span>
                    <div className="flex items-center gap-2">
                      {["bK", "Pt", "Sf", "FB", "GA"].map((logo) => (
                        <span key={logo} className="grid h-7 w-7 place-items-center rounded-lg bg-white border border-gray-200 text-[10px] font-bold text-gray-600">
                          {logo}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Decorative gradient blob behind the card */}
              <div aria-hidden className="absolute -bottom-8 -left-8 -z-10 w-72 h-72 rounded-full bg-emerald-200/40 blur-3xl" />
              <div aria-hidden className="absolute -top-8 -right-8 -z-10 w-60 h-60 rounded-full bg-amber-200/30 blur-3xl" />
            </div>
          </div>
        </section>

        {/* ════════════════════════ 3. Plan cards ════════════════════════ */}
        <section id="pricing" className="px-4 sm:px-6 lg:px-8 pb-24">
          <div className="mx-auto max-w-6xl">
            {plans.length === 0 ? (
              <p className="text-center text-gray-400">Plans are being set up — check back soon.</p>
            ) : (
              <PricingCards plans={plans} />
            )}
          </div>
        </section>

        {/* ═══════════════════ 4. Everything in every plan ═══════════════════ */}
        <section id="features" className="bg-gray-50/60 py-24 px-4 sm:px-6 lg:px-8 border-y border-gray-200/60">
          <div className="mx-auto max-w-6xl">
            <header className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#0f5931]">What&apos;s included</span>
              <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">Built for selling, end-to-end</h2>
              <p className="mt-3 text-gray-600 text-base">
                Every plan ships with the things merchants actually use every day. No paywalls for the basics.
              </p>
            </header>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {FEATURES.map(({ icon: Icon, label, sub }) => (
                <article key={label} className="group bg-white border border-gray-200/80 rounded-2xl p-6 hover:border-[#0f5931]/40 hover:shadow-lg hover:shadow-emerald-700/5 hover:-translate-y-0.5 transition-all duration-200">
                  <div className="flex items-start gap-4">
                    <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-emerald-100 to-emerald-50 text-[#0f5931] shrink-0 group-hover:scale-105 transition-transform">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-bold text-gray-900">{label}</h3>
                      <p className="mt-1.5 text-sm text-gray-600 leading-relaxed">{sub}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ════════════════════ 5. Comparison table ════════════════════ */}
        <section id="compare" className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-6xl">
            <header className="text-center max-w-2xl mx-auto mb-14">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#0f5931]">Compare</span>
              <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">Pick the plan that fits</h2>
              <p className="mt-3 text-gray-600 text-base">Every feature, side by side. Upgrade any time.</p>
            </header>
            <div className="overflow-hidden rounded-3xl border border-gray-200 shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gradient-to-b from-gray-50 to-white border-b border-gray-200">
                    <tr>
                      <th className="text-left px-6 py-5 text-xs font-bold uppercase tracking-wider text-gray-500">Feature</th>
                      {plans.map((p) => (
                        <th key={p.id} className={`px-6 py-5 text-sm font-bold text-gray-900 text-left ${p.highlight ? "bg-[#0f5931]/5" : ""}`}>
                          <div className="flex items-center gap-2">
                            {p.name}
                            {p.highlight && (
                              <span className="text-[10px] font-bold uppercase tracking-wide bg-[#0f5931] text-white px-2 py-0.5 rounded">
                                Popular
                              </span>
                            )}
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="text-sm divide-y divide-gray-100">
                    {COMPARE_ROWS.map((row, rowIdx) => (
                      <tr key={row.label} className={rowIdx % 2 === 1 ? "bg-gray-50/50" : "bg-white"}>
                        <td className="px-6 py-4 font-medium text-gray-700">{row.label}</td>
                        {plans.map((p) => {
                          const v = row.values[p.slug];
                          return (
                            <td key={p.id} className={`px-6 py-4 text-gray-700 ${p.highlight ? "bg-[#0f5931]/[0.035]" : ""}`}>
                              {typeof v === "boolean"
                                ? v
                                  ? <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 text-[#0f5931]"><FiCheck className="h-3.5 w-3.5" /></span>
                                  : <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-gray-100 text-gray-400"><FiX className="h-3.5 w-3.5" /></span>
                                : <span className="font-medium">{v ?? "—"}</span>}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════ 6. Use cases ══════════════════════ */}
        <section className="bg-gray-50/60 py-24 px-4 sm:px-6 lg:px-8 border-y border-gray-200/60">
          <div className="mx-auto max-w-6xl">
            <header className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#0f5931]">Use cases</span>
              <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">Built for every kind of store</h2>
              <p className="mt-3 text-gray-600 text-base">
                From boutiques to cloud kitchens — CD Ecom adapts to how you sell.
              </p>
            </header>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {USE_CASES.map((u) => (
                <article key={u.title} className="group relative bg-white rounded-3xl p-7 border border-gray-200/80 overflow-hidden hover:shadow-2xl hover:shadow-emerald-900/10 hover:-translate-y-1 transition-all duration-300">
                  {/* decorative gradient blob */}
                  <div aria-hidden className={`absolute -top-12 -right-12 w-32 h-32 rounded-full ${u.blob} blur-2xl opacity-60 group-hover:opacity-80 transition-opacity`} />
                  <div className="relative">
                    <span className={`inline-flex items-center text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${u.tagCls}`}>
                      {u.tag}
                    </span>
                    <h3 className="mt-4 text-xl font-bold text-gray-900">{u.title}</h3>
                    <p className="mt-2.5 text-sm text-gray-600 leading-relaxed">{u.body}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ══════════════════ 7. Integrations strip ══════════════════ */}
        <section className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-6xl text-center">
            <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#0f5931]">Integrations</span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">Plays nicely with your stack</h2>
            <p className="mt-3 text-gray-600 text-base max-w-xl mx-auto">
              Bangladeshi-first payment + courier rails, plus every global tool you already rely on.
            </p>
            <div className="mt-12 grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
              {INTEGRATIONS.map((name) => (
                <div key={name} className="group bg-white border border-gray-200/80 rounded-2xl h-20 flex items-center justify-center text-sm font-semibold text-gray-700 hover:border-[#0f5931] hover:text-[#0f5931] hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
                  {name}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ══════════════════════ 8. Trust band ══════════════════════ */}
        <section className="relative overflow-hidden">
          <div aria-hidden className="absolute inset-0 bg-gradient-to-br from-[#0f5931] via-[#12693a] to-[#072b18]" />
          <div aria-hidden className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,0.08),transparent_45%),radial-gradient(circle_at_80%_80%,rgba(255,255,255,0.06),transparent_45%)]" />
          <div className="relative py-20 px-4 sm:px-6 lg:px-8 text-white">
            <div className="mx-auto max-w-6xl">
              <header className="text-center mb-12">
                <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-emerald-200/80">By the numbers</span>
                <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight">Built to be trusted</h2>
              </header>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
                {STATS.map(({ icon: Icon, stat, label }) => (
                  <div key={label} className="text-center">
                    <Icon className="h-7 w-7 mb-3 mx-auto opacity-70" />
                    <div className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-r from-white to-emerald-100 bg-clip-text text-transparent">
                      {stat}
                    </div>
                    <div className="text-sm opacity-80 mt-2">{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════ 9. Testimonials ══════════════════════ */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="mx-auto max-w-6xl">
            <header className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#0f5931]">Loved by merchants</span>
              <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">From day-one to your busiest day</h2>
              <p className="mt-3 text-gray-600 text-base">Real stores selling real things — pick the same stack they did.</p>
            </header>
            <div className="grid md:grid-cols-3 gap-6">
              {TESTIMONIALS.map((t, i) => (
                <article key={t.author} className={`relative rounded-3xl p-7 border ${
                  i === 1
                    ? "bg-gradient-to-b from-[#0f5931] to-[#0a3d22] border-transparent text-white shadow-xl shadow-emerald-700/20"
                    : "bg-white border-gray-200 hover:shadow-lg transition-shadow"
                }`}>
                  <div className={`flex gap-0.5 mb-4 ${i === 1 ? "text-amber-300" : "text-amber-400"}`}>
                    {[0,1,2,3,4].map((s) => <FiStar key={s} className="h-4 w-4 fill-current" />)}
                  </div>
                  <p className={`text-[15px] leading-relaxed ${i === 1 ? "text-white/95" : "text-gray-700"}`}>&ldquo;{t.quote}&rdquo;</p>
                  <div className="mt-6 flex items-center gap-3">
                    <div className={`grid h-11 w-11 place-items-center rounded-full text-sm font-bold ${
                      i === 1 ? "bg-white text-[#0f5931]" : "bg-gradient-to-br from-[#0f5931] to-[#12693a] text-white"
                    }`}>
                      {t.author.slice(0, 1)}
                    </div>
                    <div>
                      <div className={`text-sm font-bold ${i === 1 ? "text-white" : "text-gray-900"}`}>{t.author}</div>
                      <div className={`text-xs ${i === 1 ? "text-white/70" : "text-gray-500"}`}>{t.store}</div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ══════════════════════ 10. FAQ ══════════════════════ */}
        <section id="faq" className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50/60 border-y border-gray-200/60">
          <div className="mx-auto max-w-3xl">
            <header className="text-center mb-14">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#0f5931]">FAQ</span>
              <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">Got questions?</h2>
              <p className="mt-3 text-gray-600 text-base">Quick answers to the things we get asked the most.</p>
            </header>
            <div className="space-y-3">
              {FAQS.map((f) => (
                <details key={f.q} className="group bg-white border border-gray-200/80 rounded-2xl p-6 open:shadow-md transition-shadow [&_summary]:cursor-pointer">
                  <summary className="font-semibold text-gray-900 marker:hidden flex items-center justify-between gap-3">
                    <span>{f.q}</span>
                    <span className="grid h-7 w-7 place-items-center rounded-full bg-emerald-100 text-[#0f5931] text-base transition-transform group-open:rotate-45 shrink-0">+</span>
                  </summary>
                  <p className="mt-4 text-sm text-gray-600 leading-relaxed">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ══════════════════════ 11. Final CTA ══════════════════════ */}
        <section className="py-24 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-5xl">
            <div className="relative overflow-hidden rounded-[2rem] py-16 sm:py-20 px-6 sm:px-10 text-center text-white shadow-2xl shadow-emerald-900/30">
              <div aria-hidden className="absolute inset-0 bg-gradient-to-br from-[#0f5931] via-[#12693a] to-[#072b18]" />
              <div aria-hidden className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-emerald-300/15 blur-3xl" />
              <div aria-hidden className="absolute -bottom-40 -left-32 w-96 h-96 rounded-full bg-amber-300/10 blur-3xl" />
              <div className="relative">
                <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Ready to start selling?</h2>
                <p className="mt-4 text-base sm:text-lg text-white/85 max-w-xl mx-auto">
                  Set up your store in under 10 minutes. No credit card to start. Pay only when you&apos;re ready to launch.
                </p>
                <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
                  <Link
                    href="/start/checkout?plan=pro"
                    className="inline-flex items-center gap-2 h-12 px-7 rounded-xl bg-white text-[#0f5931] font-bold hover:bg-emerald-50 transition-colors shadow-lg"
                  >
                    Start free trial <FiArrowRight className="h-4 w-4" />
                  </Link>
                  <a
                    href="#pricing"
                    className="inline-flex items-center gap-2 h-12 px-7 rounded-xl bg-white/10 backdrop-blur border border-white/20 text-white font-semibold hover:bg-white/15 transition-colors"
                  >
                    See plans
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-gray-200/60 py-10 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="mx-auto max-w-6xl flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500">
            <div>© {new Date().getFullYear()} CD Ecom by Contra Digital · Built in Bangladesh 🇧🇩</div>
            <div className="flex items-center gap-5">
              <Link href="/terms" className="hover:text-gray-900 transition-colors">Terms</Link>
              <Link href="/privacy" className="hover:text-gray-900 transition-colors">Privacy</Link>
              <Link href="/contact" className="hover:text-gray-900 transition-colors">Contact</Link>
            </div>
          </div>
        </footer>
      </main>
    </>
  );
}

// ─── Static content (kept at module bottom so JSX above reads clean) ─────────
const FEATURES = [
  { icon: FiShoppingBag, label: "Mobile-first storefront",       sub: "Optimized for thumb-shopping — fast, accessible, beautiful out of the box." },
  { icon: FiCreditCard,  label: "bKash, Nagad & COD",             sub: "Bangladeshi payment rails baked in — no plugin marketplace required." },
  { icon: FiTruck,       label: "Pathao + Steadfast",             sub: "One-click dispatch, live status sync, automatic delivery confirmation." },
  { icon: FiBarChart2,   label: "Real-time analytics",            sub: "Orders, revenue, traffic sources — updated live across every staff device." },
  { icon: FiUsers,       label: "Staff accounts + roles",         sub: "Invite your team, scope permissions, audit every change." },
  { icon: FiTag,         label: "Coupons & flash sales",          sub: "Run urgency-driven campaigns with stock-aware countdown timers." },
  { icon: FiSmartphone,  label: "PWA + native app",               sub: "Customers can install your store like a real app — push notifications included." },
  { icon: FiGlobe,       label: "Custom domain + SSL",            sub: "Bring your own domain, we handle the certificate auto-renewal." },
  { icon: FiZap,         label: "Facebook Pixel + CAPI",          sub: "Server-side conversions API with event deduplication and deferred Purchase." },
  { icon: FiShield,      label: "Built-in spam protection",       sub: "Block bots, fake orders, and abusive phone numbers automatically." },
  { icon: FiClock,       label: "Order timeline + audit log",     sub: "Every status change, every staff action — fully traceable." },
  { icon: FiRefreshCw,   label: "Realtime everywhere",            sub: "Live sync across admin tabs, so your team never works on stale data." },
];

const USE_CASES = [
  { tag: "Fashion",       title: "Boutiques & apparel",      body: "Variant images, size guides, lookbooks — built to convert browsers into buyers.",  blob: "bg-pink-200/70",     tagCls: "bg-pink-100 text-pink-700" },
  { tag: "Electronics",   title: "Gadgets & accessories",    body: "Spec tables, model variants, compare-and-bundle flows for techies.",                blob: "bg-blue-200/70",     tagCls: "bg-blue-100 text-blue-700" },
  { tag: "Food",          title: "Restaurants & kitchens",   body: "Hourly menus, area-based delivery zones, fast COD checkout for hungry customers.", blob: "bg-amber-200/70",    tagCls: "bg-amber-100 text-amber-700" },
  { tag: "Beauty",        title: "Cosmetics & skincare",     body: "Shade swatches, before/after galleries, recurring subscription bundles.",          blob: "bg-purple-200/70",   tagCls: "bg-purple-100 text-purple-700" },
  { tag: "Grocery",       title: "Mini-marts & dairy",       body: "Lightning catalog, low-stock alerts, automated courier dispatch at scale.",        blob: "bg-emerald-200/70",  tagCls: "bg-emerald-100 text-emerald-700" },
  { tag: "Services",      title: "Booking & appointments",   body: "Slot-based products, deposit checkout, automated customer reminders.",             blob: "bg-cyan-200/70",     tagCls: "bg-cyan-100 text-cyan-700" },
];

const INTEGRATIONS = ["bKash", "Nagad", "Pathao", "Steadfast", "Facebook Pixel", "Google Analytics", "GTM", "Mailchimp", "WhatsApp", "Cloudinary", "Twilio SMS", "Webhooks"];

const STATS = [
  { icon: FiAward,       stat: "99.9%",   label: "Uptime SLA" },
  { icon: FiShield,      stat: "14-day",  label: "Money-back guarantee" },
  { icon: FiHeadphones,  stat: "24/7",    label: "Bangla + English support" },
  { icon: FiTrendingUp,  stat: "<2s",     label: "Median page load" },
];

const COMPARE_ROWS: { label: string; values: Record<string, boolean | string | null> }[] = [
  { label: "Products",                values: { starter: "100",  pro: "Unlimited", enterprise: "Unlimited" } },
  { label: "Staff accounts",          values: { starter: "1",    pro: "5",         enterprise: "Unlimited" } },
  { label: "Custom domain + SSL",     values: { starter: false,  pro: true,        enterprise: true } },
  { label: "bKash + COD checkout",    values: { starter: true,   pro: true,        enterprise: true } },
  { label: "Pathao + Steadfast",      values: { starter: false,  pro: true,        enterprise: true } },
  { label: "Coupons & flash sales",   values: { starter: false,  pro: true,        enterprise: true } },
  { label: "Facebook Pixel + CAPI",   values: { starter: true,   pro: true,        enterprise: true } },
  { label: "Native mobile app",       values: { starter: false,  pro: false,       enterprise: true } },
  { label: "AI product copy",         values: { starter: false,  pro: false,       enterprise: true } },
  { label: "Support",                 values: { starter: "Email", pro: "Priority email", enterprise: "24/7 dedicated" } },
  { label: "Onboarding",              values: { starter: "Docs", pro: "Email",     enterprise: "Dedicated manager" } },
  { label: "Public API + Webhooks",   values: { starter: false,  pro: true,        enterprise: true } },
];

const TESTIMONIALS = [
  { author: "Tasnim Rahman", store: "Dhaka Couture · Fashion",          quote: "Switched from Shopify a month ago. The Pathao integration alone saves us two hours every single day. bKash worked first try." },
  { author: "Imran Hossain", store: "Gadget Bazaar · Electronics",      quote: "Order management is leagues ahead of WooCommerce. Realtime sync across all our staff devices was the real unlock for us." },
  { author: "Sumi Akter",    store: "Sweet Treats BD · Food",           quote: "I'm not technical and I had our store live in an afternoon. Customers love the bKash checkout — conversion jumped 40%." },
];

const FAQS = [
  { q: "Can I upgrade or downgrade my plan later?",       a: "Any time, from your dashboard. Upgrades take effect immediately. Downgrades apply at the next billing cycle so you don't lose paid time." },
  { q: "Do you charge transaction fees?",                  a: "No. CD Ecom never takes a cut of your sales — you pay the plan price and keep 100% of revenue. Payment gateways like bKash and Nagad have their own standard fees." },
  { q: "Does Cash-on-Delivery work out of the box?",       a: "Yes — COD is enabled on every plan with no extra setup. Toggle it in checkout settings and you're done." },
  { q: "How do courier integrations work?",                a: "Pro and Enterprise plans include one-click dispatch to Pathao and Steadfast. Enter your courier API keys once; we handle dispatch, status sync, and proof-of-delivery automatically." },
  { q: "Can I use my own domain?",                          a: "Yes — Pro and Enterprise plans support custom domains with free SSL (Let's Encrypt). DNS instructions are in your dashboard; most setups complete in under 15 minutes." },
  { q: "Is there a free trial?",                            a: "Every paid plan comes with a 14-day money-back guarantee. If it's not for you, request a full refund and we'll process it within 3 business days." },
  { q: "Do you support Bangla?",                            a: "Yes — both the storefront and the admin dashboard are fully bilingual (English + বাংলা). Customers switch any time; you control the default language." },
  { q: "What if I need a feature that's not listed?",      a: "Enterprise plans include custom integrations and feature requests handled by our team. For Starter and Pro, our public webhooks + REST API let you build whatever you need." },
];
