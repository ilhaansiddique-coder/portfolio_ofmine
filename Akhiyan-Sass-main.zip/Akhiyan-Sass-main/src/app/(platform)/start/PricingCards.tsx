"use client";

/**
 * Pricing cards row with a sticky billing-period toggle.
 *
 * Visual treatment is intentionally "premium SaaS":
 *   - Popular plan is visually elevated (scale, glow, gradient border).
 *   - Yearly toggle ships a SAVE pill + per-card "+2 months FREE" promo line.
 *   - Cards use a subtle inner gradient + soft shadow stack so they read as
 *     actual surfaces, not flat boxes.
 *
 * Plan data is DB-driven (passed in from the server component) so superadmin
 * pricing changes don't require a frontend redeploy.
 */

import { useState } from "react";
import Link from "next/link";
import { FiCheck, FiZap, FiArrowRight, FiGift } from "react-icons/fi";

export interface PlanCard {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  /** paisa (1/100 of a taka) */
  priceMonthly: number | null;
  features: string[];
  highlight: boolean;
}

const taka = (paisa: number | null) =>
  paisa == null ? null : `৳${Math.round(paisa / 100).toLocaleString("en-US")}`;

const ANNUAL_DISCOUNT = 0.20;

export default function PricingCards({ plans }: { plans: PlanCard[] }) {
  const [period, setPeriod] = useState<"monthly" | "yearly">("yearly");

  return (
    <>
      {/* ── Billing toggle ── */}
      <div className="flex justify-center mb-14">
        <div className="inline-flex items-center rounded-full border border-gray-200 bg-white p-1 shadow-sm">
          {(["monthly", "yearly"] as const).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPeriod(p)}
              className={`relative inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold transition-all ${
                period === p ? "bg-[#0f5931] text-white shadow-md" : "text-gray-500 hover:text-gray-900"
              }`}
            >
              {p === "monthly" ? "Monthly" : "Yearly"}
              {p === "yearly" && (
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md tracking-wide ${
                  period === "yearly" ? "bg-white/20 text-white" : "bg-emerald-100 text-emerald-700"
                }`}>SAVE 20%</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── Cards ──
        * `auto-fit` grid template adapts to ANY number of plans (DB-driven
        * — could be 2 paid plans + trial, or 4 paid plans + trial). Each
        * card has a min-width so it stays legible; the row stretches to fill
        * the available width and centers itself within the section. */}
      <div
        className="grid gap-6 sm:gap-8 items-stretch justify-center"
        style={{ gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}
      >
        {/* Free Trial card — always first. No price, drives sign-up before
          * the paid plans even register. Visually distinct from real plans
          * (warm amber gradient + gift icon) so merchants understand it's
          * a try-before-you-buy offer, not a paid tier. */}
        <article className="group relative flex flex-col rounded-3xl p-8 bg-gradient-to-b from-amber-50 to-amber-100/60 border-2 border-amber-300/80 hover:shadow-xl hover:shadow-amber-500/15 hover:-translate-y-0.5 transition-all duration-300">
          <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 bg-white border border-amber-300 text-amber-900 text-[11px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-full shadow-sm">
            <FiGift className="h-3 w-3" /> Try free
          </span>

          <header>
            <h3 className="text-2xl font-bold text-amber-950">Free Trial</h3>
            <p className="mt-2 text-sm text-amber-900/70">Spin up a real store, no card needed.</p>
          </header>

          <div className="mt-6 min-h-[88px]">
            <div className="flex items-baseline gap-1.5">
              <span className="text-5xl font-bold tracking-tight text-amber-950">3</span>
              <span className="text-sm text-amber-900/80">days</span>
            </div>
            <div className="mt-1 text-[12px] text-amber-900/80">Full access — no credit card</div>
          </div>

          <Link
            href="/start/checkout?plan=trial&period=trial"
            className="mt-6 group/cta inline-flex items-center justify-center gap-2 h-12 rounded-xl text-sm font-bold bg-amber-400 text-amber-950 hover:bg-amber-300 shadow-lg shadow-amber-500/20 transition-all"
          >
            Start free trial
            <FiArrowRight className="h-4 w-4 transition-transform group-hover/cta:translate-x-0.5" />
          </Link>

          <p className="mt-3 text-center text-[12px] font-semibold text-amber-900/80">
            Upgrade any time during trial
          </p>

          <div className="my-7 h-px bg-amber-300/40" />

          <ul className="space-y-3 text-sm">
            {[
              "Full storefront access",
              "Add up to 10 test products",
              "Try every Pro feature",
              "No card, no commitment",
              "Convert your trial → paid in 1 click",
            ].map((f) => (
              <li key={f} className="flex items-start gap-3">
                <span className="grid place-items-center w-5 h-5 rounded-full shrink-0 mt-0.5 bg-amber-200">
                  <FiCheck className="h-3 w-3 text-amber-900" />
                </span>
                <span className="text-amber-900">{f}</span>
              </li>
            ))}
          </ul>
        </article>

        {plans.map((plan) => {
          const monthly = plan.priceMonthly;
          const yearlyPerMonth = monthly == null ? null : Math.round(monthly * (1 - ANNUAL_DISCOUNT));
          const displayPaisa = period === "yearly" ? yearlyPerMonth : monthly;
          const displayPrice = taka(displayPaisa);
          const slash = period === "yearly" ? taka(monthly) : null;
          const yearlyTotal = period === "yearly" && yearlyPerMonth != null
            ? `৳${Math.round((yearlyPerMonth * 12) / 100).toLocaleString("en-US")} billed yearly`
            : null;

          return (
            <article
              key={plan.id}
              className={`group relative flex flex-col rounded-3xl p-8 transition-all duration-300 ${
                plan.highlight
                  ? "md:-mt-4 md:mb-2 bg-gradient-to-b from-[#0f5931] to-[#0a3d22] text-white shadow-2xl shadow-emerald-700/30 hover:-translate-y-1"
                  : "bg-white border border-gray-200 hover:border-gray-300 hover:shadow-xl hover:-translate-y-0.5"
              }`}
            >
              {plan.highlight && (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 bg-amber-400 text-amber-950 text-[11px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-full shadow-lg">
                  <FiZap className="h-3 w-3" /> Most popular
                </span>
              )}

              <header>
                <h3 className={`text-2xl font-bold ${plan.highlight ? "text-white" : "text-gray-900"}`}>{plan.name}</h3>
                {plan.description && (
                  <p className={`mt-2 text-sm ${plan.highlight ? "text-white/75" : "text-gray-500"}`}>{plan.description}</p>
                )}
              </header>

              <div className="mt-6 min-h-[88px]">
                {displayPrice ? (
                  <>
                    {slash && (
                      <div className={`text-xs line-through ${plan.highlight ? "text-white/50" : "text-gray-400"}`}>
                        {slash}/mo
                      </div>
                    )}
                    <div className="flex items-baseline gap-1.5">
                      <span className={`text-5xl font-bold tracking-tight ${plan.highlight ? "text-white" : "text-gray-900"}`}>
                        {displayPrice}
                      </span>
                      <span className={`text-sm ${plan.highlight ? "text-white/70" : "text-gray-500"}`}>/mo</span>
                    </div>
                    {yearlyTotal ? (
                      <div className={`mt-1 text-[12px] ${plan.highlight ? "text-white/70" : "text-gray-500"}`}>
                        {yearlyTotal}
                      </div>
                    ) : (
                      <div className="mt-1 text-[12px] text-transparent select-none">.</div>
                    )}
                  </>
                ) : (
                  <div className={`text-3xl font-bold ${plan.highlight ? "text-white" : "text-gray-900"}`}>Custom</div>
                )}
              </div>

              <Link
                href={`/start/checkout?plan=${encodeURIComponent(plan.slug)}&period=${period}`}
                className={`mt-6 group/cta inline-flex items-center justify-center gap-2 h-12 rounded-xl text-sm font-bold transition-all ${
                  plan.highlight
                    ? "bg-white text-[#0f5931] hover:bg-emerald-50 shadow-lg shadow-black/10"
                    : "bg-gray-900 text-white hover:bg-gray-700"
                }`}
              >
                Get started
                <FiArrowRight className="h-4 w-4 transition-transform group-hover/cta:translate-x-0.5" />
              </Link>

              {period === "yearly" && (
                <p className={`mt-3 text-center text-[12px] font-semibold ${
                  plan.highlight ? "text-amber-300" : "text-emerald-700"
                }`}>
                  + 2 months FREE on annual
                </p>
              )}

              <div className={`my-7 h-px ${plan.highlight ? "bg-white/15" : "bg-gray-100"}`} />

              <ul className="space-y-3 text-sm">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <span className={`grid place-items-center w-5 h-5 rounded-full shrink-0 mt-0.5 ${
                      plan.highlight ? "bg-white/15" : "bg-emerald-100"
                    }`}>
                      <FiCheck className={`h-3 w-3 ${plan.highlight ? "text-white" : "text-[#0f5931]"}`} />
                    </span>
                    <span className={plan.highlight ? "text-white/90" : "text-gray-700"}>{f}</span>
                  </li>
                ))}
              </ul>
            </article>
          );
        })}
      </div>

      <p className="mt-10 text-center text-xs text-gray-500">
        All plans include free SSL · 99.9% uptime · 14-day money-back
      </p>
    </>
  );
}
