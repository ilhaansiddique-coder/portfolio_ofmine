/**
 * Platform marketing layout — pricing + checkout funnel.
 * Standalone <html>/<body>; no tenant storefront or admin chrome.
 *
 * Fonts mirror the (site) layout (Hind Siliguri body + Bricolage headings)
 * so /start and /start/checkout match the brand typography of the rest of
 * the site instead of falling back to system-ui.
 */
import type { Metadata } from "next";
import { Hind_Siliguri, Bricolage_Grotesque } from "next/font/google";
import "../globals.css";

const hindSiliguri = Hind_Siliguri({
  variable: "--font-hind-siliguri",
  subsets: ["bengali", "latin"],
  weight: ["400", "500", "700"],
  display: "swap",
  preload: true,
  adjustFontFallback: true,
});

const bricolage = Bricolage_Grotesque({
  variable: "--font-bricolage",
  subsets: ["latin"],
  weight: ["500", "700"],
  display: "swap",
  preload: false,
  adjustFontFallback: true,
});

export const metadata: Metadata = {
  title: "CD Ecom — Pricing",
  description: "Launch your online store with CD Ecom. Simple plans, fast setup.",
};

export default function PlatformLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      style={{ colorScheme: "light" }}
      className={`${hindSiliguri.variable} ${bricolage.variable} antialiased lang-en`}
    >
      <body className="min-h-screen bg-white text-zinc-900" style={{ colorScheme: "light" }}>
        {children}
      </body>
    </html>
  );
}
