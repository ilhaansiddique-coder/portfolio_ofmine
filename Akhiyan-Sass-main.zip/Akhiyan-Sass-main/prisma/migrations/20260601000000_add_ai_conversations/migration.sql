-- AI page-builder conversation history (sessions + messages)

CREATE TABLE "ai_conversations" (
  "id"         SERIAL PRIMARY KEY,
  "title"      TEXT NOT NULL DEFAULT 'New conversation',
  "page_id"    INTEGER,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL
);

CREATE INDEX "ai_conversations_updated_at_idx" ON "ai_conversations" ("updated_at");
CREATE INDEX "ai_conversations_page_id_idx" ON "ai_conversations" ("page_id");

CREATE TABLE "ai_messages" (
  "id"              SERIAL PRIMARY KEY,
  "conversation_id" INTEGER NOT NULL,
  "role"            TEXT NOT NULL,
  "content"         TEXT NOT NULL,
  "mode"            TEXT,
  "applied_data"    JSONB,
  "input_tokens"    INTEGER NOT NULL DEFAULT 0,
  "output_tokens"   INTEGER NOT NULL DEFAULT 0,
  "created_at"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ai_messages_conversation_id_fkey"
    FOREIGN KEY ("conversation_id") REFERENCES "ai_conversations" ("id")
    ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE INDEX "ai_messages_conversation_id_idx" ON "ai_messages" ("conversation_id");
CREATE INDEX "ai_messages_created_at_idx" ON "ai_messages" ("created_at");
