-- Add section_order JSONB column to landing_pages.
-- Schema already had this field; the column was missing in tenant DBs.
ALTER TABLE "landing_pages" ADD COLUMN IF NOT EXISTS "section_order" JSONB;
