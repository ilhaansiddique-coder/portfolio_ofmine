-- Add OG image and custom CSS columns to cms_pages
ALTER TABLE "cms_pages" ADD COLUMN "og_image" TEXT;
ALTER TABLE "cms_pages" ADD COLUMN "custom_css" TEXT;
