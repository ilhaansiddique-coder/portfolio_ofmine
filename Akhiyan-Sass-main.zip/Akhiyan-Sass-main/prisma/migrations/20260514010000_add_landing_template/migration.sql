-- Per-landing-page template + template_data.
-- Lets us render a totally different visual design per page (akbd, default, etc.)
ALTER TABLE "landing_pages" ADD COLUMN IF NOT EXISTS "template" TEXT NOT NULL DEFAULT 'default';
ALTER TABLE "landing_pages" ADD COLUMN IF NOT EXISTS "template_data" JSONB;
