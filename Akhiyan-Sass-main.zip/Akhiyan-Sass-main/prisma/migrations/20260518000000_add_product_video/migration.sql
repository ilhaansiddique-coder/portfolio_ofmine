-- Add optional product video URL (YouTube or direct) for the PDP gallery
ALTER TABLE "products" ADD COLUMN "video_url" TEXT;
