-- CreateTable
CREATE TABLE "site_brief" (
    "id" SERIAL NOT NULL,
    "business_name" TEXT NOT NULL,
    "one_liner" TEXT,
    "long_description" TEXT,
    "target_audience" TEXT,
    "tone" TEXT NOT NULL DEFAULT 'friendly',
    "product_categories" TEXT[],
    "locations" TEXT[],
    "unique_selling" TEXT[],
    "do_not_use" TEXT[],
    "example_paragraph" TEXT,
    "languages" TEXT[] DEFAULT ARRAY['en']::TEXT[],
    "primary_language" TEXT NOT NULL DEFAULT 'en',
    "competitors" TEXT[],
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "site_brief_pkey" PRIMARY KEY ("id")
);
