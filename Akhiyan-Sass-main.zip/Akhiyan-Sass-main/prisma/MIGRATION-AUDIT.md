# Prisma Singleton → Tenant Factory Migration Audit

**Source:** `from "@/lib/prisma"` imports (the global singleton).
**Target:** `await getPrismaForRequest(req?)` from `@/lib/prisma-tenant`.

**Total files to refactor: 146** (147 grep hits minus `prisma-tenant.ts` itself).

**Process:** check off each file as `prisma` is replaced with `await getPrismaForRequest(...)`. Build after each batch of ~10 to catch type errors early.

---

## Wave 1 — API routes (97 files)

Pattern:
```ts
// before
import { prisma } from "@/lib/prisma";
export async function GET() { ... prisma.product.findMany() ... }

// after
import { getPrismaForRequest } from "@/lib/prisma-tenant";
export async function GET(req: Request) {
  const { prisma } = await getPrismaForRequest(req);
  ...
}
```

### 1a. Public storefront API (25)
- [ ] src/app/api/v1/banners/route.ts
- [ ] src/app/api/v1/blog/[slug]/route.ts
- [ ] src/app/api/v1/blog/route.ts
- [ ] src/app/api/v1/brands/route.ts
- [ ] src/app/api/v1/categories/route.ts
- [ ] src/app/api/v1/collect/route.ts
- [ ] src/app/api/v1/contact/route.ts
- [ ] src/app/api/v1/coupons/apply/route.ts
- [ ] src/app/api/v1/fingerprint/route.ts
- [ ] src/app/api/v1/flash-sales/active/route.ts
- [ ] src/app/api/v1/incomplete-orders/route.ts
- [ ] src/app/api/v1/landing-pages/[slug]/route.ts
- [ ] src/app/api/v1/menus/route.ts
- [ ] src/app/api/v1/products/[slug]/reviews/route.ts
- [ ] src/app/api/v1/products/[slug]/route.ts
- [ ] src/app/api/v1/products/by-ids/route.ts
- [ ] src/app/api/v1/products/route.ts
- [ ] src/app/api/v1/products/search/route.ts
- [ ] src/app/api/v1/products/top-rated/route.ts
- [ ] src/app/api/v1/reviews/approved/route.ts
- [ ] src/app/api/v1/reviews/route.ts
- [ ] src/app/api/v1/shipping/calculate/route.ts
- [ ] src/app/api/v1/shipping/zones/route.ts
- [ ] src/app/api/v1/sync/route.ts

### 1b. Customer-account API (10)
- [ ] src/app/api/v1/addresses/[id]/route.ts
- [ ] src/app/api/v1/addresses/route.ts
- [ ] src/app/api/v1/auth/forgot-password/route.ts
- [ ] src/app/api/v1/auth/login/route.ts
- [ ] src/app/api/v1/auth/password/route.ts
- [ ] src/app/api/v1/auth/profile/route.ts
- [ ] src/app/api/v1/auth/register/route.ts
- [ ] src/app/api/v1/auth/reset-password/route.ts
- [ ] src/app/api/v1/auth/user/route.ts

### 1c. Order placement (4)
- [ ] src/app/api/v1/orders/[id]/cancel/route.ts
- [ ] src/app/api/v1/orders/[id]/route.ts
- [ ] src/app/api/v1/orders/route.ts
- [ ] src/app/api/v1/orders/token/[token]/route.ts

### 1d. Wishlist (2)
- [ ] src/app/api/v1/wishlist/route.ts
- [ ] src/app/api/v1/wishlist/toggle/route.ts

### 1e. Admin: catalog (16)
- [ ] src/app/api/v1/admin/banners/[id]/route.ts
- [ ] src/app/api/v1/admin/banners/route.ts
- [ ] src/app/api/v1/admin/blog/[id]/route.ts
- [ ] src/app/api/v1/admin/blog/route.ts
- [ ] src/app/api/v1/admin/brands/[id]/route.ts
- [ ] src/app/api/v1/admin/brands/route.ts
- [ ] src/app/api/v1/admin/categories/[id]/route.ts
- [ ] src/app/api/v1/admin/categories/route.ts
- [ ] src/app/api/v1/admin/coupons/[id]/route.ts
- [ ] src/app/api/v1/admin/coupons/route.ts
- [ ] src/app/api/v1/admin/flash-sales/[id]/route.ts
- [ ] src/app/api/v1/admin/flash-sales/route.ts
- [ ] src/app/api/v1/admin/products/[id]/route.ts
- [ ] src/app/api/v1/admin/products/route.ts
- [ ] src/app/api/v1/admin/reviews/[id]/route.ts
- [ ] src/app/api/v1/admin/reviews/route.ts

### 1f. Admin: orders + courier (12)
- [ ] src/app/api/v1/admin/courier/monitor/route.ts
- [ ] src/app/api/v1/admin/courier/pathao-parcels/route.ts
- [ ] src/app/api/v1/admin/courier/pathao/customer-history/route.ts
- [ ] src/app/api/v1/admin/courier/pathao/parse/route.ts
- [ ] src/app/api/v1/admin/courier/pathao/route.ts
- [ ] src/app/api/v1/admin/courier/route.ts
- [ ] src/app/api/v1/admin/courier/score/route.ts
- [ ] src/app/api/v1/admin/courier/steadfast-parcels/route.ts
- [ ] src/app/api/v1/admin/orders/[id]/route.ts
- [ ] src/app/api/v1/admin/orders/[id]/status/route.ts
- [ ] src/app/api/v1/admin/orders/route.ts
- [ ] src/app/api/v1/admin/customers/search/route.ts

### 1g. Admin: misc CRUD (16)
- [ ] src/app/api/v1/admin/dashboard/route.ts
- [ ] src/app/api/v1/admin/email-test/route.ts
- [ ] src/app/api/v1/admin/feeds/route.ts
- [ ] src/app/api/v1/admin/form-submissions/[id]/route.ts
- [ ] src/app/api/v1/admin/form-submissions/route.ts
- [ ] src/app/api/v1/admin/incomplete-orders/[id]/convert/route.ts
- [ ] src/app/api/v1/admin/incomplete-orders/[id]/route.ts
- [ ] src/app/api/v1/admin/incomplete-orders/route.ts
- [ ] src/app/api/v1/admin/landing-pages/[id]/route.ts
- [ ] src/app/api/v1/admin/landing-pages/route.ts
- [ ] src/app/api/v1/admin/menus/[id]/route.ts
- [ ] src/app/api/v1/admin/menus/route.ts
- [ ] src/app/api/v1/admin/settings/route.ts
- [ ] src/app/api/v1/admin/shipping/[id]/route.ts
- [ ] src/app/api/v1/admin/shipping/route.ts
- [ ] src/app/api/v1/admin/users/[id]/route.ts

### 1h. Admin: shortlinks + spam (12)
- [ ] src/app/api/v1/admin/shortlinks/[id]/analytics/route.ts
- [ ] src/app/api/v1/admin/shortlinks/[id]/route.ts
- [ ] src/app/api/v1/admin/shortlinks/route.ts
- [ ] src/app/api/v1/admin/spam/blocked-ips/[id]/route.ts
- [ ] src/app/api/v1/admin/spam/blocked-ips/route.ts
- [ ] src/app/api/v1/admin/spam/blocked-phones/[id]/route.ts
- [ ] src/app/api/v1/admin/spam/blocked-phones/route.ts
- [ ] src/app/api/v1/admin/spam/customer-trace/route.ts
- [ ] src/app/api/v1/admin/spam/customers/route.ts
- [ ] src/app/api/v1/admin/spam/devices/[id]/route.ts
- [ ] src/app/api/v1/admin/spam/devices/route.ts
- [ ] src/app/api/v1/admin/spam/flagged-orders/route.ts
- [ ] src/app/api/v1/admin/users/bulk/route.ts
- [ ] src/app/api/v1/admin/users/route.ts

---

## Wave 2 — Server actions (0 found)

No `"use server"` action files import the singleton directly. (May surface during builds — recheck after Wave 1.)

---

## Wave 3 — Server components / pages (42 files)

Pattern:
```tsx
// before
import { prisma } from "@/lib/prisma";
export default async function Page() { const p = await prisma.product.findMany(); ... }

// after
import { getPrismaForRequest } from "@/lib/prisma-tenant";
export default async function Page() {
  const { prisma } = await getPrismaForRequest();
  const p = await prisma.product.findMany();
  ...
}
```

### 3a. Storefront pages (10)
- [ ] src/app/[slug]/page.tsx
- [ ] src/app/about/page.tsx
- [ ] src/app/contact/page.tsx
- [ ] src/app/layout.tsx (root)
- [ ] src/app/lp/[slug]/page.tsx
- [ ] src/app/page.tsx
- [ ] src/app/privacy/page.tsx
- [ ] src/app/products/[slug]/page.tsx
- [ ] src/app/refund/page.tsx
- [ ] src/app/shop/page.tsx
- [ ] src/app/terms/page.tsx

### 3b. Dashboard pages (31)
- [ ] src/app/dashboard/(home)/page.tsx
- [ ] src/app/dashboard/banners/page.tsx
- [ ] src/app/dashboard/blog/page.tsx
- [ ] src/app/dashboard/brands/page.tsx
- [ ] src/app/dashboard/categories/page.tsx
- [ ] src/app/dashboard/content/about/page.tsx
- [ ] src/app/dashboard/content/contact/page.tsx
- [ ] src/app/dashboard/content/email/page.tsx
- [ ] src/app/dashboard/content/header-footer/page.tsx
- [ ] src/app/dashboard/content/privacy/page.tsx
- [ ] src/app/dashboard/content/refund/page.tsx
- [ ] src/app/dashboard/content/shop/page.tsx
- [ ] src/app/dashboard/content/terms/page.tsx
- [ ] src/app/dashboard/coupons/page.tsx
- [ ] src/app/dashboard/customizer/page.tsx
- [ ] src/app/dashboard/flash-sales/page.tsx
- [ ] src/app/dashboard/form-submissions/page.tsx
- [ ] src/app/dashboard/homepage/page.tsx
- [ ] src/app/dashboard/landing-pages/page.tsx
- [ ] src/app/dashboard/menus/page.tsx
- [ ] src/app/dashboard/orders/page.tsx
- [ ] src/app/dashboard/products/page.tsx
- [ ] src/app/dashboard/reviews/page.tsx
- [ ] src/app/dashboard/settings/checkout/page.tsx
- [ ] src/app/dashboard/settings/courier/page.tsx
- [ ] src/app/dashboard/settings/email/page.tsx
- [ ] src/app/dashboard/settings/language/page.tsx
- [ ] src/app/dashboard/settings/page.tsx
- [ ] src/app/dashboard/shipping/page.tsx
- [ ] src/app/dashboard/shortlinks/[id]/page.tsx
- [ ] src/app/dashboard/users/page.tsx

---

## Wave 4 — Lib helpers (7 files)

These need a different treatment: function signatures must accept a `prisma` parameter. Every call site must pass the tenant-scoped client in.

- [ ] src/lib/auto-site-url.ts
- [ ] src/lib/email-templates.ts
- [ ] src/lib/email.ts
- [ ] src/lib/feedSource.ts
- [ ] src/lib/pathaoMerchantAuth.ts
- [ ] src/lib/settingsCache.ts (special — needs tenant-keyed cache)
- [ ] src/lib/spamGuard.ts

---

## Wave 5 — Lock the door

- [ ] Replace `src/lib/prisma.ts` body with a stub that throws on import (only in production)
- [ ] Run full `npm run build` — must pass with zero `prisma` import warnings
- [ ] Manual smoke test: storefront homepage, /shop, /products/[slug], /dashboard, place a test order
