/**
 * Per-tenant DB seed — runs once on provisioning.
 *
 * Given a tenant's `dbUrl`, populates:
 *   • One admin user (role="admin") with a randomly-generated password
 *   • Minimal `site_settings` so the storefront renders on first visit
 *   • Two default shipping zones (Inside Dhaka ৳80, Outside Dhaka ৳150)
 *   • Demo catalog: 1 brand, 1 category, 2 products (1 simple + 1 variable)
 *   • A demo landing page on the default template referencing those products
 *
 * All demo data is English and guarded by "only when empty" checks, so a
 * re-run never duplicates or overwrites a live store's real content. The
 * owner can edit or delete any of it from the dashboard.
 *
 * Returns `{ adminEmail, adminPassword }` — the caller (provisioning API)
 * should email the password to the owner. We never store plaintext.
 *
 * Idempotent — safe to re-run; uses upsert.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";

export interface SeedOptions {
  ownerEmail: string;       // becomes the admin user's email
  ownerName?: string;       // displayed in dashboard
  storeName?: string;       // becomes site_name
  storeTagline?: string;
}

export interface SeedResult {
  adminEmail: string;
  adminPassword: string;    // plaintext — caller emails to owner, never logs
  adminUserId: number;
}

/** Generate a 12-char alphanumeric password. */
function generatePassword(): string {
  return randomBytes(9).toString("base64").replace(/[+/=]/g, "").slice(0, 12);
}

export async function seedTenantDb(dbUrl: string, opts: SeedOptions): Promise<SeedResult> {
  const prisma = new PrismaClient({ datasourceUrl: dbUrl });
  try {
    const password = generatePassword();
    const hashedPassword = await bcrypt.hash(password, 12);

    // ─── Admin user ───
    const admin = await prisma.user.upsert({
      where: { email: opts.ownerEmail },
      update: { role: "admin" }, // ensure existing user is promoted to admin if re-running
      create: {
        name: opts.ownerName || "Store Owner",
        email: opts.ownerEmail,
        password: hashedPassword,
        role: "admin",
      },
    });

    // ─── Minimal site settings ───
    const settings: Record<string, string> = {
      site_name: opts.storeName || "My Store",
      site_tagline: opts.storeTagline || "",
      site_description: "",
      site_language: "en",
      dashboard_language: "en",
      // Theme defaults — match globals.css fallbacks
      "theme.color.primary": "#0f5931",
      "theme.color.primary_dark": "#0a3d22",
      // Currency / locale defaults
      currency_symbol: "৳",
      currency_code: "BDT",
    };

    for (const [key, value] of Object.entries(settings)) {
      await prisma.siteSetting.upsert({
        where: { key },
        update: {}, // don't overwrite if owner already changed it
        create: { key, value, group: "general" },
      });
    }

    // ─── Default shipping zones — only seed when the tenant has none,
    //     so we never clobber zones the owner has already configured. ───
    const existingZone = await prisma.shippingZone.findFirst();
    if (!existingZone) {
      await prisma.shippingZone.createMany({
        data: [
          { name: "Inside Dhaka", cities: "Dhaka", rate: 80, estimatedDays: "1-2 days", isActive: true },
          { name: "Outside Dhaka", cities: "All", rate: 150, estimatedDays: "3-5 days", isActive: true },
        ],
      });
    }

    // ─── Demo catalog (brand + category + 2 products) ───
    //     Only seeds on a completely empty catalog so a re-run never
    //     duplicates or overwrites a live store's products. Gives a fresh
    //     tenant something to see on the storefront before they add stock.
    const productCount = await prisma.product.count();
    if (productCount === 0) {
      const brand = await prisma.brand.create({
        data: { name: "Demo Brand", slug: "demo-brand", isActive: true },
      });
      const category = await prisma.category.create({
        data: { name: "Demo Category", slug: "demo-category", isActive: true, sortOrder: 0 },
      });

      // 1) Simple product — no variations.
      await prisma.product.create({
        data: {
          name: "Classic Cotton T-Shirt",
          slug: "classic-cotton-t-shirt",
          categoryId: category.id,
          brandId: brand.id,
          description:
            "A soft, breathable everyday t-shirt made from 100% combed cotton. This is a demo product — edit or delete it from Dashboard → Products.",
          price: 750,
          originalPrice: 990,
          image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=80",
          images: JSON.stringify([
            "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=80",
            "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800&q=80",
          ]),
          badge: "New",
          badgeColor: "#0f5931",
          weight: "250g",
          stock: 100,
          unlimitedStock: false,
          isActive: true,
          isFeatured: true,
          hasVariations: false,
          sortOrder: 1,
        },
      });

      // 2) Variable product — three size variants.
      const variable = await prisma.product.create({
        data: {
          name: "Premium Polo Shirt",
          slug: "premium-polo-shirt",
          categoryId: category.id,
          brandId: brand.id,
          description:
            "A smart pique-knit polo with a structured collar. Choose your size below. This is a demo product — edit or delete it from Dashboard → Products.",
          price: 1190,
          originalPrice: 1490,
          image: "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=800&q=80",
          images: JSON.stringify([
            "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=800&q=80",
            "https://images.unsplash.com/photo-1620012253295-c15cc3e65df4?w=800&q=80",
          ]),
          badge: "Best Seller",
          badgeColor: "#b08d57",
          weight: "320g",
          stock: 0,
          unlimitedStock: false,
          isActive: true,
          isFeatured: true,
          hasVariations: true,
          variationType: "Size",
          sortOrder: 2,
        },
      });
      await prisma.productVariant.createMany({
        data: [
          { productId: variable.id, label: "M",  price: 1190, originalPrice: 1490, sku: "POLO-M",  stock: 40, sortOrder: 0, isActive: true },
          { productId: variable.id, label: "L",  price: 1190, originalPrice: 1490, sku: "POLO-L",  stock: 35, sortOrder: 1, isActive: true },
          { productId: variable.id, label: "XL", price: 1290, originalPrice: 1590, sku: "POLO-XL", stock: 25, sortOrder: 2, isActive: true },
        ],
      });

      // ─── Demo landing page (default template) referencing both demo
      //     products. Gives the owner a working LP to learn from / edit. ───
      const lpProducts = await prisma.product.findMany({ select: { id: true }, orderBy: { sortOrder: "asc" } });
      await prisma.landingPage.create({
        data: {
          slug: "demo",
          title: "Demo Landing Page",
          isActive: true,
          template: "default",
          heroHeadline: "Your Headline Goes Here",
          heroSubheadline: "This is a demo landing page. Edit every section from Dashboard → Landing Pages.",
          heroCta: "Order Now",
          heroBadge: "Limited Offer",
          heroTrustText: "Cash on delivery available",
          problemTitle: "Why customers choose us",
          problemPoints: JSON.stringify([
            { icon: "✅", text: "Genuine, quality-checked products" },
            { icon: "🚚", text: "Fast delivery across the country" },
            { icon: "💵", text: "Cash on delivery — pay when you receive" },
            { icon: "🔄", text: "Easy returns and friendly support" },
          ]),
          productsTitle: "Featured Products",
          productsSub: "Hand-picked items for you",
          products: JSON.stringify(lpProducts.map((p) => ({ product_id: p.id, quantity: 1 }))),
          featuresTitle: "What makes it special",
          features: JSON.stringify([
            { icon: "🌟", title: "Premium quality", description: "Carefully sourced and quality-checked before shipping." },
            { icon: "⚡", title: "Quick delivery", description: "Dispatched fast so you get your order without the wait." },
            { icon: "🛡️", title: "Secure checkout", description: "Your details are handled safely from order to delivery." },
          ]),
          howItWorksTitle: "How it works",
          howItWorksSub: "Three simple steps",
          howItWorks: JSON.stringify([
            { title: "Place your order", description: "Fill in the form with your name, phone and address." },
            { title: "We confirm", description: "Our team calls to confirm your order details." },
            { title: "Delivered", description: "Your package arrives at your door. Pay on delivery." },
          ]),
          faqTitle: "Frequently asked questions",
          faq: JSON.stringify([
            { question: "How do I place an order?", answer: "Fill in the order form on this page and submit. We'll call to confirm." },
            { question: "What is the delivery charge?", answer: "Inside Dhaka ৳80, outside Dhaka ৳150. Cash on delivery is available." },
            { question: "Can I return a product?", answer: "Yes — contact our support team and we'll help with returns or exchanges." },
          ]),
          checkoutTitle: "Place Your Order",
          checkoutSubtitle: "Fill in the form below to confirm. Cash on delivery.",
          checkoutBtnText: "Confirm Order",
          customShipping: false,
          shippingCost: 80,
          showEmail: false,
          showCity: true,
          guaranteeText: "Quality guaranteed · Cash on delivery",
          successMessage: "Thank you! Your order has been received — we'll call you shortly to confirm.",
          metaTitle: "Demo Landing Page",
          metaDescription: "A demo landing page built on the default template. Edit it from your dashboard.",
          contactMode: "inherit",
          primaryColor: "#0f5931",
        },
      });
    }

    return {
      adminEmail: admin.email!,
      adminPassword: password,
      adminUserId: admin.id,
    };
  } finally {
    await prisma.$disconnect();
  }
}

// CLI entry: `npx tsx prisma/tenant/seed.ts <dbUrl> <ownerEmail> [storeName]`
if (require.main === module) {
  const [dbUrl, ownerEmail, storeName] = process.argv.slice(2);
  if (!dbUrl || !ownerEmail) {
    console.error("Usage: tsx prisma/tenant/seed.ts <DB_URL> <OWNER_EMAIL> [STORE_NAME]");
    process.exit(1);
  }
  seedTenantDb(dbUrl, { ownerEmail, storeName })
    .then((r) => {
      console.log("✓ Seeded.");
      console.log(`  admin email:    ${r.adminEmail}`);
      console.log(`  admin password: ${r.adminPassword}`);
      console.log(`  user id:        ${r.adminUserId}`);
    })
    .catch((e) => {
      console.error(e);
      process.exit(1);
    });
}
