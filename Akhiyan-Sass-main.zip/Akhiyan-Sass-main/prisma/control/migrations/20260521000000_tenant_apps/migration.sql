CREATE TABLE "tenant_apps" (
  "id" SERIAL NOT NULL,
  "tenant_id" INTEGER NOT NULL,
  "app_name" TEXT NOT NULL,
  "package_id" TEXT NOT NULL,
  "logo_url" TEXT,
  "primary_color" TEXT,
  "api_base_url" TEXT NOT NULL,
  "build_status" TEXT NOT NULL DEFAULT 'not_started',
  "latest_build_url" TEXT,
  "last_build_error" TEXT,
  "requested_at" TIMESTAMP(3),
  "built_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,

  CONSTRAINT "tenant_apps_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "tenant_apps_tenant_id_key" ON "tenant_apps"("tenant_id");
CREATE UNIQUE INDEX "tenant_apps_package_id_key" ON "tenant_apps"("package_id");
CREATE INDEX "tenant_apps_tenant_id_idx" ON "tenant_apps"("tenant_id");
CREATE INDEX "tenant_apps_build_status_idx" ON "tenant_apps"("build_status");

ALTER TABLE "tenant_apps"
  ADD CONSTRAINT "tenant_apps_tenant_id_fkey"
  FOREIGN KEY ("tenant_id") REFERENCES "tenants"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

