-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateTable
CREATE TABLE "public"."audit_logs" (
    "id" SERIAL NOT NULL,
    "super_admin_id" INTEGER,
    "tenant_id" INTEGER,
    "action" TEXT NOT NULL,
    "details" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."plans" (
    "id" SERIAL NOT NULL,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "features" JSONB NOT NULL DEFAULT '{}',
    "limits" JSONB NOT NULL DEFAULT '{}',
    "priceMonthly" INTEGER,
    "priceYearly" INTEGER,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "plans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."super_admins" (
    "id" SERIAL NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "super_admins_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."tenants" (
    "id" SERIAL NOT NULL,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'provisioning',
    "dbName" TEXT NOT NULL,
    "dbUrl" TEXT NOT NULL,
    "primaryDomain" TEXT,
    "ownerEmail" TEXT NOT NULL,
    "plan" TEXT NOT NULL DEFAULT 'starter',
    "initial_admin_email" TEXT,
    "initial_admin_password" TEXT,
    "r2_bucket" TEXT,
    "r2_public_url" TEXT,
    "features" JSONB,
    "limits" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "suspended_at" TIMESTAMP(3),
    "validity_plan" TEXT,
    "expires_at" TIMESTAMP(3),
    "warning_sent_at" TIMESTAMP(3),

    CONSTRAINT "tenants_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "audit_logs_created_at_idx" ON "public"."audit_logs"("created_at" ASC);

-- CreateIndex
CREATE INDEX "audit_logs_super_admin_id_idx" ON "public"."audit_logs"("super_admin_id" ASC);

-- CreateIndex
CREATE INDEX "audit_logs_tenant_id_idx" ON "public"."audit_logs"("tenant_id" ASC);

-- CreateIndex
CREATE INDEX "plans_isActive_idx" ON "public"."plans"("isActive" ASC);

-- CreateIndex
CREATE INDEX "plans_slug_idx" ON "public"."plans"("slug" ASC);

-- CreateIndex
CREATE UNIQUE INDEX "plans_slug_key" ON "public"."plans"("slug" ASC);

-- CreateIndex
CREATE UNIQUE INDEX "super_admins_email_key" ON "public"."super_admins"("email" ASC);

-- CreateIndex
CREATE UNIQUE INDEX "tenants_dbName_key" ON "public"."tenants"("dbName" ASC);

-- CreateIndex
CREATE INDEX "tenants_expires_at_status_idx" ON "public"."tenants"("expires_at" ASC, "status" ASC);

-- CreateIndex
CREATE INDEX "tenants_primaryDomain_idx" ON "public"."tenants"("primaryDomain" ASC);

-- CreateIndex
CREATE UNIQUE INDEX "tenants_primaryDomain_key" ON "public"."tenants"("primaryDomain" ASC);

-- CreateIndex
CREATE INDEX "tenants_slug_idx" ON "public"."tenants"("slug" ASC);

-- CreateIndex
CREATE UNIQUE INDEX "tenants_slug_key" ON "public"."tenants"("slug" ASC);

-- CreateIndex
CREATE INDEX "tenants_status_idx" ON "public"."tenants"("status" ASC);

-- AddForeignKey
ALTER TABLE "public"."audit_logs" ADD CONSTRAINT "audit_logs_super_admin_id_fkey" FOREIGN KEY ("super_admin_id") REFERENCES "public"."super_admins"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."audit_logs" ADD CONSTRAINT "audit_logs_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

