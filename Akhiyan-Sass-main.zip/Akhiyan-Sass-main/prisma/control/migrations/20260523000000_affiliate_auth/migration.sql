-- Idempotent variant — uses IF NOT EXISTS and a DO block for the FK so a
-- partial replay (e.g. previous container died mid-migration leaving the
-- table created but the `_prisma_migrations` row missing) doesn't crash
-- the new container into a restart loop. Postgres 9.6+ supports IF NOT
-- EXISTS on tables/columns/indexes; FK constraints don't, so we guard
-- that with a pg_constraint lookup.

-- AlterTable: affiliate login password (bcrypt hash, nullable)
ALTER TABLE "affiliates" ADD COLUMN IF NOT EXISTS "password" TEXT;

-- CreateTable: affiliate_clicks
CREATE TABLE IF NOT EXISTS "affiliate_clicks" (
    "id"           SERIAL NOT NULL,
    "affiliate_id" INTEGER NOT NULL,
    "referer"      TEXT,
    "ip_hash"      TEXT,
    "created_at"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "affiliate_clicks_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX IF NOT EXISTS "affiliate_clicks_affiliate_id_idx" ON "affiliate_clicks"("affiliate_id");
CREATE INDEX IF NOT EXISTS "affiliate_clicks_created_at_idx"   ON "affiliate_clicks"("created_at");

-- AddForeignKey (idempotent via pg_constraint check)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'affiliate_clicks_affiliate_id_fkey'
    ) THEN
        ALTER TABLE "affiliate_clicks"
            ADD CONSTRAINT "affiliate_clicks_affiliate_id_fkey"
            FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id")
            ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
END $$;
