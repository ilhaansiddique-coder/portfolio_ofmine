-- CreateTable: affiliates
CREATE TABLE "affiliates" (
    "id"             SERIAL NOT NULL,
    "tenant_id"      INTEGER,
    "email"          TEXT NOT NULL,
    "name"           TEXT NOT NULL,
    "code"           TEXT NOT NULL,
    "commission_rate" DOUBLE PRECISION NOT NULL DEFAULT 0.20,
    "status"         TEXT NOT NULL DEFAULT 'active',
    "bkash_phone"    TEXT,
    "paypal_email"   TEXT,
    "total_earned"   DOUBLE PRECISION NOT NULL DEFAULT 0,
    "total_paid"     DOUBLE PRECISION NOT NULL DEFAULT 0,
    "dashboard_token" TEXT NOT NULL,
    "created_at"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at"     TIMESTAMP(3) NOT NULL,

    CONSTRAINT "affiliates_pkey" PRIMARY KEY ("id")
);

-- CreateTable: affiliate_referrals
CREATE TABLE "affiliate_referrals" (
    "id"           SERIAL NOT NULL,
    "affiliate_id" INTEGER NOT NULL,
    "tenant_id"    INTEGER NOT NULL,
    "plan"         TEXT NOT NULL DEFAULT 'starter',
    "created_at"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "affiliate_referrals_pkey" PRIMARY KEY ("id")
);

-- CreateTable: affiliate_commissions
CREATE TABLE "affiliate_commissions" (
    "id"           SERIAL NOT NULL,
    "affiliate_id" INTEGER NOT NULL,
    "referral_id"  INTEGER NOT NULL,
    "amount"       DOUBLE PRECISION NOT NULL,
    "status"       TEXT NOT NULL DEFAULT 'pending',
    "event"        TEXT NOT NULL DEFAULT 'signup',
    "note"         TEXT,
    "approved_at"  TIMESTAMP(3),
    "paid_at"      TIMESTAMP(3),
    "created_at"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at"   TIMESTAMP(3) NOT NULL,

    CONSTRAINT "affiliate_commissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable: affiliate_payouts
CREATE TABLE "affiliate_payouts" (
    "id"           SERIAL NOT NULL,
    "affiliate_id" INTEGER NOT NULL,
    "amount"       DOUBLE PRECISION NOT NULL,
    "method"       TEXT NOT NULL,
    "destination"  TEXT NOT NULL,
    "status"       TEXT NOT NULL DEFAULT 'pending',
    "tx_ref"       TEXT,
    "note"         TEXT,
    "processed_at" TIMESTAMP(3),
    "created_at"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at"   TIMESTAMP(3) NOT NULL,

    CONSTRAINT "affiliate_payouts_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "affiliates_tenant_id_key"      ON "affiliates"("tenant_id");
CREATE UNIQUE INDEX "affiliates_email_key"           ON "affiliates"("email");
CREATE UNIQUE INDEX "affiliates_code_key"            ON "affiliates"("code");
CREATE UNIQUE INDEX "affiliates_dashboard_token_key" ON "affiliates"("dashboard_token");
CREATE INDEX        "affiliates_code_idx"            ON "affiliates"("code");
CREATE INDEX        "affiliates_status_idx"          ON "affiliates"("status");

CREATE UNIQUE INDEX "affiliate_referrals_tenant_id_key" ON "affiliate_referrals"("tenant_id");
CREATE INDEX        "affiliate_referrals_affiliate_id_idx" ON "affiliate_referrals"("affiliate_id");

CREATE INDEX "affiliate_commissions_affiliate_id_idx" ON "affiliate_commissions"("affiliate_id");
CREATE INDEX "affiliate_commissions_status_idx"       ON "affiliate_commissions"("status");

CREATE INDEX "affiliate_payouts_affiliate_id_idx" ON "affiliate_payouts"("affiliate_id");
CREATE INDEX "affiliate_payouts_status_idx"        ON "affiliate_payouts"("status");

-- AddForeignKey
ALTER TABLE "affiliates"
    ADD CONSTRAINT "affiliates_tenant_id_fkey"
    FOREIGN KEY ("tenant_id") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "affiliate_referrals"
    ADD CONSTRAINT "affiliate_referrals_affiliate_id_fkey"
    FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "affiliate_commissions"
    ADD CONSTRAINT "affiliate_commissions_affiliate_id_fkey"
    FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "affiliate_payouts"
    ADD CONSTRAINT "affiliate_payouts_affiliate_id_fkey"
    FOREIGN KEY ("affiliate_id") REFERENCES "affiliates"("id") ON DELETE CASCADE ON UPDATE CASCADE;
