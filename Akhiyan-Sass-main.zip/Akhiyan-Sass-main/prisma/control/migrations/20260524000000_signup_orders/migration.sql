-- CreateTable: signup_orders
CREATE TABLE "signup_orders" (
    "id"          SERIAL NOT NULL,
    "store_name"  TEXT NOT NULL,
    "slug"        TEXT NOT NULL,
    "owner_name"  TEXT,
    "owner_email" TEXT NOT NULL,
    "phone"       TEXT,
    "plan"        TEXT NOT NULL DEFAULT 'starter',
    "aff_code"    TEXT,
    "status"      TEXT NOT NULL DEFAULT 'pending',
    "tenant_id"   INTEGER,
    "note"        TEXT,
    "created_at"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at"  TIMESTAMP(3) NOT NULL,

    CONSTRAINT "signup_orders_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "signup_orders_status_idx"   ON "signup_orders"("status");
CREATE INDEX "signup_orders_aff_code_idx" ON "signup_orders"("aff_code");
