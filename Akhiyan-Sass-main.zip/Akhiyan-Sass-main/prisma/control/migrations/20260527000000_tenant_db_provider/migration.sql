-- Adds a per-tenant database provider field so super admin can choose
-- where new tenant DBs are provisioned ("neon" = serverless cloud,
-- "coolify" = self-hosted Postgres on our own Coolify server).
--
-- Idempotent guards (IF NOT EXISTS) so a partial-failure replay on
-- container restart doesn't crash the migrator.
ALTER TABLE "tenants" ADD COLUMN IF NOT EXISTS "db_provider" TEXT NOT NULL DEFAULT 'neon';
