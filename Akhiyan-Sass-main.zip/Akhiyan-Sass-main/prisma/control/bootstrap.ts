/**
 * Control-plane bootstrap script.
 *
 * Seeds the control DB with:
 *  - One super admin (email from SUPER_ADMIN_EMAIL env or admin@<BASE_DOMAIN>, password: admin123 — change after first login)
 *  - The first tenant row pointing at DATABASE_URL from .env
 *
 * Run with:  npx tsx prisma/control/bootstrap.ts
 *
 * Idempotent — safe to re-run; uses upsert.
 */
import { PrismaClient } from "../../src/generated/prisma-control";
import bcrypt from "bcryptjs";

const controlPrisma = new PrismaClient({
  datasourceUrl: process.env.CONTROL_DATABASE_URL,
});

async function main() {
  const adminEmail = process.env.SUPER_ADMIN_EMAIL || `admin@${process.env.BASE_DOMAIN || "example.com"}`;
  const adminPassword = "admin123"; // dev-only; change after login

  // 1. Super admin
  const superAdmin = await controlPrisma.superAdmin.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      password: await bcrypt.hash(adminPassword, 10),
      name: "CD Ecom Super Admin",
    },
  });
  console.log(`✓ Super admin: ${superAdmin.email} (id ${superAdmin.id})`);

  // 2. First tenant — points at the existing DATABASE_URL (the dev tenant DB)
  const tenantDbUrl = process.env.DATABASE_URL;
  if (!tenantDbUrl) throw new Error("DATABASE_URL not set in .env");

  const tenant = await controlPrisma.tenant.upsert({
    where: { slug: "default" },
    update: { status: "active", dbUrl: tenantDbUrl },
    create: {
      slug: "default",
      name: "Default Test Store",
      status: "active",
      dbName: "cd_ecom_tenant_001",
      dbUrl: tenantDbUrl,
      primaryDomain: null,
      ownerEmail: adminEmail,
      plan: "starter",
    },
  });
  console.log(`✓ Tenant: ${tenant.slug} (id ${tenant.id}) — ${tenant.dbName}`);

  console.log("\nBootstrap complete.");
  console.log(`Login: ${adminEmail} / ${adminPassword}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => controlPrisma.$disconnect());
