import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),

  // ─────────────────────────────────────────────────────────────────────────
  // Storefront theme isolation.
  //
  // Themes under `src/themes/<id>/` are sealed bundles. They may import ONLY
  // from:
  //   - `@/storefront-engine/**` — the shared engine contract (types, data
  //     loaders, ErrorBoundary, locked sections, primitives)
  //   - `@/data/**`              — shared data-shape types (Product, etc.)
  //   - relative imports inside their own theme folder
  //   - node_modules (react, next, react-icons, etc.)
  //
  // Themes may NOT import from:
  //   - `@/themes/<other>/**`    — cross-theme coupling forbidden
  //   - `@/components/**`        — UI components belong to the legacy default
  //                                 theme; new themes must own their UI
  //   - `@/lib/prisma*`          — DB access goes through engine data loaders
  //   - `@/app/**`               — routes are app concerns, not theme
  //
  // The `default` theme is GRANDFATHERED — it composes the existing
  // `@/components/*` section components (Hero, FlashSale, AllProducts, ...).
  // Relocating those into `themes/default/components/` would require touching
  // ~40 unrelated call sites for zero functional benefit. New themes get the
  // strict rule; default keeps the looser baseline.
  // ─────────────────────────────────────────────────────────────────────────
  {
    files: ["src/themes/**/*.{ts,tsx}"],
    ignores: ["src/themes/default/**"],
    rules: {
      "no-restricted-imports": ["error", {
        patterns: [
          { group: ["@/themes/*"], message: "Theme cannot import from other themes. Each theme bundle must be self-contained." },
          { group: ["@/components/*"], message: "Theme cannot import @/components/*. Build the component inside `src/themes/<id>/components/` instead." },
          { group: ["@/lib/prisma*", "@/lib/prisma-tenant*"], message: "Theme cannot access Prisma directly. Use the typed data loader passed via page props." },
          { group: ["@/app/*"], message: "Theme cannot import from @/app/*." },
        ],
      }],
    },
  },
]);

export default eslintConfig;
