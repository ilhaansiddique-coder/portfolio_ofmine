# International Ecommerce Feature Tracker

Living checklist for everything an international ecommerce SaaS needs.
Update statuses as features ship. Sorted by priority within each
section.

**Status legend:**
- ✅ **Done** — shipped + tested
- 🟡 **Partial** — exists but incomplete / per-tenant gaps
- 🔴 **Missing** — not built
- ⏸ **Deferred** — planned for post-launch

---

## 1. Payments

| Feature | Status | Notes |
|---|---|---|
| Cash on delivery (COD) | ✅ | Default; works tenant-wide |
| bKash | ✅ | BD market |
| Nagad | ✅ | BD market |
| Stripe Checkout | 🔴 | **Required for international launch** |
| Stripe Customer Portal | 🔴 | Self-serve subscription mgmt |
| Stripe Billing (subscriptions) | 🔴 | For SaaS plan billing AND recurring product orders |
| Stripe Tax | 🔴 | Auto VAT/GST per country |
| PayPal | 🔴 | 400M+ users, required EU/UK/US |
| Apple Pay | 🔴 | Via Stripe one-tap |
| Google Pay | 🔴 | Via Stripe one-tap |
| Shop Pay | 🔴 | Shopify network express checkout |
| Saved payment methods (tokenized) | 🔴 | Stripe handles |
| 3DS strong customer auth | 🔴 | Required EU (PSD2) |
| Multi-currency display | 🔴 | Show prices in shopper currency |
| Multi-currency checkout | 🔴 | Charge in shopper currency |
| Live FX rates | 🔴 | openexchangerates.org / ECB |
| Klarna / Afterpay / Affirm | ⏸ | Post-launch BNPL |
| Crypto (Coinbase Commerce) | ⏸ | Optional |
| Razorpay | ⏸ | India market expansion |
| Mercado Pago | ⏸ | LATAM expansion |
| Paystack | ⏸ | Africa expansion |
| Refunds via gateway API | 🔴 | Currently manual |
| Partial refunds | 🔴 | Per line-item |

---

## 2. Tax & Legal Compliance

| Feature | Status | Notes |
|---|---|---|
| Privacy policy page | ✅ | Bilingual, editable |
| Terms of service page | ✅ | Bilingual, editable |
| Refund policy page | ✅ | Bilingual, editable |
| Cookie consent banner | 🟡 | Component exists, no geo-trigger |
| GDPR data export endpoint | 🔴 | `/api/v1/dashboard/data-export` |
| GDPR data erasure endpoint | 🔴 | `/api/v1/dashboard/data-erase` |
| CCPA "Do Not Sell" toggle | 🔴 | US-CA requirement |
| Right-to-be-forgotten cascade | 🔴 | Delete user + anonymise orders |
| VAT validation (EU VIES) | 🔴 | B2B sales exempt VAT |
| Tax-inclusive pricing display | 🔴 | UK/EU shows inc-VAT |
| Tax-exclusive pricing display | 🔴 | US/CA shows ex-tax |
| Tax invoice (with VAT breakdown) | 🔴 | Currently invoice has no tax |
| HS codes on products | 🔴 | For customs |
| EORI numbers for tenants | 🔴 | Cross-border EU shipping |
| Age verification gate | 🔴 | Alcohol/cosmetics in EU |
| DPA (Data Processing Agreement) template | 🔴 | For tenant signups |
| Plaintext admin password | 🟡 | Stored in control DB — replace w/ one-time reset link |

---

## 3. Catalog

| Feature | Status | Notes |
|---|---|---|
| Products | ✅ | |
| Categories | ✅ | |
| Brands | ✅ | |
| Tags | ✅ | |
| Variants (size/color) | ✅ | |
| Variant images per option | ✅ | |
| Stock tracking | ✅ | |
| Unlimited stock flag | ✅ | |
| Multiple images per product | ✅ | |
| Bilingual product fields (en/bn) | ✅ | |
| Product video | ✅ | |
| Custom shipping per product | ✅ | |
| Sort order | ✅ | |
| SEO meta per product | 🟡 | Title/desc only; missing OG/Twitter override |
| Schema.org JSON-LD on PDP | 🔴 | Product/Review structured data |
| Flash sales | ✅ | Timer + sale price |
| Coupons | ✅ | Code-based |
| Bundles / kits | 🔴 | "Buy 3 get 1" combos |
| Cross-sell on PDP | 🔴 | "Frequently bought together" |
| Upsell at checkout | 🔴 | Higher-tier swap |
| Recently viewed carousel | 🔴 | |
| Pre-order / backorder | 🔴 | Accept orders OOS |
| Gift cards | 🔴 | Issue + redeem |
| Subscription products | 🔴 | Recurring delivery via Stripe Billing |
| Bulk pricing tiers (B2B) | 🔴 | Wholesale discount by quantity |
| Multi-warehouse inventory | 🔴 | Stock by location |
| Product CSV import/export | 🔴 | Bulk catalog ops |
| Bulk product edit | 🔴 | Multi-select actions |
| Variant matrix view | 🔴 | Size × color grid |

---

## 4. Cart & Checkout

| Feature | Status | Notes |
|---|---|---|
| Add to cart / quantity / remove | ✅ | |
| Cart persists across sessions | ✅ | localStorage + auth-sync |
| Guest checkout | ✅ | |
| Coupons at checkout | ✅ | |
| Shipping zones | ✅ | City-based flat rate |
| Payment method selector | ✅ | COD / bKash / Nagad |
| Order notes field | ✅ | |
| Incomplete-order capture | ✅ | Server-side via /api/v1/incomplete-orders |
| ZIP / postal code field | ✅ | Optional |
| Honeypot anti-bot | ✅ | |
| Behavioral fingerprint | ✅ | |
| Address autocomplete | 🔴 | Google Places — cuts ~30% failed deliveries |
| Real-time shipping rates | 🔴 | Live quotes from carriers |
| Express checkout (Apple/Google Pay) | 🔴 | One-tap |
| Saved addresses | ✅ | |
| Free shipping threshold meter | 🔴 | "$20 to free shipping" UI |
| Cart abandonment email | 🔴 | Automated 1h/24h/72h sequence |
| Discount stacking rules | 🔴 | Coupon + tier + flash sale ordering |
| Multi-step checkout option | 🔴 | Mobile-friendly steps |
| One-click reorder | 🔴 | From past orders |
| Buy-later / save for later | 🔴 | |
| Order modification window | 🔴 | Edit address/items within Xh of order |

---

## 5. Orders & Fulfillment

| Feature | Status | Notes |
|---|---|---|
| Order creation | ✅ | |
| Order status workflow | ✅ | pending / confirmed / shipped / delivered / cancelled |
| Order tracking by token | ✅ | Public link |
| Invoice PDF generation | ✅ | |
| Invoice print | ✅ | |
| Pathao courier integration | ✅ | |
| Steadfast courier integration | ✅ | |
| Pathao parsing + city extract | ✅ | |
| Per-tenant courier config | ✅ | |
| Multi-courier per tenant | ✅ | |
| Customer history per phone | ✅ | Pathao API |
| Fraud score | ✅ | Per order |
| Shippo / EasyPost / Shipstation | 🔴 | Global 70+ carriers (UPS/FedEx/DHL/USPS/Royal Mail) |
| Multi-warehouse fulfillment | 🔴 | Split shipments |
| Customs declarations CN22/CN23 | 🔴 | International parcels |
| Tracking webhooks (auto status) | 🔴 | Currently manual mark-shipped |
| Self-serve returns portal | 🔴 | RMA + label + refund |
| Partial fulfillment | 🔴 | Ship some lines now, rest later |
| Order edit after place | 🔴 | Swap variant, change qty, refund partial |
| Bulk order export CSV | 🔴 | For accounting |
| Order tags / labels | 🔴 | Internal segmentation |

---

## 6. Customer Accounts

| Feature | Status | Notes |
|---|---|---|
| Register | ✅ | Email + phone |
| Login | ✅ | |
| Forgot password | ✅ | Email reset code |
| Reset password | ✅ | |
| Saved addresses | ✅ | |
| Order history | ✅ | |
| Wishlist | ✅ | |
| Reviews submission | ✅ | |
| Profile edit | ✅ | |
| Bilingual UI (en/bn) | ✅ | |
| Multi-language (es/fr/ar/hi…) | 🔴 | Beyond en/bn |
| Right-to-left CSS scope | 🔴 | Arabic/Hebrew layout |
| Google OAuth | 🔴 | Social login |
| Apple OAuth | 🔴 | Required iOS |
| Facebook OAuth | 🔴 | |
| Magic link login | 🔴 | Passwordless |
| 2FA / TOTP | 🔴 | Customer security |
| Saved payment methods | 🔴 | Stripe handles |
| Subscription management | 🔴 | Pause/cancel/skip |
| Account dashboard reorders | 🟡 | List exists, no one-click reorder |
| Downloadable products | 🔴 | Digital goods license keys |
| Loyalty points balance | 🔴 | Earn + redeem |
| Store credit balance | 🔴 | From returns |
| Referral link / code (customer) | 🔴 | C2C; affiliate exists for partners |

---

## 7. Reviews & Social Proof

| Feature | Status | Notes |
|---|---|---|
| Star rating submission | ✅ | |
| Text review | ✅ | |
| Admin approval workflow | ✅ | |
| Verified purchase badge | 🔴 | Auto-flag from order history |
| Photo reviews | 🔴 | Upload up to N images |
| Video reviews | 🔴 | |
| Review request email (post-delivery) | 🔴 | Automated |
| Q&A on PDP | 🔴 | Public questions + store answers |
| Helpful / Not helpful voting | 🔴 | |
| Review filtering (rating / verified / with-photo) | 🔴 | |
| Aggregated rating in schema.org | 🔴 | |

---

## 8. Marketing & Engagement

| Feature | Status | Notes |
|---|---|---|
| FB Pixel (browser + CAPI) | ✅ | Full event coverage |
| GA4 dataLayer push | ✅ | GTM-ready |
| Microsoft Clarity | ✅ | Session replay |
| Google Tag Manager | 🟡 | dataLayer fires, no admin GTM-ID input field |
| TikTok Pixel | 🔴 | |
| Pinterest tag | 🔴 | |
| Snapchat pixel | 🔴 | |
| LinkedIn insights tag | 🔴 | B2B |
| Email transactional (SMTP) | 🟡 | Works; switch to Resend/Postmark for deliverability |
| SPF / DKIM / DMARC docs | 🔴 | Sender domain auth |
| Email marketing platform connector | 🔴 | Klaviyo / Customer.io / Mailchimp |
| Newsletter signup form | 🔴 | Storefront component |
| Welcome series automation | 🔴 | Day 0 / 3 / 7 |
| Cart abandonment automation | 🔴 | 1h / 24h / 72h |
| Win-back automation | 🔴 | 30/60/90 days inactive |
| Post-purchase upsell email | 🔴 | |
| Browse abandonment | 🔴 | Viewed product, no add |
| SMS marketing (Twilio / MessageBird) | 🔴 | |
| Push notifications (web) | 🟡 | FCM in repo, no admin UI |
| Push notifications (mobile) | 🟡 | FCM + RN app partial |
| WhatsApp Business catalog | 🔴 | |
| Loyalty program | 🔴 | Points / tiers |
| Referral program (customer-to-customer) | 🔴 | Affiliate exists for partners |
| Gift cards | 🔴 | |
| Personalised product recommendations | 🔴 | Collaborative filter / embeddings |
| A/B testing framework | 🔴 | GrowthBook / PostHog flags |
| Feature flags (per-tenant) | ✅ | tenant_features system |
| Affiliate program (partners) | ✅ | Full: signup, dashboard, commissions, payouts, click tracking |

---

## 9. SEO & Discovery

| Feature | Status | Notes |
|---|---|---|
| Sitemap.xml | ✅ | |
| Robots.txt | ✅ | |
| Per-page title + meta description | ✅ | |
| OG tags (per page) | 🟡 | Partial; blog posts have full |
| Twitter card meta | 🟡 | Same as OG |
| Canonical URL on every page | 🔴 | |
| Hreflang tags (multi-lang) | 🔴 | |
| Schema.org Organization | 🔴 | |
| Schema.org Product | 🔴 | |
| Schema.org Review | 🔴 | |
| Schema.org Article (blog) | 🔴 | |
| Schema.org Breadcrumb | 🔴 | |
| 301 redirect on slug change | 🔴 | Preserve SEO |
| 404 page (custom per theme) | 🟡 | Default Next 404 |
| URL slug history table | 🔴 | For redirects |
| Google Merchant feed (xml + csv) | ✅ | |
| Facebook product feed | ✅ | |
| TikTok product feed | ✅ | |
| Pinterest product feed | 🔴 | |
| Snapchat product feed | 🔴 | |
| Image alt text auto-fill | 🔴 | From product name as default |
| Internal search analytics | 🔴 | Track empty-result queries |

---

## 10. Search & Discovery

| Feature | Status | Notes |
|---|---|---|
| Product search (name + category) | ✅ | Basic SQL ILIKE |
| Search results page | ✅ | |
| Category filters (sidebar) | ✅ | Per-theme |
| Sort options (price/name/newest) | ✅ | |
| Faceted filters (color/size/brand) | 🔴 | |
| Price range slider | 🔴 | |
| Autocomplete / typeahead | 🔴 | |
| Fuzzy / typo-tolerant search | 🔴 | Algolia / Typesense |
| Search synonyms (admin manageable) | 🔴 | |
| Trending searches | 🔴 | |
| Recently searched | 🔴 | |
| Did-you-mean suggestions | 🔴 | |
| Visual / image search | ⏸ | Premium feature |
| Voice search | ⏸ | |

---

## 11. Admin & Operations

| Feature | Status | Notes |
|---|---|---|
| Multi-tenant DB-per-tenant | ✅ | Coolify Postgres + Neon options |
| Super-admin dashboard | ✅ | Tenant + plan + signup mgmt |
| Tenant admin dashboard | ✅ | |
| Per-page role permissions (staff) | ✅ | api-route-features |
| Tenant features toggle (super-admin) | ✅ | |
| Dashboard customizer | ✅ | |
| Storefront theme picker | ✅ | 3 themes live |
| Page builder (Puck) | ✅ | Custom pages + LPs |
| AI brief + site setup | ✅ | |
| Realtime via Soketi | ✅ | New orders / dashboard updates |
| Audit log | ✅ | superadmin actions |
| Spam fraud trace | ✅ | Blocked IPs, phones, devices |
| Inventory low-stock email alert | 🔴 | |
| Supplier / PO management | 🔴 | Inbound stock tracking |
| Purchase orders | 🔴 | |
| Stock adjustment log | 🔴 | Who/when/why |
| Bulk product image upload | 🔴 | Auto-WebP/AVIF |
| Image CDN w/ on-the-fly resize | 🟡 | Cloudflare R2 + custom CDN Worker exists; on-the-fly resize missing |
| Custom reports / analytics | 🔴 | Sales by region/channel/product |
| Cohort retention chart | 🔴 | |
| LTV per acquisition source | 🔴 | |
| Conversion funnel report | 🔴 | View → cart → checkout → paid |
| Multi-store per tenant | 🔴 | |
| Webhook system (out-bound) | 🔴 | Tenants subscribe to order events |
| API tokens (REST API for tenants) | 🔴 | Public dev API |
| Backup verification (auto restore drill) | 🔴 | |
| DR runbook | 🔴 | |

---

## 12. Mobile

| Feature | Status | Notes |
|---|---|---|
| Responsive storefront themes | ✅ | All 3 themes |
| PWA install prompt | ✅ | |
| PWA manifest | ✅ | |
| Service worker | ✅ | |
| Offline mode | 🟡 | Service worker exists, no offline page |
| Mobile dashboard | ✅ | Responsive |
| Native iOS app | 🟡 | React Native scaffold in repo |
| Native Android app | 🟡 | RN scaffold |
| Mobile push notifications (FCM) | 🟡 | Backend exists, no admin UI |
| App store build pipeline | 🔴 | |
| Deep linking | 🔴 | |
| Universal links | 🔴 | |

---

## 13. Infrastructure & Security

| Feature | Status | Notes |
|---|---|---|
| HTTPS everywhere | ✅ | |
| HSTS | ✅ | preload set in next.config |
| X-Frame-Options | ✅ | SAMEORIGIN |
| Content-Security-Policy | 🔴 | Not configured |
| Cloudflare CDN | ✅ | |
| Cloudflare WAF | 🔴 | Rules not configured |
| R2 object storage | ✅ | |
| R2 versioning + lifecycle | 🔴 | |
| Postgres (Neon control + tenant) | ✅ | |
| Self-hosted Postgres (Coolify) | ✅ | Per-tenant DB picker |
| pgbouncer | ✅ | Connection pooling |
| Rate limiter (in-memory) | 🟡 | Breaks under cluster; need Upstash Redis |
| Rate limiter (distributed) | 🔴 | Upstash Redis |
| Background job queue | 🔴 | BullMQ / Inngest / QStash |
| Cron scheduler | 🟡 | Tenant-expiry hourly via Coolify scheduled task |
| Sentry error tracking | ✅ | Self-hosted GlitchTip |
| PostHog product analytics | 🔴 | |
| Plausible privacy analytics | 🔴 | |
| Status page (public) | 🔴 | Better Stack / Instatus |
| Uptime monitoring | 🔴 | |
| Log aggregation (Axiom / Better Stack) | 🔴 | |
| APM / tracing | 🔴 | Sentry traces set to 0 |
| Secrets manager (Doppler / Infisical) | 🔴 | Currently .env in Coolify |
| Dependabot | 🔴 | |
| Snyk / GitHub Advanced Security | 🔴 | |
| CI pipeline (GitHub Actions) | 🔴 | No .github/workflows |
| Pre-merge typecheck + lint | 🔴 | |
| Test suite | 🔴 | No jest/vitest |
| E2E tests (Playwright) | 🔴 | |
| Pentest pre-launch | 🔴 | |
| Load test (k6 / Artillery) | 🔴 | |
| Tenant isolation test (automated) | 🔴 | Prove tenant A can't read tenant B |

---

## 14. Internationalization

| Feature | Status | Notes |
|---|---|---|
| English UI | ✅ | |
| Bangla UI | ✅ | |
| Spanish UI | 🔴 | |
| French UI | 🔴 | |
| Arabic UI (RTL) | 🔴 | |
| Hindi UI | 🔴 | |
| Per-tenant primary language setting | ✅ | site_language |
| Per-customer language preference | 🟡 | LanguageContext, localStorage only |
| Translation management tool | 🔴 | Lokalise / Crowdin / i18next |
| Multi-currency display | 🔴 | |
| Multi-currency checkout | 🔴 | |
| Geo-IP redirect | 🔴 | EU → /eu, US → /us, etc. |
| Country picker in header | 🔴 | |
| Localized date format | 🟡 | Partial; some BD-format hardcodes |
| Localized number format | 🟡 | toBn util exists |
| Per-country tax rates | 🔴 | Stripe Tax handles |
| Per-country shipping zones | 🔴 | Currently per-city BD |
| Country-specific payment methods | 🔴 | iDEAL (NL), SEPA (EU), etc. |
| Phone format validation per country | 🔴 | Currently BD-only regex |

---

## 15. Customer Support

| Feature | Status | Notes |
|---|---|---|
| Contact form | ✅ | |
| Form submissions inbox | ✅ | |
| Live chat | 🔴 | Intercom / Plain / Crisp |
| Help center / knowledge base | 🔴 | Mintlify / Docusaurus |
| Self-serve return portal | 🔴 | |
| Ticketing system | 🔴 | |
| Order status SMS notifications | 🔴 | Twilio |
| Email notifications (order placed/shipped) | 🟡 | Templates exist, deliverability needs Resend |
| FAQ page | ✅ | apex / per-tenant |
| Admin response to reviews | 🔴 | Reply in-thread |

---

## 16. Billing (SaaS — for the platform)

| Feature | Status | Notes |
|---|---|---|
| Plan model (control DB) | ✅ | Plans table + features JSON |
| Plan picker UI | ✅ | /start pricing page |
| Signup flow (public) | ✅ | SignupOrder → manual provision |
| Trial period | 🔴 | No automated trial timer |
| Stripe Checkout for plan signup | 🔴 | Currently manual super-admin |
| Stripe Customer Portal | 🔴 | Tenant self-cancels / upgrades |
| Stripe webhook handlers | 🔴 | invoice.paid / subscription.deleted |
| Dunning (failed payment retry) | 🔴 | |
| Grace period on expiry | 🔴 | |
| Auto-suspend after expiry | 🟡 | Cron exists, no payment-driven flow |
| Invoice PDF (for SaaS tenants) | 🔴 | Stripe sends; need branded copy |
| Usage metering (orders/mo, products, staff) | 🟡 | limits JSON exists; not metered |
| Quota enforcement | 🔴 | Stop tenant when over plan limits |
| Annual discount | 🔴 | |
| Promo codes for plans | 🔴 | |
| Tax handling on plan price | 🔴 | Stripe Tax |
| EU VAT collection on plan price | 🔴 | |
| Tenant payment method update | 🔴 | Customer portal handles |

---

## 17. Advanced / Premium (post-launch)

| Feature | Status | Notes |
|---|---|---|
| Buy-now-pay-later (Klarna/Afterpay) | ⏸ | |
| Crypto payments | ⏸ | |
| Marketplace / multi-vendor | ⏸ | Vendor onboarding + payout split |
| B2B portal | ⏸ | Wholesale pricing, quotes, NET-30 |
| Headless commerce API | ⏸ | For external frontends |
| POS sync (in-store + online inventory) | ⏸ | |
| WhatsApp commerce | ⏸ | Catalog + order via chat |
| Live shopping / video commerce | ⏸ | TikTok Shop style |
| AR product preview | ⏸ | Try-on |
| AI product description generator | ✅ | Already in repo |
| AI image generation | ⏸ | |
| AI search + recs | ⏸ | Embeddings |
| Voice commerce | ⏸ | |

---

## Top 10 priorities for international launch

In order of unblocking power:

1. **Stripe + PayPal** — without these you cannot sell outside BD
2. **Multi-currency display + checkout**
3. **Stripe Tax** for VAT/GST auto-calc
4. **GDPR endpoints** — `/data-export`, `/data-erase`
5. **Shippo (or EasyPost)** for global shipping labels + tracking
6. **Cart abandonment email automation** — biggest revenue lift, low build cost
7. **Address autocomplete** — Google Places, cuts ~30% failed deliveries
8. **Apple/Google Pay** at checkout — checkout conversion
9. **Self-serve returns portal** — required for EU/UK by law
10. **Multi-language beyond en/bn** + **RTL CSS** scope

After 1-10, you can credibly onboard tenants serving US / EU / UK / AU / MEA markets.

---

## How to use this file

- Tick `🔴 → 🟡 → ✅` as work progresses
- Add notes column when a feature has partial coverage or known limitations
- Move items between sections if they fit better elsewhere
- Add new rows below existing for any feature not listed here yet
- Reference this in PR descriptions: "Closes section 1 row 4"
