#!/bin/bash

###############################################################################
# Production deployment script — HOSTINGER (PM2) target only.
#
# Coolify deploys go through the Dockerfile + docker-entrypoint.sh path —
# NOT this script. This guard prevents accidental PM2 calls from a CI
# runner that thinks it's pushing to Coolify.
#
# Override the guard explicitly when you do mean to run on Hostinger:
#   DEPLOY_TARGET=hostinger ./deploy.sh
#
# Usage: DEPLOY_TARGET=hostinger ./deploy.sh
#
# Steps, in the order that won't break tenants:
#   1. Pull latest code
#   2. Install dependencies
#   3. Generate BOTH prisma clients (control + tenant)
#   4. Migrate the CONTROL DB (superadmin / tenants tables)
#   5. Migrate EVERY active tenant DB (uses scripts/migrate-all-tenants.ts —
#      advisory-locked, transactional, idempotent)
#   6. Build the Next.js bundle
#   7. Reload PM2 (zero-downtime cluster reload, not restart)
#   8. Health-check at least one known tenant route post-deploy
#
# Order matters: schema migrations run BEFORE the new code starts handling
# traffic. If migration step fails, the script exits non-zero and the old
# process keeps serving — no half-broken tenants.
#
# If a migration partially fails (e.g. tenant 7 of 12 hits an error) the
# runner reports per-tenant status and exits non-zero. Re-run after fixing
# the offending tenant; completed migrations are skipped automatically.
###############################################################################

# Hostinger-only guard. Coolify builds the image via Dockerfile and runs
# docker-entrypoint.sh — it never calls deploy.sh. If you're seeing this
# error in CI, you've pointed the wrong deploy target at this script.
if [[ "${DEPLOY_TARGET:-}" != "hostinger" ]]; then
  echo "✗ deploy.sh is the Hostinger (PM2) deploy path." >&2
  echo "  Coolify builds via Dockerfile; nothing to do here." >&2
  echo "  Run with DEPLOY_TARGET=hostinger ./deploy.sh to force." >&2
  exit 1
fi


set -euo pipefail
IFS=$'\n\t'

# ── Output helpers ───────────────────────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

step()    { echo -e "${YELLOW}▶ $1${NC}"; }
ok()      { echo -e "${GREEN}✓ $1${NC}"; }
fail()    { echo -e "${RED}✗ $1${NC}" >&2; exit 1; }

# Health-check target — override per environment.
# Defaults to the public superadmin login page (always available, no auth).
HEALTH_URL="${HEALTH_URL:-https://cdeadmin.contradigital.agency/superadmin/login}"
PM2_APP_NAME="${PM2_APP_NAME:-cd-ecom}"

echo -e "${GREEN}🚀 Starting production deployment${NC}"
echo "    Health URL : $HEALTH_URL"
echo "    PM2 app    : $PM2_APP_NAME"
echo

# ── 1. Code ─────────────────────────────────────────────────────────────────
step "Pulling latest code"
git pull --ff-only origin main || fail "git pull failed (uncommitted changes? non-fast-forward?)"
ok "code up to date"

# ── 2. Dependencies ─────────────────────────────────────────────────────────
step "Installing dependencies"
npm ci --include=dev || fail "npm ci failed"
ok "dependencies installed"

# ── 3. Prisma clients ───────────────────────────────────────────────────────
# Both schemas must regen — code references both `@prisma/client` (tenant)
# and `@/generated/prisma-control` (control plane).
step "Generating Prisma clients (tenant + control)"
npm run db:generate || fail "prisma generate failed"
ok "prisma clients generated"

# ── 4. Control DB migration ─────────────────────────────────────────────────
# Migrates the superadmin DB (tenants, super_admins, audit_log, plans).
# Runs `prisma migrate deploy --schema prisma/control/schema.prisma`.
step "Migrating control DB"
npm run db:migrate:control || fail "control DB migration failed"
ok "control DB migrated"

# ── 5. All tenant DBs ───────────────────────────────────────────────────────
# Per-tenant advisory lock, per-tenant transaction with rollback on fail,
# continues past failures, exits non-zero so we catch problems here. New
# tenant DBs created AFTER this step run their migrations automatically on
# provisioning, so brand-new tenants are unaffected by deploy timing.
step "Migrating tenant DBs (parallel, advisory-locked)"
npm run db:migrate-all || fail "one or more tenant migrations failed — see output above"
ok "all tenants migrated"

# ── 6. Build ────────────────────────────────────────────────────────────────
# Build happens AFTER migrations because the new code may reference new
# columns. If migrations failed, we never reach this step and the old
# build keeps serving.
step "Building Next.js bundle"
node --max-old-space-size=6144 ./node_modules/next/dist/bin/next build || fail "next build failed"
ok "build complete"

# ── 7. Reload (not restart) ─────────────────────────────────────────────────
# `pm2 reload` is zero-downtime for cluster-mode apps — old workers keep
# serving in-flight requests while new workers boot. `pm2 restart` would
# briefly drop connections.
step "Reloading PM2 (zero-downtime)"
pm2 reload "$PM2_APP_NAME" --update-env || fail "pm2 reload failed"
ok "pm2 reloaded"

# Give the new workers a moment to boot before health-checking.
sleep 3

# ── 8. Post-deploy health check ─────────────────────────────────────────────
# Hits a known-public route. A failure here means the new build is up but
# broken — investigate before customer traffic notices. Doesn't roll back
# automatically (the old workers are already replaced) but surfaces the
# break immediately in the deploy log.
step "Health-checking $HEALTH_URL"
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 15 "$HEALTH_URL" || echo "000")
if [[ "$HTTP_CODE" =~ ^2 ]] || [[ "$HTTP_CODE" =~ ^3 ]]; then
  ok "health check returned HTTP $HTTP_CODE"
else
  echo -e "${RED}✗ health check returned HTTP $HTTP_CODE — investigate immediately${NC}" >&2
  echo -e "${YELLOW}  (deployment is live but possibly broken — recent logs follow)${NC}"
  pm2 logs "$PM2_APP_NAME" --lines 50 --nostream
  exit 1
fi

echo
echo -e "${GREEN}✅ Deployment completed successfully${NC}"
echo
step "PM2 status"
pm2 status
