import type { NextConfig } from "next";
import { withSentryConfig } from "@sentry/nextjs";

// Cloudflare R2 public base URL (e.g. https://pub-xxx.r2.dev). When set, legacy
// `/uploads/*` URLs stored in the DB are rewritten to R2 so we never hit local
// disk in production. Empty string means "fall back to local API handler".
// Auto-prepends https:// if the env var was set without a protocol — Next's
// rewrite validator rejects bare hostnames and kills the build otherwise.
const R2_PUBLIC_URL = (() => {
  const raw = (process.env.R2_PUBLIC_URL || "").trim().replace(/\/$/, "");
  if (!raw) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  return `https://${raw}`;
})();
let R2_HOSTNAME = "";
try { R2_HOSTNAME = R2_PUBLIC_URL ? new URL(R2_PUBLIC_URL).hostname : ""; } catch { R2_HOSTNAME = ""; }
const isDev = process.env.NODE_ENV === "development";

const nextConfig: NextConfig = {
  // `output: "standalone"` produces a self-contained .next/standalone/
  // tree that you'd typically deploy on its own. In our Docker image we
  // ship the full node_modules anyway (Prisma migrations need it), so the
  // standalone optimization adds zero benefit and a layer of overlay
  // complexity that previously caused slow cold-starts under Coolify's
  // healthcheck window. Plain `next start` is faster and simpler here.
  // output: "standalone",
  // Allow tenant + admin subdomains during dev. `localtest.me` and `lvh.me`
  // both resolve to 127.0.0.1 in any browser without /etc/hosts edits.
  // Without these, Next refuses cross-origin HMR requests from
  // `<slug>.localtest.me:3000` etc.
  allowedDevOrigins: [
    "172.16.0.2",
    "localtest.me",
    "*.localtest.me",
    "lvh.me",
    "*.lvh.me",
  ],
  // Skip TypeScript check on production build (already checked locally)
  typescript: { ignoreBuildErrors: true },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "mavesoj.com",
        pathname: "/**",
      },
      // Migration source hosts — external sites whose images are referenced
      // directly during a tenant migration before assets are re-hosted on
      // the tenant's own R2/CDN. Safe to remove once images are uploaded.
      {
        protocol: "https",
        hostname: "buets.com",
        pathname: "/**",
      },
      // Unsplash — used by demo/seed content (new-tenant seed products, sample
      // landing pages). Without this the image optimizer returns 400 for any
      // images.unsplash.com URL a fresh tenant renders.
      {
        protocol: "https",
        hostname: "images.unsplash.com",
        pathname: "/**",
      },
      // Shared R2 bucket (R2_PUBLIC_URL env var) — exact hostname
      ...(R2_HOSTNAME ? [{ protocol: "https" as const, hostname: R2_HOSTNAME, pathname: "/**" }] : []),
      // Branded CDN domain — serves all per-tenant dedicated R2 bucket images
      // via the Cloudflare CDN Worker at cdn.<BASE_DOMAIN>/b/{bucket}/{key}
      ...((() => {
        const cdnUrl = process.env.CDN_BASE_URL || `https://cdn.${process.env.BASE_DOMAIN || "contradigital.agency"}`;
        try { return [{ protocol: "https" as const, hostname: new URL(cdnUrl).hostname, pathname: "/**" }]; }
        catch { return [{ protocol: "https" as const, hostname: `cdn.${process.env.BASE_DOMAIN || "contradigital.agency"}`, pathname: "/**" }]; }
      })()),
      // Fallback: allow raw r2.dev URLs for any existing tenants provisioned
      // before the CDN Worker was set up (CLOUDFLARE_KV_CDN_NAMESPACE_ID not set).
      {
        protocol: "https",
        hostname: "*.r2.dev",
        pathname: "/**",
      },
      // Production CDN — always allowed regardless of BASE_DOMAIN env so dev
      // can render images stored against the prod CDN (e.g. tenant DB dump).
      {
        protocol: "https",
        hostname: "cdn.contradigital.agency",
        pathname: "/**",
      },
    ],
    // AVIF first (≈20-30% smaller than WebP at same quality → big mobile
    // LCP/data win). Next falls back to WebP automatically for browsers
    // without AVIF support.
    formats: ["image/avif", "image/webp"],
    minimumCacheTTL: isDev ? 0 : 60 * 60 * 24 * 30, // no optimized-image cache in dev; 30 days in prod
    deviceSizes: [384, 640, 750, 828, 1024, 1080, 1200, 1920],
    imageSizes: [16, 32, 48, 64, 96, 128, 256],
    qualities: [75],
  },
  experimental: {
    // Disable Server Component fetch caching during HMR in local dev.
    serverComponentsHmrCache: false,
    optimizePackageImports: [
      "react-icons",
      "framer-motion",
      "swiper",
    ],
    ...(isDev ? {} : {
      staleTimes: {
        dynamic: 30,
        static: 300,
      },
    }),
  },
  // When R2 is configured, REDIRECT legacy /uploads/* + /storage/* URLs to
  // the Cloudflare CDN (308 permanent). Rewrites would proxy every image
  // through Next (browser → Next server → R2 → Next → browser) which kills
  // CDN caching and adds a hop per image. A 308 redirect is cached by the
  // browser, so subsequent loads hit cdn.contradigital.agency directly.
  // When R2 is NOT set, fall back to the local API handler via rewrite.
  async redirects() {
    if (!R2_PUBLIC_URL) return [];
    return [
      { source: "/storage/uploads/:path*", destination: `${R2_PUBLIC_URL}/:path*`, permanent: true },
      { source: "/storage/:path*", destination: `${R2_PUBLIC_URL}/:path*`, permanent: true },
      { source: "/uploads/:path*", destination: `${R2_PUBLIC_URL}/:path*`, permanent: true },
    ];
  },
  async rewrites() {
    if (R2_PUBLIC_URL) return { beforeFiles: [] };
    return {
      beforeFiles: [
        { source: "/storage/uploads/:path*", destination: "/api/uploads/:path*" },
        { source: "/storage/:path*", destination: "/api/uploads/:path*" },
        { source: "/uploads/:path*", destination: "/api/uploads/:path*" },
      ],
    };
  },
  async headers() {
    // Global security headers applied to every route. Designed to be safe —
    // no CSP yet (CSP needs careful tuning for Next + FB pixel + R2 + the
    // dashboard customizer iframe; that's a separate later pass in
    // Report-Only mode first).
    //
    //  HSTS                    — force HTTPS for 2 years incl. subdomains.
    //                            Browser remembers; never falls back to HTTP.
    //  X-Frame-Options         — SAMEORIGIN so the dashboard /customizer
    //                            iframe of own preview pages still works.
    //                            Blocks clickjacking from external domains.
    //  X-Content-Type-Options  — nosniff, blocks MIME-type confusion attacks.
    //  Referrer-Policy         — strict-origin-when-cross-origin: same-site
    //                            sees full URL, cross-site sees only origin,
    //                            cross-protocol sees nothing.
    //  Permissions-Policy      — disable APIs we never use (geolocation,
    //                            camera, microphone, etc) so any future
    //                            embedded ad/tracker can't request them.
    //  X-DNS-Prefetch-Control  — speed up navigations to known third parties.
    const securityHeaders = [
      { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
      { key: "X-Frame-Options", value: "SAMEORIGIN" },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      // NOTE: `interest-cohort=()` removed — Chrome dropped FLoC, the token is
      // now unrecognized and emits a console warning on every page load.
      { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()" },
      { key: "X-DNS-Prefetch-Control", value: "on" },
    ];
    if (isDev) {
      return [
        {
          source: "/:path*",
          headers: [
            ...securityHeaders,
            { key: "Cache-Control", value: "no-store, no-cache, must-revalidate, proxy-revalidate" },
            { key: "Pragma", value: "no-cache" },
            { key: "Expires", value: "0" },
          ],
        },
      ];
    }
    return [
      {
        // Global — applies to every path. Per-path rules below merge
        // additional headers (Cache-Control etc.) on top.
        source: "/:path*",
        headers: securityHeaders,
      },
      {
        source: "/uploads/:path*",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
          { key: "X-Content-Type-Options", value: "nosniff" },
        ],
      },
      {
        // Next.js optimized images - AGGRESSIVE CACHING
        source: "/_next/image",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
          { key: "X-Content-Type-Options", value: "nosniff" },
        ],
      },
      {
        // Static assets
        source: "/_next/static/:path*",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
        ],
      },
    ];
  },
  compress: true,
  poweredByHeader: false,
  // Hide the floating Next.js dev badge / route-rendering spinner. The
  // prewarmer + ISR already make navigations feel instant; the indicator just
  // adds visual noise during dev. (No effect on production builds.)
  devIndicators: false,
};

// Wrap with Sentry config to capture errors to GlitchTip (Sentry-compatible
// self-hosted error tracker). Becomes a no-op when GLITCHTIP_DSN /
// NEXT_PUBLIC_SENTRY_DSN are unset, so local dev is unaffected.
//
// GlitchTip does not require source-map upload (it works without symbolication
// out of the box), so we keep the wrapper minimal — no auth token / org /
// project plumbing needed. To enable source maps later, set SENTRY_AUTH_TOKEN
// and pass it via the options below.
export default withSentryConfig(nextConfig, {
  // Suppress upload + telemetry — GlitchTip is the destination, not Sentry SaaS.
  silent: true,
  // Disable the Sentry-cli source-map upload step; safe because we point at
  // GlitchTip which doesn't require it.
  sourcemaps: { disable: true },
  telemetry: false,
  // Don't inject the Sentry tunnel route — adds bundle weight; GlitchTip is
  // reachable from customer browsers directly via the public DSN.
  tunnelRoute: undefined,
  // (Removed `automaticVercelMonitors: false` + `disableLogger: true` — both
  // are deprecated in @sentry/nextjs v10 and ignored under Turbopack anyway.)
});
