# CDN Worker — deployment

The Worker proxies `cdn.contradigital.agency/b/<bucket>/<key>` to R2, with a
KV-backed bucket allowlist so callers can't enumerate buckets they don't own.

Source: [`worker.js`](./worker.js)
Config: [`wrangler.toml`](./wrangler.toml)

---

## What needs to exist in Cloudflare

| Thing | How to create |
|---|---|
| **KV namespace** named `BUCKET_MAP` | Dashboard → Workers & Pages → KV → Create namespace |
| **Worker** named `contra-digital-cdn` | Dashboard → Workers & Pages → Create application → Create Worker; paste `worker.js` into the editor |
| **Two Worker secrets** | Worker → Settings → Variables and Secrets → Add (type: Secret) |
| **KV binding** | Worker → Settings → Bindings → Add → KV Namespace → variable: `BUCKET_MAP` |
| **Route** | Worker → Settings → Domains & Routes → Add → Route → `cdn.contradigital.agency/*` (zone: `contradigital.agency`) |

The KV namespace id is set in [`wrangler.toml`](./wrangler.toml) (currently
`4f98ceaf03e04a5dba9abe0805e2b431`). Update it there if you ever recreate
the namespace.

## Worker secrets

| Secret name | Value | Token scope |
|---|---|---|
| `CF_ACCOUNT_ID` | your Cloudflare account id | (identifier — not actually a secret, but stored as one for consistency) |
| `CF_API_TOKEN` | a dedicated, read-only API token | **R2:Read only** — do NOT reuse the broader `CLOUDFLARE_API_TOKEN` your Next.js app uses |

Create the read-only token at My Profile → API Tokens → Create Token → Custom
Token, with a single permission: `Account → Workers R2 Storage → Read`.

## Wrangler CLI deploy (alternative to the dashboard)

```bash
cd cloudflare/cdn-worker
wrangler login
wrangler secret put CF_ACCOUNT_ID   # paste account id
wrangler secret put CF_API_TOKEN    # paste the R2:Read token
wrangler deploy
```

On Windows PowerShell, secrets piped via `echo` get a UTF-8 BOM that breaks
authentication. Use cmd's `type` instead:
```
cmd /c "type token.txt | wrangler secret put CF_API_TOKEN"
```

## Seeding existing tenants into KV

After the Worker + KV are wired but BEFORE customer traffic hits the new
account, register every existing tenant's bucket name in KV so the Worker
will serve them:

```bash
# Set the three vars in .env first (see scripts/seed-cdn-kv.mjs header)
node scripts/seed-cdn-kv.mjs
```

New tenants provisioned after this point are auto-registered by
`kvSetBucket()` in `src/lib/cloudflare-r2-admin.ts` — no manual step needed.

## Verify

```bash
curl -I https://cdn.contradigital.agency/b/<some-bucket>/<some-key>
```

- `200 OK` with `X-CDN: cd-ecom` header → Worker is live and KV allowlist passed
- `404` → bucket is missing from `BUCKET_MAP` KV (or the key doesn't exist in R2)
- `500 "Worker misconfigured"` → `CF_ACCOUNT_ID` or `CF_API_TOKEN` secrets are missing
