/**
 * CD Ecom CDN Worker — authenticated R2 proxy with bucket allowlist
 *
 * Routes: cdn.contradigital.agency/b/{bucket-name}/{key}
 *
 * Fetches objects from R2 using the Cloudflare REST API (Bearer token auth).
 * Buckets do NOT need "Allow Public Access" enabled — the Worker authenticates
 * every request with the Cloudflare API token stored as a Worker secret.
 *
 * The BUCKET_MAP KV namespace gates which buckets this Worker is willing to
 * proxy. A tenant's bucket is registered there during provisioning
 * (see kvSetBucket in src/lib/cloudflare-r2-admin.ts). Any GET against a
 * bucket name not present in KV returns 404 — this prevents a caller from
 * probing arbitrary buckets in the account by guessing names.
 *
 * Secrets required (set via: wrangler secret put <NAME>):
 *   CF_ACCOUNT_ID   — Cloudflare account ID
 *   CF_API_TOKEN    — Cloudflare API token with R2:Read permission
 *
 * KV binding required (declared in wrangler.toml):
 *   BUCKET_MAP — namespace listing every tenant bucket the Worker may serve
 */

const CACHE_TTL = 60 * 60 * 24 * 365; // 1 year
const CF_API_BASE = "https://api.cloudflare.com/client/v4";

// ── Main handler ─────────────────────────────────────────────────────────────

export default {
  async fetch(request, env, ctx) {
    if (request.method !== "GET" && request.method !== "HEAD") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    const url = new URL(request.url);
    const path = url.pathname.slice(1); // strip leading /

    if (!path.startsWith("b/")) {
      return new Response("Not Found", { status: 404 });
    }

    const withoutPrefix = path.slice(2);
    const slashIdx = withoutPrefix.indexOf("/");
    if (slashIdx === -1) return new Response("Not Found", { status: 404 });

    const bucket = withoutPrefix.slice(0, slashIdx);
    const key = withoutPrefix.slice(slashIdx + 1);
    if (!bucket || !key) return new Response("Not Found", { status: 404 });

    // Check Cloudflare edge cache first
    const cache = caches.default;
    const cacheKey = new Request(url.toString());
    const cached = await cache.match(cacheKey);
    if (cached) return cached;

    // Bucket allowlist — refuse to serve any bucket not registered during
    // tenant provisioning. Skipped only if KV binding is absent (dev/local).
    if (env.BUCKET_MAP) {
      const registered = await env.BUCKET_MAP.get(bucket);
      if (!registered) {
        return new Response("Not Found", { status: 404 });
      }
    }

    // Fetch from R2 via Cloudflare REST API (no public bucket access needed)
    const accountId = env.CF_ACCOUNT_ID;
    const apiToken = env.CF_API_TOKEN;

    if (!accountId || !apiToken) {
      return new Response("Worker misconfigured: missing CF_ACCOUNT_ID or CF_API_TOKEN", { status: 500 });
    }

    const encodedKey = key.split("/").map(encodeURIComponent).join("/");
    const r2ApiUrl = `${CF_API_BASE}/accounts/${accountId}/r2/buckets/${bucket}/objects/${encodedKey}`;

    let r2Response;
    try {
      r2Response = await fetch(r2ApiUrl, {
        method: request.method,
        headers: {
          Authorization: `Bearer ${apiToken}`,
        },
      });
    } catch (err) {
      return new Response(`Origin fetch failed: ${err.message}`, { status: 502 });
    }

    if (!r2Response.ok) {
      return new Response("Not Found", { status: r2Response.status === 404 ? 404 : r2Response.status });
    }

    // Forward Content-Type from Cloudflare API response
    const contentType = r2Response.headers.get("Content-Type") || "application/octet-stream";

    const response = new Response(r2Response.body, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": `public, max-age=${CACHE_TTL}, immutable`,
        "Access-Control-Allow-Origin": "*",
        "X-CDN": "cd-ecom",
      },
    });

    ctx.waitUntil(cache.put(cacheKey, response.clone()));
    return response;
  },
};
