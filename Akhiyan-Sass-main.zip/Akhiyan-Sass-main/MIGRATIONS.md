# Schema Migrations — CD Ecom

This app runs one **control DB** + **N tenant DBs**, each with their own Prisma schema. Migrating means generating SQL once and applying it to every tenant in lock-step. The infrastructure for that already exists; this doc tells you how to use it without breaking customers.

> **The 30-second rule:** every schema change must be **backward-compatible with the code that was live before the change**. If the deploy fails halfway through, the old code must still be able to read and write the database. Always.

---

## Two schemas, two flows

| Schema | File | Migrate command (inside `deploy.sh`) | Pattern |
|---|---|---|---|
| **Control** | `prisma/control/schema.prisma` | `npm run db:migrate:control` | Single DB, atomic. Use for: superadmin, tenants table, plans, audit log. |
| **Tenant** | `prisma/schema.prisma` | `npm run db:migrate-all` | Runs against every active tenant DB in parallel with advisory locks. Use for: products, orders, blog, customers — anything per-tenant. |

Both run inside `./deploy.sh` automatically. **Never run them manually in prod** — `deploy.sh` orders them correctly.

---

## Day-to-day workflow

### 1. Edit the right schema

```bash
# Tenant change (most common — products, orders, etc.):
$EDITOR prisma/schema.prisma

# Control-plane change (rare — tenants table, billing plans, etc.):
$EDITOR prisma/control/schema.prisma
```

### 2. Generate the migration SQL **locally**

```bash
# Tenant schema
npx prisma migrate dev --name describe_your_change_here

# Control schema
npx prisma migrate dev --schema prisma/control/schema.prisma --name describe_your_change_here
```

This creates `prisma/migrations/<timestamp>_<name>/migration.sql` (or `prisma/control/migrations/...`). **Read the generated SQL.** If it does anything destructive (DROP COLUMN, ALTER TYPE, NOT NULL on existing), stop and follow the two-deploy pattern below.

### 3. Commit the migration file with your code

```bash
git add prisma/schema.prisma prisma/migrations/<timestamp>_<name>/
git commit -m "feat(schema): add X to Y"
```

The migration file is the contract. Once it's been applied to **any production tenant**, it is immutable — editing it breaks the checksum and future deploys fail.

### 4. Deploy

```bash
npm run deploy
```

`deploy.sh` will run the new migration against the control DB or every tenant DB depending on where you placed it, before the new build goes live.

---

## What's safe in a single deploy

| Change | Why it's safe |
|---|---|
| `ADD COLUMN` (nullable) | Old code ignores it; new code reads NULL when missing |
| `ADD COLUMN ... DEFAULT 'x'` | Old code ignores it; new rows get the default |
| `CREATE TABLE` | Old code doesn't reference it |
| `CREATE INDEX` (concurrently, on PG) | Doesn't lock — old reads/writes keep working |
| `ADD COLUMN` to a relation through a new optional FK | Old code ignores; new code populates over time |

In every case: **the old code keeps working after the migration runs and before the new code is live.** That's the bar.

---

## What requires TWO deploys (and why)

### Renaming a column

```sql
-- ❌ ONE DEPLOY (will break tenants during the brief in-flight window)
ALTER TABLE products RENAME COLUMN price TO unit_price;
```

```text
✅ TWO DEPLOYS:

Deploy A:
  1. ADD COLUMN unit_price (same type, nullable)
  2. Code writes BOTH columns
  3. Code reads from unit_price, falls back to price
  4. Backfill: UPDATE products SET unit_price = price WHERE unit_price IS NULL;

Deploy B (≥ 24h later, after every tenant is at Deploy A):
  5. Code reads/writes only unit_price
  6. DROP COLUMN price
```

### Dropping a column

```text
✅ TWO DEPLOYS:

Deploy A:
  1. Code stops reading and writing the column
  2. Confirm via logs / Sentry that no in-prod path still touches it

Deploy B:
  3. DROP COLUMN
```

### Making a nullable column NOT NULL

```text
✅ TWO DEPLOYS:

Deploy A:
  1. Code writes a non-null value on every path
  2. Backfill: UPDATE x SET col = 'default' WHERE col IS NULL;
  3. ADD CHECK constraint NOT VALID (validated later)

Deploy B:
  4. ALTER COLUMN ... SET NOT NULL  (now safe — every row has a value)
```

### Changing a column type

```text
✅ TWO DEPLOYS:

Deploy A:
  1. ADD COLUMN new_col (with new type)
  2. Code writes both columns
  3. Backfill old → new in batches
  4. Code reads from new_col

Deploy B (after backfill complete):
  5. DROP COLUMN old_col
```

---

## Tenant-migration runner — what it does and how to drive it

`scripts/migrate-all-tenants.ts` (called via `npm run db:migrate-all`) is production-grade:

- **Discovers** every `prisma/migrations/<timestamp>_<name>/migration.sql`
- **Per-tenant advisory lock** — two parallel migrators on the same DB serialize on `pg_advisory_xact_lock(8064236247109853219)`
- **Per-migration transaction** — failure rolls back, marks `failed = true` in `_prisma_migrations`, then throws
- **Idempotent** — re-running with no new SQL is a no-op
- **Continues past per-tenant failures** — reports a summary, exits non-zero so CI catches it
- **Prisma-CLI compatible** — uses the same `_prisma_migrations` table layout, so `prisma migrate status` works against tenant DBs too

### Useful invocations

```bash
# Dry-run — list pending migrations per tenant without changing anything
npm run db:migrate-all-dry

# Migrate one tenant only (after fixing its specific issue)
npm run db:migrate-all -- --slug=acme

# Higher parallelism (default 4; bump for many tenants)
npm run db:migrate-all -- --concurrency=8

# Include suspended tenants
npm run db:migrate-all -- --include-suspended
```

---

## When a single tenant's migration fails

This is the most common operational issue. Example output:

```
✓ acme: +1 applied, 12 already there
✓ beta: +1 applied, 12 already there
✗ corp: column "x" of relation "products" already exists
```

What happened: `corp`'s schema drifted (someone ran a SQL manually, or an earlier migration partially applied). Other tenants are fine.

To fix:

1. Connect to that tenant's DB (`tenant.dbUrl` from the control DB).
2. Inspect the divergent state. Usually one of:
   - The column already exists from a manual change → mark migration as already-applied:
     ```sql
     INSERT INTO _prisma_migrations (id, checksum, migration_name, started_at, finished_at, applied_steps_count)
     VALUES (gen_random_uuid()::text, '<sha256-of-the-sql>', '<migration_name>', NOW(), NOW(), 1);
     ```
   - Bad data blocks the migration → fix the data, then re-run.
3. Re-run `npm run db:migrate-all -- --slug=corp`.
4. When the tenant catches up, re-run the full `npm run deploy` (it will skip the already-migrated tenants).

**Never edit the migration SQL file** to work around one tenant — it'll re-fail when a brand-new tenant gets provisioned and runs the full history.

---

## Brand-new tenants

When a superadmin provisions a tenant (`/api/v1/superadmin/tenants` POST), the tenant-creation code runs `runTenantMigrations()` for that one DB. New tenants always start at the latest migration — they never lag.

This means: a migration that worked for existing tenants but breaks new ones (e.g. depends on data being present) is a real problem. Test new migrations against an empty DB before shipping.

---

## Don'ts

- ❌ Don't edit a migration file after it's been deployed. Use a new migration for any correction.
- ❌ Don't run `prisma migrate dev` on production. It's a dev-only command.
- ❌ Don't run `prisma db push` ever — it bypasses the migration history.
- ❌ Don't modify rows in `_prisma_migrations` by hand without understanding the checksum/state contract.
- ❌ Don't add a migration that's irreversible (DROP) without a roll-forward plan written in the PR.
- ❌ Don't put DDL inside Next.js startup code or API routes. Schema changes go through `prisma/migrations/`.

---

## Related docs

- [DEPLOY.md](DEPLOY.md) — overall deployment workflow
- [src/lib/tenant-migrate.ts](src/lib/tenant-migrate.ts) — the runner implementation
- [scripts/migrate-all-tenants.ts](scripts/migrate-all-tenants.ts) — orchestrator
