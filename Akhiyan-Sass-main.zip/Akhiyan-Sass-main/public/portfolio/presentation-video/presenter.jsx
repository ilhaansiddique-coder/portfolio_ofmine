// presenter.jsx — compact photo presenter (tuned for small frames)

function Presenter({
  x = 150, y = 200,
  scale = 1,
  pose = 'welcome',
  breath = 0,
  look = 0,
  accent = '#7C5CFF',
  talking = true,
  size = 96,
}) {
  const bob = Math.sin(breath * Math.PI * 2) * 1.5;
  const talkPulse = talking ? 1 + Math.abs(Math.sin(breath * Math.PI * 6)) * 0.015 : 1;
  const tilt = look * 2.5;

  return (
    <div style={{
      position: 'absolute',
      left: x, top: y,
      transform: `translate(-50%, -50%) scale(${scale}) translateY(${bob}px)`,
      transformOrigin: 'center',
      pointerEvents: 'none',
      width: size, height: size,
    }}>
      <div style={{
        position: 'absolute', inset: -12,
        borderRadius: '50%',
        background: `radial-gradient(circle, ${accent}66 0%, transparent 70%)`,
        filter: 'blur(10px)',
      }}/>

      <div style={{
        position: 'absolute', inset: 0,
        borderRadius: '50%',
        border: `2px solid ${accent}`,
        boxShadow: `0 0 20px ${accent}66`,
        transform: `scale(${talkPulse}) rotate(${tilt * 0.3}deg)`,
      }}/>

      <div style={{
        position: 'absolute', inset: 3,
        borderRadius: '50%',
        overflow: 'hidden',
        transform: `scale(${talkPulse}) rotate(${tilt * 0.2}deg)`,
        boxShadow: '0 6px 16px rgba(0,0,0,0.4)',
      }}>
        <img src="https://i.pravatar.cc/200?img=33" alt="presenter"
          style={{
            width: '100%', height: '100%',
            objectFit: 'cover',
            display: 'block',
            transform: `translateX(${look * 2}px)`,
          }}/>
      </div>

      <svg style={{
        position: 'absolute', inset: -6,
        transform: `rotate(${breath * 60}deg)`,
      }} width={size + 12} height={size + 12} viewBox={`0 0 ${size + 12} ${size + 12}`}>
        <circle
          cx={(size + 12) / 2} cy={(size + 12) / 2}
          r={(size + 6) / 2}
          fill="none"
          stroke={accent}
          strokeWidth="1.5"
          strokeDasharray={`${(size + 6) * 0.15} ${(size + 6) * 3}`}
          strokeLinecap="round"
          opacity="0.7"
        />
      </svg>

      {talking && (
        <div style={{
          position: 'absolute',
          left: '50%', top: size + 6,
          transform: 'translateX(-50%)',
          display: 'flex', gap: 3,
        }}>
          {[0, 1, 2].map(i => {
            const phase = Math.sin(breath * Math.PI * 8 - i * 0.8);
            return (
              <div key={i} style={{
                width: 3, height: 3,
                borderRadius: 2,
                background: accent,
                opacity: 0.4 + (phase + 1) / 2 * 0.6,
              }}/>
            );
          })}
        </div>
      )}
    </div>
  );
}

window.Presenter = Presenter;
