// scenes.jsx — 300×375 portrait scenes for Contra Digital

const PURPLE = '#7C5CFF';
const LAVENDER = '#B8A4FF';
const INK = '#0B0B10';
const PAPER = '#F5F3EE';
const DIM = 'rgba(245,243,238,0.55)';

const DISPLAY = "'Space Grotesk', 'Inter', system-ui, sans-serif";
const BODY = "'Inter', system-ui, sans-serif";
const MONO = "'JetBrains Mono', ui-monospace, monospace";

const W = 300, H = 375;

// ── Shared chrome ──────────────────────────────────────────────────────────
function SceneFrame({ label, number, total = 10, light = false }) {
  const fg = light ? INK : PAPER;
  const dim = light ? 'rgba(11,11,16,0.55)' : DIM;
  return (
    <>
      <div style={{
        position: 'absolute', top: 10, left: 12,
        display: 'flex', alignItems: 'center', gap: 5,
        fontFamily: MONO, fontSize: 7, color: dim,
        letterSpacing: '0.15em', textTransform: 'uppercase',
      }}>
        <div style={{ width: 8, height: 1, background: PURPLE }}/>
        <span style={{ color: fg }}>Contra Digital</span>
      </div>
      <div style={{
        position: 'absolute', top: 10, right: 12,
        fontFamily: MONO, fontSize: 7, color: dim,
        letterSpacing: '0.1em',
      }}>
        {String(number).padStart(2, '0')}/{String(total).padStart(2, '0')}
      </div>
      <div style={{
        position: 'absolute', top: 22, left: 12,
        fontFamily: MONO, fontSize: 7, color: PURPLE,
        letterSpacing: '0.15em', textTransform: 'uppercase',
      }}>
        {label}
      </div>
    </>
  );
}

function PurpleGlow({ x = W / 2, y = H / 2, r = 180, opacity = 0.35 }) {
  return (
    <div style={{
      position: 'absolute',
      left: x - r, top: y - r,
      width: r * 2, height: r * 2,
      background: `radial-gradient(circle, ${PURPLE} 0%, transparent 60%)`,
      opacity,
      filter: 'blur(14px)',
      pointerEvents: 'none',
    }}/>
  );
}

function GridBg({ opacity = 0.08 }) {
  return (
    <svg width={W} height={H} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      <defs>
        <pattern id="pgrid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" fill="none" stroke={PAPER} strokeWidth="0.5" opacity={opacity}/>
        </pattern>
      </defs>
      <rect width={W} height={H} fill="url(#pgrid)"/>
    </svg>
  );
}

// ── Scene 1: Hero ──────────────────────────────────────────────────────────
function HeroScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1], Easing.easeOutCubic)(t);
  const titleY = interpolate([0.2, 1.0], [20, 0], Easing.easeOutCubic)(t);
  const titleOp = interpolate([0.2, 0.9], [0, 1])(t);
  const presenterOp = interpolate([0, 0.8], [0, 1])(t);

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <GridBg />
      <PurpleGlow x={W/2} y={120} r={180} opacity={0.5}/>
      <SceneFrame label="Intro" number={1}/>

      <div style={{
        position: 'absolute', left: '50%', top: 100,
        transform: 'translateX(-50%)',
        opacity: presenterOp,
      }}>
        <Presenter x={0} y={0} scale={1} pose="welcome"
          look={Math.sin(t*2.5)*0.3} breath={t/3}
          accent={PURPLE} size={90}/>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, top: 230,
        textAlign: 'center',
        transform: `translateY(${titleY}px)`,
        opacity: titleOp,
        fontFamily: DISPLAY, fontSize: 28, fontWeight: 600,
        letterSpacing: '-0.03em', lineHeight: 1.0,
      }}>
        We design<br/>
        the <span style={{ color: PURPLE, fontStyle: 'italic' }}>next</span> thing
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 22,
        textAlign: 'center',
        fontFamily: BODY, fontSize: 10, color: DIM,
        opacity: interpolate([1.2, 1.8], [0, 1])(t),
      }}>
        — a partnership studio —
      </div>
    </div>
  );
}

// ── Scene 2: Growth Mission ────────────────────────────────────────────────
function GrowthScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);

  const bars = [
    interpolate([0.5, 1.4], [0, 40])(t),
    interpolate([0.7, 1.6], [0, 62])(t),
    interpolate([0.9, 1.8], [0, 90])(t),
    interpolate([1.1, 2.0], [0, 130])(t),
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <GridBg />
      <SceneFrame label="Mission" number={2}/>

      <div style={{
        position: 'absolute', left: 12, top: 52,
        fontFamily: DISPLAY, fontSize: 26, fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1.0,
        opacity: interpolate([0, 0.6], [0, 1])(t),
        transform: `translateY(${interpolate([0, 0.6], [10, 0])(t)}px)`,
      }}>
        Your growth<br/>is <span style={{ color: PURPLE }}>our mission.</span>
      </div>

      <div style={{
        position: 'absolute', left: 12, top: 130,
        fontFamily: BODY, fontSize: 9, color: DIM,
        maxWidth: 170, lineHeight: 1.3,
        opacity: interpolate([0.6, 1.2], [0, 1])(t),
      }}>
        We build partnerships designed for the long run.
      </div>

      <div style={{
        position: 'absolute', left: 12, bottom: 60,
        right: 110,
        height: 140,
        display: 'flex', alignItems: 'flex-end', gap: 6,
      }}>
        {bars.map((h, i) => (
          <div key={i} style={{
            flex: 1, height: h,
            background: i === 3 ? PURPLE : i === 2 ? LAVENDER : 'rgba(245,243,238,0.2)',
            borderRadius: '2px 2px 0 0',
          }}/>
        ))}
      </div>
      <div style={{
        position: 'absolute', left: 12, bottom: 40,
        fontFamily: MONO, fontSize: 7, color: DIM, letterSpacing: '0.1em',
        opacity: interpolate([1.5, 2.2], [0, 1])(t),
      }}>
        Q1   Q2   Q3   Q4 →
      </div>

      <div style={{ opacity: interpolate([0.2, 0.9], [0, 1])(t) }}>
        <Presenter x={238} y={220} scale={1} pose="point-left"
          accent={PURPLE} breath={t/3} size={80}/>
      </div>
    </div>
  );
}

// ── Scene 3: Unlimited Revisions ───────────────────────────────────────────
function RevisionsScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);
  const vNum = Math.min(99, Math.floor(t * 16));

  return (
    <div style={{ position: 'absolute', inset: 0, background: PAPER, color: INK, overflow: 'hidden' }}>
      <SceneFrame label="Revisions" number={3} light/>

      <div style={{ position: 'absolute', left: 18, top: 55, opacity: op }}>
        {[0, 1, 2, 3, 4].map((i) => {
          const sO = interpolate([i*0.15, i*0.15+0.4], [0, 1])(t);
          return (
            <div key={i} style={{
              position: 'absolute',
              left: i * 5, top: i * 5,
              width: 90, height: 62,
              background: i === 4 ? INK : PAPER,
              border: `1.5px solid ${INK}`,
              opacity: sO * (0.4 + i * 0.15),
              transform: `rotate(${(i-2)*1.5}deg)`,
              boxShadow: i === 4 ? `4px 4px 0 ${PURPLE}` : 'none',
            }}>
              <div style={{
                fontFamily: MONO, fontSize: 6, padding: 4,
                color: i === 4 ? PAPER : INK,
                letterSpacing: '0.15em', opacity: 0.7,
              }}>v{String(i+1).padStart(2,'0')}</div>
            </div>
          );
        })}
      </div>

      <div style={{
        position: 'absolute', right: 12, top: 50,
        textAlign: 'right',
        opacity: op,
      }}>
        <div style={{
          fontFamily: DISPLAY, fontSize: 58, fontWeight: 500,
          letterSpacing: '-0.05em', lineHeight: 0.9,
          fontVariantNumeric: 'tabular-nums',
          color: INK,
        }}>
          v{String(vNum).padStart(2, '0')}
        </div>
        <div style={{
          fontFamily: DISPLAY, fontSize: 16, fontWeight: 500,
          color: PURPLE, letterSpacing: '-0.02em',
          lineHeight: 1.0, marginTop: 2,
        }}>
          until it's<br/>perfect.
        </div>
      </div>

      <div style={{
        position: 'absolute', left: 12, bottom: 50,
        fontFamily: BODY, fontSize: 9, color: 'rgba(11,11,16,0.6)',
        maxWidth: 170, lineHeight: 1.3,
        opacity: interpolate([1.0, 1.6], [0, 1])(t),
      }}>
        Unlimited iterations.<br/>No cap. No hidden fees.
      </div>

      <div style={{ opacity: op }}>
        <Presenter x={238} y={310} scale={1} pose="point-left"
          accent={PURPLE} breath={t/3} size={74}/>
      </div>
    </div>
  );
}

// ── Scene 4: Lifetime Support ──────────────────────────────────────────────
function LifetimeScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);
  const lineProg = interpolate([0.4, 2.6], [0, 1], Easing.easeOutCubic)(t);

  const dots = [
    { x: 24, label: 'LAUNCH' },
    { x: 94, label: 'M6' },
    { x: 164, label: 'Y1' },
    { x: 234, label: 'Y3' },
    { x: 276, label: '∞', highlight: true },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <GridBg />
      <PurpleGlow x={W/2} y={H/2} r={170} opacity={0.25}/>
      <SceneFrame label="Support" number={4}/>

      <div style={{
        position: 'absolute', left: 12, top: 50, right: 12,
        fontFamily: DISPLAY, fontSize: 24, fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1.0,
        opacity: op,
      }}>
        Relationship<br/>doesn't end at <span style={{ color: PURPLE, fontStyle: 'italic' }}>delivery.</span>
      </div>

      <div style={{ position: 'absolute', left: 0, right: 0, top: 200, height: 60, opacity: op }}>
        <div style={{
          position: 'absolute', left: 24, right: 24, top: 8,
          height: 1.5, background: 'rgba(245,243,238,0.2)',
        }}/>
        <div style={{
          position: 'absolute', left: 24, top: 8,
          width: (W - 48) * lineProg,
          height: 1.5, background: PURPLE,
          boxShadow: `0 0 6px ${PURPLE}`,
        }}/>
        {dots.map((d, i) => {
          const dotT = interpolate([0.4+i*0.3, 0.8+i*0.3], [0, 1], Easing.easeOutBack)(t);
          return (
            <div key={i} style={{
              position: 'absolute', left: d.x, top: 0,
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              opacity: dotT,
              transform: `scale(${0.6 + 0.4 * dotT})`,
            }}>
              <div style={{
                width: d.highlight ? 12 : 7, height: d.highlight ? 12 : 7,
                borderRadius: '50%',
                background: d.highlight ? PURPLE : (i === 0 ? PAPER : 'rgba(245,243,238,0.4)'),
                boxShadow: d.highlight ? `0 0 10px ${PURPLE}` : 'none',
                marginTop: d.highlight ? 2.5 : 5,
              }}/>
              <div style={{
                fontFamily: MONO, fontSize: 6, letterSpacing: '0.1em',
                color: d.highlight ? PURPLE : DIM,
                marginTop: 6,
              }}>
                {d.label}
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ opacity: interpolate([0.6, 1.2], [0, 1])(t) }}>
        <Presenter x={258} y={322} scale={1} pose="openArms"
          accent={PURPLE} breath={t/3} size={54}/>
      </div>
    </div>
  );
}

// ── Scene 5: Personalised Plans ────────────────────────────────────────────
function PlansScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);

  const plans = [
    { name: 'STARTUP', highlight: false },
    { name: 'SCALE', highlight: true },
    { name: 'ENT', highlight: false },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: PAPER, color: INK, overflow: 'hidden' }}>
      <SceneFrame label="Plans" number={5} light/>

      <div style={{
        position: 'absolute', left: 12, top: 52,
        fontFamily: DISPLAY, fontSize: 24, fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1.0,
        opacity: op,
      }}>
        No one-size-<br/><span style={{ fontStyle: 'italic', color: PURPLE }}>fits-all.</span>
      </div>

      <div style={{
        position: 'absolute', left: 12, right: 12, top: 140,
        display: 'flex', gap: 6, justifyContent: 'center',
      }}>
        {plans.map((p, i) => {
          const cT = interpolate([0.4 + i*0.2, 1.0 + i*0.2], [0, 1], Easing.easeOutCubic)(t);
          return (
            <div key={i} style={{
              width: 84, height: 110,
              background: p.highlight ? INK : PAPER,
              color: p.highlight ? PAPER : INK,
              border: `1.5px solid ${INK}`,
              padding: 10,
              opacity: cT,
              transform: `translateY(${(1-cT)*20}px) ${p.highlight ? 'scale(1.06)' : ''}`,
              boxShadow: p.highlight ? `3px 3px 0 ${PURPLE}` : 'none',
              display: 'flex', flexDirection: 'column',
            }}>
              <div style={{
                fontFamily: MONO, fontSize: 7, letterSpacing: '0.15em',
                color: p.highlight ? PURPLE : 'rgba(11,11,16,0.5)',
              }}>
                {p.name}
              </div>
              <div style={{ flex: 1, marginTop: 10, display: 'flex', flexDirection: 'column', gap: 4 }}>
                {[0,1,2].map(j => (
                  <div key={j} style={{
                    height: 1, width: `${70 - j*12}%`,
                    background: p.highlight ? 'rgba(245,243,238,0.4)' : 'rgba(11,11,16,0.4)',
                  }}/>
                ))}
              </div>
              <div style={{
                fontFamily: DISPLAY, fontSize: 10, fontWeight: 500,
                marginTop: 'auto',
              }}>
                Custom
              </div>
            </div>
          );
        })}
      </div>

      <div style={{
        position: 'absolute', left: 12, bottom: 60,
        fontFamily: BODY, fontSize: 9, color: 'rgba(11,11,16,0.6)',
        maxWidth: 160, lineHeight: 1.3,
        opacity: interpolate([1.2, 1.8], [0, 1])(t),
      }}>
        Built around your goals, timeline &amp; budget.
      </div>

      <div style={{ opacity: op }}>
        <Presenter x={252} y={335} scale={1} pose="point-left"
          accent={PURPLE} breath={t/3} size={54}/>
      </div>
    </div>
  );
}

// ── Scene 6: Custom Design ─────────────────────────────────────────────────
function CustomScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);
  const draw = interpolate([0.3, 2.8], [0, 1], Easing.easeInOutCubic)(t);

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <GridBg />
      <SceneFrame label="Craft" number={6}/>

      <div style={{
        position: 'absolute', left: 12, top: 50,
        fontFamily: DISPLAY, fontSize: 24, fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1.0,
        opacity: op,
      }}>
        Built from<br/>scratch. <span style={{ color: PURPLE, fontStyle: 'italic' }}>Always.</span>
      </div>

      <svg style={{ position: 'absolute', left: 40, top: 140, opacity: op }}
           width="220" height="140" viewBox="0 0 220 140">
        <defs>
          <mask id="dm-p">
            <rect width="100%" height="100%" fill="black"/>
            <rect x="0" y="0" width={220 * draw} height="140" fill="white"/>
          </mask>
        </defs>
        <g mask="url(#dm-p)">
          <rect x="2" y="2" width="216" height="136" rx="4" fill="none" stroke={PAPER} strokeWidth="1.2"/>
          <circle cx="12" cy="12" r="2.5" fill={PURPLE}/>
          <circle cx="20" cy="12" r="2.5" fill="none" stroke={PAPER} strokeWidth="0.8"/>
          <circle cx="28" cy="12" r="2.5" fill="none" stroke={PAPER} strokeWidth="0.8"/>
          <rect x="10" y="24" width="95" height="55" fill={PURPLE} opacity="0.2"/>
          <rect x="10" y="24" width="95" height="55" fill="none" stroke={PAPER} strokeWidth="1"/>
          <line x1="16" y1="36" x2="75" y2="36" stroke={PAPER} strokeWidth="1.5"/>
          <line x1="16" y1="44" x2="65" y2="44" stroke={PAPER} strokeWidth="1.5"/>
          <rect x="16" y="58" width="30" height="10" fill={PURPLE}/>
          <rect x="115" y="24" width="95" height="55" fill="none" stroke={PAPER} strokeWidth="1"/>
          <line x1="115" y1="24" x2="210" y2="79" stroke={PAPER} strokeWidth="0.8" opacity="0.5"/>
          <line x1="210" y1="24" x2="115" y2="79" stroke={PAPER} strokeWidth="0.8" opacity="0.5"/>
          <rect x="10" y="88" width="60" height="44" fill="none" stroke={PAPER} strokeWidth="1"/>
          <circle cx="18" cy="96" r="3" fill={PURPLE}/>
          <rect x="75" y="88" width="60" height="44" fill="none" stroke={PAPER} strokeWidth="1"/>
          <circle cx="83" cy="96" r="3" fill={PURPLE}/>
          <rect x="140" y="88" width="60" height="44" fill="none" stroke={PAPER} strokeWidth="1"/>
          <circle cx="148" cy="96" r="3" fill={PURPLE}/>
        </g>
        {draw < 1 && (
          <circle cx={220 * draw} cy="70" r="2.5" fill={PURPLE}>
            <animate attributeName="opacity" values="0.4;1;0.4" dur="0.6s" repeatCount="indefinite"/>
          </circle>
        )}
      </svg>

      <div style={{
        position: 'absolute', left: 12, bottom: 44,
        fontFamily: BODY, fontSize: 8.5, color: DIM,
        opacity: interpolate([1.0, 1.6], [0, 1])(t),
      }}>
        No templates. Bespoke, end-to-end.
      </div>

      <div style={{ opacity: op }}>
        <Presenter x={30} y={168} scale={1} pose="welcome"
          accent={PURPLE} breath={t/3} size={44}/>
      </div>
    </div>
  );
}

// ── Scene 7: 24/7 Support ──────────────────────────────────────────────────
function SupportScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);
  const hourDeg = (t / 3) * 360;
  const minDeg = (t / 0.25) * 360;

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <GridBg />
      <PurpleGlow x={W/2} y={H/2} r={170} opacity={0.4}/>
      <SceneFrame label="Always on" number={7}/>

      <div style={{
        position: 'absolute', left: 0, right: 0, top: 46,
        textAlign: 'center',
        fontFamily: DISPLAY, fontSize: 84, fontWeight: 500,
        letterSpacing: '-0.05em', lineHeight: 0.9,
        color: PURPLE, fontVariantNumeric: 'tabular-nums',
        opacity: op,
      }}>
        24/7
      </div>

      <div style={{
        position: 'absolute', left: '50%', top: 150,
        transform: 'translateX(-50%)',
        opacity: op,
      }}>
        <svg width="90" height="90" viewBox="0 0 90 90">
          <circle cx="45" cy="45" r="43" fill="none" stroke={PAPER} strokeWidth="1" opacity="0.2"/>
          <circle cx="45" cy="45" r="43" fill="none" stroke={PURPLE} strokeWidth="1.5"
            strokeDasharray={`${Math.PI * 86 * 0.75} ${Math.PI * 86}`}
            strokeDashoffset={-t * 10}
            transform="rotate(-90 45 45)"
          />
          {[...Array(12)].map((_, i) => (
            <line key={i} x1="45" y1="6" x2="45" y2="11"
              stroke={PAPER} strokeWidth={i % 3 === 0 ? 1.5 : 0.8}
              opacity={i % 3 === 0 ? 1 : 0.3}
              transform={`rotate(${i * 30} 45 45)`}
            />
          ))}
          <line x1="45" y1="45" x2="45" y2="22"
            stroke={PAPER} strokeWidth="2" strokeLinecap="round"
            transform={`rotate(${hourDeg} 45 45)`}
          />
          <line x1="45" y1="45" x2="45" y2="14"
            stroke={PURPLE} strokeWidth="1.5" strokeLinecap="round"
            transform={`rotate(${minDeg} 45 45)`}
          />
          <circle cx="45" cy="45" r="2.5" fill={PURPLE}/>
        </svg>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, top: 252,
        textAlign: 'center',
        fontFamily: DISPLAY, fontSize: 14, fontWeight: 500,
        letterSpacing: '-0.02em', lineHeight: 1.1,
        opacity: interpolate([0.5, 1.1], [0, 1])(t),
      }}>
        Question at 2 AM?<br/>
        <span style={{ color: DIM }}>we've got you.</span>
      </div>

      <div style={{ opacity: interpolate([0.8, 1.4], [0, 1])(t) }}>
        <Presenter x={254} y={335} scale={1} pose="openArms"
          accent={PURPLE} breath={t/3} size={44}/>
      </div>
    </div>
  );
}

// ── Scene 8: Services ──────────────────────────────────────────────────────
function ServicesScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.4], [0, 1])(t);

  const services = [
    { tag: '01', label: 'Web Design & Dev' },
    { tag: '02', label: 'App Design & Dev' },
    { tag: '03', label: 'SaaS Products' },
    { tag: '04', label: 'Social Media' },
    { tag: '05', label: 'Server-Side Tagging' },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: PAPER, color: INK, overflow: 'hidden' }}>
      <SceneFrame label="What we build" number={8} light/>

      <div style={{
        position: 'absolute', left: 12, top: 50,
        fontFamily: DISPLAY, fontSize: 22, fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1.0,
        opacity: op,
      }}>
        End-to-end <span style={{ color: PURPLE, fontStyle: 'italic' }}>digital</span>.
      </div>

      <div style={{
        position: 'absolute', left: 12, right: 12, top: 110,
        borderTop: '1px solid rgba(11,11,16,0.15)',
      }}>
        {services.map((s, i) => {
          const rT = interpolate([0.3 + i*0.2, 0.8 + i*0.2], [0, 1], Easing.easeOutCubic)(t);
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '8px 0',
              borderBottom: '1px solid rgba(11,11,16,0.15)',
              opacity: rT,
              transform: `translateX(${(1-rT)*15}px)`,
            }}>
              <div style={{
                fontFamily: MONO, fontSize: 8, color: PURPLE,
                letterSpacing: '0.1em', width: 16,
              }}>{s.tag}</div>
              <div style={{
                fontFamily: DISPLAY, fontSize: 14, fontWeight: 500,
                letterSpacing: '-0.02em', flex: 1,
              }}>{s.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Scene 9: Clients ───────────────────────────────────────────────────────
function ClientsScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);
  const logos = ['ORION', 'NOVA', 'PARALLEL', 'ATLAS', 'HELIX', 'VECTOR', 'KILN', 'MARGIN'];
  const quotes = [
    { text: 'They ship like an in-house team.', author: 'CTO, Orion Labs' },
    { text: 'Best launch in five years.', author: 'Head of Growth, Nova' },
    { text: 'Calm, fast, relentlessly good.', author: 'Founder, Parallel' },
  ];
  const qIdx = Math.min(2, Math.floor(t / 1.9));
  const q = quotes[qIdx];

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <GridBg />
      <SceneFrame label="Clients" number={9}/>

      <div style={{
        position: 'absolute', left: 12, top: 50,
        fontFamily: DISPLAY, fontSize: 22, fontWeight: 500,
        letterSpacing: '-0.03em', lineHeight: 1.0,
        opacity: op,
      }}>
        Trusted<br/><span style={{ color: PURPLE, fontStyle: 'italic' }}>worldwide.</span>
      </div>

      <div key={qIdx} style={{
        position: 'absolute', left: 12, right: 12, top: 140,
        opacity: op,
      }}>
        <div style={{
          fontFamily: DISPLAY, fontSize: 15, fontWeight: 500,
          lineHeight: 1.2, letterSpacing: '-0.02em',
        }}>
          <span style={{ color: PURPLE, fontSize: 22, verticalAlign: 'top', lineHeight: 0.6 }}>“</span>
          {q.text}
        </div>
        <div style={{
          fontFamily: MONO, fontSize: 7, color: DIM, marginTop: 8,
          letterSpacing: '0.1em', textTransform: 'uppercase',
        }}>
          — {q.author}
        </div>
      </div>

      <div style={{ opacity: op }}>
        <Presenter x={56} y={318} scale={1} pose="welcome"
          accent={PURPLE} breath={t/3} size={48}/>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 30,
        height: 20,
        overflow: 'hidden',
        opacity: op,
        borderTop: '1px solid rgba(245,243,238,0.1)',
        borderBottom: '1px solid rgba(245,243,238,0.1)',
      }}>
        <div style={{
          display: 'flex', gap: 26, alignItems: 'center',
          height: '100%',
          transform: `translateX(${-t * 22}px)`,
          whiteSpace: 'nowrap',
          paddingLeft: 110,
        }}>
          {[...logos, ...logos, ...logos].map((l, i) => (
            <div key={i} style={{
              fontFamily: DISPLAY, fontSize: 10, fontWeight: 500,
              letterSpacing: '0.2em', color: DIM,
            }}>{l}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Scene 10: Closing CTA ──────────────────────────────────────────────────
function CTAScene() {
  const { localTime: t } = useSprite();
  const op = interpolate([0, 0.5], [0, 1])(t);
  const pulse = 1 + Math.sin(t * 3) * 0.03;

  return (
    <div style={{ position: 'absolute', inset: 0, background: INK, color: PAPER, overflow: 'hidden' }}>
      <PurpleGlow x={W/2} y={H/2} r={240} opacity={0.55}/>
      <GridBg opacity={0.05}/>

      <div style={{
        position: 'absolute', top: 10, left: 12,
        fontFamily: DISPLAY, fontSize: 10, fontWeight: 500,
        letterSpacing: '-0.01em',
        opacity: op,
      }}>
        Contra <span style={{ color: PURPLE }}>Digital</span>
      </div>

      <div style={{
        position: 'absolute', left: '50%', top: 58,
        transform: 'translateX(-50%)',
        opacity: interpolate([0, 0.7], [0, 1])(t),
      }}>
        <Presenter x={0} y={0} scale={1} pose="welcome"
          look={Math.sin(t*3)*0.5} breath={t/3}
          accent={PURPLE} size={72}/>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, top: 180,
        textAlign: 'center',
        fontFamily: MONO, fontSize: 7, color: PURPLE,
        letterSpacing: '0.25em', textTransform: 'uppercase',
        opacity: op,
      }}>
        — ready when you are —
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, top: 198,
        textAlign: 'center',
        fontFamily: DISPLAY, fontSize: 36, fontWeight: 500,
        letterSpacing: '-0.04em', lineHeight: 0.9,
        opacity: interpolate([0.3, 1.0], [0, 1])(t),
        transform: `translateY(${interpolate([0.3, 1.0], [12, 0], Easing.easeOutCubic)(t)}px)`,
      }}>
        Let's build<br/>
        <span style={{ color: PURPLE, fontStyle: 'italic' }}>something.</span>
      </div>

      <div style={{
        position: 'absolute', left: '50%', bottom: 62,
        transform: `translateX(-50%) scale(${pulse})`,
        opacity: interpolate([0.9, 1.5], [0, 1])(t),
        background: PURPLE, color: PAPER,
        padding: '8px 18px',
        fontFamily: DISPLAY, fontSize: 12, fontWeight: 500,
        letterSpacing: '-0.01em',
        boxShadow: `0 8px 24px rgba(124,92,255,0.5)`,
        whiteSpace: 'nowrap',
      }}>
        Start a project →
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 32,
        textAlign: 'center',
        fontFamily: MONO, fontSize: 7, color: DIM,
        letterSpacing: '0.2em',
        opacity: interpolate([1.4, 2.0], [0, 1])(t),
      }}>
        contradigital.com
      </div>
    </div>
  );
}

Object.assign(window, {
  HeroScene, GrowthScene, RevisionsScene, LifetimeScene, PlansScene,
  CustomScene, SupportScene, ServicesScene, ClientsScene, CTAScene,
});
