#!/bin/sh
#
# Container entrypoint. Runs migrations idempotently then starts the server.
# Fails the container start if a migration fails — better to crash and be
# restarted by Coolify than to serve traffic against a stale schema.

set -e

# Force line-buffered output so progress is visible in `docker logs` while
# the migration is still running, not just at the end (Coolify polls logs).
# Send both stdout AND stderr to PID 1's fds so `docker logs` shows error
# messages from the env-checks below (the previous `2>/dev/null` tail
# silently swallowed every failure reason, leaving Coolify to print only
# "Pre-flight env checks…" with no diagnostic).
exec 1>/proc/1/fd/1 2>/proc/1/fd/2 || true

echo "▶ [entrypoint] Pre-flight env checks…"
if [ -z "$CONTROL_DATABASE_URL" ]; then
  echo "✗ CONTROL_DATABASE_URL is not set — refusing to start." >&2
  exit 1
fi
# R2 is the recommended object storage backend. When unset in production
# uploads fall back to the local /uploads handler — fine for first boot
# but those files vanish on container restart. Warn instead of hard-fail
# so a deploy with R2 wired at build-time (Dockerfile ARGs / Coolify
# Build Variables) can still boot even if the runtime env panel hasn't
# been populated yet.
if [ "$NODE_ENV" = "production" ] && [ -z "$R2_PUBLIC_URL" ]; then
  echo "⚠ R2_PUBLIC_URL unset at runtime — uploads will write to local disk" >&2
  echo "  and disappear on container restart. Configure R2 in the Coolify" >&2
  echo "  Environment Variables panel for persistence. Booting anyway." >&2
fi

echo "▶ [entrypoint] Control DB migrations…"
# Do NOT let a transient control-DB error (Neon compute-quota exhausted,
# pooler hiccup, network blip) turn boot into a crash-loop. A non-zero exit
# here kills the container, Coolify's restart policy relaunches it, and the
# migration retries on every restart — each attempt opening a new connection
# that burns MORE of whatever quota was already exhausted (observed 2026-05-31:
# ~10 retries hammering Neon after it hit its compute cap).
#
# Instead: try the migration, but if it fails, log loudly and BOOT ANYWAY. The
# schema is almost always already-applied (deploys are frequent, migrations
# rare), so the app serves fine from the existing schema. If the control DB is
# genuinely unreachable, requests fail later with a clear per-request error
# rather than a silent, quota-draining restart loop. Re-running a deploy once
# the DB is healthy applies any pending migration normally.
if npx prisma migrate deploy --schema prisma/control/schema.prisma; then
  echo "✓ [entrypoint] Control DB migrations applied."
else
  rc=$?
  echo "⚠ [entrypoint] Control DB migrate failed (exit $rc). Booting anyway —" >&2
  echo "  schema is likely already current. If this is a fresh/changed schema," >&2
  echo "  re-deploy once the control DB is reachable to apply pending migrations." >&2
fi

echo "▶ [entrypoint] Tenant DB migrations (parallel, advisory-locked)…"
# Tolerate per-tenant failures so the platform stays up — bad tenants get
# logged with their slug and we can fix them after start. A real outage
# (control DB unreachable) would already have failed step 1 above.
node --import tsx scripts/migrate-all-tenants.ts || \
  echo "⚠ [entrypoint] one or more tenant migrations had issues — see output above"

# ── Post-deploy CDN purge ────────────────────────────────────────────────────
# After a new build, JS chunk hashes change. Any storefront HTML still cached
# at the Cloudflare edge (anon edge-cache rule) points at the PREVIOUS deploy's
# chunk files, which no longer exist → visitors hit "Failed to load chunk".
# Purge the zone once the new server is live so the edge re-fills with HTML that
# references the NEW chunks. Backgrounded (a `&` child survives the exec below)
# with a short delay so `next start` is serving first. Fire-and-forget: a purge
# failure never blocks or crashes boot. Uses node's global fetch (curl isn't in
# the Alpine image). NB: also fires on plain restarts — harmless at this scale.
if [ "$NODE_ENV" = "production" ] && [ -n "${CLOUDFLARE_API_TOKEN:-}" ] && [ -n "${CLOUDFLARE_ZONE_ID:-}" ]; then
  (
    sleep 20
    node -e 'fetch(`https://api.cloudflare.com/client/v4/zones/${process.env.CLOUDFLARE_ZONE_ID}/purge_cache`,{method:"POST",headers:{Authorization:`Bearer ${process.env.CLOUDFLARE_API_TOKEN}`,"Content-Type":"application/json"},body:JSON.stringify({purge_everything:true})}).then(r=>r.json()).then(j=>console.log("[entrypoint] CF purge:",j.success?"ok":JSON.stringify(j.errors))).catch(e=>console.log("[entrypoint] CF purge error:",e.message))' \
      || echo "⚠ [entrypoint] post-deploy CF purge failed (non-fatal)"
  ) &
fi

echo "▶ [entrypoint] Starting Next.js (next start)…"
echo "▶ [entrypoint] PORT=${PORT:-3000}  HOSTNAME=${HOSTNAME:-0.0.0.0}"
# exec replaces this shell with the Node process; that process will print
# `✓ Ready in <ms>` once it's bound to the port and accepting connections.
exec "$@"
