# Monitoring — CD Ecom

Three self-hosted services watch this app in production:

| Service | What it watches | URL |
|---|---|---|
| **GlitchTip** | Runtime exceptions (server, edge, browser) — Sentry-protocol compatible | `https://glitchtip.shoutify.me` |
| **Uptime Kuma** | HTTP uptime + status of the app, GlitchTip, Soketi, control DB, tenant DBs | self-hosted |
| **Soketi** | Realtime / WebSocket transport for dashboard pushes — has built-in `/health` route | self-hosted |

---

## 1. GlitchTip — error tracking

GlitchTip speaks the Sentry wire protocol, so we use `@sentry/nextjs` with the DSN pointed at the GlitchTip instance. **Zero code coupling to Sentry SaaS** — it's a drop-in replacement.

### One-time setup

1. Log into **https://glitchtip.shoutify.me**.
2. Create a project named `cd-ecom-prod` (Platform: **Next.js**).
3. Copy the DSN it gives you. Format: `https://<publicKey>@glitchtip.shoutify.me/<projectId>`.
4. Add to the production `.env`:
   ```ini
   GLITCHTIP_DSN="https://abc...@glitchtip.shoutify.me/1"
   NEXT_PUBLIC_SENTRY_DSN="https://abc...@glitchtip.shoutify.me/1"
   ```
   Both values are identical — one is read on the server, the other ends up in the client bundle. DSNs are public-safe by design.
5. (Optional) Set `SENTRY_RELEASE` to the current git SHA so events group by release. `deploy.sh` can be extended to set this from `$(git rev-parse --short HEAD)`.
6. Restart PM2 (`npm run deploy` does this) — `pm2 reload --update-env` picks up the new env.

### What gets reported

- **Server runtime** — uncaught exceptions in API routes, server components, middleware, server actions. Configured in [instrumentation.ts](instrumentation.ts).
- **Edge runtime** — same, for any code running on the Edge runtime. Configured in [instrumentation.ts](instrumentation.ts).
- **Browser** — unhandled JS errors and promise rejections in customer browsers. Configured in [instrumentation-client.ts](instrumentation-client.ts).
- **Every event is auto-tagged with `tenant_slug` and `tenant_id`** — set by [src/lib/prisma-tenant.ts](src/lib/prisma-tenant.ts:96) on every request. Filter by tenant in the GlitchTip UI to see one tenant's errors in isolation.

### What's filtered out

These never reach GlitchTip — they're either control-flow exceptions or browser-extension noise:

- `NEXT_REDIRECT`, `NEXT_NOT_FOUND` (Next.js internals)
- `ResizeObserver loop limit exceeded` (browser quirk)
- `Failed to fetch` / `Load failed` / `NetworkError` (offline mobile users)
- `AbortError: The operation was aborted` (Safari aborting in-flight requests)

Edit the `ignoreErrors` arrays in `instrumentation*.ts` to extend.

### Sampling

- `tracesSampleRate: 0` — performance tracing is **off** by default. GlitchTip supports performance traces but they're high-volume and we don't have an APM use case yet. Bump to `0.01` (1%) on the server config if you want a sample.
- `replaysSessionSampleRate: 0` — session replay off; turn on only if your GlitchTip instance has replay storage configured.

### Verifying the wiring

After setting the DSN and redeploying, force a test error:

```bash
# From any browser console on the production site:
throw new Error("glitchtip smoke test — please ignore")

# From the server:
curl -X POST https://cdeadmin.contradigital.agency/api/_test-error  # if you add a test route
```

The event should appear in GlitchTip within ~10 seconds, tagged `tenant_slug:<your-tenant>`.

### What to do when GlitchTip itself goes down

The Sentry SDK queues events in memory and drops oldest-first when full. App requests are never blocked by GlitchTip unreachability — the SDK's transport is fire-and-forget. So a GlitchTip outage causes lost telemetry, **not** lost requests.

---

## 2. Uptime Kuma — uptime monitoring

Uptime Kuma pings HTTP endpoints on a schedule and notifies (Discord / Telegram / email) when something goes down.

### Recommended monitors

| Name | URL | Interval | Notes |
|---|---|---|---|
| `app-prod` | `https://cdeadmin.contradigital.agency/superadmin/login` | 60s | Public route, always available |
| `app-tenant-staging` | `https://staging.contradigital.agency/` | 60s | Catches tenant-resolution breaks |
| `glitchtip` | `https://glitchtip.shoutify.me/api/0/` | 5m | GlitchTip's own health |
| `soketi` | `https://soketi.your-host/usage` or `:9601` | 60s | Soketi's metrics endpoint |
| `cdn-worker` | `https://cdn.contradigital.agency/b/<known-bucket>/healthz.txt` | 5m | Place a 1-byte `healthz.txt` in a known bucket (e.g. `cd-t-staging`) |
| `r2-credentials` | (custom HTTP check via Cloudflare API) | 30m | Cheap way to detect a revoked R2 token |

### Multi-tenant tip

Add one monitor per **paying** tenant's domain. Kuma's status page can be public-shared if you want a customer-facing trust signal.

### Notifications

Wire to a Discord channel called `#alerts` or a Slack channel — anywhere you actually look. Pager email alone isn't enough; people miss email.

---

## 3. Soketi — realtime transport

Soketi is the Pusher-compatible WebSocket server that powers the dashboard's live updates. The app connects to it via `laravel-echo` + `pusher-js` (see existing real-time wiring).

### Health endpoints

| Endpoint | What it tells you |
|---|---|
| `GET /usage` (on the metrics port, default `9601`) | Active connections, channels, ops/sec |
| `GET /` (on the WS port, default `6001`) | Returns "OK" — basic liveness |

### Wire to Uptime Kuma

Point a monitor at `https://soketi.your-host/usage`. Expect JSON. Failed parse = down.

### Wire to GlitchTip (optional, via the broadcast client)

The client side already has Sentry wired — if a Soketi connection fails after `maxReconnectAttempts`, the existing reconnect-loop code will raise an error visible in GlitchTip with the `realtime.connection_failed` breadcrumb. No extra wiring needed.

### Troubleshooting

| Symptom | Likely cause |
|---|---|
| Dashboard "stale" indicator stays on | Soketi unreachable from browser — check WS port + TLS |
| `4001` close codes in console | App key mismatch between `.env` and the dashboard client |
| Memory creeping up on Soketi | Stale subscribers — restart Soketi nightly via cron is fine, it's stateless |

---

## Tenant-aware alerting

GlitchTip groups events by **fingerprint** (stack + message). When a single tenant hits a unique data condition that triggers an error, GlitchTip will group the error across tenants — which is what you want for "is this a code bug or a data bug?". But it also means:

- A flood of errors in one tenant doesn't drown out others (each event still has the tenant tag).
- You can build a custom GlitchTip query: `tag:tenant_slug:acme is:unresolved` to focus on one tenant during an incident.
- Recommended GlitchTip rule: **alert on first occurrence of any new error** (not on every occurrence) — otherwise a single broken tenant page spam-alerts.

---

## Related docs

- [DEPLOY.md](DEPLOY.md) — deployment workflow (GlitchTip env vars are picked up by `pm2 reload --update-env`)
- [instrumentation.ts](instrumentation.ts) — server/edge Sentry init
- [instrumentation-client.ts](instrumentation-client.ts) — browser Sentry init
- [src/lib/prisma-tenant.ts](src/lib/prisma-tenant.ts) — tenant tag enrichment
