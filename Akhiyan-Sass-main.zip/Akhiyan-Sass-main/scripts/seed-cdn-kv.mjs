#!/usr/bin/env node
/**
 * One-time seeder: register every existing tenant's R2 bucket name in the
 * Cloudflare KV namespace used by the CDN Worker (cloudflare/cdn-worker).
 *
 * The Worker refuses to serve any bucket NOT listed in KV (allowlist guard
 * against drive-by bucket enumeration). New tenants are auto-registered by
 * kvSetBucket() in src/lib/cloudflare-r2-admin.ts during provisioning;
 * this script handles the pre-existing rows after a Cloudflare account
 * migration where the KV namespace was recreated empty.
 *
 * Reads from `.env`:
 *   R2_ACCOUNT_ID                 — Cloudflare account id
 *   CLOUDFLARE_API_TOKEN          — token with Workers KV Storage:Edit
 *   CLOUDFLARE_KV_CDN_NAMESPACE_ID — KV namespace id (the one bound as
 *                                   BUCKET_MAP in cloudflare/cdn-worker/wrangler.toml)
 *
 * Usage:
 *   node scripts/seed-cdn-kv.mjs
 */
import { PrismaClient } from "../src/generated/prisma-control/index.js";
import dotenv from "dotenv";
dotenv.config();

const accountId = process.env.R2_ACCOUNT_ID;
const apiToken = process.env.CLOUDFLARE_API_TOKEN;
const kvId = process.env.CLOUDFLARE_KV_CDN_NAMESPACE_ID;

if (!accountId || !apiToken || !kvId) {
  console.error("missing env vars. need R2_ACCOUNT_ID, CLOUDFLARE_API_TOKEN, CLOUDFLARE_KV_CDN_NAMESPACE_ID");
  process.exit(1);
}

const c = new PrismaClient();
const tenants = await c.tenant.findMany({
  select: { slug: true, r2Bucket: true, r2PublicUrl: true },
});
console.log(`Found ${tenants.length} tenants in control DB`);

let ok = 0, skip = 0, fail = 0;
for (const t of tenants) {
  if (!t.r2Bucket) {
    console.log(`  SKIP ${t.slug} (no r2Bucket set)`);
    skip++;
    continue;
  }

  // Value is intentionally minimal — the Worker only checks for presence,
  // not the value. Store the public URL anyway so future tooling can use it.
  const value = t.r2PublicUrl || "1";

  const res = await fetch(
    `https://api.cloudflare.com/client/v4/accounts/${accountId}/storage/kv/namespaces/${kvId}/values/${encodeURIComponent(t.r2Bucket)}`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${apiToken}`,
        "Content-Type": "text/plain",
      },
      body: value,
    },
  );

  if (res.ok) {
    console.log(`  OK   ${t.slug.padEnd(20)} → ${t.r2Bucket}`);
    ok++;
  } else {
    const body = await res.text().catch(() => "");
    console.error(`  FAIL ${t.slug.padEnd(20)} → ${t.r2Bucket}  (${res.status} ${body.slice(0, 200)})`);
    fail++;
  }
}

console.log(`\n${ok} ok / ${skip} skip / ${fail} fail`);
await c.$disconnect();
process.exit(fail > 0 ? 1 : 0);
