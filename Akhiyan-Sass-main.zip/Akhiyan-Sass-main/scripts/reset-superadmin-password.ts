/**
 * Reset a superadmin's password (and optionally email).
 *
 * Why this exists: there's no self-service "forgot password" for super admins
 * — by design, since the account owns every tenant. If the password is lost
 * the only recovery path is direct DB access. This script wraps that safely:
 * it hashes the password before writing, never logs the plaintext, and
 * refuses to run without explicit creds.
 *
 * Usage (from the project root):
 *
 *   # Reset password only (keep current email)
 *   NEW_PASSWORD='your-new-password' \
 *     npx tsx scripts/reset-superadmin-password.ts admin@yourdomain.com
 *
 *   # Reset password AND change the email
 *   NEW_EMAIL=new@example.com \
 *   NEW_PASSWORD='your-new-password' \
 *     npx tsx scripts/reset-superadmin-password.ts old@example.com
 *
 *   # Find a superadmin by ID instead of email (use the # in front)
 *   NEW_PASSWORD='...' npx tsx scripts/reset-superadmin-password.ts '#1'
 *
 * Coolify usage: open the app's Terminal, then run the same command.
 * The CONTROL_DATABASE_URL env var is read automatically from the container.
 */
import { PrismaClient } from "../src/generated/prisma-control";
import bcrypt from "bcryptjs";

async function main() {
  const target = process.argv[2];
  const newPassword = process.env.NEW_PASSWORD;
  const newEmail = process.env.NEW_EMAIL;

  if (!target) {
    console.error("Usage: NEW_PASSWORD='...' npx tsx scripts/reset-superadmin-password.ts <email|#id>");
    process.exit(1);
  }
  if (!newPassword) {
    console.error("Missing NEW_PASSWORD env var.");
    console.error("Example: NEW_PASSWORD='secret123' npx tsx scripts/reset-superadmin-password.ts admin@example.com");
    process.exit(1);
  }
  if (newPassword.length < 8) {
    console.error("Password must be at least 8 characters.");
    process.exit(1);
  }
  if (!process.env.CONTROL_DATABASE_URL) {
    console.error("CONTROL_DATABASE_URL not set in env.");
    process.exit(1);
  }

  const cp = new PrismaClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });

  // Look up by id (if target starts with #) or by email.
  let existing;
  if (target.startsWith("#")) {
    const id = Number(target.slice(1));
    if (!Number.isFinite(id)) {
      console.error(`Invalid id: ${target}`);
      process.exit(1);
    }
    existing = await cp.superAdmin.findUnique({ where: { id } });
  } else {
    existing = await cp.superAdmin.findUnique({ where: { email: target.toLowerCase() } });
  }

  if (!existing) {
    console.error(`No superadmin found matching: ${target}`);
    console.error("Existing superadmins:");
    const all = await cp.superAdmin.findMany({ select: { id: true, email: true, name: true } });
    for (const sa of all) console.error(`  #${sa.id}  ${sa.email}  (${sa.name})`);
    process.exit(1);
  }

  // Hash with bcrypt cost 10 — matches the codebase convention.
  const hash = await bcrypt.hash(newPassword, 10);

  const data: { password: string; email?: string } = { password: hash };
  if (newEmail) {
    const normalized = newEmail.toLowerCase().trim();
    if (!normalized.includes("@")) {
      console.error(`NEW_EMAIL '${newEmail}' is not a valid email address.`);
      process.exit(1);
    }
    // Refuse if another superadmin already has that email.
    const clash = await cp.superAdmin.findUnique({ where: { email: normalized } });
    if (clash && clash.id !== existing.id) {
      console.error(`Another superadmin (#${clash.id}) already uses email ${normalized}.`);
      process.exit(1);
    }
    data.email = normalized;
  }

  const updated = await cp.superAdmin.update({
    where: { id: existing.id },
    data,
    select: { id: true, email: true, name: true, updatedAt: true },
  });

  console.log("✓ Reset complete:");
  console.log(JSON.stringify(updated, null, 2));
  console.log(`\nNote: existing browser sessions for this account stay valid until expiry.`);
  console.log(`The new credentials apply to the NEXT login attempt.`);

  await cp.$disconnect();
}

main().catch((e) => {
  console.error("Reset failed:", e);
  process.exit(1);
});
