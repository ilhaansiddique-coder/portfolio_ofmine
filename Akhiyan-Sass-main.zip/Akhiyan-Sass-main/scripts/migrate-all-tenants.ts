/**
 * Apply all checked-in `prisma/migrations/*` to every active tenant DB.
 *
 * Production-safe:
 *   • In-process (no spawn), so works regardless of node version / shell.
 *   • Per-tenant Postgres advisory lock prevents concurrent migrators on
 *     the same DB.
 *   • Each migration runs inside its own transaction with rollback-on-fail.
 *   • Tracks history in `_prisma_migrations` (Prisma-CLI compatible).
 *   • Continues past failures, reports a summary at the end, exits non-zero
 *     so CI catches it.
 *
 * Workflow when changing the tenant schema:
 *   1. Edit `prisma/schema.prisma`
 *   2. `npx prisma migrate dev --name <change>` (creates new migration file)
 *   3. `npm run db:migrate-all`              (applies to every tenant)
 *
 * Flags:
 *   --slug=acme        only that tenant
 *   --include-suspended  also migrate suspended tenants (default: skip)
 *   --concurrency=N    parallelism (default 4). Each tenant still serializes.
 *   --dry              list pending migrations per tenant, change nothing
 *
 * Run: npx tsx scripts/migrate-all-tenants.ts
 */
import { PrismaClient as ControlPrisma } from "../src/generated/prisma-control";
import { runTenantMigrations, listTenantMigrations } from "../src/lib/tenant-migrate";

const args = process.argv.slice(2);
const DRY = args.includes("--dry");
const INCLUDE_SUSPENDED = args.includes("--include-suspended");
const slugFilter = args.find((a) => a.startsWith("--slug="))?.slice(7);
const concurrency = Math.max(1, Number(args.find((a) => a.startsWith("--concurrency="))?.slice(14)) || 4);

interface Result {
  slug: string;
  applied: string[];
  skipped: string[];
  error?: string;
}

async function processOne(tenant: { slug: string; dbUrl: string }): Promise<Result> {
  const tag = tenant.slug;
  if (!tenant.dbUrl) {
    return { slug: tag, applied: [], skipped: [], error: "no dbUrl" };
  }
  if (DRY) {
    try {
      const history = await listTenantMigrations(tenant.dbUrl);
      const applied = history.filter((h) => h.finished_at !== null).map((h) => h.migration_name);
      console.log(`  ${tag}: ${applied.length} already applied (${applied.slice(-2).join(", ") || "—"})`);
      return { slug: tag, applied: [], skipped: applied };
    } catch (e) {
      return { slug: tag, applied: [], skipped: [], error: e instanceof Error ? e.message : String(e) };
    }
  }
  try {
    const r = await runTenantMigrations(tenant.dbUrl);
    const summary = r.applied.length === 0
      ? `up-to-date (${r.skipped.length} already applied)`
      : `+${r.applied.length} applied, ${r.skipped.length} already there`;
    console.log(`  ✓ ${tag}: ${summary}`);
    return { slug: tag, applied: r.applied, skipped: r.skipped };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.log(`  ✗ ${tag}: ${msg.slice(0, 200)}`);
    return { slug: tag, applied: [], skipped: [], error: msg };
  }
}

/** Worker pool — at most `concurrency` migrations in flight at once. */
async function pool<T, R>(items: T[], n: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(n, items.length) }, async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) break;
      out[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return out;
}

async function main() {
  const control = new ControlPrisma({ datasourceUrl: process.env.CONTROL_DATABASE_URL });

  const where = slugFilter
    ? { slug: slugFilter }
    : INCLUDE_SUSPENDED
      ? { status: { in: ["active", "suspended"] } }
      : { status: "active" };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const tenants = await control.tenant.findMany({
    where: where as any,
    select: { id: true, slug: true, name: true, dbUrl: true, status: true },
    orderBy: { id: "asc" },
  });
  await control.$disconnect();

  if (tenants.length === 0) { console.error("No tenants matched."); process.exit(1); }

  console.log(`${DRY ? "[dry] " : ""}Migrating ${tenants.length} tenant${tenants.length === 1 ? "" : "s"} (concurrency=${concurrency})…\n`);

  const results = await pool(tenants, concurrency, processOne);

  const ok = results.filter((r) => !r.error);
  const failed = results.filter((r) => r.error);
  const totalApplied = ok.reduce((n, r) => n + r.applied.length, 0);

  console.log(`\nDone. ${ok.length}/${tenants.length} tenants ok, ${totalApplied} migration step(s) applied across them.`);
  if (failed.length) {
    console.log(`\nFailures (${failed.length}):`);
    for (const f of failed) console.log(`  - ${f.slug}: ${f.error}`);
    process.exit(2);
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
