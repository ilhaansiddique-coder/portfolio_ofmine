// Simulate what the admin/landing-pages GET endpoint returns to the dashboard,
// passing through the same `serialize()` helper. Confirms whether `template`
// actually reaches the client.
import { PrismaClient as C } from "../src/generated/prisma-control/index.js";
import { PrismaClient as T } from "@prisma/client";
import dotenv from "dotenv"; dotenv.config();

function camelToSnake(s) { return s.replace(/[A-Z]/g, (l) => `_${l.toLowerCase()}`); }
function serialize(obj) {
  if (obj === null || obj === undefined) return obj;
  if (obj instanceof Date) return obj.toISOString();
  if (Array.isArray(obj)) return obj.map(serialize);
  if (typeof obj === "object") {
    const out = {};
    for (const [k, v] of Object.entries(obj)) {
      if (k.startsWith("_")) continue;
      out[camelToSnake(k)] = serialize(v);
    }
    return out;
  }
  return obj;
}

const c = new C();
const t = await c.tenant.findUnique({ where: { slug: "homeoprime" }, select: { dbUrl: true } });
await c.$disconnect();
const tdb = new T({ datasourceUrl: t.dbUrl });
const rows = await tdb.landingPage.findMany({ orderBy: { createdAt: "desc" } });
const serialized = rows.map(serialize);
console.log("rows returned:", serialized.length);
for (const r of serialized) {
  console.log(`  slug=${r.slug}  template=${r.template}  template_data?=${!!r.template_data}`);
}
await tdb.$disconnect();
