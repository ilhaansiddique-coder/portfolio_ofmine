import { PrismaClient as C } from "../src/generated/prisma-control/index.js";
import { PrismaClient as T } from "@prisma/client";
import dotenv from "dotenv"; dotenv.config();
const c = new C();
const tenants = await c.tenant.findMany({ select: { slug: true, dbUrl: true } });
await c.$disconnect();
for (const t of tenants) {
  if (!t.dbUrl) continue;
  const tdb = new T({ datasourceUrl: t.dbUrl });
  const rows = await tdb.landingPage.findMany({ select: { id: true, slug: true, title: true, template: true } });
  console.log(`\n=== Tenant: ${t.slug} ===`);
  rows.forEach(r => console.log(`  id=${r.id}  template=${r.template}  slug=${r.slug}  title=${r.title}`));
  await tdb.$disconnect();
}
