/**
 * Baseline existing tenant DBs onto the migration system.
 *
 * Run ONCE after upgrading from the old `db push` flow. Marks every active
 * tenant as having the initial migration applied (so the runner won't try
 * to re-apply CREATE TABLE statements against DBs that already have those
 * tables).
 *
 * Idempotent. Safe to re-run — uses INSERT ... ON CONFLICT DO NOTHING.
 *
 * Run: npx tsx scripts/baseline-tenants.ts
 */
import { PrismaClient as ControlPrisma } from "../src/generated/prisma-control";
import { markMigrationApplied } from "../src/lib/tenant-migrate";
import fs from "fs";
import path from "path";

async function main() {
  const migrationsDir = path.resolve(process.cwd(), "prisma", "migrations");
  const all = fs.readdirSync(migrationsDir, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
    .sort();
  if (all.length === 0) { console.error("No migrations to baseline."); process.exit(1); }

  const baseline = all[0];
  console.log(`Baselining tenants on migration: ${baseline}\n`);

  const control = new ControlPrisma({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
  const tenants = await control.tenant.findMany({
    select: { id: true, slug: true, dbUrl: true, status: true },
    orderBy: { id: "asc" },
  });
  await control.$disconnect();

  let ok = 0;
  for (const t of tenants) {
    if (!t.dbUrl) {
      console.log(`  - ${t.slug}: no dbUrl, skip`);
      continue;
    }
    try {
      await markMigrationApplied(t.dbUrl, baseline);
      console.log(`  ✓ ${t.slug} marked baselined`);
      ok++;
    } catch (e) {
      console.log(`  ✗ ${t.slug}: ${e instanceof Error ? e.message : e}`);
    }
  }
  console.log(`\n${ok}/${tenants.length} baselined.`);
}

main().catch((e) => { console.error(e); process.exit(1); });
