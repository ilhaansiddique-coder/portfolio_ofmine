/**
 * Codemod: rewrite API routes from global `prisma` singleton to per-request
 * tenant factory. Run: npx tsx scripts/refactor-prisma-routes.ts [--dry]
 *
 * For each .ts file under src/app/api/ that imports from "@/lib/prisma":
 *  1. Swap the import to `getPrismaForRequest` from "@/lib/prisma-tenant"
 *  2. For each top-level `export async function (GET|POST|PUT|PATCH|DELETE)(...)`:
 *      - Detect first param name (req / request / _req / _request / missing)
 *      - If underscore-prefixed, strip the underscore (now used)
 *      - If missing, inject `req: Request` as first param
 *      - Inject `const { prisma } = await getPrismaForRequest(<name>);` as
 *        the first statement in the function body
 *
 * Skips files where prisma is used outside handlers (closures, module-level
 * code) — emits a warning so we can fix them by hand.
 */
import fs from "fs";
import path from "path";

const ROOT = path.resolve(__dirname, "..");
const API_DIR = path.join(ROOT, "src", "app", "api");
const DRY = process.argv.includes("--dry");

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (entry.name === "route.ts") out.push(full);
  }
  return out;
}

const PRISMA_IMPORT_RE = /import\s+\{\s*prisma\s*\}\s+from\s+["']@\/lib\/prisma["'];?/;
const HANDLER_RE =
  /(export\s+async\s+function\s+(GET|POST|PUT|PATCH|DELETE)\s*\()([\s\S]*?)(\)\s*(?::\s*[^{]+)?\s*\{)/g;

function rewriteHandlerSignature(sigInner: string): { newInner: string; reqName: string } {
  const trimmed = sigInner.trim();
  if (trimmed === "") {
    return { newInner: "req: Request", reqName: "req" };
  }
  // Find first param name + type
  // Match: optionally _req or _request OR req/request, with optional type annotation
  const firstParamMatch = sigInner.match(/^(\s*)(_?)(req(?:uest)?)(\s*:[^,)]*)?/);
  if (!firstParamMatch) {
    // Param exists but is not a request var. Add req: Request before it.
    return {
      newInner: `req: Request, ${sigInner.trimStart()}`,
      reqName: "req",
    };
  }
  const [, leading, underscore, baseName, typeAnnot] = firstParamMatch;
  if (underscore) {
    // Strip underscore — we now use it
    const newInner = sigInner.replace(
      /^(\s*)_+(req(?:uest)?)/,
      `$1$2`
    );
    return { newInner, reqName: baseName };
  }
  // Already named correctly
  return { newInner: sigInner, reqName: baseName };
}

const warnings: string[] = [];
let filesChanged = 0;

for (const file of walk(API_DIR)) {
  let src = fs.readFileSync(file, "utf8");
  if (!PRISMA_IMPORT_RE.test(src)) continue;

  // 1. Swap import
  let newSrc = src.replace(
    PRISMA_IMPORT_RE,
    `import { getPrismaForRequest } from "@/lib/prisma-tenant";`
  );

  // 2. Rewrite handler signatures + inject prisma destructure
  newSrc = newSrc.replace(HANDLER_RE, (_match, prefix, _method, sigInner, suffix) => {
    const { newInner, reqName } = rewriteHandlerSignature(sigInner);
    const indent = "  ";
    const inject = `\n${indent}const { prisma } = await getPrismaForRequest(${reqName});`;
    return `${prefix}${newInner}${suffix}${inject}`;
  });

  // 3. Detect prisma uses outside any rewritten handler — warn (best-effort)
  // Check if `prisma.` appears in module-level scope (rough heuristic: top of file before first export)
  const beforeFirstHandler = newSrc.split(/^export\s+async\s+function/m)[0] || "";
  if (/\bprisma\./.test(beforeFirstHandler)) {
    warnings.push(`module-level prisma usage in ${path.relative(ROOT, file)}`);
  }

  if (newSrc === src) continue;
  filesChanged++;
  if (DRY) {
    console.log(`would change: ${path.relative(ROOT, file)}`);
  } else {
    fs.writeFileSync(file, newSrc, "utf8");
    console.log(`✓ ${path.relative(ROOT, file)}`);
  }
}

console.log(`\n${filesChanged} files ${DRY ? "would be" : ""} changed.`);
if (warnings.length) {
  console.log(`\nWarnings (manual review needed):`);
  warnings.forEach((w) => console.log(` - ${w}`));
}
