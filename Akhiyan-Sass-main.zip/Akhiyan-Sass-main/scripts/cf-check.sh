#!/usr/bin/env bash
set -e
ENV_FILE="/mnt/d/Ecommerce Portfolio/Akhiyan Sass/.env"
TOKEN=$(awk -F= '/^CLOUDFLARE_API_TOKEN=/ {sub(/^CLOUDFLARE_API_TOKEN=/,""); gsub(/"/,""); gsub(/^[ \t]+|[ \t\r]+$/,""); print; exit}' "$ENV_FILE")
echo "token len: ${#TOKEN}"

echo ""
echo "=== Verify token ==="
curl -sS "https://api.cloudflare.com/client/v4/user/tokens/verify" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"
echo ""

echo ""
echo "=== Zones ==="
ZONES=$(curl -sS "https://api.cloudflare.com/client/v4/zones?per_page=20" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json")
echo "$ZONES" | python3 -c "import sys,json; d=json.load(sys.stdin); [print(z['id'],z['name'],z['status']) for z in d.get('result',[])]" || echo "$ZONES" | head -c 800

# Pick the first zone (assume contradigital.agency); user can adjust
ZONE_ID=$(echo "$ZONES" | python3 -c "import sys,json; d=json.load(sys.stdin); rs=d.get('result',[]); print(rs[0]['id'] if rs else '')")
echo ""
echo "Using zone: $ZONE_ID"

echo ""
echo "=== Custom hostnames ==="
curl -sS "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/custom_hostnames?per_page=50" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  | python3 -c "
import sys,json
d=json.load(sys.stdin)
for h in d.get('result',[]):
    print('---')
    print('hostname:', h.get('hostname'))
    print('status:', h.get('status'))
    print('verification_errors:', h.get('verification_errors'))
    ssl=h.get('ssl',{}) or {}
    print('ssl.status:', ssl.get('status'))
    print('ssl.method:', ssl.get('method'))
    print('ssl.validation_errors:', ssl.get('validation_errors'))
    print('ssl.validation_records:', ssl.get('validation_records'))
    print('ownership_verification:', h.get('ownership_verification'))
    print('ownership_verification_http:', h.get('ownership_verification_http'))
"
