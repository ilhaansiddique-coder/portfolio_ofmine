#!/usr/bin/env node
/**
 * Apply pending Prisma migrations to ALL tenant databases.
 * If a migration is marked applied but its tables are missing, automatically
 * marks it rolled-back so it re-applies cleanly.
 */
import { PrismaClient as ControlClient } from "../src/generated/prisma-control/index.js";
import { execSync } from "child_process";
import dotenv from "dotenv";

dotenv.config();

const control = new ControlClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });

const tenants = await control.tenant.findMany({ select: { slug: true, dbUrl: true } });
console.log(`Found ${tenants.length} tenants`);

for (const t of tenants) {
  if (!t.dbUrl) { console.log(`SKIP ${t.slug} (no dbUrl)`); continue; }
  console.log(`\n=== Migrating ${t.slug} ===`);
  const env = { ...process.env, DATABASE_URL: t.dbUrl, DIRECT_URL: t.dbUrl };
  const run = (cmd) => execSync(cmd, { stdio: "inherit", env });
  const runCapture = (cmd) => execSync(cmd, { env, encoding: "utf8" });

  // First attempt
  try {
    run("npx prisma migrate deploy --schema prisma/schema.prisma");
    console.log(`OK ${t.slug}`);
    continue;
  } catch {}

  // If failed because a prior migration was marked applied but the table is missing,
  // mark it rolled-back and retry. Specifically detect "relation \"cms_pages\" does not exist".
  console.log("Attempting to repair migration history...");
  try {
    // Connect to tenant DB directly to check + clean migration history
    const { PrismaClient } = await import("@prisma/client");
    const tdb = new PrismaClient({ datasourceUrl: t.dbUrl });
    // Check if cms_pages exists
    const tableExists = await tdb.$queryRawUnsafe(
      `SELECT EXISTS (SELECT FROM pg_tables WHERE schemaname='public' AND tablename='cms_pages') as exists`
    );
    const exists = tableExists[0]?.exists;
    console.log(`  cms_pages table exists: ${exists}`);
    if (!exists) {
      // Mark add_cms_pages migration as rolled back so it re-runs
      await tdb.$executeRawUnsafe(
        `DELETE FROM "_prisma_migrations" WHERE migration_name LIKE '%add_cms_pages%' OR migration_name LIKE '%og_image_custom_css%'`
      );
      console.log("  Cleared cms_pages migration history rows");
    }
    await tdb.$disconnect();
  } catch (err) {
    console.error("  Repair failed:", err.message);
    continue;
  }

  // Retry
  try {
    run("npx prisma migrate deploy --schema prisma/schema.prisma");
    console.log(`OK ${t.slug} (after repair)`);
  } catch (err) {
    console.error(`FAIL ${t.slug}: ${err.message}`);
  }
}

await control.$disconnect();
