#!/usr/bin/env node
/**
 * Upload images + seed the "Piles Care" landing page for the homeoprime tenant.
 *
 * Reads images from /tmp/homioprime/, uploads them to the tenant's bucket
 * (R2 or local) using the same code paths as the dashboard upload route, then
 * creates the landingPage row pointing at those URLs.
 */
import { PrismaClient as ControlClient } from "../src/generated/prisma-control/index.js";
import { PrismaClient as TenantClient } from "@prisma/client";
import { readFile, mkdir, writeFile } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import sharp from "sharp";
import dotenv from "dotenv";

dotenv.config();

const TENANT_SLUG = "homeoprime";
const SRC_DIR = process.argv[2] || "/tmp/homioprime";

if (!existsSync(SRC_DIR)) {
  console.error(`Source dir not found: ${SRC_DIR}`);
  process.exit(1);
}

// Map of source file → friendly name used in the URL
const FILES = {
  "logo.jpeg": "hero-logo",
  "Doctors Image.jpeg": "doctor-photo",
  "Review 1.jpeg": "review-1",
  "review 2.jpeg": "review-2",
  "review 3.jpeg": "review-3",
  "review 4.jpeg": "review-4",
  "review 5.jpeg": "review-5",
};

const control = new ControlClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
const tenant = await control.tenant.findUnique({
  where: { slug: TENANT_SLUG },
  select: { id: true, slug: true, dbUrl: true, r2Bucket: true, r2PublicUrl: true },
});
if (!tenant) { console.error(`tenant ${TENANT_SLUG} not found`); process.exit(1); }
console.log(`tenant: ${tenant.slug} (id=${tenant.id})`);
console.log(`R2 bucket: ${tenant.r2Bucket || "(local fallback)"}`);

async function processImage(srcPath, basename) {
  const raw = await readFile(srcPath);
  const ext = path.extname(srcPath).toLowerCase();
  let buf = raw;
  let finalExt = ext;
  if ([".jpg", ".jpeg", ".png"].includes(ext)) {
    const img = sharp(raw);
    const meta = await img.metadata();
    if (meta.width && meta.width > 1920) img.resize(1920, null, { withoutEnlargement: true });
    buf = await img.webp({ quality: 80 }).toBuffer();
    finalExt = ".webp";
  }
  return { buf, name: `${basename}-${Date.now()}${finalExt}`, contentType: "image/webp" };
}

const uploadedUrls = {};

for (const [srcFile, friendly] of Object.entries(FILES)) {
  const srcPath = path.join(SRC_DIR, srcFile);
  if (!existsSync(srcPath)) { console.warn(`SKIP missing: ${srcFile}`); continue; }
  const { buf, name, contentType } = await processImage(srcPath, friendly);

  if (tenant.r2Bucket && tenant.r2PublicUrl) {
    const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");
    const s3 = new S3Client({
      region: "auto",
      endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
      credentials: {
        accessKeyId: process.env.R2_ACCESS_KEY_ID,
        secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
      },
    });
    await s3.send(new PutObjectCommand({
      Bucket: tenant.r2Bucket, Key: name, Body: buf,
      ContentType: contentType, CacheControl: "public, max-age=31536000, immutable",
    }));
    const baseUrl = tenant.r2PublicUrl.replace(/\/$/, "");
    uploadedUrls[friendly] = `${baseUrl}/${name}`;
    console.log(`  uploaded R2: ${uploadedUrls[friendly]}`);
  } else {
    const dir = path.join("public", "uploads", `tenant_${tenant.id}`);
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, name), buf);
    uploadedUrls[friendly] = `/uploads/tenant_${tenant.id}/${name}`;
    console.log(`  saved local: ${uploadedUrls[friendly]}`);
  }
}

console.log("\nAll uploaded URLs:");
console.log(JSON.stringify(uploadedUrls, null, 2));

// Now create the landing page in the tenant DB
const tdb = new TenantClient({ datasourceUrl: tenant.dbUrl });

const features = [
  { icon: "✓", title: "ব্লাড যাওয়া বন্ধ হবে", description: "ব্লাড যাওয়া বন্ধ হবে" },
  { icon: "✓", title: "গোটা শুকিয়ে যাবে", description: "গোটা শুকিয়ে যাবে, পুঁজ পড়া বন্ধ হবে" },
  { icon: "✓", title: "চুল-কামি ও জ্বালা-পোড়া বন্ধ", description: "চুল-কামি ও জ্বালা-পোড়া বন্ধ হবে" },
  { icon: "✓", title: "কোষ্ট-কাঠিন্য দূর", description: "কোষ্ট-কাঠিন্য দূর করবে" },
];

const howItWorks = [
  { title: "জার্মানি ফর্মুলায় তৈরী", description: "জার্মানি ফর্মুলায় তৈরী" },
  { title: "বাংলাদেশ সরকার অনুমোদিত", description: "বাংলাদেশ সরকার অনুমোদিত" },
  { title: "সরাসরি চেম্বারে আসার সুযোগ", description: "সরাসরি চেম্বারে আসার সুযোগ" },
  { title: "কোন পার্শ্বপ্রতিক্রিয়া নেই", description: "কোন পার্শ্বপ্রতিক্রিয়া নেই" },
  { title: "১২ হাজার মানুষের আস্থা", description: "১২ হাজার মানুষ ব্যবহার করে উপকার পেয়েছেন" },
];

const faq = [
  { question: "স্থায়ী ভাবে কি সুস্থ হবে?", answer: "শতভাগ নিশ্চিত, স্থায়ী সমাধান পাবেন ইনশাআল্লাহ।" },
  { question: "কতদিন খেতে হবে?", answer: "সাধারণত ৩০-৬০ দিন নিয়মিত সেবন করতে হয়, রোগের তীব্রতা অনুযায়ী ডাক্তারের পরামর্শ মতো।" },
  { question: "কোন পার্শ্বপ্রতিক্রিয়া আছে কি?", answer: "এই ঔষধ জার্মানি হোমিও ফর্মুলায় তৈরি, কোনো পার্শ্বপ্রতিক্রিয়া নেই।" },
];

const testimonials = [
  { name: "সন্তুষ্ট গ্রাহক ১", review: "পাইলস কেয়ার ব্যবহার করে অনেক উপকার পেয়েছি।", rating: 5, image: uploadedUrls["review-1"] || "" },
  { name: "সন্তুষ্ট গ্রাহক ২", review: "জ্বালাপোড়া বন্ধ হয়েছে, ডাক্তারকে ধন্যবাদ।", rating: 5, image: uploadedUrls["review-2"] || "" },
  { name: "সন্তুষ্ট গ্রাহক ৩", review: "নিয়মিত ব্যবহারে গোটা শুকিয়ে গেছে।", rating: 5, image: uploadedUrls["review-3"] || "" },
  { name: "সন্তুষ্ট গ্রাহক ৪", review: "কোষ্ঠকাঠিন্য দূর হয়েছে, পেট পরিষ্কার থাকে।", rating: 5, image: uploadedUrls["review-4"] || "" },
  { name: "সন্তুষ্ট গ্রাহক ৫", review: "পার্শ্বপ্রতিক্রিয়া ছাড়াই কাজ করেছে।", rating: 5, image: uploadedUrls["review-5"] || "" },
];

const guaranteeText = `ডাক্তার পরিচিতি: Dr. P.B Shuvo (Dmsh, DHC, Dhaka) — অভিজ্ঞতা ১২ বছর, ১২,০০০+ পেশেন্ট, ৩+ প্রতিষ্ঠান। চেম্বার: ইন্টারন্যাশনাল হোমিও, লালদিঘি, চট্টগ্রাম। ফোন: 01948810200`;

const sectionOrder = ["hero", "features", "how_it_works", "testimonials", "checkout"];
const sectionVisibility = { hero: true, problem: false, products: false, features: true, how_it_works: true, testimonials: true, faq: false, checkout: true };

const templateData = {
  doctorPhoto: uploadedUrls["doctor-photo"] || "",
  doctorName: "Dr. P.B Shuvo",
  doctorCredentials: ["DHMS, BHB (Dhaka)", "DHC (Dhaka)", "অভিজ্ঞতা ১২ বছর", "১২,০০০+ পেশেন্ট"],
  doctorRegNumber: "Register Doctor, Govt. Reg.",
  doctorRole: "Consultant (Homeo Medicine)",
  productImage: uploadedUrls["hero-logo"] || "",
  chamberHeading: "চেম্বারের ঠিকানা",
  chamberAddressLines: [
    "ইন্টারন্যাশনাল হোমিও",
    "লালদিঘি, চট্টগ্রাম",
    "ফ্রি পরামর্শের জন্য ফোন করুন",
  ],
  ctaButtonText: "অর্ডার করতে ক্লিক করুন",
  faqHeading: "প্রায়শই জিজ্ঞাসিত প্রশ্নাবলী",
};

const upsertData = {
    slug: "piles-care",
    title: "পাইলস কেয়ার - জার্মানি হোমিও ফর্মুলা",
    isActive: true,
    primaryColor: "#1a3a63",

    template: "akbd",
    templateData,

    heroHeadline: "জার্মানি ফর্মুলায় তৈরী",
    heroSubheadline: "পা'য়ু'পথের বিভিন্ন সমস্যার স্থায়ী ও কার্যকরী সমাধান।",
    heroImage: uploadedUrls["hero-logo"] || null,
    heroCta: "অর্ডার করতে ক্লিক করুন",
    heroBadge: "জার্মানি ফর্মুলায় তৈরী",

    featuresTitle: "আপনি যে উপকার পাবেন",
    featuresImage: uploadedUrls["doctor-photo"] || null,
    features: JSON.stringify(features),

    howItWorksTitle: "আমাদের থেকে কেনো নিবেন?",
    howItWorks: JSON.stringify(howItWorks),

    testimonialsTitle: "সম্মানিত গ্রাহকের মন্তব্য",
    testimonialsMode: "custom",
    testimonials: JSON.stringify(testimonials),

    faqTitle: "প্রায়শই জিজ্ঞাসিত প্রশ্নাবলী",
    faq: JSON.stringify(faq),

    checkoutTitle: "🛒 আপনার অর্ডার দিন এখনই",
    checkoutSubtitle: "নিচের ফরমটি পূরণ করে অর্ডারটি কনফার্ম করুন।",
    checkoutBtnText: "Place Order",
    customShipping: false,
    shippingCost: 80,
    showEmail: false,
    showCity: true,
    guaranteeText,

    whatsapp: "01948810200",
    contactMode: "phone",

    sectionOrder: JSON.stringify(sectionOrder),
    sectionVisibility: JSON.stringify(sectionVisibility),

    metaTitle: "পাইলস কেয়ার - জার্মানি হোমিও ফর্মুলা",
    metaDescription: "পাইলস, অর্শ্ব, ফিষ্টুলা ও এনাল ফিশারের বিশ্বস্ত সমাধান। সরকার অনুমোদিত ডাক্তার দ্বারা তৈরি।",
};

const created = await tdb.landingPage.upsert({
  where: { slug: "piles-care" },
  create: upsertData,
  update: upsertData,
});

console.log(`\nLanding page upserted: id=${created.id}  slug=${created.slug}`);
console.log(`View at: http://${tenant.slug}.localtest.me:3005/lp/${created.slug}`);

await tdb.$disconnect();
await control.$disconnect();
