/**
 * Dev warmer — pre-compiles every page Turbopack would otherwise compile
 * on first visit. Run alongside `next dev` so subsequent navigations are
 * instant.
 *
 * Strategy:
 *   1. Poll the server until ready
 *   2. Fire one request per route, in batches of 4 to avoid overwhelming
 *      the dev compiler
 *   3. Print timing so you can see where the slow routes are
 *
 * Cost: ~30s of background traffic on dev start. Saves the 5-30s wait the
 * first time you click any unwarmed link.
 */
const PORT = process.env.PORT || "3005";
const BASE = `http://localhost:${PORT}`;
const ADMIN_HOST = `cdeadmin.localtest.me:${PORT}`;
const TENANT_HOST = `localtest.me:${PORT}`;

const STOREFRONT_ROUTES = [
  "/",
  "/shop",
  "/checkout",
  "/contact",
  "/about",
  "/privacy",
  "/terms",
  "/refund",
  "/cdlogin",
  "/search",
];

const DASHBOARD_ROUTES = [
  "/dashboard",
  "/dashboard/products",
  "/dashboard/orders",
  "/dashboard/categories",
  "/dashboard/brands",
  "/dashboard/blog",
  "/dashboard/banners",
  "/dashboard/coupons",
  "/dashboard/customizer",
  "/dashboard/flash-sales",
  "/dashboard/reviews",
  "/dashboard/settings",
  "/dashboard/shipping",
  "/dashboard/users",
  "/dashboard/landing-pages",
  "/dashboard/menus",
  "/dashboard/feeds",
  "/dashboard/spam",
  "/dashboard/content/about",
  "/dashboard/content/header-footer",
];

const ADMIN_ROUTES = [
  "/", // → /superadmin (rewrite)
  "/login", // → /superadmin/login
  "/tenants",
  "/tenants/new",
  "/activity",
];

const API_ROUTES = [
  "/api/v1/health/tenant",
  "/api/v1/products",
  "/api/v1/categories",
  "/api/v1/brands",
  "/api/v1/banners",
  "/api/v1/settings",
  "/api/v1/checkout-settings",
];

interface Job { path: string; host: string; label: string }

async function ping({ path, host, label }: Job): Promise<{ label: string; status: number; ms: number; err?: string }> {
  const t = Date.now();
  try {
    const res = await fetch(`${BASE}${path}`, {
      headers: { Host: host, "User-Agent": "cd-ecom-dev-warmup" },
      redirect: "manual",
      // Turbopack first-compile of heavy pages can hit 60-90s on slow disks.
      // Bump way past that so warmup actually waits for compilation instead
      // of bailing.
      signal: AbortSignal.timeout(180_000),
    });
    return { label, status: res.status, ms: Date.now() - t };
  } catch (e) {
    return { label, status: 0, ms: Date.now() - t, err: e instanceof Error ? e.message : String(e) };
  }
}

async function waitReady(): Promise<void> {
  // 5 min — first health-endpoint hit triggers Turbopack compile + Neon
  // scale-from-zero, which together can take 30-90s on a cold dev start.
  const deadline = Date.now() + 300_000;
  process.stdout.write("[warmup] waiting for dev server");
  while (Date.now() < deadline) {
    try {
      const r = await fetch(`${BASE}/api/v1/health/tenant`, { signal: AbortSignal.timeout(120_000) });
      if (r.status < 500) {
        process.stdout.write(" ready\n");
        return;
      }
    } catch { /* not ready yet */ }
    process.stdout.write(".");
    await new Promise((r) => setTimeout(r, 2000));
  }
  process.stdout.write(" timeout\n");
}

async function runBatch(jobs: Job[], concurrency: number): Promise<void> {
  let i = 0;
  const workers = Array.from({ length: Math.min(concurrency, jobs.length) }, async () => {
    while (true) {
      const idx = i++;
      if (idx >= jobs.length) break;
      const r = await ping(jobs[idx]);
      const tag = r.err ? `✗ ${r.err.slice(0, 30)}` : `${r.status}`;
      const ms = r.ms.toString().padStart(5, " ");
      console.log(`  ${ms}ms ${tag.padEnd(8, " ")} ${r.label}`);
    }
  });
  await Promise.all(workers);
}

async function main() {
  await waitReady();
  const start = Date.now();

  const jobs: Job[] = [
    ...STOREFRONT_ROUTES.map((p) => ({ path: p, host: TENANT_HOST, label: `tenant ${p}` })),
    ...DASHBOARD_ROUTES.map((p) => ({ path: p, host: TENANT_HOST, label: `tenant ${p}` })),
    ...ADMIN_ROUTES.map((p) => ({ path: p, host: ADMIN_HOST, label: `admin  ${p}` })),
    ...API_ROUTES.map((p) => ({ path: p, host: TENANT_HOST, label: `api    ${p}` })),
  ];

  // Concurrency 1: Turbopack thrashes when multiple routes compile in parallel
  // — each one takes longer than running them sequentially. Slower wall-time
  // but actually completes.
  console.log(`[warmup] firing ${jobs.length} routes (sequential)…`);
  await runBatch(jobs, 1);

  console.log(`[warmup] done in ${((Date.now() - start) / 1000).toFixed(1)}s`);
}

main().catch((e) => {
  console.error("[warmup] error:", e);
  process.exit(1);
});
