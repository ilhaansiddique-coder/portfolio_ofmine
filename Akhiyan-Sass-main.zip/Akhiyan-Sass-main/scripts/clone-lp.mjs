#!/usr/bin/env node
/**
 * Clone an existing landing page row to a new slug.
 *
 * Usage:
 *   node scripts/clone-lp.mjs <tenant-slug> <source-slug> <new-slug> [new-title]
 *
 * Example:
 *   node scripts/clone-lp.mjs homeoprime piles-care piles-care-v2 "Piles Care v2"
 *
 * Copies every field except id/timestamps. Renders identically — same
 * template, same content. Edit via /dashboard/landing-pages afterward.
 */
import { PrismaClient as ControlClient } from "../src/generated/prisma-control/index.js";
import { PrismaClient as TenantClient } from "@prisma/client";
import dotenv from "dotenv";
dotenv.config();

const [tenantSlug, sourceSlug, newSlug, newTitleArg] = process.argv.slice(2);
if (!tenantSlug || !sourceSlug || !newSlug) {
  console.error("usage: node scripts/clone-lp.mjs <tenant> <source-slug> <new-slug> [new-title]");
  process.exit(1);
}

const c = new ControlClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
const tenant = await c.tenant.findUnique({ where: { slug: tenantSlug }, select: { id: true, slug: true, dbUrl: true } });
if (!tenant) { console.error(`tenant ${tenantSlug} not found`); process.exit(1); }
await c.$disconnect();

const tdb = new TenantClient({ datasourceUrl: tenant.dbUrl });

const src = await tdb.landingPage.findUnique({ where: { slug: sourceSlug } });
if (!src) { console.error(`landing page ${sourceSlug} not found in tenant ${tenantSlug}`); process.exit(1); }

// Build the clone payload — strip id + timestamps, override slug + title.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const { id, createdAt, updatedAt, ...rest } = src;
const data = {
  ...rest,
  slug: newSlug,
  title: newTitleArg || `${src.title} (copy)`,
};

const existing = await tdb.landingPage.findUnique({ where: { slug: newSlug } });
if (existing) { console.error(`slug ${newSlug} already exists (id=${existing.id}) — pick another`); process.exit(1); }

const created = await tdb.landingPage.create({ data });
console.log(`\n✓ Cloned landing page:`);
console.log(`  source: ${sourceSlug}  (id=${src.id})`);
console.log(`  new:    ${newSlug}     (id=${created.id})`);
console.log(`  title:  ${created.title}`);
console.log(`  template: ${created.template || "default"}`);
console.log(`\n  View at: https://${tenant.slug}.contradigital.agency/lp/${created.slug}`);
console.log(`  Local:   http://${tenant.slug}.localtest.me:3005/lp/${created.slug}`);
console.log(`  Edit at: /dashboard/landing-pages → ${created.title}`);

await tdb.$disconnect();
