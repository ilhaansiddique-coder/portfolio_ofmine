/**
 * One-shot codemod: add `broadcastToTenant(...)` calls before every
 * `return jsonResponse(...)` inside admin CRUD route POST/PUT/PATCH/DELETE
 * handlers, plus the `import` and `tenant` destructure. Idempotent.
 *
 * Run: npx tsx scripts/add-realtime-broadcasts.ts
 */
import fs from "fs";
import path from "path";

const ROOT = path.resolve(__dirname, "..");

const TARGETS: Record<string, string> = {
  "src/app/api/v1/admin/categories/route.ts": "categories",
  "src/app/api/v1/admin/categories/[id]/route.ts": "categories",
  "src/app/api/v1/admin/brands/route.ts": "brands",
  "src/app/api/v1/admin/brands/[id]/route.ts": "brands",
  "src/app/api/v1/admin/coupons/route.ts": "coupons",
  "src/app/api/v1/admin/coupons/[id]/route.ts": "coupons",
  "src/app/api/v1/admin/banners/route.ts": "banners",
  "src/app/api/v1/admin/banners/[id]/route.ts": "banners",
  "src/app/api/v1/admin/blog/route.ts": "blog",
  "src/app/api/v1/admin/blog/[id]/route.ts": "blog",
  "src/app/api/v1/admin/flash-sales/route.ts": "flash_sales",
  "src/app/api/v1/admin/flash-sales/[id]/route.ts": "flash_sales",
  "src/app/api/v1/admin/menus/route.ts": "menus",
  "src/app/api/v1/admin/menus/[id]/route.ts": "menus",
  "src/app/api/v1/admin/landing-pages/route.ts": "landing_pages",
  "src/app/api/v1/admin/landing-pages/[id]/route.ts": "landing_pages",
  "src/app/api/v1/admin/shipping/route.ts": "shipping",
  "src/app/api/v1/admin/shipping/[id]/route.ts": "shipping",
  "src/app/api/v1/admin/shortlinks/route.ts": "shortlinks",
  "src/app/api/v1/admin/shortlinks/[id]/route.ts": "shortlinks",
  "src/app/api/v1/admin/reviews/route.ts": "reviews",
  "src/app/api/v1/admin/reviews/[id]/route.ts": "reviews",
  "src/app/api/v1/admin/settings/route.ts": "settings",
  "src/app/api/v1/admin/spam/blocked-phones/route.ts": "spam",
  "src/app/api/v1/admin/spam/blocked-phones/[id]/route.ts": "spam",
  "src/app/api/v1/admin/spam/blocked-ips/route.ts": "spam",
  "src/app/api/v1/admin/spam/blocked-ips/[id]/route.ts": "spam",
  "src/app/api/v1/admin/spam/devices/[id]/route.ts": "spam",
};

const IMPORT_LINE = `import { broadcastToTenant } from "@/lib/realtime";`;
const SENTINEL = "/* @broadcast */";
const MUTATING = ["POST", "PUT", "PATCH", "DELETE"];

/**
 * Split a file into top-level chunks at `export async function NAME(`
 * boundaries. Returns header (everything before first handler) + handler
 * chunks. Each chunk starts with the export line.
 */
function splitHandlers(src: string): { header: string; chunks: { method: string; body: string }[] } {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const matches: { idx: number; method: string }[] = [];
  const re = /^export\s+async\s+function\s+(GET|POST|PUT|PATCH|DELETE)\b/gm;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) matches.push({ idx: m.index, method: m[1] });

  if (matches.length === 0) return { header: src, chunks: [] };

  const header = src.slice(0, matches[0].idx);
  const chunks: { method: string; body: string }[] = [];
  for (let i = 0; i < matches.length; i++) {
    const start = matches[i].idx;
    const end = i + 1 < matches.length ? matches[i + 1].idx : src.length;
    chunks.push({ method: matches[i].method, body: src.slice(start, end) });
  }
  return { header, chunks };
}

let touched = 0;

for (const [rel, resource] of Object.entries(TARGETS)) {
  const file = path.join(ROOT, rel);
  if (!fs.existsSync(file)) {
    console.warn(`miss: ${rel}`);
    continue;
  }
  const before = fs.readFileSync(file, "utf8");
  let src = before;

  // 1. Add import after `getPrismaForRequest` import line.
  if (!src.includes(IMPORT_LINE)) {
    src = src.replace(
      /(import\s+\{\s*getPrismaForRequest[^}]*\}\s+from\s+["']@\/lib\/prisma-tenant["'];?)/,
      `$1\n${IMPORT_LINE}`,
    );
  }

  const { header, chunks } = splitHandlers(src);
  if (chunks.length === 0) {
    if (src !== before) fs.writeFileSync(file, src, "utf8");
    continue;
  }

  // 2. For each MUTATING handler chunk: ensure `tenant` destructure + insert
  //    broadcast before each `return jsonResponse(...)` (skip already-injected).
  const newChunks = chunks.map((c) => {
    if (!MUTATING.includes(c.method)) return c.body;
    let body = c.body;
    body = body.replace(
      /const\s+\{\s*prisma\s*\}\s*=\s*await\s+getPrismaForRequest\(/g,
      "const { prisma, tenant } = await getPrismaForRequest(",
    );
    if (!body.includes(SENTINEL)) {
      body = body.replace(
        /return jsonResponse\(/g,
        `void broadcastToTenant(tenant.id, "${resource}", "changed", {}); ${SENTINEL} return jsonResponse(`,
      );
    }
    return body;
  });

  const next = header + newChunks.join("");
  if (next !== before) {
    fs.writeFileSync(file, next, "utf8");
    console.log(`✓ ${rel}`);
    touched++;
  } else {
    console.log(`= ${rel} (unchanged)`);
  }
}

console.log(`\n${touched} files touched.`);
