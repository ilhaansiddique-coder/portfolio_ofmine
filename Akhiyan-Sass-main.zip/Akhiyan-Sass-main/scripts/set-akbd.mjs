/**
 * Force a landing page row to use the akbd template, restoring template_data
 * with sensible defaults if missing.
 *
 * Usage: node scripts/set-akbd.mjs <tenant-slug> <lp-slug>
 */
import { PrismaClient as ControlClient } from "../src/generated/prisma-control/index.js";
import { PrismaClient as TenantClient } from "@prisma/client";
import dotenv from "dotenv";
dotenv.config();

const [tenantSlug, lpSlug] = process.argv.slice(2);
if (!tenantSlug || !lpSlug) {
  console.error("usage: node scripts/set-akbd.mjs <tenant-slug> <lp-slug>");
  process.exit(1);
}

const c = new ControlClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
const tenant = await c.tenant.findUnique({ where: { slug: tenantSlug }, select: { dbUrl: true, slug: true } });
await c.$disconnect();
if (!tenant) { console.error(`tenant ${tenantSlug} not found`); process.exit(1); }

const tdb = new TenantClient({ datasourceUrl: tenant.dbUrl });
const row = await tdb.landingPage.findUnique({ where: { slug: lpSlug } });
if (!row) { console.error(`lp ${lpSlug} not found`); process.exit(1); }

// Keep existing template_data if present, otherwise seed defaults so the
// akbd template has the doctor + chamber cards populated.
const existing = (typeof row.templateData === "string"
  ? JSON.parse(row.templateData || "{}")
  : (row.templateData || {})) || {};

// Try to parse heroImage / featuresImage as fallback doctor + product images.
const fallbackProduct = row.heroImage || "";
const fallbackDoctor = row.featuresImage || "";

const templateData = {
  doctor_photo: existing.doctor_photo || fallbackDoctor,
  doctor_name: existing.doctor_name || "Dr. P.B Shuvo",
  doctor_credentials: existing.doctor_credentials || [
    "DHMS, BHB (Dhaka)",
    "DHC (Dhaka)",
    "অভিজ্ঞতা ১২ বছর",
    "১২,০০০+ পেশেন্ট",
  ],
  doctor_reg_number: existing.doctor_reg_number || "Register Doctor, Govt. Reg.",
  doctor_role: existing.doctor_role || "Consultant (Homeo Medicine)",
  product_image: existing.product_image || fallbackProduct,
  chamber_heading: existing.chamber_heading || "চেম্বারের ঠিকানা",
  chamber_address_lines: existing.chamber_address_lines || [
    "ইন্টারন্যাশনাল হোমিও",
    "লালদিঘি, চট্টগ্রাম",
    "ফ্রি পরামর্শের জন্য ফোন করুন",
  ],
  cta_button_text: existing.cta_button_text || "অর্ডার করতে ক্লিক করুন",
  faq_heading: existing.faq_heading || "প্রায়শই জিজ্ঞাসিত প্রশ্নাবলী",
};

const updated = await tdb.landingPage.update({
  where: { slug: lpSlug },
  data: { template: "akbd", templateData },
});

console.log(`✓ ${tenant.slug}/lp/${lpSlug} → template=${updated.template}`);
console.log(`  template_data keys: ${Object.keys(templateData).join(", ")}`);
await tdb.$disconnect();
