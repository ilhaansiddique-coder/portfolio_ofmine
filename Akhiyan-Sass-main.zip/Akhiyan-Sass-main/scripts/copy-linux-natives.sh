#!/usr/bin/env bash
set -e
SRC=/home/nirob/akhiyan-sass/node_modules
DST="/mnt/d/Ecommerce Portfolio/Akhiyan Sass/node_modules"

mkdir -p "$DST/@unrs" "$DST/@next" "$DST/@esbuild" "$DST/@sentry" "$DST/@rollup" "$DST/@tailwindcss" "$DST/@img"

PACKAGES=(
  lightningcss-linux-x64-gnu
  lightningcss-linux-x64-musl
  @unrs/resolver-binding-linux-x64-musl
  @unrs/resolver-binding-linux-x64-gnu
  @next/swc-linux-x64-gnu
  @next/swc-linux-x64-musl
  @esbuild/linux-x64
  @sentry/cli-linux-x64
  @rollup/rollup-linux-x64-gnu
  @rollup/rollup-linux-x64-musl
  @tailwindcss/oxide-linux-x64-musl
  @tailwindcss/oxide-linux-x64-gnu
  @img/sharp-libvips-linux-x64
  @img/sharp-linux-x64
)

for p in "${PACKAGES[@]}"; do
  if [ -d "$SRC/$p" ] && [ ! -d "$DST/$p" ]; then
    cp -r "$SRC/$p" "$DST/$p"
    echo "  + $p"
  elif [ -d "$DST/$p" ]; then
    echo "  . $p (exists)"
  else
    echo "  ? $p (not in WSL)"
  fi
done
echo done
