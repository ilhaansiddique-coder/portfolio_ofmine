#!/usr/bin/env node
/**
 * Auto-sync Windows project → WSL on every change.
 *
 * Why this exists: the dev runtime lives in WSL (~/akhiyan-sass) but editing
 * happens on the Windows-side checkout. Without this, Next.js dev in WSL
 * runs stale code after every edit. Run this in a dedicated terminal:
 *
 *     npm run sync:wsl
 *
 * What it does:
 *   1. On startup, runs a one-shot `rsync` so the two trees are in sync
 *      before watching (catches any drift since the last run).
 *   2. Then watches the project recursively and mirrors each create /
 *      change / delete to WSL with `wsl cp` / `wsl rm`.
 *
 * Ignores everything that shouldn't be synced (node_modules, .next, .git,
 * lock files generated inside WSL, etc.). Edit IGNORE to tune.
 *
 * Notes:
 *   - Uses fs.watch({recursive:true}) which is native + cheap on Windows.
 *   - A 200ms debounce coalesces editor save-storms (VS Code writes a
 *     tempfile + rename, which fires multiple events for one save).
 *   - WSL distro defaults to whatever `wsl` resolves to. Override with
 *     SYNC_WSL_DISTRO=Ubuntu or similar.
 */
import { watch, existsSync } from "node:fs";
import { spawn, spawnSync } from "node:child_process";
import { join, sep } from "node:path";

const ROOT = process.cwd();
const WSL_DEST = process.env.SYNC_WSL_DEST || "/home/nirob/akhiyan-sass";
const WSL_DISTRO = process.env.SYNC_WSL_DISTRO || "";

// Anything matching ANY path segment listed here is skipped.
const IGNORE = new Set([
  "node_modules",
  ".next",
  ".git",
  ".turbo",
  ".vercel",
  ".wrangler",
  ".stfolder",
  ".stignore",
  ".vscode",
  ".idea",
  "coverage",
  "dist",
  "build",
  "out",
  // Junk from sync conflicts / OS metadata
  "Thumbs.db",
  ".DS_Store",
]);

// Files whose names START with these prefixes are skipped too (Syncthing
// temp files, vim swap files, etc.)
const IGNORE_PREFIX = [".sync-conflict-", ".~", "~$"];
const IGNORE_SUFFIX = [".swp", ".swo", ".tmp", "~"];

// ── helpers ──────────────────────────────────────────────────────────────────
function wslArgs(cmd) {
  return WSL_DISTRO ? ["-d", WSL_DISTRO, "bash", "-c", cmd] : ["bash", "-c", cmd];
}

function shellEscape(s) {
  return `'${String(s).replace(/'/g, `'\\''`)}'`;
}

function winToWslMount(absWinPath) {
  // C:\foo\bar  →  /mnt/c/foo/bar
  const drive = absWinPath[0].toLowerCase();
  const rest = absWinPath.slice(2).replace(/\\/g, "/");
  return `/mnt/${drive}${rest}`;
}

function ignored(rel) {
  const parts = rel.split(/[\\/]/);
  for (const p of parts) {
    if (IGNORE.has(p)) return true;
    if (IGNORE_PREFIX.some((pre) => p.startsWith(pre))) return true;
    if (IGNORE_SUFFIX.some((suf) => p.endsWith(suf))) return true;
  }
  return false;
}

// ── initial full sync via rsync ──────────────────────────────────────────────
function initialRsync() {
  const wslSrc = winToWslMount(ROOT) + "/";
  const wslDest = WSL_DEST.replace(/\/+$/, "") + "/";
  const excludes = [
    "node_modules",
    ".next",
    ".git",
    ".turbo",
    ".vercel",
    ".wrangler",
    ".stfolder",
    ".vscode",
    ".idea",
    "coverage",
    "dist",
    "build",
    "out",
  ]
    .map((p) => `--exclude=${p}`)
    .join(" ");

  const cmd = `mkdir -p ${shellEscape(WSL_DEST)} && rsync -a --delete ${excludes} ${shellEscape(wslSrc)} ${shellEscape(wslDest)}`;
  console.log(`[sync] initial rsync → ${WSL_DEST} …`);
  const t0 = Date.now();
  const r = spawnSync("wsl", wslArgs(cmd), { stdio: "inherit" });
  if (r.status === 0) {
    console.log(`[sync] initial rsync done in ${Date.now() - t0}ms`);
  } else {
    console.error(`[sync] initial rsync FAILED (exit ${r.status}). Continuing — watch will still mirror changes.`);
  }
}

// ── per-change mirror ────────────────────────────────────────────────────────
const queue = new Map(); // rel → 1
let timer = null;

function schedule(rel) {
  if (!rel) return;
  if (ignored(rel)) return;
  queue.set(rel, 1);
  if (!timer) timer = setTimeout(flush, 200);
}

function flush() {
  timer = null;
  if (queue.size === 0) return;
  const items = [...queue.keys()];
  queue.clear();

  // Group create/update vs delete so we can batch them into a single
  // shell invocation. wsl bash startup is ~80ms; avoiding N invocations
  // for a multi-file save matters.
  const toCopy = [];
  const toDelete = [];
  for (const rel of items) {
    const winAbs = join(ROOT, rel);
    if (existsSync(winAbs)) toCopy.push(rel);
    else toDelete.push(rel);
  }

  const lines = [];
  for (const rel of toCopy) {
    const winAbs = join(ROOT, rel);
    const src = winToWslMount(winAbs);
    const dest = `${WSL_DEST}/${rel.split(sep).join("/")}`;
    lines.push(`mkdir -p ${shellEscape(dest.replace(/\/[^/]+$/, ""))} && cp -r ${shellEscape(src)} ${shellEscape(dest)}`);
  }
  for (const rel of toDelete) {
    const dest = `${WSL_DEST}/${rel.split(sep).join("/")}`;
    lines.push(`rm -rf ${shellEscape(dest)}`);
  }

  if (lines.length === 0) return;
  const cmd = lines.join(" && ");
  const child = spawn("wsl", wslArgs(cmd), { stdio: ["ignore", "ignore", "pipe"] });
  let err = "";
  child.stderr.on("data", (d) => { err += d.toString(); });
  child.on("close", (code) => {
    if (code === 0) {
      const sample = items.slice(0, 3).join(", ") + (items.length > 3 ? `, …(+${items.length - 3})` : "");
      console.log(`[sync] ✓ ${items.length} item${items.length === 1 ? "" : "s"}: ${sample}`);
    } else {
      console.error(`[sync] ✗ exit ${code}: ${err.trim().split("\n").slice(0, 3).join(" | ")}`);
    }
  });
}

// ── start ────────────────────────────────────────────────────────────────────
console.log(`[sync] root:   ${ROOT}`);
console.log(`[sync] wsl:    ${WSL_DEST}`);
console.log(`[sync] distro: ${WSL_DISTRO || "(default)"}`);
initialRsync();
console.log(`[sync] watching for changes… (Ctrl-C to stop)`);

try {
  watch(ROOT, { recursive: true }, (_event, filename) => schedule(filename));
} catch (e) {
  console.error(`[sync] fs.watch failed:`, e);
  process.exit(1);
}

// Keep the process alive
process.on("SIGINT", () => {
  console.log(`\n[sync] stopped.`);
  process.exit(0);
});
