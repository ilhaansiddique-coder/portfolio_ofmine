# Neon → Coolify Postgres migration runbook

Goal: move CD-Ecom off Neon's compute-hour quota onto the self-hosted Coolify
Postgres. Order: **control DB first (prove it), then tenant DBs one-by-one**,
with verification between each. The live customer (`buets`) goes near the end,
after a throwaway tenant proves the path.

Neon **reads still work** under the quota — only new compute/migrations are
blocked — so dumps are fine. The Coolify Postgres is exposed on a **public
port** (you toggled this) so the dev machine can drive everything.

## 0. Prereqs (one-time)

- PostgreSQL 17 client installed (✓ `C:\Program Files\PostgreSQL\17\bin`).
- Add to local `.env` (NOT committed):
  ```
  COOLIFY_PG_ADMIN_URL="postgresql://postgres:<pw>@<vps-host>:<public-port>/postgres?sslmode=disable"
  # What the RUNNING app (inside Docker) should use at runtime — internal host:
  COOLIFY_PG_PUBLIC_HOST="cdecom-pgbouncer"
  COOLIFY_PG_PUBLIC_PORT="6432"
  ```
  `COOLIFY_PG_ADMIN_URL` = the PUBLIC url you just exposed (for migration).
  The `PUBLIC_HOST/PORT` = the INTERNAL url the app stores on each tenant row.

## 1. Control DB

```powershell
# a. Create the control DB on Coolify (psql, one-time):
& "C:\Program Files\PostgreSQL\17\bin\psql.exe" "$env:COOLIFY_PG_ADMIN_URL" -c "CREATE DATABASE cd_ecom_control;"

# b. Dump Neon control → restore into Coolify control + verify:
$neon    = "<CONTROL_DATABASE_URL from .env>"
$coolify = "postgresql://postgres:<pw>@<vps-host>:<public-port>/cd_ecom_control?sslmode=disable"
.\migrate-db.ps1 -Src $neon -Dst $coolify -Label control            # dry run
.\migrate-db.ps1 -Src $neon -Dst $coolify -Label control -Restore   # real

# c. Cutover (Coolify env panel) — point control at the new DB:
#    CONTROL_DATABASE_URL = postgresql://postgres:<pw>@cdecom-pgbouncer:6432/cd_ecom_control?sslmode=disable&pgbouncer=true
#    CONTROL_DIRECT_URL   = postgresql://postgres:<pw>@<internal-pg-host>:5432/cd_ecom_control?sslmode=disable
#    Redeploy. Entrypoint runs `prisma migrate deploy` (already-applied = no-op),
#    app boots, tenants resolve from Coolify control. Neon quota no longer on the path.
```

## 2. Tenant DBs (repeat per slug; throwaway first, buets near the end)

Order suggestion: `test` → `dev` → `ahalan` → `demo` → `oclp` → `oneclickshop`
→ `homeoprime` → **`buets` last**.

```powershell
# a. Provision an empty Coolify DB for the slug:
npx tsx scripts/migration/provision-and-repoint.ts provision <slug>
#    → prints DIRECT url, saves dumps/<slug>.url.json

# b. Migrate data (Neon tenant → the new Coolify DB). DST = the DIRECT url
#    from step a, but with the PUBLIC host:port swapped in for migration:
$src = "<that tenant's Neon dbUrl>"
$dst = "postgresql://<slug>_user:<pw>@<vps-host>:<public-port>/cd_ecom_<slug>?sslmode=disable"
.\migrate-db.ps1 -Src $src -Dst $dst -Label <slug>            # dry run
.\migrate-db.ps1 -Src $src -Dst $dst -Label <slug> -Restore   # real

# c. Repoint the control row to Coolify (runtime internal url):
npx tsx scripts/migration/provision-and-repoint.ts repoint <slug>

# d. VERIFY LIVE: open the tenant's storefront, place a test action, check
#    dashboard loads. Only then move to the next slug.
```

## 3. After all migrated

- `provision-and-repoint.ts show` → every tenant should read `provider=coolify`.
- Set `DEFAULT_DB_PROVIDER=coolify` so NEW tenants never touch Neon.
- Keep Neon DBs ~1 week as a fallback, then delete the Neon projects.
- Re-close the public Postgres port (or firewall to your IP).

## Safety notes
- `migrate-db.ps1` restore is `--single-transaction` → all-or-nothing, never
  a half-migrated tenant.
- Source (Neon) is only ever READ. Nothing on Neon is modified.
- Dumps + `*.url.json` hold live data/creds → gitignored, never committed.
- Don't repoint a tenant until its `migrate-db` verify passed.
