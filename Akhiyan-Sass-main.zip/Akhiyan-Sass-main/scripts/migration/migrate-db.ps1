<#
.SYNOPSIS
  Migrate a single Postgres database from Neon -> Coolify Postgres using
  pg_dump / pg_restore (PostgreSQL 17 client, already installed).

.DESCRIPTION
  Used to move CD-Ecom off Neon's compute-hour quota. Handles ONE database
  per invocation so each step is verifiable. Neon reads still work under the
  quota, so the dump side is fine.

  Flow:
    1. pg_dump SRC  -> a local custom-format .dump file (schema + data)
    2. (restore) pg_restore that file INTO the pre-created DST database
    3. Compares table counts between SRC and DST

  The DST database MUST already exist (created by provision-coolify-db.ps1
  or `prisma migrate deploy`). pg_restore does NOT create the database.

.PARAMETER Src
  Source connection URL (Neon). Read-only — never modified.

.PARAMETER Dst
  Destination connection URL (Coolify, DIRECT host — NOT pgbouncer:6432;
  restore needs a session connection, the bouncer transaction pool breaks it).

.PARAMETER Label
  Short name for the dump file + logs (e.g. "control", "buets").

.PARAMETER Restore
  Without this switch the script only DUMPS + shows a plan (dry run for the
  write side). With it, it also restores into DST and verifies.

.EXAMPLE
  # Dry run (dump only):
  .\migrate-db.ps1 -Src $neon -Dst $coolify -Label buets

  # Real migration:
  .\migrate-db.ps1 -Src $neon -Dst $coolify -Label buets -Restore
#>
param(
  [Parameter(Mandatory = $true)][string]$Src,
  [Parameter(Mandatory = $true)][string]$Dst,
  [Parameter(Mandatory = $true)][string]$Label,
  [switch]$Restore
)

$ErrorActionPreference = "Stop"
$pgbin = "C:\Program Files\PostgreSQL\17\bin"
$pg_dump = Join-Path $pgbin "pg_dump.exe"
$pg_restore = Join-Path $pgbin "pg_restore.exe"
$psql = Join-Path $pgbin "psql.exe"
$env:PGCONNECT_TIMEOUT = "30"

$outDir = Join-Path $PSScriptRoot "dumps"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$dumpFile = Join-Path $outDir "$Label.dump"

function Mask([string]$u) { return ($u -replace '(://[^:]+:)[^@]+@', '$1***@') }

Write-Host ""
Write-Host "=== Migrate DB: $Label ===" -ForegroundColor Cyan
Write-Host ("SRC : " + (Mask $Src))
Write-Host ("DST : " + (Mask $Dst))
Write-Host ("Mode: " + $(if ($Restore) { "DUMP + RESTORE + VERIFY" } else { "DUMP ONLY (dry run)" }))
Write-Host ""

# 1. DUMP (custom format -Fc: compressed, lets pg_restore reorder for FKs).
#    --no-owner / --no-acl: the Coolify DB has a different owner role, so we
#    strip ownership + grants and let the restore run as the DST user.
Write-Host "-> Dumping SRC ..." -ForegroundColor Yellow
& $pg_dump --format=custom --no-owner --no-acl --file="$dumpFile" "$Src"
if ($LASTEXITCODE -ne 0) { throw "pg_dump failed (exit $LASTEXITCODE)" }
$size = [math]::Round((Get-Item $dumpFile).Length / 1KB, 1)
Write-Host ("   dump OK -> $dumpFile ($size KB)") -ForegroundColor Green

# Source table counts (for verification later).
$countSql = @"
SELECT relname, n_live_tup
FROM pg_stat_user_tables
ORDER BY relname;
"@
Write-Host "-> Reading SRC table counts ..." -ForegroundColor Yellow
$srcCounts = & $psql "$Src" -t -A -F "|" -c $countSql
Write-Host ("   " + ($srcCounts | Measure-Object).Count + " tables in SRC")

if (-not $Restore) {
  Write-Host ""
  Write-Host "DRY RUN complete. Dump saved. Re-run with -Restore to write into DST." -ForegroundColor Cyan
  Write-Host ""
  exit 0
}

# 2. RESTORE into the (already-created, possibly-migrated) DST.
#    --clean --if-exists: drop existing objects first so a re-run is idempotent.
#    --no-owner --no-acl: same reasoning as the dump.
#    --single-transaction: all-or-nothing; a failure rolls back, never a
#    half-migrated tenant.
Write-Host "-> Restoring into DST ..." -ForegroundColor Yellow
& $pg_restore --clean --if-exists --no-owner --no-acl --single-transaction --dbname="$Dst" "$dumpFile"
if ($LASTEXITCODE -ne 0) { throw "pg_restore failed (exit $LASTEXITCODE) — DST rolled back, nothing changed." }
Write-Host "   restore OK" -ForegroundColor Green

# 3. VERIFY — compare table counts SRC vs DST.
Write-Host "-> Verifying counts ..." -ForegroundColor Yellow
$dstCounts = & $psql "$Dst" -t -A -F "|" -c $countSql

$srcMap = @{}; foreach ($l in $srcCounts) { if ($l) { $p = $l.Split("|"); $srcMap[$p[0]] = $p[1] } }
$dstMap = @{}; foreach ($l in $dstCounts) { if ($l) { $p = $l.Split("|"); $dstMap[$p[0]] = $p[1] } }
$allTables = ($srcMap.Keys + $dstMap.Keys | Select-Object -Unique | Sort-Object)
$mismatch = $false
foreach ($t in $allTables) {
  $s = if ($srcMap.ContainsKey($t)) { [int]$srcMap[$t] } else { 0 }
  $d = if ($dstMap.ContainsKey($t)) { [int]$dstMap[$t] } else { 0 }
  # pg_stat live-tup is approximate; flag only when clearly off.
  $ok = ($s -eq $d) -or ([math]::Abs($s - $d) -le [math]::Max(1, [int]($s * 0.02)))
  if (-not $ok) { $mismatch = $true }
  $mark = if ($ok) { "OK " } else { "!! " }
  Write-Host ("   $mark {0,-26} src={1,-7} dst={2}" -f $t, $s, $d)
}
Write-Host ""
if ($mismatch) {
  Write-Host "VERIFY: count mismatch — investigate before repointing tenant.dbUrl." -ForegroundColor Red
  exit 1
}
Write-Host "VERIFY: counts match. Migration of '$Label' complete." -ForegroundColor Green
Write-Host ""
