/**
 * provision-and-repoint.ts — companion to migrate-db.ps1.
 *
 * Two subcommands for the Neon -> Coolify tenant-DB migration:
 *
 *   provision <slug>
 *     Creates an EMPTY cd_ecom_<slug> database + role on the Coolify Postgres
 *     (reusing the app's createTenantCoolifyDatabase helper). Prints the new
 *     DIRECT url (for pg_restore) and the pooled url (for tenant.dbUrl). Does
 *     NOT touch the control row yet — migrate the data first, then repoint.
 *
 *   repoint <slug>
 *     Flips the control tenant row to the Coolify DB: sets dbUrl=<pooled>,
 *     dbProvider='coolify'. Reads the url it printed at provision time from
 *     scripts/migration/dumps/<slug>.url.json. Run this ONLY after migrate-db
 *     verified the data copied.
 *
 *   show
 *     Lists every tenant + current provider/host (sanity check).
 *
 * Requires (local .env):
 *   CONTROL_DATABASE_URL          — Neon control (reads/writes work; only new
 *                                   COMPUTE is quota-blocked, updates are fine)
 *   COOLIFY_PG_ADMIN_URL          — the PUBLIC Coolify Postgres admin url you
 *                                   just exposed (superuser @ postgres db)
 *   COOLIFY_PG_PUBLIC_HOST/PORT   — optional; what tenant.dbUrl should advertise
 *                                   at RUNTIME (the internal cdecom-pgbouncer:6432).
 *                                   The app runs inside Docker, so its stored
 *                                   url must use the INTERNAL host, not the
 *                                   public one we use for migration.
 */

import { writeFileSync, readFileSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { controlPrisma } from "../../src/lib/prisma-control";
import { createTenantCoolifyDatabase } from "../../src/lib/coolify-postgres";

const DUMP_DIR = join(__dirname, "dumps");
if (!existsSync(DUMP_DIR)) mkdirSync(DUMP_DIR, { recursive: true });

function mask(u?: string | null): string {
  if (!u) return "(none)";
  return u.replace(/(:\/\/[^:]+:)[^@]+@/, "$1***@");
}

async function show() {
  const ts = await controlPrisma.tenant.findMany({
    select: { id: true, slug: true, dbProvider: true, dbUrl: true } as any,
    orderBy: { id: "asc" },
  });
  for (const t of ts as any[]) {
    console.log(`#${t.id} ${t.slug.padEnd(14)} ${(t.dbProvider ?? "?").padEnd(8)} ${mask(t.dbUrl)}`);
  }
}

async function provision(slug: string) {
  if (!slug) throw new Error("usage: provision <slug>");
  console.log(`Provisioning Coolify DB for "${slug}" ...`);

  // Use the app helper to CREATE the db + user + grants (the valuable part).
  // Its returned URLs bake in a pgbouncer assumption that doesn't match this
  // standalone Postgres, so we DON'T use them — we rebuild clean DIRECT URLs
  // from the password it generated (extracted from the returned url).
  const created = await createTenantCoolifyDatabase({ tenantSlug: slug });
  const pw = new URL(created.directUrl).password;
  const user = created.username;
  const db = created.databaseName;

  // PUBLIC host:port → used by pg_restore from dev (migration side).
  const PUB = process.env.MIG_PUBLIC_HOSTPORT || "72.61.227.4:5544";
  // INTERNAL host:port → what the RUNTIME app (inside Docker) stores + uses.
  // Direct Postgres for now; pgbouncer swap happens after migration.
  const INT = process.env.MIG_INTERNAL_HOSTPORT || "a11u7bdg957nfdmmjihqwxqi:5432";

  const restoreUrl = `postgresql://${user}:${pw}@${PUB}/${db}?sslmode=disable`;
  const runtimeUrl = `postgresql://${user}:${pw}@${INT}/${db}?sslmode=disable`;

  const rec = { slug, databaseName: db, username: user, restoreUrl, runtimeUrl };
  writeFileSync(join(DUMP_DIR, `${slug}.url.json`), JSON.stringify(rec, null, 2));
  console.log("  databaseName            : " + db);
  console.log("  RESTORE target (public) : " + restoreUrl.replace(pw, "***"));
  console.log("  RUNTIME dbUrl (internal): " + runtimeUrl.replace(pw, "***"));
  console.log(`  saved -> dumps/${slug}.url.json`);
}

async function repoint(slug: string) {
  if (!slug) throw new Error("usage: repoint <slug>");
  const path = join(DUMP_DIR, `${slug}.url.json`);
  if (!existsSync(path)) throw new Error(`No ${slug}.url.json — run provision first.`);
  const rec = JSON.parse(readFileSync(path, "utf8"));
  const tenant = await controlPrisma.tenant.findFirst({ where: { slug } });
  if (!tenant) throw new Error(`tenant ${slug} not found`);
  const runtimeUrl = rec.runtimeUrl || rec.pooledUrl; // back-compat
  const before = (tenant as any).dbUrl;
  await controlPrisma.tenant.update({
    where: { id: tenant.id },
    data: { dbUrl: runtimeUrl, dbProvider: "coolify" } as any,
  });
  console.log(`Repointed ${slug}:`);
  console.log("  was: " + mask(before));
  console.log("  now: " + mask(runtimeUrl) + "  (provider=coolify)");
  console.log("  Keep the Neon DB until you've confirmed the live store works.");
}

(async () => {
  const [cmd, arg] = process.argv.slice(2);
  try {
    if (cmd === "show") await show();
    else if (cmd === "provision") await provision(arg);
    else if (cmd === "repoint") await repoint(arg);
    else {
      console.log("Commands: show | provision <slug> | repoint <slug>");
      process.exit(1);
    }
  } finally {
    await controlPrisma.$disconnect();
  }
})().catch((e) => { console.error("✗ " + (e?.message || e)); process.exit(1); });
