/**
 * One-shot: regenerate PWA + favicon variants from public/logo.png.
 * Run: npx tsx scripts/resize-logo.ts
 */
import sharp from "sharp";
import path from "path";

const root = path.resolve(__dirname, "..");
const src = path.join(root, "public", "logo.png");

async function run() {
  const targets = [
    { out: "public/icon-192.png", size: 192 },
    { out: "public/icon-512.png", size: 512 },
    { out: "public/apple-touch-icon.png", size: 180 },
    { out: "src/app/icon.png", size: 256 },
    { out: "src/app/apple-icon.png", size: 180 },
  ];
  for (const t of targets) {
    const dest = path.join(root, t.out);
    await sharp(src)
      .resize(t.size, t.size, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .png()
      .toFile(dest);
    console.log(`✓ ${t.out} (${t.size}px)`);
  }
}

run().catch((e) => { console.error(e); process.exit(1); });
