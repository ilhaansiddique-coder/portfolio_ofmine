#!/usr/bin/env node
/**
 * Migrate every tenant's R2 bucket from an OLD Cloudflare account to the
 * NEW one currently configured in .env.
 *
 * Idempotent — safe to re-run. Each object is copied only if missing or
 * smaller in the destination.
 *
 * Required env (in .env):
 *   # NEW account (already in .env from the migration)
 *   R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY
 *   CLOUDFLARE_API_TOKEN          — needs R2:Edit + Workers KV Storage:Edit
 *   CLOUDFLARE_KV_CDN_NAMESPACE_ID — for re-registering bucket allowlist
 *
 *   # OLD account (ADD these temporarily for migration, then remove)
 *   OLD_R2_ACCOUNT_ID
 *   OLD_R2_ACCESS_KEY_ID
 *   OLD_R2_SECRET_ACCESS_KEY
 *
 * What it does:
 *   1. Reads every tenant.r2Bucket from the control DB
 *   2. For each bucket:
 *      a. Creates the bucket in the NEW account (skips if exists)
 *      b. Lists every object in the OLD bucket
 *      c. Copies each missing/changed object to the NEW bucket
 *      d. Registers the bucket name in the NEW KV namespace
 *   3. Prints a final summary
 *
 * Usage:
 *   node scripts/migrate-r2.mjs           # migrate all tenants
 *   node scripts/migrate-r2.mjs --dry-run # list what would be migrated, no writes
 */
import {
  S3Client,
  ListObjectsV2Command,
  HeadObjectCommand,
  GetObjectCommand,
  PutObjectCommand,
  CreateBucketCommand,
} from "@aws-sdk/client-s3";
import { PrismaClient } from "../src/generated/prisma-control/index.js";
import dotenv from "dotenv";
dotenv.config();

const DRY = process.argv.includes("--dry-run");

// ── Env checks ──────────────────────────────────────────────
const needs = [
  "R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY",
  "CLOUDFLARE_API_TOKEN", "CLOUDFLARE_KV_CDN_NAMESPACE_ID",
  "OLD_R2_ACCOUNT_ID", "OLD_R2_ACCESS_KEY_ID", "OLD_R2_SECRET_ACCESS_KEY",
];
const missing = needs.filter((k) => !process.env[k]);
if (missing.length) {
  console.error("Missing env vars:", missing.join(", "));
  console.error("\nAdd the OLD_R2_* vars to .env temporarily for migration:");
  console.error("  OLD_R2_ACCOUNT_ID=...");
  console.error("  OLD_R2_ACCESS_KEY_ID=...");
  console.error("  OLD_R2_SECRET_ACCESS_KEY=...");
  process.exit(1);
}

// ── S3 clients ──────────────────────────────────────────────
const oldR2 = new S3Client({
  region: "auto",
  endpoint: `https://${process.env.OLD_R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.OLD_R2_ACCESS_KEY_ID,
    secretAccessKey: process.env.OLD_R2_SECRET_ACCESS_KEY,
  },
});
const newR2 = new S3Client({
  region: "auto",
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
  },
});

const CF_API = "https://api.cloudflare.com/client/v4";

// ── Helpers ─────────────────────────────────────────────────
async function ensureBucket(bucket) {
  try {
    await newR2.send(new ListObjectsV2Command({ Bucket: bucket, MaxKeys: 1 }));
    return "exists";
  } catch (e) {
    if (e.name === "NoSuchBucket" || e.$metadata?.httpStatusCode === 404) {
      if (DRY) return "would-create";
      // Use the Cloudflare REST API — CreateBucketCommand on R2's S3 endpoint
      // sometimes 400s on region negotiation; the REST API is more reliable.
      const res = await fetch(
        `${CF_API}/accounts/${process.env.R2_ACCOUNT_ID}/r2/buckets`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.CLOUDFLARE_API_TOKEN}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name: bucket }),
        },
      );
      if (!res.ok) {
        const body = await res.text();
        if (res.status === 409 || body.includes("already exists")) return "exists";
        throw new Error(`create bucket failed: ${res.status} ${body}`);
      }
      return "created";
    }
    throw e;
  }
}

async function existsInDest(bucket, key, size) {
  try {
    const head = await newR2.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
    return head.ContentLength === size; // same size = consider it copied already
  } catch {
    return false;
  }
}

async function copyObject(bucket, key) {
  const get = await oldR2.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
  const chunks = [];
  for await (const c of get.Body) chunks.push(c);
  const body = Buffer.concat(chunks);
  await newR2.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: body,
      ContentType: get.ContentType || "application/octet-stream",
      CacheControl: get.CacheControl,
      ContentDisposition: get.ContentDisposition,
    }),
  );
}

async function kvRegister(bucket, publicUrl) {
  if (DRY) return;
  const res = await fetch(
    `${CF_API}/accounts/${process.env.R2_ACCOUNT_ID}/storage/kv/namespaces/${process.env.CLOUDFLARE_KV_CDN_NAMESPACE_ID}/values/${encodeURIComponent(bucket)}`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${process.env.CLOUDFLARE_API_TOKEN}`,
        "Content-Type": "text/plain",
      },
      body: publicUrl || "1",
    },
  );
  if (!res.ok) console.warn(`  KV register failed for ${bucket}: ${res.status}`);
}

// ── Main ────────────────────────────────────────────────────
const c = new PrismaClient();
const tenants = await c.tenant.findMany({
  select: { slug: true, r2Bucket: true, r2PublicUrl: true },
});

const stats = { totalBuckets: 0, totalFiles: 0, totalCopied: 0, totalSkipped: 0, errors: 0 };

console.log(`\n=== R2 migration ${DRY ? "(DRY RUN)" : ""} ===`);
console.log(`OLD account: ${process.env.OLD_R2_ACCOUNT_ID}`);
console.log(`NEW account: ${process.env.R2_ACCOUNT_ID}`);
console.log(`Tenants in control DB: ${tenants.length}\n`);

for (const t of tenants) {
  if (!t.r2Bucket) {
    console.log(`SKIP ${t.slug} (no r2Bucket)`);
    continue;
  }
  console.log(`\n── ${t.slug} → bucket: ${t.r2Bucket} ──`);
  stats.totalBuckets++;

  try {
    const state = await ensureBucket(t.r2Bucket);
    console.log(`  bucket: ${state}`);

    // List + copy all objects from OLD
    let token = undefined;
    let bucketFiles = 0, bucketCopied = 0, bucketSkipped = 0;
    do {
      const list = await oldR2.send(
        new ListObjectsV2Command({
          Bucket: t.r2Bucket,
          ContinuationToken: token,
        }),
      );
      for (const obj of list.Contents || []) {
        bucketFiles++;
        if (await existsInDest(t.r2Bucket, obj.Key, obj.Size)) {
          bucketSkipped++;
          continue;
        }
        if (DRY) {
          bucketCopied++;
          continue;
        }
        try {
          await copyObject(t.r2Bucket, obj.Key);
          bucketCopied++;
          if (bucketCopied % 10 === 0) {
            process.stdout.write(`  copied ${bucketCopied}/${bucketFiles}...\r`);
          }
        } catch (e) {
          console.error(`  FAIL ${obj.Key}: ${e.message}`);
          stats.errors++;
        }
      }
      token = list.IsTruncated ? list.NextContinuationToken : undefined;
    } while (token);

    console.log(`  files: ${bucketFiles} | copied: ${bucketCopied} | skipped (already in new): ${bucketSkipped}`);

    await kvRegister(t.r2Bucket, t.r2PublicUrl);
    console.log(`  KV: registered`);

    stats.totalFiles += bucketFiles;
    stats.totalCopied += bucketCopied;
    stats.totalSkipped += bucketSkipped;
  } catch (e) {
    console.error(`  ERROR: ${e.message}`);
    stats.errors++;
  }
}

console.log(`\n=== Done ===`);
console.log(`Buckets processed: ${stats.totalBuckets}`);
console.log(`Files total: ${stats.totalFiles}`);
console.log(`Files copied: ${stats.totalCopied}`);
console.log(`Files already there: ${stats.totalSkipped}`);
console.log(`Errors: ${stats.errors}`);

await c.$disconnect();
process.exit(stats.errors > 0 ? 1 : 0);
