#!/usr/bin/env node
/**
 * Generic seeder for akbd-style landing pages.
 *
 * Usage:
 *   node scripts/seed-akbd-page.mjs <config.json> [--images=<dir>]
 *
 * The config JSON shape is documented in scripts/pages/_sample.json.
 * Images named in `config.images` are uploaded from the --images dir
 * (or `./pages-images/<slug>/` if omitted) to the tenant's R2 bucket,
 * then their public URLs are wired into the landingPage row.
 *
 * Re-running with the same slug UPSERTS — re-uploads the images and
 * overwrites the page row, so it's safe to tweak the JSON and rerun.
 */
import { PrismaClient as ControlClient } from "../src/generated/prisma-control/index.js";
import { PrismaClient as TenantClient } from "@prisma/client";
import { readFile, mkdir, writeFile } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import sharp from "sharp";
import dotenv from "dotenv";

dotenv.config();

// ── Parse CLI args ────────────────────────────────────────
const args = process.argv.slice(2);
const configPath = args.find((a) => !a.startsWith("--"));
if (!configPath) {
  console.error("usage: node scripts/seed-akbd-page.mjs <config.json> [--images=<dir>]");
  process.exit(1);
}
const imagesArg = args.find((a) => a.startsWith("--images="));
const overrideImagesDir = imagesArg ? imagesArg.split("=")[1] : null;

const cfg = JSON.parse(await readFile(configPath, "utf8"));
const SRC_DIR = overrideImagesDir || path.join(path.dirname(configPath), "..", "pages-images", cfg.slug);
console.log(`config:  ${configPath}`);
console.log(`images:  ${SRC_DIR}`);

// ── Resolve tenant ────────────────────────────────────────
const control = new ControlClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
const tenant = await control.tenant.findUnique({
  where: { slug: cfg.tenant },
  select: { id: true, slug: true, dbUrl: true, r2Bucket: true, r2PublicUrl: true },
});
if (!tenant) { console.error(`tenant '${cfg.tenant}' not found`); process.exit(1); }
console.log(`tenant:  ${tenant.slug} (id=${tenant.id})`);

// ── Upload images ─────────────────────────────────────────
async function processImage(srcPath, basename) {
  const raw = await readFile(srcPath);
  const ext = path.extname(srcPath).toLowerCase();
  let buf = raw;
  let finalExt = ext;
  if ([".jpg", ".jpeg", ".png"].includes(ext)) {
    const img = sharp(raw);
    const meta = await img.metadata();
    if (meta.width && meta.width > 1920) img.resize(1920, null, { withoutEnlargement: true });
    buf = await img.webp({ quality: 80 }).toBuffer();
    finalExt = ".webp";
  }
  return { buf, name: `${basename}-${Date.now()}${finalExt}`, contentType: "image/webp" };
}

const uploadedUrls = {};
if (cfg.images && Object.keys(cfg.images).length > 0) {
  if (!existsSync(SRC_DIR)) {
    console.error(`images dir not found: ${SRC_DIR}`);
    process.exit(1);
  }
  for (const [srcFile, friendly] of Object.entries(cfg.images)) {
    const srcPath = path.join(SRC_DIR, srcFile);
    if (!existsSync(srcPath)) { console.warn(`  SKIP missing: ${srcFile}`); continue; }
    const { buf, name, contentType } = await processImage(srcPath, friendly);

    if (tenant.r2Bucket && tenant.r2PublicUrl) {
      const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");
      const s3 = new S3Client({
        region: "auto",
        endpoint: process.env.R2_ENDPOINT || `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
        credentials: {
          accessKeyId: process.env.R2_ACCESS_KEY_ID,
          secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
        },
      });
      await s3.send(new PutObjectCommand({
        Bucket: tenant.r2Bucket, Key: name, Body: buf,
        ContentType: contentType, CacheControl: "public, max-age=31536000, immutable",
      }));
      const baseUrl = tenant.r2PublicUrl.replace(/\/$/, "");
      uploadedUrls[friendly] = `${baseUrl}/${name}`;
    } else {
      const dir = path.join("public", "uploads", `tenant_${tenant.id}`);
      await mkdir(dir, { recursive: true });
      await writeFile(path.join(dir, name), buf);
      uploadedUrls[friendly] = `/uploads/tenant_${tenant.id}/${name}`;
    }
    console.log(`  uploaded: ${friendly} → ${uploadedUrls[friendly]}`);
  }
}

// ── Compose templateData with uploaded image URLs ─────────
// Replace any `"@image:hero-logo"` style placeholders in templateData with the
// uploaded URL for that friendly name.
function resolveImages(value) {
  if (typeof value === "string" && value.startsWith("@image:")) {
    const key = value.slice(7);
    return uploadedUrls[key] || "";
  }
  if (Array.isArray(value)) return value.map(resolveImages);
  if (value && typeof value === "object") {
    const out = {};
    for (const [k, v] of Object.entries(value)) out[k] = resolveImages(v);
    return out;
  }
  return value;
}
const templateData = resolveImages(cfg.templateData || {});

// ── Resolve testimonial image URLs ────────────────────────
const testimonials = (cfg.testimonials || []).map((t) => ({
  ...t,
  image: t.image && t.image.startsWith("@image:")
    ? (uploadedUrls[t.image.slice(7)] || "")
    : (t.image || ""),
}));

// ── Build landingPage row ─────────────────────────────────
const heroImage = cfg.hero?.image && cfg.hero.image.startsWith("@image:")
  ? (uploadedUrls[cfg.hero.image.slice(7)] || null)
  : (cfg.hero?.image || null);

const featuresImage = cfg.features?.image && cfg.features.image.startsWith("@image:")
  ? (uploadedUrls[cfg.features.image.slice(7)] || null)
  : (cfg.features?.image || null);

const upsertData = {
  slug: cfg.slug,
  title: cfg.title,
  isActive: cfg.isActive !== false,
  primaryColor: cfg.primaryColor || "#1a3a63",

  template: "akbd",
  templateData,

  heroHeadline: cfg.hero?.headline || null,
  heroSubheadline: cfg.hero?.subheadline || null,
  heroImage,
  heroCta: cfg.hero?.cta || "অর্ডার করতে ক্লিক করুন",
  heroBadge: cfg.hero?.badge || null,

  featuresTitle: cfg.features?.title || null,
  featuresImage,
  features: cfg.features?.items ? JSON.stringify(cfg.features.items) : null,

  howItWorksTitle: cfg.whyChoose?.title || null,
  howItWorks: cfg.whyChoose?.items ? JSON.stringify(cfg.whyChoose.items) : null,

  testimonialsTitle: cfg.testimonialsTitle || "সম্মানিত গ্রাহকের মন্তব্য",
  testimonialsMode: "custom",
  testimonials: testimonials.length > 0 ? JSON.stringify(testimonials) : null,

  faqTitle: cfg.faqTitle || null,
  faq: cfg.faq ? JSON.stringify(cfg.faq) : null,

  checkoutTitle: cfg.checkout?.title || "🛒 আপনার অর্ডার দিন এখনই",
  checkoutSubtitle: cfg.checkout?.subtitle || "নিচের ফরমটি পূরণ করে অর্ডারটি কনফার্ম করুন।",
  checkoutBtnText: cfg.checkout?.btnText || "Place Order",
  customShipping: !!cfg.checkout?.customShipping,
  shippingCost: cfg.checkout?.shippingCost ?? 80,
  showEmail: !!cfg.checkout?.showEmail,
  showCity: cfg.checkout?.showCity !== false,
  guaranteeText: cfg.checkout?.guaranteeText || null,

  whatsapp: cfg.phone || null,
  contactMode: cfg.contactMode || "phone",

  sectionOrder: JSON.stringify(["hero", "features", "how_it_works", "testimonials", "checkout"]),
  sectionVisibility: JSON.stringify({
    hero: true, problem: false, products: false,
    features: true, how_it_works: true, testimonials: true,
    faq: !!cfg.faq, checkout: true,
  }),

  metaTitle: cfg.meta?.title || cfg.title,
  metaDescription: cfg.meta?.description || cfg.hero?.subheadline || null,
};

const tdb = new TenantClient({ datasourceUrl: tenant.dbUrl });
const created = await tdb.landingPage.upsert({
  where: { slug: cfg.slug },
  create: upsertData,
  update: upsertData,
});

console.log(`\n✓ landing page upserted: id=${created.id}  slug=${created.slug}`);
console.log(`  view at: http://${tenant.slug}.localtest.me:3005/lp/${created.slug}`);

await tdb.$disconnect();
await control.$disconnect();
