/**
 * Codemod for Wave 3: server components (page.tsx, layout.tsx).
 *
 * Walks src/app/ skipping /api/. For each file importing `prisma` from
 * "@/lib/prisma":
 *  1. Swap the import to `getPrismaForRequest` from "@/lib/prisma-tenant"
 *  2. For each top-level `export default async function ...` AND
 *     `export async function generateMetadata`, inject
 *     `const { prisma } = await getPrismaForRequest();` (no arg — uses headers())
 *     as the first body statement.
 *
 * Skips files where prisma is captured in a module-level helper / closure
 * (warns for manual fix).
 */
import fs from "fs";
import path from "path";

const ROOT = path.resolve(__dirname, "..");
const APP_DIR = path.join(ROOT, "src", "app");
const DRY = process.argv.includes("--dry");

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      // skip the api/ tree (handled by Wave 1 codemod)
      if (entry.name === "api") continue;
      walk(full, out);
    } else if (entry.name === "page.tsx" || entry.name === "layout.tsx") {
      out.push(full);
    }
  }
  return out;
}

const PRISMA_IMPORT_RE = /import\s+\{\s*prisma\s*\}\s+from\s+["']@\/lib\/prisma["'];?/;

// Match `export default async function Name(...args...) {` and
// `export async function generateMetadata(...args...) {` — multi-line OK.
const HANDLER_RE =
  /(export\s+(?:default\s+)?async\s+function\s+(?:generateMetadata|[A-Z][A-Za-z0-9_]*|)\s*\([\s\S]*?\)\s*(?::\s*[^{]+)?\s*\{)/g;

const warnings: string[] = [];
let filesChanged = 0;

for (const file of walk(APP_DIR)) {
  let src = fs.readFileSync(file, "utf8");
  if (!PRISMA_IMPORT_RE.test(src)) continue;

  let newSrc = src.replace(
    PRISMA_IMPORT_RE,
    `import { getPrismaForRequest } from "@/lib/prisma-tenant";`
  );

  let injectedAny = false;
  newSrc = newSrc.replace(HANDLER_RE, (match) => {
    // Only inject if this handler is `default async` OR `generateMetadata`
    if (
      !/export\s+default\s+async\s+function/.test(match) &&
      !/generateMetadata/.test(match)
    ) {
      return match;
    }
    injectedAny = true;
    return `${match}\n  const { prisma } = await getPrismaForRequest();`;
  });

  // Heuristic: detect prisma uses in module-level closures (outside any
  // injected handler). Look at prefix before first matched handler.
  const beforeFirstHandler = newSrc.split(/^export\s+(?:default\s+)?async\s+function/m)[0] || "";
  if (/\bprisma\./.test(beforeFirstHandler)) {
    warnings.push(`module-level prisma usage in ${path.relative(ROOT, file)}`);
  }

  if (newSrc === src) continue;
  if (!injectedAny) {
    warnings.push(`no async handlers found in ${path.relative(ROOT, file)}`);
  }

  filesChanged++;
  if (DRY) {
    console.log(`would change: ${path.relative(ROOT, file)}`);
  } else {
    fs.writeFileSync(file, newSrc, "utf8");
    console.log(`✓ ${path.relative(ROOT, file)}`);
  }
}

console.log(`\n${filesChanged} files ${DRY ? "would be" : ""} changed.`);
if (warnings.length) {
  console.log(`\nWarnings:`);
  warnings.forEach((w) => console.log(` - ${w}`));
}
