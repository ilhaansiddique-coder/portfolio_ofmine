/**
 * One-shot script: seeds the "Piles Care" landing page for the HomioPrime tenant.
 *
 * What it does:
 *   1. Looks up the homioprime tenant in the control DB to find its
 *      tenant DB URL + R2 bucket.
 *   2. Uploads the 7 images from C:\Users\User\Downloads\homioprime to that
 *      tenant's R2 bucket (logo, doctor, 5 reviews).
 *   3. Inserts a fully-populated LandingPage row in the tenant DB.
 *
 * Usage:
 *   npx tsx scripts/seed-homioprime-lp.ts
 *
 * Idempotent — if a LP with slug "piles-care" already exists, it UPDATES it
 * rather than creating a duplicate.
 */
import { PrismaClient as ControlPrisma } from "../src/generated/prisma-control";
import { PrismaClient as TenantPrisma } from "@prisma/client";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const IMAGES_DIR = "C:\\Users\\User\\Downloads\\homioprime";
const TENANT_SLUG = "homeoprime";
const LP_SLUG = "piles-care";

const controlPrisma = new ControlPrisma({
  datasourceUrl: process.env.CONTROL_DATABASE_URL,
});

async function uploadImage(
  client: S3Client,
  bucket: string,
  publicUrl: string,
  localFile: string,
  key: string,
  contentType: string,
): Promise<string> {
  const buf = readFileSync(join(IMAGES_DIR, localFile));
  await client.send(new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: buf,
    ContentType: contentType,
    CacheControl: "public, max-age=31536000, immutable",
  }));
  const url = `${publicUrl.replace(/\/$/, "")}/${key}`;
  console.log(`  ✓ ${localFile} → ${url}`);
  return url;
}

async function main() {
  console.log(`→ Looking up tenant "${TENANT_SLUG}"…`);
  const tenant = await controlPrisma.tenant.findUnique({ where: { slug: TENANT_SLUG } });
  if (!tenant) throw new Error(`Tenant "${TENANT_SLUG}" not found in control DB`);
  if (!tenant.r2Bucket || !tenant.r2PublicUrl) {
    throw new Error(`Tenant "${TENANT_SLUG}" has no r2Bucket / r2PublicUrl set`);
  }
  console.log(`  ✓ Tenant id=${tenant.id} bucket=${tenant.r2Bucket}`);

  const r2 = new S3Client({
    region: "auto",
    endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID || "",
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || "",
    },
  });

  console.log(`→ Uploading images to bucket "${tenant.r2Bucket}"…`);
  const ts = Date.now();
  const prefix = `landing-pages/${LP_SLUG}/${ts}`;

  const heroImg = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "logo.jpeg", `${prefix}/hero-logo.jpeg`, "image/jpeg");
  const doctorImg = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "Doctors Image.png", `${prefix}/doctor.png`, "image/png");
  const review1 = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "Review 1.jpeg", `${prefix}/review-1.jpeg`, "image/jpeg");
  const review2 = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "review 2.jpeg", `${prefix}/review-2.jpeg`, "image/jpeg");
  const review3 = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "review 3.jpeg", `${prefix}/review-3.jpeg`, "image/jpeg");
  const review4 = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "review 4.jpeg", `${prefix}/review-4.jpeg`, "image/jpeg");
  const review5 = await uploadImage(r2, tenant.r2Bucket, tenant.r2PublicUrl, "review 5.jpeg", `${prefix}/review-5.jpeg`, "image/jpeg");

  console.log(`→ Connecting to tenant DB…`);
  const tenantDb = new TenantPrisma({ datasourceUrl: tenant.dbUrl });

  // Try to find an existing piles-related product to attach (optional)
  let productId: number | null = null;
  try {
    const products = await tenantDb.product.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, name: true },
    });
    console.log(`  ℹ Found ${products.length} active products. First: ${products[0]?.name ?? "(none)"}`);
    productId = products[0]?.id ?? null;
  } catch (e) {
    console.warn("  ⚠ Could not list products:", (e as Error).message);
  }

  // ── Build the LP data ──────────────────────────────────────────────────
  const problemPoints = [
    { text: "গোটা এবং মাংস পৃণ্ড শুকিয়ে যাবে।", icon: "" },
    { text: "পায়ু পথের জ্বালাপুরা ও চুলকানি বন্ধ করবে।", icon: "" },
    { text: "পুঁজ পড়া ও আঠালো পানি পড়া বন্ধ করবে।", icon: "" },
    { text: "কোষ্ঠকাঠিন্য দূর করবে ও পায়খানা নরম করতে সহায়তা করবে।", icon: "" },
  ];

  const features = [
    { icon: "🩺", title: "সরকার অনুমোদিত ডাক্তার দ্বারা তৈরী", description: "অভিজ্ঞ ও নিবন্ধিত হোমিও ডাক্তারের ফর্মুলায় প্রস্তুত।" },
    { icon: "🏥", title: "সরাসরি চেম্বারে সাক্ষাৎ", description: "ডাক্তারের চেম্বারে গিয়ে সরাসরি পরামর্শ নিতে পারবেন।" },
    { icon: "✅", title: "কোনো পার্শ্বপ্রতিক্রিয়া নেই", description: "১০০% নিরাপদ — যেকোনো বয়সের রোগী নির্ভয়ে সেবন করতে পারবেন।" },
    { icon: "👥", title: "হাজার হাজার সুস্থ রোগী", description: "১২,০০০+ রোগী ইতোমধ্যে সম্পূর্ণ সুস্থ হয়েছেন।" },
    { icon: "🇩🇪", title: "জার্মানি হোমিও ফর্মুলা", description: "আন্তর্জাতিক মানের জার্মান হোমিও ফর্মুলায় তৈরী।" },
  ];

  const howItWorks = [
    { title: "সকালে ১ কাপ", description: "প্রতিদিন সকালে খালি পেটে আমাদের দেওয়া কাপে ১ কাপ সেবন করুন।" },
    { title: "রাতে ১ কাপ", description: "রাতে ঘুমানোর আগে খালি পেটে ১ কাপ সেবন করুন।" },
    { title: "১ মাস নিয়মিত", description: "টানা ১ মাস সেবন করুন — ইনশাআল্লাহ স্থায়ী সমাধান পাবেন।" },
  ];

  const testimonials = [
    {
      name: "Sadiya Khanam (Chittagong)",
      rating: 5,
      review: "আমার বাবার বয়স ৬০ বছর, ওনার ফিস্টুলা ছিলো। পুঁজ-পানি বের হতো। ব্যথা ও চুলকানিও ছিলো। ফেইসবুকে হোমিও প্রাইমের ভিডিও দেখে বাবার জন্য ওষুধ নিলাম। ওদের ওষুধ খেয়ে আমার বাবার ফিস্টুলা পুরোপুরি দূর হয়ে গিয়েছে।",
      image: review1,
    },
    {
      name: "Md Habib (Bogura)",
      rating: 5,
      review: "আমি পায়খানা করলে রক্ত বের হতো। ব্যথা, চুলকানি ও জ্বালাপোড়া ছিলো। পায়খানা আসলেই ভয় করতো। হোমিও প্রাইম থেকে ১৫ দিনের ওষুধ খেয়ে আমার রক্ত পড়া বন্ধ হয়েছে, ব্যথা-চুলকানিও এখন আর নেই। আমার কি আর ওষুধ খেতে হবে?",
      image: review2,
    },
    {
      name: "Saif Hossen (Rampura)",
      rating: 5,
      review: "আমার ৫ বছরের পুরাতন পাইলস ছিলো। পায়ুপথ দিয়ে গোটা বের হয়ে আসতো। আপনাদের ওষুধ ১ মাস খেয়ে আমার গোটা সম্পূর্ণ শুকিয়ে গেছে। ডাক্তার শুভকে মন থেকে ধন্যবাদ।",
      image: review3,
    },
    {
      name: "অলি আকবর (টেকনাফ)",
      rating: 5,
      review: "আমার পাইলসের অপারেশন হয়েছিলো। অপারেশনের কিছুদিন পর আবার পাইলস দেখা গেলো। কি করবো ভেবে না পেয়ে ডাক্তার শুভ থেকে ওষুধ নিলাম। ১ মাস ওষুধ খাইছি। এখন মোটামুটি ভালো লাগতেছে।",
      image: review4,
    },
    {
      name: "Tahmina Khan (Narayanganj)",
      rating: 5,
      review: "আমার পায়খানার রাস্তায় গোটা ছিলো, মাঝে মাঝে রক্ত পড়তো। অনেক ওষুধ খাইছি কোনো উপকার পাই নাই। শেষে আপনাদের থেকে নিলাম, আপনাদের ওষুধ ১৫ দিন খেয়েই আমার গোটা শুকাতে শুরু করেছে। আমার জন্য আরেক ফাইল পাঠিয়ে দিন।",
      image: review5,
    },
  ];

  const faq = [
    { question: "পাইলস কি স্থায়ীভাবে সুস্থ হবে?", answer: "ইনশাআল্লাহ, এই পর্যন্ত আমাদের প্রায় ১৫ হাজার রোগী স্থায়ীভাবে সুস্থ হয়েছেন।" },
    { question: "ওষুধ কতদিন খেতে হবে?", answer: "১ মাস নিয়মিত সেবন করলে ইনশাআল্লাহ স্থায়ীভাবে সমস্যার সমাধান পাবেন।" },
    { question: "এই ওষুধের কোনো পার্শ্বপ্রতিক্রিয়া আছে কি?", answer: "না, এটি ১০০% হোমিও ফর্মুলায় তৈরী — কোনো পার্শ্বপ্রতিক্রিয়া নেই। যেকোনো বয়সের রোগী নির্ভয়ে সেবন করতে পারবেন।" },
    { question: "কিভাবে অর্ডার করবো?", answer: "উপরের ফরম পূরণ করে অর্ডার করুন অথবা ফোন করুন: 01948810200। ক্যাশ অন ডেলিভারিতে সারা বাংলাদেশে ডেলিভারি দেওয়া হয়।" },
    { question: "ডাক্তারের চেম্বারের ঠিকানা কোথায়?", answer: "ইন্টারন্যাশনাল হোমিও, লালদিঘি, চট্টগ্রাম। ফোন: 01948810200" },
  ];

  const productsJson = productId ? [{ product_id: productId, quantity: 1 }] : [];

  const sectionVisibility = {
    hero: true,
    problem: true,
    products: true,
    features: true,
    how_it_works: true,
    testimonials: true,
    faq: true,
  };

  const data = {
    slug: LP_SLUG,
    title: "পাইলস কেয়ার — Homeo Prime",
    isActive: true,

    heroHeadline: "জার্মানি হোমিও ফর্মুলায় তৈরী",
    heroSubheadline: "পাইলস, অর্শ্ব, ফিস্টুলা ও এনাল ফিশারের বিশ্বস্ত সমাধান।",
    heroImage: heroImg,
    heroVideoAutoplay: false,
    heroCta: "এখনই অর্ডার করুন",
    heroTrustText: "১২+ বছর অভিজ্ঞতা, ১২,০০০+ সুস্থ রোগী, ৩+ প্রতিষ্ঠান",
    heroBadge: "১২,০০০+\nসুস্থ রোগী",

    problemTitle: "পাইলস কেয়ার আপনার যে উপকার করবে",
    problemPoints: JSON.stringify(problemPoints),

    productsTitle: "আমাদের প্রোডাক্ট",
    productsSub: "জার্মানি হোমিও ফর্মুলায় তৈরী — পাইলসের নিশ্চিত সমাধান",

    featuresTitle: "🔥 আমাদের থেকে কেন নেবেন?",
    featuresImage: doctorImg,
    features: JSON.stringify(features),

    testimonialsTitle: "আমাদের রোগীদের অভিজ্ঞতা",
    testimonialsMode: "custom",
    testimonials: JSON.stringify(testimonials),

    howItWorksTitle: "সেবনবিধি — কিভাবে খাবেন?",
    howItWorksSub: "সকালে এবং রাতে আমাদের দেওয়া কাপে ১ কাপ খালি পেটে খাবেন",
    howItWorks: JSON.stringify(howItWorks),

    faqTitle: "সাধারণ প্রশ্ন (FAQ)",
    faq: JSON.stringify(faq),

    products: JSON.stringify(productsJson),

    checkoutTitle: "🛒 অর্ডার করতে নিচের ফরমটি পূরণ করুন",
    checkoutSubtitle: "অফার মূল্য মাত্র ৳১২৫০ (রেগুলার ৳১৫৫০) — সীমিত সময়ের জন্য",
    checkoutBtnText: "অর্ডার কনফার্ম করুন",
    customShipping: false,
    shippingCost: 60,
    showEmail: false,
    showCity: true,
    guaranteeText: "১০০% নিরাপদ হোমিও ফর্মুলা — কোনো পার্শ্বপ্রতিক্রিয়া নেই",
    successMessage: "ধন্যবাদ! শীঘ্রই আমরা আপনার সাথে যোগাযোগ করবো।",

    metaTitle: "পাইলস কেয়ার — Homeo Prime | জার্মানি হোমিও ফর্মুলা",
    metaDescription: "পাইলস, অর্শ্ব, ফিস্টুলা ও এনাল ফিশারের বিশ্বস্ত হোমিও সমাধান। ১২,০০০+ সুস্থ রোগী। সারা বাংলাদেশে ক্যাশ অন ডেলিভারি। ফোন: 01948810200",

    whatsapp: "01948810200",
    contactMode: "phone",
    sectionVisibility: JSON.stringify(sectionVisibility),
    primaryColor: "#1a8e8a",
  };

  console.log(`→ Upserting LandingPage (slug="${LP_SLUG}")…`);
  const existing = await tenantDb.landingPage.findUnique({ where: { slug: LP_SLUG } });
  const lp = existing
    ? await tenantDb.landingPage.update({ where: { slug: LP_SLUG }, data })
    : await tenantDb.landingPage.create({ data });

  console.log(`  ✓ ${existing ? "Updated" : "Created"} LP id=${lp.id} slug=${lp.slug}`);

  const lpUrl = tenant.primaryDomain
    ? `https://${tenant.primaryDomain}/lp/${lp.slug}`
    : `https://${tenant.slug}.${process.env.BASE_DOMAIN || "contradigital.agency"}/lp/${lp.slug}`;
  console.log(`\n✓ Landing page ready: ${lpUrl}`);

  await tenantDb.$disconnect();
}

main()
  .catch((e) => { console.error("✗", e); process.exit(1); })
  .finally(() => controlPrisma.$disconnect());
