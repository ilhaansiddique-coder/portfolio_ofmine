#!/usr/bin/env node
/**
 * Diagnose multi-tenant resolution. Run on local AND live with each env's
 * .env in place. If the printed control-host / tenant dbUrl differ between
 * environments, that's why a row created in one isn't visible in the other.
 */
import { PrismaClient as ControlClient } from "../src/generated/prisma-control/index.js";
import { PrismaClient as TenantClient } from "@prisma/client";
import dotenv from "dotenv";

dotenv.config();

const masked = (s) => {
  if (!s) return "(unset)";
  try {
    const u = new URL(s);
    return `${u.protocol}//${u.username}@${u.hostname}/${u.pathname.replace(/^\//, "")}`;
  } catch {
    return s.slice(0, 24) + "...";
  }
};

console.log("=== Environment ===");
console.log("BASE_DOMAIN          :", process.env.BASE_DOMAIN || "(unset)");
console.log("CONTROL_DATABASE_URL :", masked(process.env.CONTROL_DATABASE_URL));
console.log("DATABASE_URL         :", masked(process.env.DATABASE_URL));
console.log();

const c = new ControlClient({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
const tenants = await c.tenant.findMany({
  select: { id: true, slug: true, dbUrl: true, primaryDomain: true, status: true },
});
console.log("=== Tenants (from control DB) ===");
for (const t of tenants) {
  console.log(`  ${t.slug.padEnd(15)} status=${t.status} primaryDomain=${t.primaryDomain || "-"}`);
  console.log(`    dbUrl: ${masked(t.dbUrl)}`);
}
await c.$disconnect();

console.log();
console.log("=== Landing pages in each tenant DB ===");
for (const t of tenants) {
  if (!t.dbUrl) continue;
  try {
    const tdb = new TenantClient({ datasourceUrl: t.dbUrl });
    const rows = await tdb.landingPage.findMany({
      select: { id: true, slug: true, title: true, isActive: true, template: true },
    });
    console.log(`  Tenant: ${t.slug}  (${rows.length} pages)`);
    for (const r of rows) {
      console.log(`    id=${r.id}  active=${r.isActive}  template=${r.template || "default"}  /lp/${r.slug}`);
    }
    await tdb.$disconnect();
  } catch (e) {
    console.log(`  Tenant: ${t.slug}  ERROR: ${e.message}`);
  }
}
