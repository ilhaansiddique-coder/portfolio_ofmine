/**
 * Tenant isolation smoke test.
 *
 * Verifies that two tenant DBs are truly separate:
 *  1. Pull both tenants from the control plane
 *  2. Connect to each tenant's DB
 *  3. Insert a uniquely-named product into tenant A
 *  4. Confirm tenant B does NOT see it
 *  5. Cleanup
 *
 * Run: npx tsx scripts/test-isolation.ts
 */
import { PrismaClient as ControlPrisma } from "../src/generated/prisma-control";
import { PrismaClient } from "@prisma/client";

async function main() {
  const control = new ControlPrisma({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
  const tenants = await control.tenant.findMany({
    where: { status: "active" },
    orderBy: { id: "asc" },
    take: 2,
  });
  if (tenants.length < 2) {
    console.error(`Need 2 active tenants — found ${tenants.length}. Provision another via the dashboard first.`);
    process.exit(1);
  }
  const [a, b] = tenants;
  console.log(`Tenant A: ${a.slug} (${a.dbName})`);
  console.log(`Tenant B: ${b.slug} (${b.dbName})\n`);

  const pa = new PrismaClient({ datasourceUrl: a.dbUrl });
  const pb = new PrismaClient({ datasourceUrl: b.dbUrl });

  const marker = `__isolation_test_${Date.now()}`;

  try {
    const before = {
      a: await pa.product.count(),
      b: await pb.product.count(),
    };
    console.log(`Before: A.products=${before.a} B.products=${before.b}`);

    // Insert into A
    const created = await pa.product.create({
      data: {
        name: marker,
        slug: marker,
        price: 1,
        image: "test.png",
        stock: 0,
      },
    });
    console.log(`✓ Inserted product into A: id=${created.id} name=${marker}`);

    // Verify A has it
    const aHas = await pa.product.findUnique({ where: { slug: marker } });
    console.log(`✓ A can see it: ${!!aHas}`);

    // Verify B does NOT
    const bHas = await pb.product.findUnique({ where: { slug: marker } });
    if (bHas) {
      console.error(`✗ ISOLATION BREACH: tenant B can see A's product!`);
      process.exit(2);
    }
    console.log(`✓ B does NOT see it (isolation holds)`);

    const after = {
      a: await pa.product.count(),
      b: await pb.product.count(),
    };
    console.log(`\nAfter:  A.products=${after.a} B.products=${after.b}`);
    if (after.a !== before.a + 1) console.error(`✗ A delta wrong`);
    if (after.b !== before.b) console.error(`✗ B count changed unexpectedly`);

    // Cleanup
    await pa.product.delete({ where: { id: created.id } });
    console.log(`\n✓ Cleaned up. ISOLATION VERIFIED.`);

  } finally {
    await pa.$disconnect();
    await pb.$disconnect();
    await control.$disconnect();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
