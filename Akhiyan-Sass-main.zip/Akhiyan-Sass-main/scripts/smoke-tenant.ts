/**
 * Smoke test: hit every dashboard page + every admin GET endpoint while
 * impersonating the default tenant. Report HTTP status + any non-OK responses.
 *
 * Usage: npx tsx scripts/smoke-tenant.ts
 */
import { PrismaClient as ControlPrisma } from "../src/generated/prisma-control";

const BASE = process.env.SMOKE_BASE_URL || "http://localhost:3005";

async function main() {
  // 1. Login as super admin → grab cookie
  console.log("→ logging in as super admin…");
  const loginRes = await fetch(`${BASE}/api/v1/superadmin/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: process.env.SUPER_ADMIN_EMAIL || `admin@${process.env.BASE_DOMAIN || "example.com"}`, password: process.env.SUPER_ADMIN_PASSWORD || "changeme" }),
  });
  const cookies1 = loginRes.headers.getSetCookie();
  if (!loginRes.ok) {
    console.error("login failed:", loginRes.status, await loginRes.text());
    process.exit(1);
  }
  const superCookie = cookies1.find((c) => c.startsWith("superadmin_token="))?.split(";")[0] || "";

  // 2. Pick default tenant from control DB
  const control = new ControlPrisma({ datasourceUrl: process.env.CONTROL_DATABASE_URL });
  const tenant = await control.tenant.findFirst({ where: { slug: "default" } });
  await control.$disconnect();
  if (!tenant) { console.error("default tenant missing"); process.exit(1); }
  console.log(`→ tenant: ${tenant.slug} (id ${tenant.id})`);

  // 3. Impersonate
  console.log("→ impersonating…");
  const impRes = await fetch(`${BASE}/api/v1/superadmin/tenants/${tenant.id}/impersonate`, {
    method: "POST",
    headers: { Cookie: superCookie },
  });
  const impCookies = impRes.headers.getSetCookie();
  const impCookie = impCookies.find((c) => c.startsWith("superadmin_impersonate="))?.split(";")[0] || "";
  if (!impCookie) { console.error("no impersonation cookie returned:", await impRes.text()); process.exit(1); }
  const allCookies = `${superCookie}; ${impCookie}`;

  // 4. Probe endpoints
  const targets = [
    // dashboard server pages
    "/dashboard",
    "/dashboard/products",
    "/dashboard/orders",
    "/dashboard/categories",
    "/dashboard/brands",
    "/dashboard/blog",
    "/dashboard/banners",
    "/dashboard/coupons",
    "/dashboard/customizer",
    "/dashboard/flash-sales",
    "/dashboard/form-submissions",
    "/dashboard/homepage",
    "/dashboard/landing-pages",
    "/dashboard/menus",
    "/dashboard/reviews",
    "/dashboard/settings",
    "/dashboard/settings/checkout",
    "/dashboard/settings/courier",
    "/dashboard/settings/email",
    "/dashboard/settings/language",
    "/dashboard/shipping",
    "/dashboard/users",
    "/dashboard/content/about",
    "/dashboard/content/contact",
    "/dashboard/content/email",
    "/dashboard/content/header-footer",
    "/dashboard/content/privacy",
    "/dashboard/content/refund",
    "/dashboard/content/shop",
    "/dashboard/content/terms",
    // admin api gets
    "/api/v1/admin/dashboard",
    "/api/v1/admin/orders",
    "/api/v1/admin/products",
    "/api/v1/admin/categories",
    "/api/v1/admin/brands",
    "/api/v1/admin/coupons",
    "/api/v1/admin/banners",
    "/api/v1/admin/blog",
    "/api/v1/admin/menus",
    "/api/v1/admin/settings",
    "/api/v1/admin/shipping",
    "/api/v1/admin/users",
    "/api/v1/admin/reviews",
    "/api/v1/admin/incomplete-orders",
    "/api/v1/admin/landing-pages",
    "/api/v1/admin/flash-sales",
    "/api/v1/admin/form-submissions",
    "/api/v1/admin/feeds",
    "/api/v1/admin/shortlinks",
    "/api/v1/admin/spam/blocked-ips",
    "/api/v1/admin/spam/blocked-phones",
    "/api/v1/admin/spam/customers",
    "/api/v1/admin/spam/devices",
    "/api/v1/admin/spam/flagged-orders",
    "/api/v1/admin/courier?action=test",
    "/api/v1/admin/courier/active",
    // public
    "/api/v1/products",
    "/api/v1/categories",
    "/api/v1/settings",
    "/api/v1/health/tenant",
  ];

  const failures: { path: string; status: number; body?: string }[] = [];
  let ok = 0;
  for (const path of targets) {
    try {
      const res = await fetch(`${BASE}${path}`, {
        headers: { Cookie: allCookies },
        redirect: "manual",
      });
      const status = res.status;
      // Success: 200 or 3xx redirect (e.g. dashboard layouts redirecting to staff page)
      if (status >= 200 && status < 400) {
        ok++;
        console.log(`  ✓ ${status} ${path}`);
      } else if (status === 404) {
        console.log(`  ⚠ 404 ${path}`);
      } else {
        const body = await res.text().catch(() => "");
        failures.push({ path, status, body: body.slice(0, 600) });
        console.log(`  ✗ ${status} ${path}`);
      }
    } catch (e) {
      failures.push({ path, status: 0, body: e instanceof Error ? e.message : String(e) });
      console.log(`  ✗ NETWORK ${path}`);
    }
  }

  console.log(`\n${ok}/${targets.length} ok`);
  if (failures.length) {
    console.log(`\nFailures:`);
    for (const f of failures) {
      console.log(`\n--- ${f.status} ${f.path} ---`);
      if (f.body) console.log(f.body);
    }
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
