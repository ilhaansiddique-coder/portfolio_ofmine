# CD Ecom — Coolify Deployment & Operations Runbook (FINAL)

Authoritative, step‑by‑step guide derived from the **actual working
production configuration**. Follow top‑to‑bottom for a fresh deploy. Each
major fix we applied in production has its own section so it can be
re‑applied or audited independently.

> **Product:** CD Ecom by Contra Digital — multi‑tenant SaaS ecommerce.
> **Stack:** Next.js 16 (standalone Docker) · Prisma (2 schemas) · Postgres
> (control DB + one DB per tenant via Neon) · Coolify + Traefik · Cloudflare
> (DNS + **Cloudflare Tunnel**) · Cloudflare R2 + CDN Worker · Soketi
> (realtime) · GlitchTip (errors).
>
> **Two independent apps share one Coolify host:**
> - **CD Ecom** — `contradigital.agency`, `*.contradigital.agency` (tenant
>   subdomains), tenant custom domains, `cdeadmin.contradigital.agency`.
> - **Inventra** — Coolify project `contra-digital-wholesale-sass`,
>   `inventra.site`, `*.inventra.site`, `admin.inventra.site`. Separate
>   deployment, separate Cloudflare account.

---

## Table of contents

1. Architecture
2. Coolify application setup
3. Environment variables
4. Database model (control + per‑tenant)
5. Multi‑tenant domain configuration
6. Cold‑start / Cloudflare 522 — root cause & the permanent fix (Tunnel)
7. Cloudflare Tunnel — full setup (both accounts)
8. Adding a new app / subdomain (the CNAME rule)
9. What must **never** go through the tunnel (CDN Worker)
10. Healthcheck, keep‑warm & kernel tuning
11. Performance / caching hardening (in‑code)
12. Firewall lockdown (optional, deferred)
13. Troubleshooting

---

## 1. Architecture

```
                         ┌──────────────────────────────────────────┐
  Visitor / Tenant ─────► │ Cloudflare (orange-cloud, proxied DNS)    │
                         └───────────────┬──────────────────────────┘
                                         │  OUTBOUND tunnel (QUIC)
                              ┌──────────▼───────────┐
                              │  Coolify host (VPS)   │
                              │  cloudflared-cd  ─┐   │
                              │  cloudflared-inv ─┤   │
                              │        ┌──────────▼┐  │
                              │        │ Traefik    │ │  (coolify-proxy)
                              │        │ (host route│ │  routes by Host header
                              │        └─────┬──────┘ │
                              │   ┌──────────┼───────┐│
                              │   │ CD Ecom  │Inventra││  (2 Coolify apps, :3000)
                              │   └────┬─────┴───┬────┘│
                              └────────┼─────────┼─────┘
                  ┌──────────────────┼──────┐  ┌┴─────────────────┐
            ┌─────▼──────┐  ┌────────▼────┐ │  │ Cloudflare R2 +  │
            │ CONTROL DB │  │ Tenant DB×N │ │  │ CDN Worker + KV  │ (edge only,
            │ (Neon)     │  │ (Neon)      │ │  │ cdn.<basedomain> │  NOT tunnel)
            └────────────┘  └─────────────┘ │  └──────────────────┘
```

Key facts:

- **Cloudflare → origin is now via Cloudflare Tunnel** (outbound from the
  host). There is **no public inbound** dependency for serving traffic.
- **Traefik (`coolify-proxy`)** still does all host routing. The tunnel just
  forwards every hostname to Traefik (`https://localhost:443`).
- The app resolves the tenant from the request **`Host` header**
  (`getPrismaForRequest` → `resolveTenantByHost`). One container serves all
  hosts; routing is in‑app, not per‑domain in Traefik.
- **CDN Worker** (`cdn.contradigital.agency`) runs at Cloudflare's edge,
  serves R2 images, and **never touches the origin or the tunnel**.

---

## 2. Coolify application setup

Do this **once per app** (CD Ecom, Inventra — they use the same codebase).

1. **New Resource → Application → Docker (Dockerfile)**, point at the Git
   repo, branch `main`. Build pack: **Dockerfile** (repo‑root `Dockerfile`).
   Do **not** use Nixpacks.
2. **Port:** `3000`.
3. **Healthcheck:** Path `/superadmin/login` (public, always 200, no auth),
   Port `3000`. The `Dockerfile` already declares `EXPOSE 3000` and a
   `HEALTHCHECK` (interval 30s, timeout 10s, **start‑period 180s**, retries
   5). Enable Coolify’s **“Wait for healthcheck before making available”**
   so a redeploy never routes traffic to a still‑booting container.
   - *Why this matters:* without a passing healthcheck Coolify/Traefik adds
     the backend the moment port 3000 opens — before Next.js is ready —
     causing post‑deploy 522s. CD Ecom had this; Inventra did not (it showed
     no `(healthy)` in `docker ps`). The Dockerfile healthcheck fixes both;
     **Inventra must be redeployed on current `main`** to pick it up.
4. **Entrypoint** (baked into `docker-entrypoint.sh`, idempotent — safe on
   every start):
   - Runs **control DB** migrations:
     `prisma migrate deploy --schema prisma/control/schema.prisma`
     (refuses to start if `CONTROL_DATABASE_URL` is missing).
   - Runs **per‑tenant** migrations across every `Tenant.dbUrl`.
   - Starts Next.js: `next start -H 0.0.0.0 -p 3000`.
5. **Build‑time args** — `NEXT_PUBLIC_*` are baked into the client bundle at
   build time. They MUST be passed as Coolify **Build Variables** (not just
   runtime env), or the browser bundle ships with empty values. Changing any
   `NEXT_PUBLIC_*` requires a **rebuild/redeploy**, not just a restart.
6. Deploy. First boot runs migrations then serves.

---

## 3. Environment variables

| Var | Where | Notes |
|---|---|---|
| `CONTROL_DATABASE_URL` | runtime | Control‑plane Neon DB. App refuses to start without it. |
| `SUPER_ADMIN_JWT_SECRET` | runtime | **Fail‑closed** — no dev fallback. Must be a strong secret. |
| `NEON_API_KEY` | runtime | Auto‑provisions a Neon DB per new tenant. |
| `BASE_DOMAIN` | runtime | e.g. `contradigital.agency`. Drives slug subdomains + `cnameTarget()`. |
| `NEXT_PUBLIC_BASE_DOMAIN` | **build** | Client‑side base domain. |
| `NEXT_PUBLIC_SITE_URL` / `NEXT_PUBLIC_SITE_NAME` | **build** | Baked into bundle. |
| `NEXT_PUBLIC_SOKETI_HOST/KEY/PORT/TLS` | **build** | Realtime client. Key MUST equal Soketi’s `SOKETI_DEFAULT_APP_KEY`. |
| `SOKETI_APP_ID/APP_KEY/APP_SECRET/HOST/PORT/TLS` | runtime | Server‑side realtime (must match the Soketi container’s default app). |
| `R2_PUBLIC_URL` / `CDN_BASE_URL` | runtime/build | Image base. CDN worker domain. |
| `CLOUDFLARE_KV_CDN_NAMESPACE_ID` | runtime | `ef9c47610fb745e3915ee6e6f18de950` — CDN worker bucket allowlist KV. |
| `CLOUDFLARE_ZONE_ID` / `CLOUDFLARE_API_TOKEN` | runtime | Cloudflare‑for‑SaaS custom hostnames (optional). |
| `GLITCHTIP_DSN` / `NEXT_PUBLIC_SENTRY_DSN` | build/runtime | Error tracking (no‑op if unset). |

Never bake secrets into the image — Coolify injects runtime env at container
start. `.env*` is in `.dockerignore`.

---

## 4. Database model

- **Control DB** (`CONTROL_DATABASE_URL`, schema `prisma/control/schema.prisma`):
  superadmins, `Tenant`, `Plan`, `auditLog`. `Tenant` holds `slug`,
  `primaryDomain`, `dbUrl`, `features`, `limits`, `plan`, `status`.
- **Tenant DBs** (schema `prisma/schema.prisma`): one Neon Postgres **per
  tenant**, auto‑created via the Neon API on tenant provisioning. The
  connection string is stored on `Tenant.dbUrl`.
- **Plan snapshot:** creating a tenant copies the selected plan’s
  `features`/`limits` onto the tenant (mirrors the assign‑plan path).
- Migrations run automatically from the entrypoint on every container start
  (idempotent).

---

## 5. Multi‑tenant domain configuration

Three ways a hostname reaches a tenant — **all now ride the tunnel**:

1. **Slug subdomain** — `‹slug›.contradigital.agency` (or `.inventra.site`).
   Covered by the **wildcard** DNS record (see §7). Zero per‑tenant DNS work.
2. **Tenant custom domain** — e.g. `oneclickshopp.com`. The tenant points a
   `CNAME` at `cname.‹BASE_DOMAIN›` (the app’s `cnameTarget()`), or it is a
   Cloudflare‑for‑SaaS custom hostname. `cname.contradigital.agency` is a
   proxied CNAME → the CD tunnel, so **every custom domain is automatically
   covered** with zero ops.
   - Domain ownership is **verified before binding** (DNS/CNAME/A or HTTP
     probe) — `skipDnsCheck` is **never** coupled to Cloudflare‑for‑SaaS
     (security: prevents domain squatting / cross‑tenant hijack).
   - Cloudflare‑for‑SaaS users: set the **Fallback Origin** to a
     tunnel‑backed hostname (e.g. `cname.contradigital.agency`).
3. **Platform subdomains** — `cdeadmin`, `coolify`, `skt`, `uptime`, etc.
   These each have their **own explicit DNS record** and must be repointed
   to the tunnel individually (see §7 — the wildcard does **not** override
   an explicit record).

Email links (order/confirmation/admin notifications) resolve the **active
domain dynamically per send**: tenant `primaryDomain` → captured `site_url`
→ env → slug subdomain. Connecting a custom domain takes effect on the next
email with no rebuild.

---

## 6. Cold‑start / Cloudflare 522 — root cause & permanent fix

### Symptom
Every site (CD Ecom tenants, custom domains, `cdeadmin`, Inventra, Coolify
itself) returned **Cloudflare 522 “Connection timed out — Host Error”** on
the **first visit after a few minutes idle**, then worked on refresh.

### Investigation (confirmed, not guessed)
- Host healthy & idle: 32 GB RAM, ~3.4 GB used, load 0.34, no OOM, no
  container restarts. **Not** resource exhaustion.
- `dig`: A/AAAA returned **Cloudflare anycast IPs** (proxied) — not a broken
  origin AAAA.
- Direct origin curl from the host: **`302 in 0.06 s`** — origin perfectly
  healthy when a connection exists.
- Conclusion: the **idle TCP connection between Cloudflare and the origin
  was being silently dropped** by the VPS network/NAT/firewall after a few
  minutes. Cloudflare reused a dead pooled socket → no SYN‑ACK → 522; the
  next request opened a fresh socket → worked. Low‑traffic hosts sat idle
  long enough to trigger it constantly.
- A **second, smaller cause** for Inventra only: no Coolify/Docker
  healthcheck → Traefik routed to the container during its boot window →
  post‑deploy 522.

### The permanent fix
**Cloudflare Tunnel.** `cloudflared` on the host dials **outbound** to
Cloudflare and maintains 4 persistent connections with its own heartbeat.
There is **no idle inbound socket** for the VPS to drop — the 522 failure
mode is *structurally eliminated*, for every site, permanently. Bonus: the
origin IP is no longer exposed in DNS.

Earlier mitigations we also applied (now redundant but harmless):
- Persisted TCP keepalive: `/etc/sysctl.d/99-keepalive.conf`
  (`tcp_keepalive_time=60`, `intvl=30`, `probes=5`).
- Uptime‑Kuma 30 s monitors per hostname (kept the flow warm).

These are kept as belt‑and‑braces; the **tunnel is the real fix**.

---

## 7. Cloudflare Tunnel — full setup (both accounts)

Two Cloudflare accounts (Contradigital + Inventra) ⇒ **two tunnels**, one
per account, both on the same host, both forwarding to the same Traefik.
Credentials isolated per directory.

```
/etc/cloudflared/cd/   → Contradigital account → tunnel "coolify-cd"
/etc/cloudflared/inv/  → Inventra account      → tunnel "coolify-inv"
```

**Production tunnel IDs (current):**
- CD: `8e84eaf1-91ec-4269-bb03-5c5403530b10`
- Inventra: `657b61a8-38d0-43fe-8617-fffffe9b94db`

### 7.1 Install cloudflared
```
curl -L https://pkg.cloudflare.com/cloudflare-main.gpg | tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null
echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared $(lsb_release -cs) main" > /etc/apt/sources.list.d/cloudflared.list
apt update && apt install -y cloudflared
```

### 7.2 Per account — login, create tunnel
`cloudflared tunnel login` **always writes `cert.pem` to
`/root/.cloudflared/cert.pem`** (it ignores `--origincert` for the output
path). Move it into the right account dir **immediately**, before the next
login overwrites it.

```
# --- Contradigital ---
mkdir -p /etc/cloudflared/cd && rm -f /root/.cloudflared/cert.pem
cloudflared tunnel login                       # browser: pick the CONTRADIGITAL account, authorize contradigital.agency
mv /root/.cloudflared/cert.pem /etc/cloudflared/cd/cert.pem
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem create coolify-cd
# → note the UUID; the <UUID>.json is written into /etc/cloudflared/cd/

# --- Inventra ---
mkdir -p /etc/cloudflared/inv && rm -f /root/.cloudflared/cert.pem
cloudflared tunnel login                       # browser: pick the INVENTRA account, authorize inventra.site
mv /root/.cloudflared/cert.pem /etc/cloudflared/inv/cert.pem
cloudflared tunnel --origincert /etc/cloudflared/inv/cert.pem create coolify-inv
```

### 7.3 Config (catch‑all → Traefik)

A single catch‑all rule is enough — Traefik already routes every Host. This
is what makes **all** apex / wildcard / custom domains work through the
tunnel automatically.

`/etc/cloudflared/cd/config.yml`:
```yaml
tunnel: 8e84eaf1-91ec-4269-bb03-5c5403530b10
credentials-file: /etc/cloudflared/cd/8e84eaf1-91ec-4269-bb03-5c5403530b10.json
origincert: /etc/cloudflared/cd/cert.pem
ingress:
  - service: https://localhost:443
    originRequest:
      noTLSVerify: true
```
`/etc/cloudflared/inv/config.yml` — identical but with the Inventra UUID,
its `.json`, and `/etc/cloudflared/inv/cert.pem`.

`noTLSVerify: true` because Traefik serves its own cert and the traffic is
already inside the box. Validate before starting:
```
cloudflared tunnel --config /etc/cloudflared/cd/config.yml ingress validate   # expect: OK
```
> Note: the `--config` flag must come **before** `ingress validate`.

### 7.4 systemd services (one per tunnel — do NOT use `service install`)

`/etc/systemd/system/cloudflared-cd.service`:
```ini
[Unit]
Description=cloudflared (contradigital)
After=network.target
[Service]
ExecStart=/usr/bin/cloudflared tunnel --no-autoupdate --config /etc/cloudflared/cd/config.yml run
Restart=always
User=root
[Install]
WantedBy=multi-user.target
```
`/etc/systemd/system/cloudflared-inv.service` — same, `--config
/etc/cloudflared/inv/config.yml`, Description (inventra).

```
systemctl daemon-reload
systemctl enable --now cloudflared-cd cloudflared-inv
systemctl status cloudflared-cd cloudflared-inv   # each: active + 4 "Registered tunnel connection"
```

### 7.5 DNS — point hostnames at the tunnel

`route dns` creates a **proxied CNAME → `<UUID>.cfargotunnel.com`**.
`--overwrite-dns` replaces any existing A/AAAA/CNAME (needed because the old
origin records already exist).

**Contradigital (cert = cd):**
```
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd cname.contradigital.agency
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd contradigital.agency
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd "*.contradigital.agency"
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd cdeadmin.contradigital.agency
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd coolify.contradigital.agency
# also any other explicit‑record subdomains you use: skt, uptime, ...
```
**Inventra (cert = inv):**
```
cloudflared tunnel --origincert /etc/cloudflared/inv/cert.pem route dns --overwrite-dns coolify-inv inventra.site
cloudflared tunnel --origincert /etc/cloudflared/inv/cert.pem route dns --overwrite-dns coolify-inv "*.inventra.site"
cloudflared tunnel --origincert /etc/cloudflared/inv/cert.pem route dns --overwrite-dns coolify-inv admin.inventra.site
```

> **The wildcard gotcha:** `*.contradigital.agency` → tunnel does **NOT**
> override a subdomain that has its **own explicit A/AAAA/CNAME record**.
> Any platform subdomain created with an explicit record (cdeadmin, coolify,
> skt, uptime, whdb.inventra.site, …) must be repointed individually with
> the command above.

`cname.contradigital.agency` is the single most important record — every
tenant custom domain CNAMEs to it, so once it’s tunnel‑backed, all custom
domains are fixed at once.

### 7.6 Verify
Let the host sit **idle 10+ minutes**, then **first‑hit** (cold):
`cdeadmin.contradigital.agency`, a `*.contradigital.agency` tenant,
`oneclickshopp.com`, `admin.inventra.site`, `inventra.site`,
`coolify.contradigital.agency`. Every one must load on the **first** request.
Confirmed working in production.

---

## 8. Adding a new app / subdomain (the CNAME rule)

For every new app/subdomain on this host:

1. **Coolify:** add the domain to the app as usual (creates the Traefik
   `Host()` router). Unchanged from before.
2. **DNS:** create a **CNAME**, NOT an A record:

| Zone | CNAME target | Proxy |
|---|---|---|
| `*.contradigital.agency` | `8e84eaf1-91ec-4269-bb03-5c5403530b10.cfargotunnel.com` | Proxied |
| `*.inventra.site` | `657b61a8-38d0-43fe-8617-fffffe9b94db.cfargotunnel.com` | Proxied |

Easiest (creates the exact proxied CNAME):
```
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd NEW.contradigital.agency
# inventra: --origincert /etc/cloudflared/inv/cert.pem ... coolify-inv NEW.inventra.site
```

Optional shell helper (add to `~/.bashrc`):
```
tunnel-add(){ cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem route dns --overwrite-dns coolify-cd "$1"; }
tunnel-add-inv(){ cloudflared tunnel --origincert /etc/cloudflared/inv/cert.pem route dns --overwrite-dns coolify-inv "$1"; }
```

**Two rules, always:**
- **Never** point a new subdomain at the raw origin IP (`A → 72.61.227.4`).
  Always CNAME → the tunnel.
- Use the correct tunnel per zone (contradigital → `8e84e…`, inventra →
  `657b61a8…`).

A new slug subdomain with **no** DNS record is auto‑covered by the wildcard
— nothing to do. New tenant custom domains are auto‑covered via
`cname.‹BASE_DOMAIN›`.

---

## 9. What must NEVER go through the tunnel — CDN Worker

`cdn.contradigital.agency` is served by the **Cloudflare CDN Worker**
(`cloudflare/cdn-worker`) at Cloudflare’s edge → R2 buckets (KV allowlist
`CLOUDFLARE_KV_CDN_NAMESPACE_ID`). It **never touches the origin** and never
had the 522 problem.

- **Do NOT** run `route dns ... cdn.contradigital.agency`. That would replace
  the Worker‑backed record with a tunnel CNAME → Traefik (no R2 logic) →
  **every tenant’s images break instantly**.
- Leave the `cdn` DNS record and its Worker Route exactly as they are.
- Rule: **Cloudflare Workers = edge, no origin, no tunnel.** Only
  origin/Traefik apps go through the tunnel.

Likewise leave MX / TXT / SPF / DKIM and other non‑HTTP records alone.

---

## 10. Healthcheck, keep‑warm & kernel tuning

- **Dockerfile HEALTHCHECK** (already in repo): `/superadmin/login`,
  start‑period 180 s. Ensures Traefik only routes when Next.js is ready —
  fixes the post‑deploy boot 522. **Inventra must be redeployed on current
  `main`** to gain it (it previously lacked a healthcheck).
- **Coolify:** enable “wait for healthcheck before making available”.
- **TCP keepalive** (persisted): `/etc/sysctl.d/99-keepalive.conf` →
  `tcp_keepalive_time=60`, `tcp_keepalive_intvl=30`,
  `tcp_keepalive_probes=5`; `sysctl --system`.
- **Uptime‑Kuma:** 30 s HTTP monitors per public hostname (warm path +
  alerting). Redundant with the tunnel but useful for monitoring.

---

## 11. Performance / caching hardening (in‑code, all tenants)

Shipped in the codebase (single deploy → every tenant):

- **`next.config.ts`:** `images.formats = ["image/avif","image/webp"]`
  (AVIF first — smaller, mobile LCP).
- **Fonts (`(site)/layout.tsx`):** Hind Siliguri `display: "swap"` (was
  `"block"` — FOIT was ~1.4 s of render‑block; `adjustFontFallback` keeps
  CLS 0).
- **Cross‑request data cache** (`unstable_cache`, tenant‑id‑keyed, tagged):
  landing pages (`landing-pages`), product detail + related/other
  (`t<id>:products`, 60 s), static pages terms/privacy/refund/
  contact/about (shared cached `getSetting`, `t<id>:settings`). This removes
  the per‑visit Neon cold‑start on every public page.
- **Lazy Swiper:** testimonials carousel `dynamic(..., { ssr:false })` —
  off the initial bundle.
- **Security fixes:** custom‑domain claim always verifies ownership (no
  `skipDnsCheck` coupling) — blocks domain squatting.
- **Page builder removed:** the Puck CMS page-builder feature
  (`/dashboard/page-builder`, `/p/[slug]`, AI Generate Page,
  `@puckeditor/core`) was deleted entirely. AI Site Setup is the
  supported way to generate site content.
- **Analytics:** `trackPurchase` coerces `value`/`num_items` to finite
  numbers — fixes Meta Pixel “currency invalid” when the order total
  serialized as a string.

These are independent of the tunnel/infra work.

---

## 12. Firewall lockdown (optional, deferred)

After the tunnels are proven stable (recommend 24–48 h of no 522 under real
traffic), optionally block public inbound `:80`/`:443` so the origin is
reachable **only** through the tunnels.

- **Benefit:** origin IP not directly exposed; the last idle‑drop path gone.
- **Risk:** the tunnel becomes the sole ingress. If both `cloudflared`
  services are down, all sites are unreachable until systemd restarts them
  (`Restart=always` mitigates this). Anything reaching the box directly on
  :80/:443 (not via tunnel) is cut off.
- **Recommendation:** leave the firewall **as‑is** until stability is
  proven. Do not lock down preemptively — the tunnel already solved the
  problem and lockdown only adds a single‑point dependency.

(Not applied in production as of this runbook — intentionally deferred.)

---

## 13. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| 522 on first visit, works on refresh, all sites | Idle CF↔origin socket dropped | Cloudflare Tunnel (§7). Verify with §7.6 idle test. |
| 522 only right after a deploy | App routed mid‑boot (no healthcheck) | Ensure Dockerfile HEALTHCHECK + Coolify “wait for healthcheck”; redeploy. |
| One subdomain still 522s after tunnel | It has its own explicit A/AAAA record (wildcard doesn’t override) | `cloudflared tunnel --origincert … route dns --overwrite-dns <tunnel> THAT.host` |
| All tenant images 404/broken | `cdn.*` record was repointed to the tunnel | Restore the CDN Worker Route / proxied record; **never** tunnel `cdn.*` (§9). |
| Custom domain (tenant) 522 | `cname.<BASE_DOMAIN>` not tunnel‑backed | `route dns --overwrite-dns coolify-cd cname.contradigital.agency`. |
| Realtime/WebSocket dead | Soketi key mismatch | Client `NEXT_PUBLIC_SOKETI_KEY` (build‑baked) must equal Soketi `SOKETI_DEFAULT_APP_KEY`; rebuild app if rotated. |
| App won’t start | `CONTROL_DATABASE_URL` / `SUPER_ADMIN_JWT_SECRET` missing | Set runtime env (fail‑closed by design). |
| Tunnel down | `cloudflared` service stopped | `systemctl status/restart cloudflared-cd|cloudflared-inv`; check `journalctl -u`. |
| `ingress validate` errors “flag not defined: -config” | Flag order | `cloudflared tunnel --config FILE ingress validate` (flag before subcommand). |
| `route dns` “record already exists” | Existing origin record | Add `--overwrite-dns`. |
| `cloudflared login` cert not where expected | `login` ignores `--origincert` | It always writes `/root/.cloudflared/cert.pem`; `mv` it into the account dir before the next login. |

### Quick health snapshot
```
systemctl is-active cloudflared-cd cloudflared-inv
cloudflared tunnel --origincert /etc/cloudflared/cd/cert.pem list
docker ps --format '{{.Names}} {{.Status}}'        # apps should be (healthy)
curl -sI https://cdeadmin.contradigital.agency/superadmin/login
```

---

*Runbook reflects the production configuration as deployed. Tunnel = the
permanent fix for the multi‑tenant cold‑start / 522 issue.*
