/**
 * Browser-side instrumentation entry point.
 * Loaded automatically by Next.js 15+ on every client page.
 *
 * Reports JS errors / unhandled promise rejections from customer browsers
 * to GlitchTip. DSNs are designed to be public — exposing it via the
 * NEXT_PUBLIC_ env var is the standard pattern.
 */
import * as Sentry from "@sentry/nextjs";

const dsn = process.env.NEXT_PUBLIC_SENTRY_DSN || "";

if (dsn) {
  Sentry.init({
    dsn,
    tracesSampleRate: 0,
    // 10% of normal sessions + 100% of sessions with errors are captured for
    // replay. Set to 0 if your GlitchTip instance doesn't have replay enabled
    // (it ignores them but wastes bandwidth).
    replaysSessionSampleRate: 0,
    replaysOnErrorSampleRate: 0,
    environment: process.env.NEXT_PUBLIC_NODE_ENV || "production",
    release: process.env.NEXT_PUBLIC_SENTRY_RELEASE,
    ignoreErrors: [
      // Browser extension chatter
      "ResizeObserver loop limit exceeded",
      "ResizeObserver loop completed with undelivered notifications",
      "Non-Error promise rejection captured",
      // Network blips on shaky mobile
      "NetworkError when attempting to fetch resource",
      "Failed to fetch",
      "Load failed",
      // Safari quirks
      "AbortError: The operation was aborted",
    ],
  });
}

// Captures navigations on the app router so transaction names are meaningful.
export const onRouterTransitionStart = Sentry.captureRouterTransitionStart;
