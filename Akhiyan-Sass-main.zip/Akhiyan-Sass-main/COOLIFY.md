# Deploying CD Ecom on Coolify

This guide is the one-time setup. After the initial deploy, every code push triggers Coolify to rebuild the image, which **automatically runs migrations** via the entrypoint. You do not need `deploy.sh` on Coolify — that script is for bare-metal / PM2-style hosting.

---

## What the Dockerfile does

The repo ships a production-grade [`Dockerfile`](Dockerfile) with three stages:

1. **`deps`** — installs all packages (dev included for build tooling)
2. **`builder`** — runs `prisma generate` for both schemas + `next build` (standalone output)
3. **`runner`** — minimal Alpine + Node + only what's needed at runtime

At container start, [`docker-entrypoint.sh`](docker-entrypoint.sh) runs:

```
1. prisma migrate deploy --schema prisma/control/schema.prisma   # control DB
2. tsx scripts/migrate-all-tenants.ts                            # every tenant DB
3. node server.js                                                # Next.js
```

Both migration steps are idempotent — safe to run on every container restart. If migrations fail, the container exits and Coolify restarts it (you'll see the error in logs).

---

## Step-by-step Coolify setup

### 1. Create the app

In Coolify → **+ New Resource** → **Public Repository** (or Private + add deploy key):

```
Source:     your-git-repo-url
Branch:     main
Build pack: Dockerfile        ← Coolify auto-detects from the repo
```

### 2. Add the environment variables

Coolify → app → **Environment Variables**. Paste these in:

```ini
# === Control plane (Neon) ===
CONTROL_DATABASE_URL=postgresql://USER:PASS@HOST/DB?sslmode=require
CONTROL_DIRECT_URL=postgresql://USER:PASS@HOST/DB?sslmode=require

# === Multi-tenant routing ===
BASE_DOMAIN=contradigital.agency

# === Session signing — KEEP STABLE (rotating logs everyone out) ===
NEXTAUTH_SECRET=replace_with_32+_random_bytes_hex
SUPER_ADMIN_JWT_SECRET=replace_with_DIFFERENT_32+_random_bytes_hex

# === Neon (for provisioning new tenants) ===
NEON_API_KEY=napi_xxx
NEON_ORG_ID=org-xxx

# === Cloudflare R2 (storage) ===
CLOUDFLARE_API_TOKEN=cfut_xxx
R2_ACCOUNT_ID=9c2d40914a2ef1ab8bd5a6382b629b5e
R2_ACCESS_KEY_ID=xxx
R2_SECRET_ACCESS_KEY=xxx
CLOUDFLARE_KV_CDN_NAMESPACE_ID=ef9c47610fb745e3915ee6e6f18de950
CDN_BASE_URL=https://cdn.contradigital.agency

# === Custom-domain feature ===
APP_PUBLIC_IP=<your-coolify-server-public-IP>   # for apex-domain A-record verification

# === Branding ===
PLATFORM_NAME=CD Ecom

# === Error tracking (optional) ===
GLITCHTIP_DSN=https://xxx@glitchtip.shoutify.me/PROJECT_ID
NEXT_PUBLIC_SENTRY_DSN=https://xxx@glitchtip.shoutify.me/PROJECT_ID

# === SMTP (used by control-plane mailer + tenant emails fallback) ===
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=you@yourdomain.com
SMTP_PASS=app-password
SMTP_FROM=you@yourdomain.com
ADMIN_EMAIL=admin@contradigital.agency
```

Mark anything containing a secret as **Build Variable: No, Runtime: Yes** so it isn't baked into the image — only injected at container start.

### 3. Configure the network

Coolify → app → **Network**:

```
Port exposed to host: 3000
```

(matches `EXPOSE 3000` in the Dockerfile).

### 4. Configure the domain(s)

Coolify → app → **Domains**. Add ALL of these:

```
https://contradigital.agency
https://cdeadmin.contradigital.agency
https://*.contradigital.agency
```

The wildcard makes every tenant subdomain (`acme.contradigital.agency`, `beta.contradigital.agency`, etc.) route to this app without per-tenant Coolify entries.

Then in **Cloudflare** (or your DNS provider):

| Type | Name | Value | Proxy |
|---|---|---|---|
| A | `@` | `<your-coolify-server-IP>` | ✓ proxied |
| A | `cdeadmin` | `<your-coolify-server-IP>` | ✓ proxied |
| A | `*` | `<your-coolify-server-IP>` | ✓ proxied |
| CNAME | `cname` | `contradigital.agency` | ✗ DNS-only (this is what tenants point their own domains AT) |
| CNAME | `cdn` | `contra-digital-cdn.tooolstack.workers.dev` | ✓ proxied (existing) |

### 5. Health check

Coolify auto-detects the `HEALTHCHECK` directive in the Dockerfile. If you want to override:

```
Path:    /superadmin/login
Port:    3000
Interval: 30s
Timeout:  10s
```

### 6. Deploy

Click **Deploy**. Watch the logs:

```
▶ [entrypoint] Control DB migrations…
No pending migrations to apply.
▶ [entrypoint] Tenant DB migrations (parallel, advisory-locked)…
  ✓ test: up-to-date (1 already applied)
▶ [entrypoint] Starting Next.js…
✓ Ready in 1.2s
```

If you see "Failed to fetch DATABASE_URL" or similar, double-check env vars.

---

## Logging in as superadmin

After the deploy is green, **two ways in**:

| Method | URL | Notes |
|---|---|---|
| **Path** (works immediately) | `https://contradigital.agency/superadmin/login` | Works before `cdeadmin.*` DNS propagates |
| **Subdomain** (preferred) | `https://cdeadmin.contradigital.agency/` | Cleaner — host-based routing rewrites to `/superadmin/` |

**Current credentials** (we just reset them):

```
Email:    admin@contradigital.agency
Password: DmAtn2aWx4W
```

**Change the password immediately after first login** if anyone else has seen it — there's no audit trail on the change itself, but every superadmin action IS audited.

---

## Resetting the superadmin password later

If you lose access (e.g. forget the new password), in Coolify open the app's **Terminal** tab and run:

```bash
NEW_PASSWORD='your-new-secret' npx tsx scripts/reset-superadmin-password.ts admin@contradigital.agency
```

Optional — also rotate the email:

```bash
NEW_EMAIL=newowner@contradigital.agency \
NEW_PASSWORD='your-new-secret' \
  npx tsx scripts/reset-superadmin-password.ts admin@contradigital.agency
```

Existing browser sessions stay valid until the JWT expires; new logins use the new credentials.

---

## What happens on each future deploy

1. You `git push` → Coolify webhook fires.
2. Coolify rebuilds the Docker image (~3–5 min).
3. New container starts → entrypoint runs migrations (no-op if nothing changed) → server starts.
4. Healthcheck passes → Coolify swaps traffic from old container to new.
5. Old container is killed.

**Zero downtime** (Coolify handles rolling deploys) and **migrations always run before the new code serves traffic**.

---

## Common issues

| Symptom | Cause | Fix |
|---|---|---|
| Container restarts in a loop | Migration failure (check logs) | Run `npx prisma migrate status --schema prisma/control/schema.prisma` against the live DB to diagnose |
| `500` on every page | Missing required env var (usually `CONTROL_DATABASE_URL` or `NEXTAUTH_SECRET`) | Check Coolify env tab; redeploy after fixing |
| Login works at `/superadmin/login` but not `cdeadmin.contradigital.agency` | DNS not propagated yet, OR `cdeadmin.*` not in Coolify's Domains list | Wait 5 min for DNS; add domain to Coolify |
| New tenants hit "no tenant resolved" | Wildcard `*.contradigital.agency` not in Coolify domains, or DNS wildcard not set | Add both |
| Healthcheck fails but logs look fine | Cold start > 90s (heavy first build) | Bump `--start-period` in Dockerfile's HEALTHCHECK directive |

---

## What's NOT done by Docker (still manual / DNS-side)

- **Cloudflare CDN Worker** at `cdn.contradigital.agency` — deployed separately via `wrangler deploy` from `cloudflare/cdn-worker/`. Already done if images work.
- **Per-tenant DNS** for custom domains — tenants do this themselves through the new in-dashboard Custom Domain page.
- **SSL certificates** for `*.contradigital.agency` — handled by Cloudflare's universal SSL (proxied records). For custom tenant domains pointed at Coolify via CNAME, Coolify auto-provisions Let's Encrypt certs (enabled by default).
- **Backup of the control DB** — enable Neon's point-in-time recovery in the Neon dashboard. Recommended retention: 7 days minimum.

---

## Related docs

- [DEPLOY.md](DEPLOY.md) — bare-metal / PM2 deployment workflow (the alternative to Coolify; use one or the other)
- [MIGRATIONS.md](MIGRATIONS.md) — schema-change workflow (read before editing `prisma/schema.prisma`)
- [MONITORING.md](MONITORING.md) — GlitchTip + Uptime Kuma + Soketi wiring
