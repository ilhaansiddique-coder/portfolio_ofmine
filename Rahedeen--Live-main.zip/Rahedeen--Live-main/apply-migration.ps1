# PowerShell script to apply migration via Supabase Management API
$projectRef = "smopyfuaijaklmtpwgws"
$accessToken = "sbp_41ee67fd75124cfe839149ca9045b0e1be9883ff"

# Read the canonical SQL migration file
$sql = Get-Content -Path "supabase\migrations\20260329_add_mock_data_config.sql" -Raw

# Use Supabase Management API to execute SQL
$uri = "https://api.supabase.com/v1/projects/$projectRef/database/query"
$headers = @{
    "Authorization" = "Bearer $accessToken"
    "Content-Type" = "application/json"
}
$body = @{
    "query" = $sql
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -Body $body
    Write-Host "✓ Migration applied successfully!" -ForegroundColor Green
    Write-Host $response
} catch {
    Write-Host "✗ Failed to apply migration:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    if ($_.Exception.Response) {
        Write-Host "Response: $($_.Exception.Response)"
    }
}
