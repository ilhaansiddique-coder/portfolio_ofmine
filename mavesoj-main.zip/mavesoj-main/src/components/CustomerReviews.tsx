"use client";

import { FiStar } from "react-icons/fi";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import MotionFadeIn from "./MotionFadeIn";
import { useLang } from "@/lib/LanguageContext";

interface Review {
  id: number;
  customer_name: string;
  rating: number;
  review: string;
  product_name?: string;
}

const avatarColors = [
  "bg-primary", "bg-amber-600", "bg-emerald-600", "bg-blue-600",
  "bg-purple-600", "bg-rose-600", "bg-teal-600", "bg-indigo-600",
];

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return parts[0][0] + parts[1][0];
  return name.slice(0, 2);
}

const fallbackReviews: Review[] = [
  { id: 1, customer_name: "মোঃ বেলাল শেখ", review: "খুবই ভালো মানের পণ্য পেয়েছি। একদম খাঁটি। ডেলিভারিও খুব দ্রুত হয়েছে।", rating: 5 },
  { id: 2, customer_name: "মোঃ মিলন মাহমুদ", review: "একদম ফ্রেশ এবং ভালো মানের পণ্য। প্যাকেজিংও অনেক সুন্দর ছিল।", rating: 5 },
  { id: 3, customer_name: "শুহেভ আহমেদ", review: "বাজারের চেয়ে অনেক ভালো মান। রিকমেন্ড করছি সবাইকে।", rating: 5 },
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[...Array(5)].map((_, i) => (
        <FiStar
          key={i}
          className={`w-4 h-4 ${i < rating ? "text-amber-400 fill-amber-400" : "text-gray-200"}`}
        />
      ))}
    </div>
  );
}

export default function CustomerReviews({ reviews }: { reviews?: Review[] }) {
  const { t } = useLang();
  const items = reviews && reviews.length > 0 ? reviews : fallbackReviews;

  return (
    <section className="py-12 md:py-16 bg-background-alt">
      <div className="container mx-auto px-4">
        <MotionFadeIn className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground section-heading">
            {t("reviews.title")}
          </h2>
          <p className="text-text-muted mt-4">{t("reviews.subtitle")}</p>
        </MotionFadeIn>

        <MotionFadeIn>
          <Swiper
            modules={[Autoplay, Pagination]}
            spaceBetween={20}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 4000, disableOnInteraction: false }}
            breakpoints={{
              640: { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
            className="pb-14"
          >
            {items.map((review, idx) => (
              <SwiperSlide key={review.id}>
                <div className="bg-white rounded-2xl p-6 border border-border shadow-sm h-full">
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className={`w-12 h-12 rounded-full ${avatarColors[idx % avatarColors.length]} flex items-center justify-center text-white font-bold text-sm shrink-0`}
                    >
                      {getInitials(review.customer_name)}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-semibold text-foreground text-sm truncate">
                        {review.customer_name}
                      </h4>
                      <StarRating rating={review.rating} />
                    </div>
                  </div>
                  <p className="text-text-body text-sm leading-relaxed line-clamp-3">
                    {review.review}
                  </p>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </MotionFadeIn>
      </div>
    </section>
  );
}
